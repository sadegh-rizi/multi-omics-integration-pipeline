# Outlier removal — what was done and why

Reference summary for the methods section and for discussion with the vendor.
Numbers are from the current pipeline state (post whole-mouse exclusion).

There are **three separate things** here that get conflated if described
loosely: one animal removed, a screen for further samples that found nothing,
and a value-level detection-limit filter. Plus one filter that was tested and
rejected.

---

## 1. One mouse removed — samples 25, 26, 27

**What:** Mouse `C00431239 - 3`, contributing sample 25 (Cortex), 26
(Cerebellum), 27 (Hippocampus). Removed from every analysis unconditionally.

**Why — two independent lines of evidence converged on this animal:**

- The **vendor** excluded sample 26 (Cerebellum) from their own figures,
  labelled "excludes outlier". Their criterion is not documented anywhere in
  the deck — this is an open question for them.
- Our **MAD-based per-lipid leverage screen**, run independently and without
  reference to their choice, flagged sample 25 (Cortex) as the single
  strongest outlier in the dataset: the most extreme point in 11 of 987 Cortex
  lipids, a rate chance alone produces with p = 0.0001.

Two different tissues from one animal, flagged by two different methods, is an
animal-level signal rather than a per-sample one.

**Sample 27 (Hippocampus) was never independently flagged.** It is removed for
consistency of the experimental unit — the mouse — not because it failed QC.
State it that way in the methods; it is a design choice, not a QC finding.

**Consequences, verified not assumed:**

- 60 → **57 samples**. Every mouse contributes all 3 regions, so this costs
  exactly one sample per region.
- Per-region cells go from 5/5/5/5 to **MIA-Male 4**, MIA-Female 5,
  Control-Male 5, Control-Female 5. Design is now slightly unbalanced in the
  MIA-male cell, which weakens the interaction term more than the main effects.
- **11 feature-region fits** fell below the pre-specified `min_per_cell = 3`
  rule. Every one had been sitting at exactly 3 usable MIA-male observations
  and dropped to 2. The threshold was **not** revised — changing an analysis
  rule after seeing which features it excludes is a forking-path move, and
  11 of ~2,867 fits (0.38%) cannot change a conclusion. Two of the 11 involve
  Feature 791 `Hex2Cer(d20:1_15:0)`, already flagged as a trace artifact.

---

## 2. Screen for further sample outliers — nothing found

**What:** Per-region multivariate outlier screen on the autoscaled matrix
after the mouse was already removed (n = 19 per region).

- **Hotelling's T²** — as run, 10 PCs (the plan specified 3).
  **No sample exceeded the 95% limit in any region.**
- **Robust Mahalanobis distance**, MCD-based, 3 PCs, χ² 99% cutoff. Flagged
  Cortex 13/16/19/22/37/49, Cerebellum 14/17/20/35/56/59, Hippocampus
  6/9/15/33/42/48/51 — that is 6, 6 and 7 of 19.

**Why those flags were rejected.** 6/19 is ~32% flagged by a threshold
labelled 99% — 32× its nominal rate. Simulating the identical configuration
(n = 19, p = 3, MCD h = 11, χ² 99%) on **clean multivariate normal data
containing zero outliers**, 400 replicates:

| | flags per region |
|---|---|
| Nominal | 0.19 |
| **Simulated median on clean data** | **6** |
| Clean datasets flagging ≥ 5 | 82.8% |
| Clean datasets flagging ≥ 6 | 60.0% |
| Observed | 6, 6, 7 |

The observed counts *are* the null expectation for this procedure at this
sample size. Mechanism: MCD estimates the covariance from only the 11 most
concentrated points, so the 8 excluded points get inflated distances by
construction, and the χ² cutoff assumes a *known* covariance — badly violated
when it came from 11 observations. Properly calibrated small-sample cutoffs
exist (Hardin & Rocke's F-approximation); the plain χ² quantile is not one.

**The apparent mouse cluster is also chance.** Mouse `C00462971 - 1` was
flagged in all three regions, superficially resembling how
`C00431239 - 3` was found. But at these flag rates the expected number of mice
hitting all three is 0.70, and exactly 1 was observed. The genuine outlier
mouse was flagged by two *independent* methods, one at p = 0.0001, and had a
mechanism. This one has neither.

**Decision:** `SAMPLE_OUTLIER_EXCLUSIONS = ()`. No additional samples removed.

---

## 3. Value-level detection-limit filter

**What was found.** 13 lipids where a subset of samples report raw peak areas
around 10⁻⁶–10⁻⁷ while the rest of the *same lipid* sit in the hundreds.
Clearest case: `Hex1Cer(d18:1_14:0)` in Cortex — 8 of 20 samples at ~1–2×10⁻⁷,
the other 12 at 200–900. A 5.8-billion-fold gap, uncorrelated with BioGroup,
Sex, run order or tissue mass.

**Interpretation:** almost certainly **gap-filled non-detects** — the
processing software forcing an integration at the expected retention time
where no peak was found, producing a meaningless sliver of area instead of an
honest missing value. **This is an inference, not a confirmed fact** — it is
Tier-1 question 1 for the vendor.

**Rule applied.** A value is below detection if it falls under
`max(3 × mean_blank_for_that_lipid, 1.0)`:

- **Blank component** — mean across the six blank injections
  (`PreRunBlank_1-5+.raw`, `PostRunBlank+.raw`), missing/zero treated as zero
  signal. The 3× multiplier is conventional; Schiffman et al. (2019,
  *BMC Bioinformatics* 20:334) describe 2–5 as the usual range.
- **Absolute floor of 1.0** — necessary because for 8 of the 13 artifact
  lipids the blank is exactly **zero**, so no blank-derived threshold exists.
  Justified by the observed magnitude gap: across all measurements the 5th
  percentile is ~1.5×10³ and the median ~4.4×10⁴, while only 1.1% of values
  fall below 1.0. The floor sits inside a genuinely empty band.

**Result (current, 57 samples):** **880 values excluded** — 738 blank-derived,
142 absolute-floor — across **96 lipids**, roughly evenly spread by region
(Cortex 301, Cerebellum 292, Hippocampus 287). Five lipids lose all values and
drop out entirely.

Excluded values become `NaN`. **Nothing is imputed** — consistent with the
project's exclude-don't-impute rule, and the opposite of MetaboAnalyst's
default of replacing missing values with a fraction of the minimum, which
would manufacture more fake near-zero values here.

Runs after `exclude_nonpositive` and before `log2_transform` in both
preprocessing pipelines, and on the Tech-Mix QC intensities too.

---

## 4. Technical-variance filter — tested and rejected

Not part of the pipeline, but tested as an exclusion condition because 71% of
Cortex and 69% of Hippocampus lipids have technical variance ≥ 50% of
biological variance (Tech-Mix replicates; Cerebellum 19%).

Removing technical-dominated lipids:

| Region | features before → after | PLS-DA permutation p before → after |
|---|---|---|
| Cortex | 897 → 205 (−77%) | 0.371 → **0.860** |
| Hippocampus | 898 → 263 (−71%) | 0.101 → 0.112 |
| Cerebellum | 901 → 749 (−17%) | 0.629 → 0.621 |

**No region improved; Cortex got substantially worse.** Not adopted. This is
also the direct answer to "would removing noisy lipids help?" — measured, and
no.

---

## One-paragraph version for a slide or abstract

> One animal (mouse `C00431239 - 3`, all three regions) was excluded, on the
> basis of two independent lines of evidence: the measuring laboratory had
> excluded its Cerebellum sample, and our own per-lipid leverage screen
> independently identified its Cortex sample as the strongest outlier in the
> dataset (p = 0.0001). A multivariate screen (Hotelling's T², robust
> Mahalanobis) for further sample outliers among the remaining 57 samples
> identified none — apparent flags at the 99% level were shown by simulation
> to be the expected false-positive rate of MCD-based distances at n = 19, not
> genuine outliers. At the value level, 880 measurements across 96 lipids
> falling below an empirical detection limit
> (`max(3 × blank, 1.0)`, derived from six blank injections) were set to
> missing and not imputed. Filtering out technically-noisy lipids was tested
> and did not improve group separation in any region.
