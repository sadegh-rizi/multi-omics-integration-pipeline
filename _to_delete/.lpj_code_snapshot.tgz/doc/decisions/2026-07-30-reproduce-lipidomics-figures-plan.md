# Plan: reproduce the lipidomics figures from the vendor deck

## Source and scope

`2 MB2_088_Lalowski_Figures 1.pptx` (prepared by Molly Boettiger, CU Anschutz,
likely via MetaboAnalyst — the "Auto-scaled: mean-centered and divided by the
standard deviation" phrasing matches MetaboAnalyst's terminology verbatim).
Lipidomics-relevant plots to reproduce:

- **Heatmap, top 50 lipids**, hierarchically clustered on both axes: 4
  variants — all groups (excludes outlier), Cortex, Cerebellum (excludes
  outlier), Hippocampus.
- **PLS-DA scores plot**: 3 variants — Cortex, Cerebellum (excludes
  outlier), Hippocampus. No all-groups PLS-DA exists in the source deck.

Metabolomics panels in the same deck are out of scope.

## Finding that shapes this plan: the excluded outlier is identifiable, and it converges with an independent finding

Checked which sample the Cerebellum PLS-DA plot's "excludes outlier" refers
to: the lipidomics panel shows 19 of the 20 Cerebellum samples. The missing
one is **MB2_088-26** (MIA, Male, mouse `C00431239 - 3`).

That mouse contributes three samples: `MB2_088-25` (Cortex), `MB2_088-26`
(Cerebellum), `MB2_088-27` (Hippocampus). Sample 25 (Cortex) is the single
strongest outlier found independently in this repo's own leverage analysis
(11 of 987 Cortex lipids have it as their single most extreme point, a rate
chance alone would produce with p=0.0001). Two independent QC approaches —
the vendor's (method undocumented in the deck) and this repo's (MAD-based
per-lipid leverage detection) — flagged two different tissue samples from
the *same* animal. That is a meaningful convergent signal, not a
coincidence, and worth surfacing explicitly in the reproduction rather than
silently matching or ignoring the vendor's exclusion.

Sample 27 (Hippocampus, same mouse) was not a standout in the existing
leverage scan, but that scan's top results weren't exhaustively checked for
it — worth a direct look as part of validation, not assumed clean.

## The core decision: faithful replication, rigor-added version, or both

Recommendation: **both**, produced as a pair for each plot type, not as a
replacement of one by the other.

1. **Faithful-in-spirit replication** — matches the vendor's plot type and
   general method as closely as can be determined, using this repo's own
   preprocessed data. Purpose: a consistency check — does this repo's
   preprocessing pipeline produce a comparable picture to what the vendor
   saw, or does it diverge? This is a diagnostic, not a thesis figure.
   "Faithful" has a real limit: the vendor's exact top-N selection
   criterion and clustering distance/linkage are not stated anywhere in the
   deck, so this tier can only be faithful to the *plot type and general
   method*, not a bit-for-bit match of unknown internal settings.
2. **Rigor-added version** — same plot types, but addressing the two issues
   already flagged from inspecting the original deck: circular top-N
   feature selection for the heatmap, and an unvalidated PLS-DA score plot
   with no permutation test or cross-validated accuracy. This tier is the
   one that would actually be defensible to put in the thesis, and the
   pairing with tier 1 makes the difference visible rather than asserted.

## Heatmap method

- **Scaling**: reuse `preprocess_for_multivariate` (existing, already
  matches the vendor's stated "auto-scaled: mean-centered, divided by SD").
- **Top-N selection (tier 1, faithful)**: rank by nominal (uncorrected)
  p-value from the existing `differential_effects.csv` MIA-vs-Control
  effect, take the top 50 per region/all-groups. This is a documented,
  reusable, defensible proxy for "most different," even though it's
  unlikely to be the vendor's exact criterion.
- **Top-N selection (tier 2, rigor-added)**: same ranking, but the figure
  caption explicitly states "top 50 by nominal p-value, uncorrected for
  multiple testing across ~880 lipids — shown for pattern visibility, not
  as a claim of statistical significance." This directly reuses the
  sub-threshold-interpretation framing already established for this
  analysis (see `doc/methodology.md`), applied to a figure instead of a
  table.
- **Clustering**: Euclidean distance, Ward linkage on both axes (a common,
  reasonable default — not verified against the vendor's actual settings,
  since those aren't recoverable from the file).
- **Outlier handling**: produce both a with-mouse-`C00431239-3` and a
  without version for every region that mouse contributes to (Cortex,
  Cerebellum, Hippocampus), explicitly labeled — mirroring the vendor's own
  with/without transparency, rather than silently picking one.

## PLS-DA method

- **Implementation**: `sklearn.cross_decomposition.PLSRegression` fit on
  one-hot group labels, scores plot from `x_scores_` — scikit-learn has no
  dedicated "PLS-DA" class, this is the standard pattern. Considered R's
  `ropls` (Bioconductor, purpose-built for PLS-DA with built-in permutation
  testing, and R infrastructure already exists in this repo from the limma
  work) as an alternative — leaning Python/manual instead, since permutation
  testing for PLS-DA is straightforward to implement directly and this
  avoids adding a second cross-language round-trip for something that
  doesn't need R's specific statistical machinery the way limma did. This
  is a real judgment call, not a clear-cut one — flagged as an open item.
- **Tier 1 (faithful)**: scores plot only, matching what the deck shows.
- **Tier 2 (rigor-added)**: add a permutation test (shuffle group labels
  ~1000x, refit, compare observed separation — e.g. between-group distance
  or cross-validated classification accuracy — against the permuted null
  distribution) and report the resulting p-value directly on the plot or in
  its caption, plus the cumulative variance explained by the two shown
  components (already visible in the vendor plots as ~29–35% — low, and
  worth carrying into the reproduction as context).
- **Outlier handling**: same with/without-`C00431239-3` pairing as the
  heatmap, for the regions it contributes to.

## Hard dependency: detection-limit preprocessing must land first

`doc/decisions/2026-07-30-trace-level-detection-limit-preprocessing-plan.md`
(not yet implemented) is a blocking prerequisite, and this has now been
verified rather than assumed. Checking directly whether artifact lipids
reach a top-50 list:

- Naive |log2 fold-change| ranking on raw data: **3 artifact lipids in
  Cortex's top 50, 4 in Cerebellum, 4 in Hippocampus** — `SM(t40:0)` and
  `PC(44:8)` appear in all three regions.
- Nominal p-value ranking: 4 artifact lipids in Cerebellum's top 50.

So the vendor's published heatmaps very likely contain several rows whose
apparent group difference is a peak-integration artifact rather than
biology. Running this reproduction first would faithfully reproduce those
artifacts.

Consequence for tier 1: once the detection-limit fix is applied, the
"faithful" reproduction will likely **not** match the vendor's figures
exactly — specific rows will disappear from the top-50 lists. That
divergence is a finding to report, not a failure to reconcile, and the
validation section below should treat it that way.

Note also that the workbook contains six blank-injection columns
(`PreRunBlank_1-5+.raw`, `PostRunBlank+.raw`) which the detection-limit
plan now uses; 612 of 992 lipids carry non-zero blank signal, so a
contamination filter may additionally remove 11–21 lipids from the
analyzable panel before any top-N selection happens.

## File layout

- `src/reproduce_vendor_figures.py` (flat, matching existing convention):
  `select_top_n_by_nominal_p`, `cluster_heatmap`, `fit_plsda`,
  `permutation_test_plsda`.
- `tests/test_reproduce_vendor_figures.py`: unit tests on small synthetic
  data — selection function returns the right count and ranking, clustering
  runs and returns a consistent ordering, PLS-DA permutation test returns a
  higher p-value on shuffled-label synthetic data with no true group
  structure than on data with an injected group difference.
- Output figures: `results/mia_vs_control/reproduction_heatmap_<region>_<faithful|annotated>[_no_outlier].pdf`
  and `reproduction_plsda_<region>_<faithful|annotated>[_no_outlier].pdf`,
  through `plot_config.save_figure` per the existing convention (PDF +
  presentation PNG + manuscript PNG).
- Notebook: new section in `mia_vs_control.ipynb`, or a dedicated
  `notebooks/reproduce_vendor_figures.ipynb` if it gets long — open item,
  not decided.

## Validation

- Report whether the tier-1 (faithful) reproduction visually resembles the
  vendor's plots at all — if preprocessing diverges enough that even the
  "faithful" tier looks nothing like the original, that's worth knowing and
  investigating before trusting anything downstream.
- For PLS-DA tier 2: report the permutation p-value plainly, including if
  it comes back non-significant — that would directly confirm or complicate
  the "PLS-DA oversells separation" critique from inspecting the original
  deck, and either outcome is worth reporting honestly.
- Check whether sample 27 (Hippocampus, mouse `C00431239-3`) shows any
  leverage/outlier signal under the same criteria already used for 25/26,
  to complete the picture on whether this is a whole-animal issue.

## Open items

1. PLS-DA in Python (scikit-learn + manual permutation) vs R (`ropls`) —
   leaning Python for the reason stated above, genuinely open.
2. Exact heatmap clustering distance/linkage (proposed: Euclidean/Ward) —
   a reasonable default, not verified against anything.
3. Whether the rigor-added tier belongs in the thesis body or an appendix,
   next to or instead of the faithful tier — a presentation decision, not
   a methods one.
4. Notebook placement (new section vs new notebook) — decide once scope is
   confirmed.
