# Plan: the biology that is in the data — regional lipid architecture, sex structure, and a pre-registered MIA composite panel

**Status: PROPOSED 2026-10-05 — implementation NOT authorized.** Sadegh asked
in a Cowork session for a plan covering (A) the P14 regional lipid
architecture, (B) sex structure in cortex, and (C) a pre-registered panel of
5–10 MIA composite scores tested at cage level. Confirm §7 before
implementation, per `/careful-planning`.

Depends on `2026-09-26-known-broken-fixes-plan.md` items 1 and 3 (all-60
population in code, contrast-specific pairing). Outputs go to new trees
`results/mia_vs_control/10_region_biology/`, `11_sex_structure/` and
`12_mia_composites/`. Nothing existing is overwritten. Nothing in `data/` is
touched.

---

## 1. Why this, and what changes the framing

The MIA question at feature level is closed at this sample size
(`doc/context/pipeline-test-evaluation.md`). Two kinds of biology remain:

- **Biology the data clearly holds.** Region is the strongest effect:
  between/within ratio 2.83 on PC1, ~30% of variance, hundreds of lipids per
  contrast. A description of the P14 regional lipidome, interpreted through
  lipid chemistry and myelination, is a guaranteed thesis chapter.
- **One honest last attempt at MIA.** Replace 964 tests with a few
  literature-motivated composites. That cuts the multiplicity burden by two
  orders of magnitude and puts the question on interpretable axes.

**A correction to the request (B).** "Sex structure in cortex" came from an
earlier summary and is not supported by the current numbers (§2). Part B is
therefore planned as a question — *is there sex structure at all, once it is
separated from cage and collection date?* — not as the exploration of a known
effect.

## 2. What was checked during planning (read-only)

No group comparison was computed for this plan.

**Feature inventory** (`results/pipeline_test/prevalence20_noexclusion/03_differential/differential_effects.csv`,
964-feature panel):
- 39 classes. 598 of 962 named species are chain-resolved (`_`); the rest are
  sum composition.
- 218 ether species (`O-`/`P-`). 95 contain 22:6 and 76 contain 20:4.
- Sulfatides appear as `ST(d40:1)`-style names (LipidSearch convention;
  assumption to confirm, §8). Hexosylceramides are `Hex1Cer`/`Hex2Cer`.
- 18 sphingolipids carry a ≥ C24 acyl chain. There are 9 ganglioside classes
  (GM2, GM3, GD1a, GD1b, GD2, GD3, GT1a, GT3, GQ1b) and cardiolipins (CL).
- Existing aggregation (`06_aggregation/`): 78 class means/medians and 160
  structural indices (mean chain length, mean double bonds, PUFA fraction,
  saturated:unsaturated, overall and per class). All null for MIA in every
  variant.

**Sex — the evidence is weak, not strong:**
- Cortex Female vs Male, all 60: 47 features at p<0.05 of 953, min q 0.289.
- Permutation null (`05_diagnostics/permutation_effective_tests.csv`, sex
  permuted within BioGroup): mean 26.9 nominal discoveries, variance 416
  (SD 20.4), so z ≈ +1.0. That is ordinary.
- Cortex PCA (`04_multivariate/pca_score_attribution_cortex.csv`): sex R² is
  at most 0.144 (PC2), and that same PC has cage R² 0.285 and date R² 0.204.
- Published adult atlas: sex effects on the brain lipidome are "generally
  limited" (Nature 2026, §8). At P14, before puberty, a small effect is the
  expectation.

**Sex by cage** (`region_input_metadata.csv`, mouse level):

| Group | Cage | Date | F | M |
|---|---|---|---|---|
| Control | C00429562 | 2024-06-11 | 3 | 3 |
| Control | C00462970 | 2024-10-23 | 2 | 2 |
| MIA | C00431239 | 2024-06-11 | 0 | 3 |
| MIA | C00437351 | 2024-06-11 | 1 | 0 |
| MIA | C00462971 | 2024-09-13 | 3 | 0 |
| MIA | C00462968 | 2024-09-13 | 1 | 0 |
| MIA | C00 | 2024-08-06 | 0 | 1 |
| MIA | C01 | 2024-08-06 | 0 | 1 |

- **The only clean sex contrast is within the two control cages**: 5 F
  vs 5 M, balanced within each cage.
- In MIA, sex is identical to cage, and largely to date: 4 of 5 MIA females
  are from 2024-09-13, and all MIA males are from 06-11 or 08-06.

**Literature (titles/abstracts only — full texts to be read before the
panel is frozen, §7 D5):**
- MIA delays myelination in offspring hippocampus (Makinodan et al. 2008).
- Prenatal immune activation causes long-term brain mitochondrial changes
  (Transl. Psychiatry 2024).
- Omega-3 deficiency worsens the effects of gestational LPS (Brain Behav.
  Immun. 2018).
- Microglial lipid states (J. Neurochem. 2025).
- Myelin lipids are ethanolamine plasmalogen, galactocerebroside and
  sulfatide (CG-4 differentiation study; J. Lipid Res. review).
- Reference lipidomes: Fitzner et al. 2020 (cell-type- and
  region-resolved); Nature 2026 MALDI atlas (adult, lipizones).

## 3. Threats that decide whether any of this means something

1. **Everything is relative.** Per-sample normalisation, with no internal
   standards (A9), makes region differences compositional. *Mitigation:*
   prefer within-sample log ratios and within-class fractions. These are
   invariant to any per-sample scaling, so median vs PQN cannot change them
   (unit test, §6).
2. **Annotation uncertainty.** Sum-composition names, O-/P- ether ambiguity,
   and "ST" assumed to be sulfatide. *Mitigation:* annotation rules are
   explicit, unparseable names stay missing, and every term records how many
   members are species-level vs sum composition.
3. **Correlated lipids break standard enrichment.** Competitive tests that
   treat lipids as independent are anti-conservative. *Mitigation:* every
   category test permutes **samples**, never lipids. Region tests use mouse
   sign-flips; sex tests use within-cage label permutation.
4. **Sex is confounded with cage and date in MIA.** *Mitigation:* the primary
   sex estimate uses the control cages only. MIA is used for a concordance
   check, never pooled naively.
5. **Forking paths in the MIA panel.** Sadegh and the agents have already
   seen feature-level, class-mean and structural-index MIA results, including
   the fragile ChE(22:4) cortex hit. The panel is literature-motivated but
   **not blind**. *Mitigation:*
   - Freeze the definitions and code (commit hash) before any group
     comparison is run.
   - Exclude composites whose motivation came from results seen (cholesteryl
     esters).
   - Report every composite whatever the result.
6. **The cage-level ceiling.** With 2 control vs 6 MIA cages, an exact cage
   permutation has p ≥ 1/28 = 0.036. No multiplicity-corrected cage-level
   permutation test can succeed with more than one hypothesis. *Mitigation:*
   one primary hypothesis (D6); everything else is estimation with intervals.

## 4. Proposed analysis

### 4.1 Shared — lipid annotation terms

New `src/lpj_lipidomics/annotation/lipid_terms.py`. One row per feature:

- category: glycerophospholipid, sphingolipid, glycerolipid, sterol ester,
  fatty acyl, ganglioside;
- class and headgroup;
- total carbons, total double bonds, chain-resolved flag;
- ether flag (O-/P-); sphingoid base (e.g. d18:1);
- VLC flag (sphingolipid acyl ≥ C24);
- PUFA flags (contains 22:6, 20:4, 20:5);
- myelin-marker flag, defined before use (§4.2 A5).

Built from the delivered `Lipid Name` via the existing
`aggregation.parse_lipid_structure`. Unparseable fields stay missing. An
optional second ontology is LION (Molenaar et al. 2019) name matching via
LION/web (D2).

### 4.2 Part A — the P14 regional lipid architecture

**A1 — Region effects per lipid.**
- For each contrast (Cx−Cb, Hp−Cb, Cx−Hp), use within-mouse differences,
  all 20 mice, contrast-specific pairing.
- Model `diff ~ 1 + group_c + sex_c` with centred covariates, so the
  intercept is the average region difference. Region × treatment was 0 at
  q<0.05, so pooling over groups is justified (D1).
- Report estimate, 95% CI and BH q within each contrast.

**A2 — Category-level region effects.** For each annotation term with ≥ 5
member lipids:
- **Self-contained:** the term score is the mean of member lipid
  differences per mouse. Test it with a mouse **sign-flip** permutation
  (2²⁰ ≈ 10⁶ possible; 10,000 draws). This is valid because the null of no
  region difference makes each mouse's difference symmetric.
- **Competitive:** mean member t minus mean non-member t, with the null
  from the same sign-flips. This keeps the inter-lipid correlation.
- BH across terms within each contrast.
- **Report magnitude first.** With region effects this strong, most terms
  will be "significant". The finding is the ranking and size of term
  effects, not the p-values.

**A3 — Structural axes, normalisation-invariant.** Within-class indices per
sample:
- chain length, unsaturation;
- n-3 vs n-6 (22:6 vs 20:4 share within PE and PC);
- ether fraction of PE and PC;
- VLC fraction of SM, Cer and Hex1Cer.

Region contrasts use the same sign-flip inference. These extend the existing
160 structural indices with region contrasts. The existing indices were only
ever used for MIA.

**A4 — Myelin lipid index (pre-declared marker set).**
- log ratio of {Hex1Cer, ST (sulfatide), ether PE, ≥ C24 SM/Cer/Hex1Cer} to
  all other glycerophospholipids, per sample.
- Pre-declared expectation, from the caudal-to-rostral developmental
  myelination literature (to be verified, §8): at P14, cerebellum >
  hippocampus ≥ cortex.
- If the ordering is reversed, check the annotation (especially the ST
  assumption) before interpreting.

**A5 — Cell-type reference projection (exploratory, gated).**
- **Gate:** obtain Fitzner et al. 2020's supplementary tables and check
  three things — ages, isolation method, and name overlap with this panel.
  Proceed only if ≥ 50% of the reference's cell-type-enriched species map to
  this panel at the same annotation level.
- **Method:** define each cell type's enriched lipid set from the reference
  only. Score each sample by the mean region-standardised z of the set.
- **Validation:** the oligodendrocyte score must correlate positively with
  the A4 myelin index. A4 uses a literature definition, so this is a partly
  independent check.
- If the gate fails, A5 is dropped and recorded as not feasible.

**A6 — Comparison with adult references (descriptive).**
- Rank concordance of region-difference directions on the species shared
  with the Nature 2026 atlas and Fitzner 2020.
- Disagreements are candidate developmental (P14 vs adult) differences,
  reported as hypotheses.

**A7 — Metabolomics (secondary).** Same A1–A2 machinery on metabolite
classes, as a second-modality description of regional architecture.

### 4.3 Part B — is there sex structure, separable from cage and date?

**B1 — Primary, clean estimate: controls, within cage.**
- 10 control mice, per region: `value ~ sex + cage`, with cage as a fixed
  effect.
- Inference: exact within-cage sex permutation, C(6,3)·C(4,2) = 120
  assignments, so the empirical p floor is 1/120 ≈ 0.0083.
- **Global question first:** compare the observed count of features at
  p<0.05 with the within-cage permutation distribution (z, as for E5). Only
  if that is clearly in excess are individual features or terms examined.

**B2 — Category level.** The A2 term scores, tested for sex with the same
within-cage permutation. This gives fewer tests and interpretable axes.

**B3 — Does MIA show the same sex signature?** In MIA, sex is a
between-cage contrast. Compare the MIA sex signature (confounded with cage
and date) with the B1 control signature using the existing disattenuated
concordance machinery. Concordance near 1 supports a real sex effect;
concordance near 0 means the MIA "sex" pattern is cage or date.

**B4 — Region specificity.** In controls, model the within-mouse region
differences as `diff ~ sex + cage`. This tests whether the sex signature is
cortex-specific or shared across regions. Pooling regions per mouse (mean
profile) is the most precise version of the global question.

**B5 — Reporting.** If B1 is at the permutation null, report "no detectable
sex structure at P14" with the MDE. The earlier "sex structure in cortex"
statement is withdrawn in `doc/context/` (D4).

### 4.4 Part C — pre-registered MIA composite panel

**Panel (D5 confirms membership).** All composites are within-sample log
ratios or within-class fractions (normalisation-invariant). Each is computed
per sample and standardised within region using all samples (label-blind).

| # | Composite | Definition | Literature motivation | Expected direction in MIA |
|---|---|---|---|---|
| C1 | Myelin lipid index | A4 definition | MIA delays myelination (Makinodan 2008, hippocampus) | lower |
| C2 | n-3 DHA share | 22:6-containing / all species, within PE and PC | maternal inflammation × n-3 status (BBI 2018) | lower |
| C3 | AA:DHA balance | log(20:4-containing / 22:6-containing), PE+PC | pro-inflammatory precursor balance | higher |
| C4 | Ceramide:SM | log(ΣCer / ΣSM) | inflammatory sphingomyelinase activation | higher |
| C5 | Lyso:parent | log((ΣLPC+ΣLPE) / (ΣPC+ΣPE)) | phospholipase A2 activity in inflammation | higher |
| C6 | Ether PE fraction | Σether PE / ΣPE | peroxisomal / oxidative-stress sensitivity of plasmalogens | lower |
| C7 | Cardiolipin | log(ΣCL / Σmajor phospholipids) | long-term mitochondrial change after prenatal immune activation (Transl. Psychiatry 2024) | lower |
| C8 | Ganglioside maturity | log(Σ{GD1a, GD1b, GT1a, GQ1b} / Σ{GM3, GD3, GM2, GD2, GT3}) | developmental shift from simple to complex gangliosides; delay hypothesis | lower |

- **Excluded on purpose:** cholesteryl esters (motivated by ChE(22:4),
  already seen), TG and DG (not brain-membrane hypotheses).
- **Directions are recorded but tests are two-sided.**

**Two-stage execution (the pre-registration mechanism).**
1. **Stage 1, label-blind.** Compute all composites. Compute their
   variance components from `score ~ sex + region + (1|cage) + (1|mouse)`,
   with **no group term**, which is conservative because between-cage
   variance absorbs any group effect. Compute each composite's MDE at the
   cage level. Commit outputs and code; record the hash in
   `12_mia_composites/00_frozen_panel/manifest.json`.
2. **Stage 2, unblinded.** Run the group comparisons from the frozen
   commit only. No composite is added, dropped or redefined after stage 1.

**Inference (D6, D7, D8).**
- **Primary (one hypothesis):** C1 in the pre-declared region (D7).
  - Model: linear mixed model `score ~ group + sex + (1|cage)`.
  - Reported: Satterthwaite p and an exact cage-permutation p (floor
    0.036).
  - Success requires both p < 0.05 and a same-direction estimate in the
    2024-06-11 date-matched subset.
- **Secondary (C2–C8, and C1 in the other regions):** effect in
  within-region SD units with 95% CI, from the same model. p-values are
  shown, BH within the secondary family. No claim is made from a
  secondary composite alone.
- **Sensitivities:** cage-mean t-test (df 6); 2024-06-11 subset
  (descriptive, 3 cages); T²-95/99 populations; PQN arm (should be
  identical by invariance).
- **Reporting rule:** all eight composites are reported, in a pre-declared
  order. A null is reported with its stage-1 MDE.

### 4.5 Out of scope

- Cerebellar co-abundance modules (deferred; separate plan if wanted).
- Maternal-response and behaviour data. These are being requested (A11). If
  they arrive, a continuous-phenotype analysis gets its own plan.
- PQN, which sits in the fixes plan §4.9.

## 5. Files

**New:**
- `src/lpj_lipidomics/annotation/lipid_terms.py`
- `src/lpj_lipidomics/statistics/category_scores.py` (term scores,
  sign-flip and within-cage permutation, composite ratios)
- `src/lpj_lipidomics/runners/run_region_biology.py` (Part A)
- `src/lpj_lipidomics/runners/run_sex_structure.py` (Part B)
- `src/lpj_lipidomics/runners/run_mia_composites.py` (Part C, `--stage 1|2`)
- `tests/test_lipid_terms.py`, `tests/test_category_scores.py`,
  `tests/test_mia_composites.py`
- `results/mia_vs_control/10_region_biology/`, `11_sex_structure/`,
  `12_mia_composites/{00_frozen_panel,01_label_blind,02_unblinded}/`
- this file; `prompts/2026-10-05-biology-in-the-data-plan-v1.md`

**Changed:**
- `doc/open-questions.md`
- `doc/analysis-state.md` (after implementation)
- `doc/context/strategic-direction.md` (withdraw "sex structure in cortex",
  D4)

**Not touched:** `data/`, `.claude/`, existing result trees.

## 6. Validation (pre-declared 2026-10-05)

**Unit tests (synthetic):**
1. **Parser:** `ST(d40:1)` → sphingolipid, sphingoid d40:1, sulfatide flag;
   `PE(O-16:0_22:6)` → ether, contains 22:6; `PC(38:4)` → sum composition,
   chain-resolved False.
2. **Invariance:** adding a constant to every feature of a sample leaves
   every C1–C8 composite and every within-class index unchanged (to 1e-12).
3. **Sign-flip null:** on symmetric null data, term p-values are uniform
   (KS p > 0.01 over 500 synthetic datasets).
4. **Within-cage permutation:** permuted labels never cross cages and
   preserve each cage's sex counts.
5. **Stage-1 blindness:** the stage-1 code path never reads `Bio group`
   (asserted by passing metadata with that column removed).

**Project-data checks:**
6. **Positive control:** the A1 Cx−Cb per-lipid estimates correlate at
   ρ > 0.99 with the existing `09_region_persistence` all-60 profile.
7. **Pre-declared expectation:** the A4 myelin-index region ordering is
   recorded before running and compared after (§4.2 A4).
8. **A5 gate**, as stated, decided before any score is computed.
9. **Frozen panel:** the stage-2 manifest hash equals the stage-1 hash.

## 7. Decisions needed before implementation

**D1 — Region effects model.**
- (a) All 20 mice, `diff ~ 1 + group_c + sex_c`.
- (b) Controls only.
- *Recommendation: (a)*, with (b) as a sensitivity. The interaction is null,
  and (a) doubles n.

**D2 — Ontology.**
- (a) In-house terms only.
- (b) In-house plus LION/web mapping.
- *Recommendation: (b)*, with LION terms reported only where mapping
  succeeds; unmapped lipids are listed.

**D3 — Cell-type projection (A5).**
- (a) Attempt with the feasibility gate.
- (b) Drop.
- *Recommendation: (a).* It gives the myelin story an independent check.

**D4 — Sex framing.**
- (a) Primary = within-cage controls (B1); withdraw "sex structure in
  cortex" from `doc/context/` now.
- (b) Keep it until B1 runs.
- *Recommendation: (a).* The current evidence (z ≈ +1.0) does not support
  the claim.

**D5 — Panel membership.**
- Review C1–C8 with your supervisor. Read the cited full texts and confirm
  each rationale and expected direction.
- Confirm cholesteryl esters stay excluded.
- *Recommendation:* keep all eight unless a rationale fails on reading. Do
  not add composites after seeing stage-1 output.

**D6 — Inference structure.**
- (a) One primary (C1), the rest estimation.
- (b) Eight region-averaged composites, Holm.
- (c) All 24 region × composite tests, BH.
- *Recommendation: (a).* The cage-level floor makes (b) and (c) unable to
  pass a permutation-calibrated threshold.

**D7 — Primary region for C1.**
- (a) Hippocampus (Makinodan 2008).
- (b) Region-averaged.
- (c) Cerebellum (most myelin at P14).
- *Recommendation: (a)*, because it is the only region with a direct MIA
  myelination precedent.

**D8 — Model.**
- (a) LMM with cage random intercept; cage-mean t and exact cage
  permutation as sensitivity and calibration.
- (b) Cage-mean t only.
- *Recommendation: (a).*

**D9 — Branch and order.**
- Branch `task/biology-in-the-data` after the fixes plan items 1 and 3 merge.
- Part A first (no MIA content), then B, then C stage 1, review, C stage 2.
- *Recommendation:* as stated.

## 8. Assumptions and limitations

- `ST` is assumed to be sulfatide (LipidSearch convention, sphingoid
  notation). O- and P- ether lipids are not distinguished, so "ether PE" is
  not the same as "plasmalogen". Both go to the vendor (register A10).
- **Literature rationales come from titles and abstracts read during
  planning.** They must be checked in full text before the panel is frozen
  (D5). "Caudal-to-rostral myelination, cerebellum ahead of cortex at P14" is
  a hypothesis to verify, not an established input.
- Reference lipidomes are adult (Nature 2026) or of ages still to be
  checked (Fitzner 2020). Differences from P14 are expected and are part of
  what A6 describes.
- Every Part C result is bounded by 8 cages, 2 of them control. The
  composite panel reduces multiplicity; it does not add experimental units.
  A positive primary result would be hypothesis-generating.
- Part B rests on 10 control mice in 2 cages. A null at that n is weak
  evidence of absence and is reported with its MDE.
- Region and composite results are relative abundances (A9).
