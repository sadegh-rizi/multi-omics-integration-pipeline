# Project brief: a stability-assessment package for outlier detection in omics

Self-contained handoff. Everything below was measured during the MIA
lipidomics analysis (60 samples, 3 brain regions, ~950 lipids) unless marked
otherwise.

---

## The idea in one sentence

**ClustAssess, but for outlier detection**: instead of running one detector at
one parameter setting and trusting the answer, sweep detectors × parameters ×
data representations, calibrate every score onto a common null-percentile
scale, and report a **per-sample stability profile** rather than a verdict.

## Why this is a gap

| what exists | what it answers |
|---|---|
| **PyOD** (~50 detectors) | "give me detector X's score" |
| **PyOD 2** (arXiv 2412.12154) | "which *single* detector should I use?" — via LLM model selection |
| **Outlier-ensemble literature** (Aggarwal & Sathe; Zhao's review) | "combine several scores into one better score" |
| **SEAOP** (Brief Bioinform 2024, proteomics) | closest work in the omics-QC niche — **read before committing** |
| **ClustAssess** | per-element clustering stability via ECC — the model to imitate |

None of them report **per-element stability across a configuration space**, and
none calibrate to a stated false-positive rate. PyOD 2 is the sharpest foil:
its contribution is choosing one model automatically. For a decision about
excluding a biological sample, *"GPT-4o selected Isolation Forest"* is not a
defensible justification in a methods section. *"Flagged under 94% of 180
configurations, at a calibrated 5% false-positive rate"* is.

**The strongest differentiator is sample size.** ADBench/ODDS benchmarks live
at n in the thousands. Omics QC lives at n = 20–60, and detector defaults are
demonstrably broken there. Nobody has characterised this regime.

## Evidence that single-setting outlier detection fails at small n

Every one of these was measured, and each would have produced a wrong answer
if taken from one configuration:

| finding | consequence |
|---|---|
| MCD robust Mahalanobis at n=19 | median **6 false flags per region** on clean simulated data |
| Hotelling T² with the F-form limit | fires at **1.04%** when labelled 95%; the correct Beta form gives 5.06% |
| k-NN on raw features, p=844, n=20 | score varies **1.3%** across samples — distance concentration makes it degenerate |
| isotropic vs soft-weighted k-NN, 10 PCs | flag-set Jaccard **0.000** in two of three regions — same detector, opposite answers |
| Isolation Forest, planted outlier | rank ranged **1–6 across 40 seeds**; a single fit is not reproducible |
| k-NN at k=15, n=20 | ρ = **0.96** with plain centroid distance — redundant with T², not a second opinion |
| null calibrated on contaminated data | limit inflated **23%** in cortex; two samples that should flag do not |
| PyOD default `contamination=0.1` | flags exactly 6 of 60 samples **by construction**, whatever the data says |

## The metric: ECOS (Element-Centric Outlier Stability)

Deliberately parallel to ClustAssess's ECC — per-element, threshold-free,
averaged over the configuration set.

For sample *i*, across configurations *c*, using calibrated null percentiles
`p_i^(c)`:

- **Elevation** `E_i = median_c(p_i^(c))` — how extreme, typically
- **Dispersion** `D_i = IQR_c(p_i^(c))` — how reproducibly so

**Report the pair, never a scalar.** Interpretation:

| | low dispersion | high dispersion |
|---|---|---|
| **high elevation** | robust outlier | configuration-sensitive |
| **low elevation** | robust inlier | ordinary inlier |

### Why a scalar is impossible

**Inliers have high dispersion.** A typical inlier scored IQR = 0.503, versus
0.007 for the most robust outlier — because an inlier's rank among other
inliers is arbitrary noise. Low dispersion is only meaningful at high
elevation, so the two axes cannot be collapsed.

### Candidates that were tested and lost

- **Top-weighted Kendall τ** (per-element decomposition, mean over
  configuration pairs — the structural ECC analogue). Compressed everything
  into 0.77–0.89 and could not separate a robust outlier (τ = 0.861) from a
  configuration-sensitive one (τ = 0.854). Dominated by agreement among the
  inlier bulk.
- **Rank standard deviation.** Actively misleading: the single most
  configuration-sensitive sample had the **lowest** rank sd (0.058), because
  it held a stable rank while its percentile swung across the threshold.
- **Flag stability** (proportion of configurations flagging). Works, but
  inherits the arbitrary threshold the package exists to escape. Keep it as a
  secondary reporting column only.

### Known limitation — document, don't patch

Dispersion is partly confounded with elevation because percentiles are bounded
(ρ = −0.25 to −0.51). The obvious fix, logit-transforming before taking the
IQR, **makes it worse**: ρ → −0.79, and it assigns the most stable sample in
the dataset the largest dispersion in the table. Keep raw percentiles.

## Architecture

```
detectors/      thin wrappers: PyOD + own implementations, uniform signature
                (values, *, parameter) -> Series[score], score increases with unusualness
calibration/    simulate_null_limits, score_to_percentile,
                verify_false_positive_rate, two-stage trimmed calibration
stability/      ECOS: elevation, dispersion, quadrant classification
report/         long-format table + quadrant plot + calibration diagnostic
```

Two components carry the novelty and neither exists elsewhere:

1. **Simulation calibration to a common percentile scale.** Ensembles usually
   standardise by z-score or rank — scale-free but *not* calibrated, so you
   cannot state a false-positive rate. This is what caught the F-vs-Beta error
   and MCD's 6 false flags.
2. **Two-stage trimmed calibration.** Estimating the null covariance from data
   containing the outliers lets each outlier raise its own threshold. Stage 1
   calibrates on everything, trims what it flags, re-estimates, rescores
   everyone. **Exactly one iteration, pre-specified** — iterating to
   convergence is self-fulfilling. Report both stages; a flag surviving both
   is robust, one appearing only after trimming is calibration-sensitive.

## Starting code

~70% exists in `LPJ_lipidomics/src/`, already reviewed and verified
bit-identical to PyOD for k-NN and LOF (Spearman = 1.0000, max abs
difference 0.0):

- `outlier_detectors.py` — k-NN (isotropic + eigenvalue-weighted), LOF,
  Isolation Forest (seed-averaged), Ledoit-Wolf Mahalanobis, Kernel-PCA
  reconstruction distance
- `outlier_calibration.py` — null simulation, percentile conversion, FPR
  verification, batched calibration per detector
- `outlier_ensemble.py` — stability fractions, percentile combination

Extract these rather than starting over. Two known bugs to fix during
extraction: stability was computed across scopes rather than within them, and
a detector-name mismatch silently dropped LOF from per-region verdicts.

## Validation plan

- Benchmark on **ADBench / ODDS subsampled to n = 20–60**. This does not exist
  in the literature and is a publishable result on its own: characterising how
  standard detectors behave when n is small enough that their defaults break.
- Show ECOS separates planted outliers from configuration artefacts better
  than any single configuration, and better than a combined ensemble score.
- Reproduce a known QC call from real data as an external check. (In the
  lipidomics project this is the vendor's independent exclusion of sample 26
  on metabolomics grounds.)

## Honest risks

- **Novelty is tools-paper level, not new-method level.** ClustAssess is also
  a tools paper; that is fine, but the framing must not overclaim.
- **"How is this not PyOD with a wrapper?"** will be the first review comment.
  One-sentence answer: *PyOD supplies detectors; this supplies calibrated
  stability over a configuration space, at sample sizes where those detectors'
  defaults are known to fail.* If that cannot be demonstrated empirically at
  n = 20, the paper does not stand.
- **Scope.** This is a separate deliverable from the MIA thesis. Do it as an
  extraction and a spin-off, not a parallel project.

## Open questions

1. Which detectors form the default configuration space? Parameter-free ones
   (ECOD, COPOD) are interesting precisely because they add a fixed reference
   point with nothing to sweep.
2. Should the representation axis (number of PCs) be swept, or fixed per
   dataset? It changed the answer more than any other axis here.
3. Is there a defensible way to weight configurations, or must they be
   equally weighted? Equal weighting is currently assumed and unjustified.
4. Does ECOS need a null distribution of its own — i.e. what dispersion would
   a clean dataset produce?
