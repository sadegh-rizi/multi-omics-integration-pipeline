# Plan: integrating lipidomics, metabolomics and proteomics, with MIA tested three ways

**Status: CONFIRMED 2026-10-11** (decisions below; D8 amended to all 60 only).

Sadegh asked in a Cowork session for a plan covering three integration
options. He also asked that it use existing packages rather than
re-implementing methods. Confirm §7 before implementation, per
`/careful-planning`.

- Outputs would go to a new tree, `results/mia_vs_control/14_integration/`.
- Nothing existing is overwritten. Nothing in `data/` is modified.

## Confirmed decisions (2026-10-11)

Sadegh accepted every recommendation in §7, with one change to D8.

| # | Decision |
|---|---|
| D1 | Ask the colleague about proteomics run structure and the pre-imputation matrix before running the region-anchored fits (register A12). Input building and the proteomics marker check (§6.1–6.2) may proceed meanwhile. |
| D2 | (c): use the delivered imputed matrix now; the pre-imputation matrix becomes a sensitivity analysis once available. |
| D3 | (a): complete lipid and metabolite features only (842/177). |
| D4 | (a): DIABLO design weight 0.1. |
| D5 | (a): `mofapy2` in the Python venv. |
| D6 | (a): Euclidean distance on model components. |
| D7 | (a): whole-cage permutation primary, mouse-level sensitivity, the three-part rule. |
| **D8** | **All 60 samples only. The T²-95 and T²-99 sensitivity arms are dropped** (amended from the recommendation). |
| D9 | (a): pin an archived `Deriv` (and `doBy` if needed) for R 4.3.3, then install FactoMineR; install mixOmics first. |
| D10 | (a): inputs and controls, then Option 3, Option 1, Option 2. |

Where the text below mentions T²-95/T²-99 arms or `<population>` folders,
D8 overrides it: only `prevalence20_noexclusion` is run.

---

## 1. Why this design

**Origin.** Sadegh proposed integrating the modalities in control mice
only, inferring networks there, and comparing them with MIA. That was
discussed and replaced, for four reasons (Cowork, 2026-10-11):

- **Networks are not identifiable at this n.** The study has 10 control
  mice from 2 litters. In controls, cage and collection date are the same
  split, so it would create a large spurious correlation block.
- **These would not be gene regulatory networks.** The data are
  co-abundance measurements, not regulatory ones.
- **MIA would look rewired even with identical biology.** Edge-level
  control-vs-MIA comparisons are biased by MIA's larger noise.
- **A per-edge test is hopeless.** With 10 vs 10 mice, a control
  correlation of 0.8 must fall to about 0.05 in MIA to reach p < 0.05,
  before correcting over about 12 million edges.

**What is kept.** The intent survives: learn a multi-omics description of
the brain from the data, then ask whether MIA departs from it. The anchor
moves from edges to **brain region**:

- Region is the strongest structure in every modality (about 30% of
  variance).
- It is preserved under MIA: all concordance intervals include 1, and no
  Region × Group interaction was found
  (`09_region_persistence/`, `13_asca/`).

**The three options differ in how MIA enters:**

| Option | Samples used to fit | How MIA is tested |
|---|---|---|
| 1. Unsupervised integration | all 60 | factors learned without labels, then tested against treatment |
| 2. Supervised on region | all 60 | region components learned with MIA inside; MIA's position on them tested |
| 3. Control reference | 30 control samples | model fitted on controls only; MIA samples projected without refitting |

- **Option 3 is the cleanest test.** MIA never influences the model, so
  the test cannot be biased toward similarity.
- **Option 2 is slightly circular** for a "no MIA effect" claim, because
  its axes were partly fitted to MIA samples. It is kept as the descriptive
  view of the joint region programme.
- **Option 1** is the label-free check that treatment does not emerge as a
  factor by itself.

## 2. What was checked during planning (read-only)

**Proteomics files.** `data/proteomics_{Cerebellum,Cortex,Hippocampus}_matrix *_after data imputation ND_prior to ANOVA.txt`
are Perseus exports of FragPipe output.

- **Expression columns:** 20 per region, `MaxLFQ Unique Intensity`, log2,
  range 12.7–26.6. There are no missing values: the data were already
  imputed from a down-shifted normal ("ND").
- **Annotation columns:** `Protein ID`, `Gene`, `Description`, spectral
  counts, probabilities.
- **Proteins:** 4,533 / 4,370 / 4,448 per region; 3,821 shared by all three
  (the set the colleague's explorer uses).
- **Sample numbers match ours exactly:**
  - cerebellum 2, 5, …, 59;
  - cortex 1, 4, …, 58;
  - hippocampus 3, 6, …, 60.

  These are the same numbering as the lipidomics and metabolomics metadata.
- **Region marker proteins present** (positive controls, §6):
  - cerebellum granule cells: Gabra6, Calb1;
  - cortex: Satb2, Tbr1;
  - also Camk2a, Gfap, Mobp.

  Not detected: Pcp2, Zic1, Car8, Prox1, Neurod6.
- **Enzymes relevant to lipid biochemistry present:**
  - sphingolipid synthesis: Cers1/2/6, Sptlc1/2, Degs1, Asah1, Smpd1/3;
  - galactosylceramide and hydroxylation: Fa2h, Ugt8;
  - plasmalogen synthesis: Gnpat, Agps, Far1;
  - other: Elovl5, Pcyt1a/2, Cept1, Fasn, Acsl6, Hmgcr, Dhcr24, Cyp46a1,
    Pla2g6;
  - myelin proteins Mbp, Plp1, Mog, Mag, Cnp.

  Absent: Cers4/5, most Elovls, Sgms1/2, Scd1/2, Gal3st1. These are for a
  later knowledge-constrained analysis; they are out of scope here.

**Packages.**
- Python lock: only scikit-learn.
- R `renv.lock`: R 4.3.3, Bioconductor 3.18, 91 packages. **None of
  mixOmics, MOFA2, FactoMineR, lme4 is installed.**
- A `Deriv` install failure occurred on 2026-10-11 (CRAN version vs
  R 4.3.3). FactoMineR depends on it indirectly: car → pbkrtest → doBy →
  Deriv. That must be resolved, or MFA taken from another package (D9).

Nothing was fitted; no group comparison was computed.

## 3. Threats that decide what any result means

1. **Proteomics regions may be separate runs.** The three matrices were
   produced and imputed separately. If each region was a separate LC-MS
   batch or FragPipe/MaxLFQ run, part of every proteomic region difference
   is technical. The colleague's explorer states this caveat. This matters
   for all three options because all are anchored on region. It needs
   answering from the colleague (new register A12, D1).
2. **Imputed values look like data.** An unknown share of values are
   draws from a down-shifted normal; the export carries no imputation
   flag. Imputed values carry no biology but
   create structure (low-abundance proteins co-vary with the imputation
   pattern). The pre-imputation matrix would allow either masking or
   letting MOFA handle missingness natively (D2).
3. **Cage and date are confounded with treatment.** In MIA, sex is a cage
   property. In controls, cage and date are the same split. Every MIA
   test uses whole-cage permutation as primary, with a mouse-level
   sensitivity (D7). Statistics are made pivotal (t-type, not
   sums of squares), so the calibration failure found in `13_asca/` cannot
   recur.
4. **Integration methods return components on noise.** MOFA, DIABLO and
   MFA all produce factors and loadings whatever the data. Every option
   has a shuffled-data negative control (§6) and a region positive control.
   This is the "does it correctly find nothing?" question in
   `doc/analysis-state.md`.
5. **Shared extraction (register A4).** If one extract fed all three
   assays, sample-level extraction efficiency or tissue mass creates
   cross-modal correlation. Tissue mass is reported against every factor
   and component.
6. **Repeated measures.** Three regions per mouse. Cross-validation folds
   and bootstrap units are mice, never samples.

## 4. Proposed analysis

### 4.0 Shared inputs

**Blocks**, aligned by sample number, one row per sample:
- **Lipidomics:** persistence input, log2, median-normalised,
  prevalence-20. Features complete in all samples: 842 for all 60.
- **Metabolomics:** as above, 177 features.
- **Proteomics:** the 3,821 shared proteins, log2 MaxLFQ as delivered
  (subject to D1/D2).

**Metadata:** mouse, region, group, sex, cage, collection date, tissue mass
(`09_region_persistence/.../region_input_metadata.csv`).

**Population:** all 60 samples only (D8). No proteomics-specific
exclusions.

**Reader.** One small reader for the Perseus text format: pandas, skipping
`#!` rows, keeping `Protein ID` and `Gene`. This is file I/O, not a method,
and it is the only new non-plumbing code. It writes
`00_inputs/blocks/{lipidomics,metabolomics,proteomics}.csv` and
`sample_metadata.csv` with sha256 provenance of the source files.

### 4.1 Option 1: unsupervised integration on all samples (MOFA+)

**Package:** `mofapy2` (Python; D5). One group, three views.
- `scale_views=True`, so the 3,821-protein view does not dominate.
- 15 initial factors, with MOFA's own dropping of factors below 2% variance
  explained.
- 10 random seeds, factors matched across seeds by absolute correlation.
  Only factors recovered in at least 8 of 10 seeds are reported.

**Read-outs:**
- variance explained per factor × view;
- factor associations with region, sex, group, cage, date and tissue mass
  (R² from an ANOVA per factor, `statsmodels`);
- top-weighted features per view.

**Positive control:** at least one stable factor with region R² ≥ 0.5,
active in at least two views. If none exists, stop and investigate.

**Negative control.**
- Shuffle sample labels independently within each view, 20 times. This
  breaks the cross-view links but keeps each view's own structure.
- Refit MOFA each time and record the variance explained by factors active
  in more than one view.
- Observed shared variance must exceed the shuffled maximum before any
  factor is called multi-omic.

**Treatment test, per stable factor.**
- Statistic: the mouse-mean factor score (averaged over the mouse's
  regions), compared between groups with a Welch t.
- Primary: exact whole-cage permutation (28 assignments; floor
  1/28 ≈ 0.036). Sensitivity: mouse-level permutation within sex, 9,999
  shuffles.
- Region-specific versions (each region's score) are descriptive only.
- **Decision rule (fixed now, before results):** a factor is reported as
  "treatment-associated" only if all three of these hold:
  - cage-level p = 1/28;
  - mouse-level p < 0.05;
  - group R² > cage R² for that factor.

  Even then it is called "not separable from cage and date".

**Cross-check:** MFA (block-scaled PCA; `FactoMineR::MFA`, D9) on the same
blocks. Its first components are compared with the stable MOFA factors by
correlation of sample scores.

### 4.2 Option 2: region-supervised integration on all samples (DIABLO)

**Package:** `mixOmics` (Bioconductor 3.18): `block.splsda` with region as
the outcome.
- **Repeated measures:** removed with `mixOmics::withinVariation()` (the
  multilevel decomposition, with mouse as the unit) applied to each block
  before fitting.
- **Design matrix:** off-diagonal weights 0.1, mixOmics' recommended trade-off
  between discrimination and cross-block correlation (D4).
- **Components:** 2, since there are 3 classes.
- **Feature numbers (`keepX`):** tuned over a small pre-declared grid
  (per block: 10, 25, 50, 100 features) with mouse-grouped folds (5 folds
  of 4 mice, 10 repeats).
  - The runner builds the folds and calls `block.splsda` and `predict` on
    each split.
  - `tune.block.splsda` and `perf` are not used for tuning: their internal
    folds split by sample, which would put the same mouse in training and
    test.
  - They are used only for a descriptive comparison.

**Read-outs:**
- grouped-CV region classification error;
- component loadings per block, with selection stability from the CV runs;
- `circosPlot` and `cimDiablo` of the cross-block correlations of selected
  features (descriptive).

**Positive control:** grouped-CV balanced accuracy ≥ 0.9.

**Negative control:** the same pipeline with region labels shuffled within
mouse, 100 times. Accuracy should centre near 1/3, and the observed value
must exceed all 100.

**Treatment test.**
1. For each mouse and each region pair, compute the difference of
   component scores: the mouse's regional contrast on the joint region
   axes.
2. Compare Control with MIA using a Welch t, per contrast × component.
3. Inference as in §4.1: cage primary, mouse sensitivity, same three-part
   rule.

This is the multi-omics form of the persistence question. It is reported
with the caveat in §1 that the axes saw the MIA samples.

### 4.3 Option 3: control reference, MIA projected (primary MIA test)

**Fit on the 30 control samples only:**
- **DIABLO** as in §4.2 (`block.splsda` after `withinVariation`), with
  `keepX` tuned by the same mouse-grouped CV, within controls.
- **MFA** on the control samples, with MIA samples as supplementary
  individuals (`FactoMineR::MFA(..., ind.sup = MIA rows)`). This is the
  unsupervised reference; the package projects supplementary rows natively.

**Reference distribution (controls, out of sample).** For each of the 10
control mice:
1. Refit the model without that mouse.
2. Project its 3 samples (`predict()` for DIABLO; `ind.sup` for MFA).
3. Record each sample's distance to its region's centroid among the 9
   training mice, and whether DIABLO classifies its region correctly.

**MIA, projected through the same 10 models.** Each MIA sample is projected
by all 10 leave-one-out control models, and its distances are averaged.
MIA and control samples are therefore both scored by models fitted on 9
control mice.

**Per-block read-out.** For each block separately, DIABLO block scores and
MFA partial individuals show which modality, if any, places MIA away from
the control reference. Example: a myelin lipid–protein axis.

**Positive control:** control leave-one-mouse-out region accuracy ≥ 0.9.

**Statistic.** Per region and per model, compare the mouse-level
out-of-sample distance between MIA and Control with a Welch t.

**Inference.**
- Whole-cage permutation (28): each assignment refits the 10 leave-one-out
  models with the relabelled "controls". This is affordable, since DIABLO
  and MFA fit in seconds.
- Mouse-level sensitivity: 999 shuffles.
- Same three-part decision rule.
- **The null claim:** "MIA samples sit where the control model expects" is
  stated if MIA distances fall inside the control out-of-sample
  distribution, and the mouse-level test, which overstates evidence, is not
  significant.

### 4.4 Figures (all 60 unless stated)

- **Option 1:** variance-explained heatmap (factor × view), with the
  shuffled-data maximum marked; factor × covariate R² heatmap.
- **Option 2:** DIABLO sample plot (component 1 vs 2, region colour,
  treatment marker); circos plot.
- **Option 3:** out-of-sample distance per region, with control
  leave-one-out and projected MIA shown together; a per-block version.

## 5. Files

**New**
- `src/lpj_lipidomics/io/proteomics.py`: Perseus text reader (I/O only).
- `src/lpj_lipidomics/runners/run_integration_inputs.py`: builds the aligned
  blocks, metadata and provenance (§4.0).
- `src/lpj_lipidomics/runners/run_integration_mofa.py`: Option 1 with
  `mofapy2`; the treatment tests reuse
  `statistics.clustered.cage_group_assignments` and
  `exact_empirical_p_value`.
- `R/integration/run_diablo.R`: Options 2 and 3 (DIABLO) with `mixOmics`;
  the grouped-CV and leave-one-out loops call `block.splsda` and `predict`.
- `R/integration/run_mfa.R`: the Option 1 cross-check and Option 3 MFA with
  `FactoMineR`.
- `src/lpj_lipidomics/runners/run_integration_tests.py`: the shared
  cage-level and mouse-level treatment tests on the exported scores and
  distances, so inference is identical across R and Python fits.
- `tests/test_integration_inputs.py`:
  - sample alignment across blocks (sample number, region, mouse);
  - no raw-data writes;
  - the grouped folds never split a mouse;
  - the permutation sets match §3.3.
- `results/mia_vs_control/14_integration/prevalence20_noexclusion/{00_inputs,01_mofa,02_diablo_region,03_control_reference,04_tests}/`
  with `manifest.json` and `provenance.json`.

**Changed**
- `renv.lock`: adds mixOmics, FactoMineR and their dependencies (D9).
- `requirements.txt` / `requirements-lock.txt`: add mofapy2 and, if needed,
  mudata (D5).

## 6. Validation

1. **Alignment.** Every block has the same 60 sample numbers; mouse, region
   and group agree with the persistence metadata.
2. **Proteomics positive controls.** Gabra6 and Calb1 are higher in
   cerebellum; Satb2 and Tbr1 higher in cortex (paired, within mouse). If
   these fail, the proteomic region axis is suspect (§3.1).
3. **Region positive controls:** §4.1 (a region factor), §4.2 (grouped-CV
   accuracy ≥ 0.9), §4.3 (control leave-one-out accuracy ≥ 0.9).
4. **Negative controls:**
   - cross-view shuffling (MOFA): shared variance collapses;
   - region shuffling within mouse (DIABLO): accuracy about 1/3.
5. **Calibration of the treatment tests.** Gaussian data simulated with the
   real design, with and without a cage random effect, 200 datasets.
   - The mouse-level p-values are uniform: rejection 0.03–0.07 at 0.05.
   - The cage-level p-values are uniform on {1/28, …, 1}.

   This is the check that was skipped in `13_asca/`; here it runs before
   any real result is read.
6. **Stability.** MOFA factors are recovered across 10 seeds; DIABLO
   feature selection frequency is reported across CV repeats.
7. **Technical covariates.** Each factor or component is reported against
   tissue mass and collection date (§3.5).

## 7. Decisions needed before implementation

Recommendations are separate from the options; Sadegh decides.

**D1. Proteomics region comparability** (blocking)
- Ask the colleague whether the three regions were separate LC-MS batches
  or separate FragPipe/MaxLFQ runs.
- *Recommendation:* ask before running. If they were separate, all three
  options still run, but proteomic region effects are labelled
  "may include run differences", and Option 3's per-block read-out becomes
  essential.

**D2. Imputed proteomics values**
- (a) Use as delivered.
- (b) Request the pre-imputation matrix; MOFA then handles missing values
  natively, and the other methods use proteins with no missing values.
- (c) (a) now, (b) as a sensitivity once available.
- *Recommendation:* (c).

**D3. Lipid and metabolite features**
- (a) Complete features only (842/177).
- (b) All features, with NA for MOFA only.
- *Recommendation:* (a), matching ASCA and keeping one feature set for all
  methods.

**D4. DIABLO design weight**
- (a) 0.1.
- (b) 0.5.
- (c) Both, with 0.1 primary.
- *Recommendation:* (a). 0.1 favours discrimination, which suits a region
  positive control; 0.5 is mixOmics' alternative favouring correlation.

**D5. MOFA implementation**
- (a) `mofapy2` in the Python venv.
- (b) `MOFA2` in R with its basilisk-managed Python.
- *Recommendation:* (a). It is one dependency, pinned in
  `requirements-lock.txt`; MOFA2's R plotting is not needed.

**D6. Option 3 distance**
- (a) Euclidean distance on the model's components.
- (b) Mahalanobis distance using the training-control covariance.
- *Recommendation:* (a). With 9 mice per training set, a covariance
  estimate is unstable.

**D7. MIA inference**
- (a) Whole-cage permutation primary, mouse-level sensitivity, the
  three-part rule.
- (b) Mouse-level only.
- *Recommendation:* (a). With pivotal statistics, the cage-level test is
  calibrated (§6.5), and it is the only one that respects the treatment
  unit.

**D8. Populations**
- (a) All 60 primary; T²-95 and T²-99 as sensitivity analyses.
- (b) All 60 only.
- *Recommendation:* (a).

**D9. R dependencies**
- (a) Pin an archived `Deriv` (and `doBy` if needed) compatible with
  R 4.3.3, then install FactoMineR.
- (b) Upgrade the project to R ≥ 4.4 (large change; re-locks everything).
- (c) Take MFA from `ade4` instead (lighter dependencies, but no direct
  supplementary-individual projection).
- *Recommendation:* (a). mixOmics does not depend on `Deriv`, so it can be
  installed first.

**D10. Order of work**
- (a) Inputs and controls first (§4.0, §6.1–6.2), then Option 3, then
  Option 1, then Option 2.
- (b) All at once.
- *Recommendation:* (a). Option 3 is the primary MIA test; Option 2 is
  descriptive.

## 8. Assumptions and limitations

- **The integration has more features, not more samples.** n stays 20 mice
  (8 cages). Nothing here can detect a smaller MIA effect than the
  single-modality analyses could; its value is a joint description of
  regional biology and a better-founded null.
- **Protein abundance is relative and region-normalised by the vendor
  pipeline.** As for lipids, region contrasts describe composition.
- **Proteomics outlier flags are not used.** The colleague's explorer marks
  its own outlier flags. The permitted populations remain the lipidomics
  T² rule.
- **Data use.** The proteomics data belong to the colleague and vendor
  project. Agreement to use them in this thesis is assumed and should be
  confirmed (D1 conversation).
- **Exploratory.** The plan follows null single-modality results. MIA
  claims are pre-declared here so they cannot be shaped by what the
  integration shows.

## References (methods and packages)

- Argelaguet R et al. (2020). *Genome Biol.* 21:111 (MOFA+; `mofapy2`).
- Singh A et al. (2019). *Bioinformatics* 35:3055–3062 (DIABLO).
- Rohart F et al. (2017). *PLoS Comput. Biol.* 13:e1005752 (mixOmics).
- Liquet B et al. (2012). *BMC Bioinformatics* 13:325 (multilevel
  decomposition, `withinVariation`).
- Lê S, Josse J, Husson F (2008). *J. Stat. Softw.* 25(1) (FactoMineR, MFA).
