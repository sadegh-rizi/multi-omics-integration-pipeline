# Plan: parameter-swept multi-detector outlier ensemble

Everything used so far — Hotelling T², DModX, and the rejected MCD-Mahalanobis
— is a variant of the same linear PCA/covariance family. This plan adds
detectors that are different **in kind**, sweeps each across its parameter
range rather than trusting one setting, and combines them into a single
verdict.

The governing principle is the one that unmasked the MCD false-positive
problem: **a flag that appears only at one parameter value is an artefact of
that value. A flag that survives a range of settings and more than one method
is real.**

All simulation numbers below were measured on 2026-08-26 and should reproduce.

---

## Part 0 — Precondition: these methods cannot run on the raw feature matrix

This must be settled before anything else, because it invalidates the obvious
implementation.

Our per-region matrix is ~844 features × 20 samples. In p ≫ n, Euclidean
distances **concentrate**: every point becomes nearly equidistant from every
other, and proximity-based detectors degenerate. Measured on clean
multivariate-normal data, relative contrast `(max−min)/min` of the k-NN
distance:

| n | p | space | rel. contrast | CV of the score |
|---|---|---|---|---|
| 20 | 3 | raw | 2.219 | 0.328 |
| 20 | 10 | raw | 0.711 | 0.144 |
| 20 | 100 | raw | 0.159 | 0.038 |
| 20 | **844** | **raw** | **0.053** | **0.013** |
| 20 | 844 | **3 PCs** | **2.178** | **0.327** |
| 60 | 844 | raw | 0.061 | 0.013 |
| 60 | 844 | **3 PCs** | **2.925** | **0.344** |

At p = 844 the k-NN score varies by 1.3% across samples. There is no signal to
threshold. **k-NN, LOF and Isolation Forest must run on a reduced
representation.**

**This does not collapse the exercise back into the PCA family.** Separate the
two axes explicitly:

- **Representation** — how the sample is described (raw features, or q PCs).
- **Detector** — what notion of "unusual" is applied to that description.

T² is a *global, elliptical, covariance-weighted distance from the centroid*.
k-NN distance on the same PC scores is a *local, isotropic, non-parametric*
measure that estimates no covariance at all. Those remain different in kind
even when they share a representation. Say this in the write-up; a reader will
otherwise assume the reduction smuggled the assumption back in.

**Treat representation as a swept parameter too:** q ∈ {3, 5, 10} PCs, plus a
raw-feature run retained *only* to demonstrate the degeneracy. Report the
relative-contrast diagnostic next to every raw-feature result so nobody reads
a flag off a degenerate configuration.

### Axis-weighting within the PC representation: isotropic vs soft-thresholded

Representation (q PCs) and axis-weighting are a further, orthogonal choice —
the book's hard/soft PCA distinction applies here too, not only to T² and
DModX.

- **Isotropic** — the q retained PC scores, unweighted. This is what every
  k-NN sweep above assumes: a local, non-parametric distance with no notion of
  which axis matters more.
- **Soft-thresholded** — each retained PC score divided by its own
  √eigenvalue before the distance is computed (the same standardization T²
  applies — "soft PCA" in the book's terms). This makes the local distance
  correlation-aware: a deviation along a low-variance PC counts for more,
  which is exactly where dependency-violating outliers hide.

**This does not reopen the covariance-estimation problem that ruled out MCD.**
The per-axis scale is the eigenvalue PCA already produces from the same
decomposition T²/DModX use — there is no new p×p matrix to estimate, and
nothing here is more fragile at n = 20 than T² already is. It is a rescaling
of an existing, already-diagonal estimate, not a new one.

**It does blur the proximity/covariance distinction drawn above, on purpose.**
Soft-thresholded k-NN sits between the two families: local like k-NN,
correlation-aware like T². That is a reason to run both variants side by
side, not a reason to pick one — report both, and treat agreement between
them as evidence a flag isn't an artefact of the axis weighting, the same
logic as every other sweep in this plan.

**Numerical guard.** Only apply this within the existing q ≤ 10 scope — at q
close to the sample rank (n − 1), the smallest retained eigenvalues approach
zero and dividing by their square root is unstable. Assert eigenvalues stay
above a floor (e.g. 1% of the largest retained eigenvalue) before applying
the weighting, and report the assertion rather than letting the score blow up
silently.

---

## Part 1 — Detector inventory and sweep grid

Five detectors, six sweep rows — k-NN runs in two axis-weightings (Part 0).
All run per region (n = 20) and pooled (n = 60), on the full sample set with
the outlier mouse retained, per standing policy.

| #   | Detector                                  | Family                        | Swept parameter     | Per region (n=20) | Pooled (n=60)  |
| --- | ----------------------------------------- | ----------------------------- | ------------------- | ----------------- | -------------- |
| 1a  | **k-NN mean distance (isotropic)**        | proximity                     | k, q ∈ {3,5,10}     | 2–15              | 2–25           |
| 1b  | **k-NN mean distance (soft-thresholded)** | proximity / correlation-aware | k, q ∈ {3,5,10}     | 2–15              | 2–25           |
| 2   | **LOF**                                   | local density                 | k                   | 8–10 (see Part 5) | 10–25          |
| 3   | **Isolation Forest**                      | partition                     | random seed (×50)   | ✓                 | ✓              |
| 4   | **Ledoit–Wolf Mahalanobis**               | shrinkage covariance          | shrinkage intensity | 0 → 1, 9 steps    | 0 → 1, 9 steps |
| 5   | **Kernel-PCA reconstruction distance**    | nonlinear                     | RBF bandwidth γ     | 0.01–1.0          | 0.01–1.0       |

Notes on each:

**1a. k-NN mean distance, isotropic.** Highest priority and the most stable
thing in the whole set. Score = mean distance to the k nearest neighbours on
unweighted PC scores. No covariance, no distributional assumption. Sweep k
around √n as agreed.

**1b. k-NN mean distance, soft-thresholded.** Same statistic, computed on PC
scores divided by their own √eigenvalue first (Part 0). Correlation-aware
without estimating a new covariance matrix — the eigenvalues are already in
hand from the same PCA T²/DModX use. Reported alongside 1a specifically to
check whether flags survive axis-weighting; not a replacement for it.

**2. LOF.** Ratio of a point's local density to its neighbours'. Detects a
point in a sparse pocket even when it is not globally far — genuinely
different from every other detector here. Small-n caveat resolved in Part 5.

**3. Isolation Forest.** Assumption-free, partition-based. **Must be
seed-averaged.** On one fixed dataset with a planted 4-SD outlier, its rank
across 40 seeds ranged 1–6 at n = 20 and 2–4 at n = 60. A single run is not
reproducible. Average the score over ≥ 50 seeds and report the rank range as a
stability diagnostic in its own right.

**4. Ledoit–Wolf Mahalanobis.** This is the one that is *meaningfully*
different from T² rather than a restatement of it. T² uses the sample
covariance of q retained PCs. Ledoit–Wolf shrinks the full-dimensional
covariance toward a scaled identity, which is well-conditioned when p > n
where the sample covariance is singular. Sweeping shrinkage from 0 (sample
covariance, degenerate) to 1 (pure identity, i.e. plain Euclidean) traces the
whole path between "trust the correlations" and "ignore them". Report the
automatically selected LW intensity alongside the sweep — where it lands on
that path is informative.

**Small-n calibration guard.** At the cerebellum raw-feature cell, the
auto-selected intensity was α = 0.3582. Its stage-1 null limit flagged all 20
samples, leaving no covariance sample for the planned trim; the same
low-shrinkage offset was not repaired by trimming. Therefore the reported
sweep excludes α = 0 and retains only the existing grid values α = 0.875 and
1.0, where calibration remains usable. The low auto-selected intensity is
still retained as the explicit ensemble representative, with its
stage-1/contaminated null carried into stage 2 as a named fallback and excluded
from stability counts. This is a calibration limitation, not evidence that
all samples are outliers.

**5. Kernel-PCA reconstruction distance.** See Part 4 for why this
formulation and not one-class SVM. Conceptually it is the nonlinear analogue
of DModX: distance from the fitted manifold rather than from a plane.

---

## Part 2 — Calibration: simulation, never a theoretical cutoff

None of detectors 1–3 and 5 has a closed-form null distribution. Any published
"rule of thumb" cutoff (LOF > 1.5, contamination = 0.1) is a guess about a
different dataset.

**Protocol, applied identically to every (detector, parameter, representation,
n) cell:**

1. Simulate `R` clean matrices of the same shape as the real one, from a
   multivariate normal with a covariance estimated as specified in
   "Two-stage calibration" below.
2. Compute the detector score for all samples in each replicate.
3. Take the 95th and 99th percentiles of the pooled null scores as limits.
4. **Verify the limit fires at 5%** on held-out clean replicates. If it does
   not, the cell is broken — report it as broken rather than shipping it.

This is the same discipline that exposed MCD (median 6 false flags per region
on clean data) and the F-form T² limit (1.04% actual against a nominal 5%).
Apply it here before, not after.

Convert every score to a **null percentile** as the common currency. Raw
scores from different detectors are on incomparable scales and must never be
compared or averaged directly.

### Two-stage calibration — the null must not be contaminated by the outliers

**This corrects the original protocol, which estimated the null covariance
from the full observed matrix.** A genuine outlier inflates that covariance,
widens the null, raises the limit, and makes itself harder to flag. It is the
same self-inclusion failure identified for OC-SVM in Part 4 and for the F-form
T² limit — and the original Part 2 specified it.

**Measured magnitude** (k-NN, pc3; limit from the full covariance versus one
estimated after trimming the highest-scoring samples):

| scope | limit (full) | limit (trimmed) | inflation | flags |
|---|---|---|---|---|
| Pooled, n=60 | 21.15 | 17.52 | 17.2% | 8 → 8 (unchanged) |
| Cerebellum, n=20 | 27.56 | 24.00 | 12.9% | {35,56} → {20,35,56} |
| **Cortex, n=20** | 18.50 | 14.19 | **23.3%** | {22,25} → {16,22,25,37} |
| Hippocampus, n=20 | 18.15 | 16.34 | 10.0% | unchanged |

Pooled is unaffected — its flagged samples clear both limits. **Per region it
changes the answer**, because at n=20 one outlier is 5% of the covariance
estimate against 1.7% at n=60. Cortex gains sample 37, the soft-only
dependency violator, which clears the bar only once the null stops being
inflated by the samples it is meant to screen.

The bias direction is always the same: contamination **suppresses** flags.
Results under the contaminated null understate outlyingness; they do not
invent outliers.

**Protocol:**

1. **Stage 1** — calibrate with the covariance estimated from all samples, as
   now. Score everyone. Record the flag set.
2. **Trim** — remove every sample flagged at 95% in stage 1 from the
   *covariance estimate only*.
3. **Stage 2** — re-estimate the covariance on the remainder, recalibrate, and
   rescore **all** samples, including the trimmed ones.
4. **Stop.** Exactly one trimming iteration, fixed in advance.

Iterating to convergence is self-fulfilling: each trim tightens the null,
which flags more, which trims more. One iteration is the pre-specified rule,
not a judgement made after seeing the result.

**Report both stages, never just stage 2.** Every output carries
`calibration_stage` (`contaminated` / `trimmed`) and the verdict carries
`flag_stage1`, `flag_stage2`, and `calibration_sensitive = flag_stage1 !=
flag_stage2`. A sample flagged in both stages is robust; one flagged only
after trimming is reported as calibration-sensitive and is neither promoted
nor discarded. This is the same sweep-rather-than-choose logic applied to
every other decision in this plan.

**Do not use MCD** as the robust estimator. It is miscalibrated at n ≈ 20
(median 6 false flags per region on clean data) and was rejected for that
reason; reintroducing it here would reimport the problem.

**One check the code cannot perform.** `verify_false_positive_rate` draws its
verification replicates from the same covariance used to build the limit, so
it reports ≈5% and looks healthy under either stage. The FPR column is
structurally incapable of detecting contamination. It validates the
percentile arithmetic, not the null model.

### Replicate count: R = 200, floor of R = 100

The original 2,000 was never justified against anything. Measured stability —
12 independent calibrations per setting, checking whether the **flag set**
changes:

| R | pooled rel SD | flag sets | cortex rel SD | flag sets |
|---|---|---|---|---|
| 25 | 1.52% | 1 | 3.39% | **2** |
| 50 | 1.70% | 1 | 2.40% | **2** |
| **100** | 1.24% | 1 | 1.22% | 1 |
| 200 | 0.72% | 1 | 1.58% | 1 |
| 400 | 0.69% | 1 | 1.24% | 1 |

Pooled is stable from R = 25; its flagged samples sit at 1.03–1.54× the limit.
Per region is **not** stable below R = 100, because cortex's second-ranked
sample sits at 1.04× the limit and a 2–3% wobble flips it. Above R = 100 the
flag set no longer changes.

**Consequence for existing outputs:** the committed run used R = 50, so its
per-region results are inside the noise band and must be treated as
provisional. Its pooled results are sound.

Adopt **R = 200** per stage, with **R = 100** as the validated floor if run
time matters. Nothing above 200 buys anything measurable.

### Run configuration and its measured cost

Isolation Forest dominates everything. Measured marginal cost per null
replicate at **50 seeds × 100 trees** (fixed overhead ≈ 3.8 s amortises; these
do not):

| n | q | ms / replicate |
|---|---|---|
| 20 | 3 | 1,893 |
| 20 | 10 | 4,357 |
| 60 | 3 | 3,930 |
| 60 | 10 | 3,200 – 4,557 |

Against 3.5 ms for the whole k-NN sweep, 2.3 ms for the LOF sweep, 8.1 ms for
Ledoit-Wolf and 22.9 ms per Kernel-PCA γ — **212 ms for every non-IF detector
combined**.

Two things in that table are worth absorbing before choosing settings:

- **Cost barely falls with sample size.** n = 20 is no cheaper than n = 60 at
  q = 10. At these sizes the work is per-forest construction across 50 seeds,
  not tree depth, so the three regional scopes cost about the same as pooled.
- **Cost rises steeply with representation dimension** — roughly 2× from
  pc3 to pc10 at n = 20. Adding pc5 and pc10 to IF roughly triples it.

Repeated timings of the same cell varied by up to 30% under load, so every
projection below is ±30%, not a precise figure.

**Adopted configuration:**

| | replicates | rationale |
|---|---|---|
| k-NN, LOF, Ledoit-Wolf, Kernel-PCA | **R = 200** | the validated setting; costs ~34 min for the whole grid |
| **Isolation Forest** (50 seeds × 100 trees, pc3 + pc5 + pc10) | **R = 50** | the only way to fit IF across three representations in the time budget |

Asymmetric replicate counts are legitimate — every detector's limit is
calibrated independently against its own null, so R need not match across
detectors. It must be recorded per row, which `n_null_replicates` already
does.

**Projected total: ≈ 170 minutes** (IF ≈ 136 min, everything else ≈ 34 min),
two stages included. For reference, IF at R = 100 across three
representations would be ≈ 290 min and at R = 200 ≈ 580 min — the earlier
"180 min at R = 100" estimate was wrong because it extrapolated the n = 20 IF
cost from n = 60 rather than measuring it.

**Open risk that must be checked, not assumed.** R = 50 is the count shown
above to be *insufficient* for per-region k-NN — cortex's flag set changed
between seeds at R = 25 and R = 50. Whether IF is equally sensitive is
**untested**: its score is an average over 50 seeds and therefore smoother
than a single fit, which may make its null more stable at the same R, but no
measurement supports that yet.

So before any per-region IF flag is trusted, run the same check used for
k-NN: repeat the IF calibration with ≥ 8 independent seeds at R = 50 and
confirm the flag set does not change. If it does, either raise IF to R = 100
for the regional scopes only, or restrict IF to pooled — where R = 50 was
already sufficient for every other detector — and report regional IF as
supporting evidence that does not count toward the Part 3 rule.

**Cheaper levers, if the budget tightens.** Cutting trees from 100 to 50 saves
only 23–47%, less than expected, because per-forest overhead rather than tree
building dominates at n ≤ 60. Restricting IF to `pc3` saves roughly two
thirds. **Do not cut the seed count**: the 50-seed average is what protects
against the 1–6 rank swing at n = 20 that motivated including IF at all.

With IF present the Part 6 trinity (Mahalanobis + k-NN + Isolation Forest) is
available as specified, and `candidate_outlier` can be populated once
`ensemble_complete` is true.

### Driver defects to fix before this run

Both found in code review and confirmed against the committed outputs:

1. **Stability is computed across all scopes at once**
   (`run_outlier_ensemble.py:365`). `stability_fraction` never receives
   `scope`; the loop then filters by sample name, and since every regional
   sample also appears in pooled, each scope receives the same blended value.
   Verified: 60/60 samples have an identical `stable_detector_count` in every
   scope they appear in. Group by `["scope", "Sample", "detector"]` and carry
   scope into the verdict join. This is also why `stability_fractions.csv`
   has no scope column.
2. **The per-region verdict silently drops LOF.** Line 265 names the detector
   `lof_supporting` outside pooled; line 379 always looks up `lof`. Verified:
   pooled matches 60 rows, cerebellum matches 0. The column is all-NaN for
   regions and `.mean(axis=1)` skips it, so `five_detector_mean` is quietly a
   four-detector mean per region.

Also: `trinity_max` flags 120/120 because `score_to_percentile` returns
exactly 1.0 whenever a score exceeds every null draw, and a max over
detectors saturates. Drop it or give it enough replicates that ties at 1.0
are rare.

---

## Part 3 — The stability rule, fixed before looking

Write this into the code as an assertion, not applied by eye afterwards.

A sample is reported as a **candidate outlier** only if:

- **(a) Parameter stability** — it exceeds the 95% limit across **≥ 60% of the
  swept parameter range** for that detector, not at isolated settings; and
- **(b) Method corroboration** — condition (a) holds for **≥ 2 of the 6
  sweep rows**, at least one of which is not in the covariance family (i.e.
  not #4, not the existing T²/DModX, and not 1b — soft-thresholded k-NN
  shares axis-weighting logic with the covariance family even though it is
  computed locally, so it does not satisfy the non-covariance requirement on
  its own).

Everything else goes in the table as *unstable* or *single-method*, visible
but not promoted.

**Report the stability fraction as a number**, per sample per detector — the
proportion of swept settings at which the sample was flagged. That single
column is the deliverable. It is what distinguishes sample 25 (expected to
hold everywhere) from the samples that appeared only under MCD.

---

## Part 4 — Resolved: which nonlinear formulation

**Decision: Kernel-PCA reconstruction distance. One-class SVM is rejected.**

This was an open question; the simulation answers it. Planted 4-SD outlier,
detection rate = fraction of bandwidth settings at which the planted sample
ranks first, and limit ratio = stability of the clean-data 95% limit across
the γ sweep:

| n   | formulation                    | limit stability across γ | detection rate  |
| --- | ------------------------------ | ------------------------ | --------------- |
| 20  | **Kernel-PCA recon. distance** | 1.0×                     | **0.90 – 0.93** |
| 20  | One-class SVM                  | unstable                 | **0.02 – 0.08** |
| 60  | **Kernel-PCA recon. distance** | 1.1×                     | **0.83 – 0.85** |
| 60  | One-class SVM                  | unstable                 | 0.00 – 0.02     |

One-class SVM essentially never finds the planted outlier. The reason is
structural, not a tuning failure: OC-SVM fits a boundary to the data it is
given, and the outlier is *in* that data, so it participates in defining the
boundary that is supposed to exclude it. With ν = 0.05 and n = 20, a single
support vector is 5% of the sample. This is the same self-inclusion problem
that made the F-form T² limit wrong, in a more severe form.

Kernel-PCA reconstruction distance does not have this failure mode — the
outlier degrades its own reconstruction — and its limit barely moves across
two orders of magnitude of γ, which is exactly the robustness the MCD lesson
demanded. Still calibrate it by simulation per Part 2.

---

## Part 5 — Resolved: LOF per region or pooled only

**Decision: pooled is primary; per-region runs but restricted to k = 8–10 and
reported as supporting.**

Detection rate for a planted 4-SD outlier across the k sweep:

| n   | detector | k=2      | k=3/5 | k=5/10 | k=8/15 | k=12/20 | k=15/25 |
| --- | -------- | -------- | ----- | ------ | ------ | ------- | ------- |
| 20  | k-NN     | 0.73     | 0.79  | 0.82   | 0.83   | 0.87    | 0.87    |
| 20  | **LOF**  | **0.59** | 0.72  | 0.81   | 0.86   | 0.87    | 0.89    |
| 60  | k-NN     | 0.67     | 0.71  | 0.72   | 0.73   | 0.73    | 0.72    |
| 60  | **LOF**  | **0.43** | 0.61  | 0.71   | 0.72   | 0.73    | 0.77    |

Two readings:

**k-NN is the flatter, more trustworthy detector** — range 0.73–0.87 at n = 20
against LOF's 0.59–0.89. This confirms ranking k-NN as the highest-priority
addition. (These numbers are for isotropic k-NN, 1a. Soft-thresholded k-NN,
1b, is new to this plan and has not been run through this same planted-outlier
check yet — do that before trusting it alongside 1a.)

**LOF at n = 20 is squeezed from both sides.** It is unreliable below k ≈ 8
(0.59 at k = 2). But at n = 20, k = 15 means the "local" neighbourhood is 75%
of the data, at which point LOF stops measuring local density and becomes a
slow global distance — it is no longer different in kind from k-NN, so it adds
nothing to the ensemble. The window where it is both reliable and still local
is roughly **k = 8–10**. That is narrow, and a two-or-three-point sweep cannot
demonstrate stability.

Pooled at n = 60 has a usable window of k ≈ 10–25 that stays comfortably below
n/2, which is where LOF earns its place.

So: **run both, but weight them differently.** Pooled LOF participates in the
Part 3 corroboration rule. Per-region LOF is reported with an explicit
"narrow-window, n = 20" caveat and does **not** count toward corroboration on
its own. Show the full k = 2–15 per-region sweep in the output anyway — the
collapse at low k is itself evidence a reader should see.

---

## Part 6 — Combining into one verdict (the TRINITY approach)

Combine on the **percentile scale from Part 2**, never on raw scores.

**Primary combination** — the book's Ch. 13.10 trinity, one representative per
family:

- Mahalanobis-type: **Ledoit–Wolf Mahalanobis** (auto-selected shrinkage)
- Proximity: **k-NN mean distance, isotropic (1a)** at k = ⌊√n⌉
- Partition: **Isolation Forest**, seed-averaged over 50 seeds

**1b (soft-thresholded k-NN) stays out of the primary trinity** — folding it
in would let axis-weighting logic vote twice, once through Ledoit–Wolf and
once through 1b. Report 1a-vs-1b agreement as a secondary diagnostic instead:
if soft-thresholding changes which samples are flagged, that is itself worth
showing, separate from the ensemble verdict.

Ensemble score = **mean of the three null percentiles**. Flag at ensemble
percentile > 0.95.

**Report two secondary combinations alongside it**, because the choice of
combination rule is itself a researcher degree of freedom:

- **Maximum** percentile across the three — more sensitive, flags anything any
  member dislikes.
- **Full five-detector mean**, adding pooled LOF and Kernel-PCA.

If the three combination rules disagree about a sample, that sample is not a
robust outlier, and the disagreement is the finding. Do not pick the rule that
produces the most satisfying list.

**Calibrate the ensemble itself by simulation too.** Averaging three
correlated percentiles does not yield a uniform null, so the 0.95 ensemble
threshold will not fire at 5% by construction. Run the Part 2 protocol on the
combined score and report its true false-positive rate.

---

## Part 7 — What this is expected to show, written in advance

Recorded before running so the outcome cannot be reinterpreted afterwards.

- **Sample 25** should be stable across nearly all detectors and settings. It
  is already T² = 10.78 against a Beta limit of 5.36, roughly 60% of the
  theoretical ceiling. If it is *not* stable here, the existing case for
  excluding it weakens considerably and that must be reported.
- **The samples that only MCD flagged** should show low stability fractions.
  That would be a clean, positive demonstration that the ensemble does what it
  was built for.
- **Most likely overall outcome:** one or two consistently flagged samples and
  a long tail of unstable single-method flags — i.e. confirmation that the
  outlier problem is smaller than the number of tables suggests. That is a
  useful result and should be presented as one, not treated as a failure to
  find something.
- This does **not** change the null result. No detector here is expected to
  alter any differential conclusion, and nothing found is adopted into the
  primary analysis without going through the specification curve.

---

## File layout

- `src/outlier_detectors.py` — one function per detector, uniform signature
  `(values, *, parameter) -> pd.Series[score]`; the k-NN function additionally
  takes `weighting: Literal["isotropic", "soft"]` for 1a/1b
- `src/outlier_calibration.py` — `simulate_null_limits`,
  `score_to_percentile`, `verify_false_positive_rate`
- `src/outlier_ensemble.py` — `stability_fraction`, `combine_percentiles`,
  `apply_stability_rule`
- `src/run_outlier_ensemble.py` — sweep driver, writes the long table
- `tests/test_outlier_detectors.py` — planted-outlier recovery per detector;
  distance-concentration guard; seed-averaging determinism; percentile
  conversion is monotone

## Outputs

```
results/mia_vs_control/02_qc/ensemble/detector_scores_long.csv
results/mia_vs_control/02_qc/ensemble/null_limits.csv
results/mia_vs_control/02_qc/ensemble/stability_fractions.csv
results/mia_vs_control/02_qc/ensemble/ensemble_verdict.csv
results/mia_vs_control/02_qc/ensemble/distance_concentration_diagnostic.csv
results/mia_vs_control/02_qc/ensemble/figures/stability_heatmap_{scope}.*
results/mia_vs_control/02_qc/ensemble/figures/sweep_curves_{detector}_{scope}.*
results/mia_vs_control/02_qc/ensemble/figures/ensemble_vs_t2_scatter.*
```

**`detector_scores_long.csv`** — the requested long-format table, one row per
`(detector, parameter_name, parameter_value, representation, scope, Sample)`
with columns `score`, `null_percentile`, `flag_95`, `flag_99`.

**Figures.** The stability heatmap is the headline: samples on one axis,
(detector × parameter) on the other, cell = flagged or not. A real outlier is
a solid horizontal band; an artefact is a few scattered cells. That single
image replaces reading five tables.

## Sequencing

1. **Part 0** — representation study and the concentration diagnostic.
   Everything downstream is meaningless without it.
2. **Part 2** — calibration machinery, with the T²/Beta case as a known-answer
   test (it must reproduce 5.36 at n = 20, p = 2).
3. Detectors **1, 4** — k-NN and Ledoit–Wolf, the two most stable.
4. Detectors **3, 5** — Isolation Forest and Kernel-PCA.
5. Detector **2** — LOF, pooled first, per-region second.
6. **Parts 3 and 6** — stability rule and combination.

## Validation

- Concentration diagnostic reproduces contrast ≈ 0.05 at p = 844 and ≈ 2.2 on
  3 PCs at n = 20.
- Calibration harness reproduces the Beta T² limit of 5.361 at n = 20, p = 2
  and a 5% ± 1.5% flag rate.
- Every detector recovers a planted 4-SD outlier at a rate matching the tables
  in Parts 4 and 5, ± 0.1.
- Isolation Forest scores are deterministic given a fixed seed list.
- Ensemble false-positive rate is measured and reported, not assumed to be 5%.
- Percentile conversion is monotone in score for every detector.
- Soft-thresholded k-NN's eigenvalue-floor guard fires on synthetic
  near-degenerate input rather than producing an unstable score.
- `pytest -q` passes.

## Explicitly out of scope

- Adopting any exclusion into the primary analysis. This plan produces
  evidence about samples, not a new sample list.
- Re-running the specification curve. If an exclusion is ever adopted it
  becomes a specification axis and is run then.
- Re-tuning any detector to make a particular sample appear or disappear.
