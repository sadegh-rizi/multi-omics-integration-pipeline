# Plan: an interactive PyShiny explorer for the lipidomics and metabolomics results

**Status: IMPLEMENTED 2026-10-07 on branch `task/explorer-app` (uncommitted) — see `app/README.md` and `prompts/2026-10-07-pyshiny-explorer-implementation-v1.md` for the decisions as implemented and the validation run.** Originally PROPOSED 2026-10-07. Sadegh asked
in a Cowork session for an app similar to bulkAnalyseR, customised so that
everything done so far can be visualised and explored interactively. A
colleague's proteomics app for the same mice is the closest model. He
specifically asked for a lipidomics **cross plot (log2FC vs log2FC)** and
for **PyShiny**. Confirm §7 before implementation, per `/careful-planning`.

The app lives in `app/` in this repo. It reads result files; it never writes
to `results/` or `data/`.

---

## 1. What the app is for

Three uses, in order of importance:

1. **Exploring what the pipeline produced**, without re-reading CSVs: any
   lipid in any region, any contrast, any population, side by side.
2. **Showing supervisors and colleagues** the design limits as they explore:
   cage structure, collection-date confound, population rule, exclusion
   dependence. These appear as banners and badges, not footnotes.
3. **Quick sensitivity checks**: remove a sample, re-threshold, compare two
   effect vectors. Clearly labelled as exploratory whenever the result is
   not the pipeline's own.

It is not a new analysis pipeline. Every number shown either comes from a
saved pipeline output or from the same package function the pipeline uses.

## 2. What was reviewed during planning

**bulkAnalyseR** (`repos/bulkAnalyseR/R/`, read-only). Its panels are:
- Landing and SampleSelect;
- QC: Jaccard similarity, PCA with ellipses, MA, scatter, violin, bar;
- DE (edgeR/DESeq2), DEplot (volcano/MA), DEsummary (heatmap, PCA);
- Cross plot;
- Patterns, Enrichment, GRN.

The cross plot (`cross_plot.R`, `crossPanel.R`) puts two DE comparisons'
log2FC on x and y. Points fall in four categories: not DE, DE both, DE in 1
only, DE in 2 only. The axes have a fixed 1:1 ratio, with guide lines on the
axes and diagonals. Auto-labels go to the points nearest the origin in each
of the 8 regions cut by the axes and diagonals. There are lfc and adjusted-p
threshold sliders, a gene highlight box and table/plot downloads.

**Colleague's proteomics explorer**
(`mohorianulab.org/shiny/.../MIA_proteomics_regional_explorer/`, R Shiny on
the bulkAnalyseR framework). Twelve tabs:
- Overview: counts, litters, how-to, design warning.
- Select samples: region, condition, outlier flag, sex, individual samples.
- Sample overview: PCA per region or pooled, colour-by, top-variable slider,
  ellipses, labels, per-sample box plots, QC download.
- Protein explorer: one protein, lines joining a mouse's three regions,
  Control/MIA panels, outlier labels.
- Differential expression: robust-trend limma per region, sex scope, run
  button. A note says thresholds change highlighting only.
- Volcano/MA: FDR or raw-p y-axis, highlight, PDF downloads.
- Cross plots: region × region MIA effects; FDR/raw evidence rule;
  thresholds; joined-table download; a note that this shows concordance, not
  an interaction test.
- Regional DE: paired region contrasts within Control or MIA.
- Regional differences: Control vs MIA regional difference per feature; a
  descriptive ranking.
- Outlier review: flags described as "priority for review", not failure.
- Data: downloads.
- bulkAnalyseR patterns: all features classified stable, so of little use.

**What this repo already has, by tab** (paths under `results/`):

| Need | Saved source | Notes |
|---|---|---|
| Expression matrix + metadata, all 60 | `mia_vs_control/09_region_persistence/prevalence20_noexclusion/{lipidomics,metabolomics}/00_inputs/region_input_{matrix,metadata}.csv` | metadata includes Cage, Date collected |
| Per-region MIA / Sex / interaction, lipidomics | `pipeline_test/prevalence20_{noexclusion,t2_95,t2_99}/03_differential/differential_effects.csv` | `pipeline_test_rerun/` exists (fixes plan G9) |
| Same, metabolomics | `metabolomics-pipeline/results/metabolomics_pipeline/prevalence20_t2_95/03_differential/` | **T²-95 only** — no all-60 saved (D3) |
| Region contrasts, concordance, reliability, ICC, interaction | `mia_vs_control/09_region_persistence/prevalence20_{noexclusion,hotelling95,hotelling99}/*/` | `contrast_pairing.csv` present (fixes item 3) |
| Outlier screens | `mia_vs_control/02_qc/outlier_screen_{region}.csv`, `outlier_diagnostics_*` | T², robust Mahalanobis, DModX, flags |
| QC | `02_qc/missingness/`, `technical_vs_biological_variance.csv`, `qc_injection_{cv,drift}.csv`, noisyR files | |
| Class / structural aggregates | `pipeline_test/*/06_aggregation/` | |
| PCA attribution | `mia_vs_control/04_multivariate/pca_score_attribution_*.csv` | recomputed live in the app anyway |

**Excluded by the population rule** until re-run on 60:
`mia_vs_control/00_inputs/`, `08_cage_structure/`, the specification curve,
feature-PCA `primary`.

Reusable package functions:
- `statistics.differential.fit_regionwise_differential` (the planned OLS
  `BioGroup * Sex` per region, BH);
- `statistics.region_contrast.build_region_contrasts`,
  `one_sample_region_tests`, `interaction_tests`,
  `disattenuated_concordance`;
- `outliers.screen.hotelling_t2` / `sample_outlier_table`.

## 3. Threats

1. **Numbers that disagree with the thesis.** A live recompute that differs
   from the saved table would undermine both. *Mitigation:* the saved/recompute
   rule (§4.2). A pre-declared check (§6.1) is that recomputing on a preset
   equals the saved table.
2. **The 57-sample population coming back.** *Mitigation:* a source registry
   that refuses the excluded trees, plus a whole-mouse-removal warning in
   sample selection (D6).
3. **Interactive p-hacking.** Sliders and sample removal make it easy to
   find "significant" lipids. *Mitigation:*
   - thresholds only change highlighting;
   - every recomputed view carries an "exploratory" badge;
   - the design banner (2 vs 6 cages, date confound) is on every inferential
     tab;
   - the exclusion-dependence cross plot preset (§4.3, tab 7) shows directly
     whether a hit is σ̂-driven.
4. **Scope creep.** The app grows into a second pipeline. *Mitigation:* no
   new statistics in the app. Anything new is added to the package first, then
   displayed.

## 4. Proposed design

### 4.1 Architecture

```
app/
  app.py              # shiny.App: navbar, modality switch, shared state
  registry.py         # permitted sources per (modality, population); refuses excluded trees
  data.py             # cached loaders (functools.lru_cache), lipid annotation join
  compute.py          # thin wrappers over lpj_lipidomics functions; cache keyed by sample set
  plots.py            # plotly figure builders, project palette
  modules/            # one file per tab (shiny module: ui + server)
  README.md           # how to run, what is saved vs recomputed
tests/test_app_registry.py, tests/test_app_compute.py
```

- Stack: `shiny` (core API, modules), `shinywidgets` + `plotly` for
  interactive plots (hover = lipid name, class, estimate, q), pandas,
  statsmodels and scikit-learn (already pinned). New dependencies need
  approval (D1).
- Run: `shiny run app/app.py` in the WSL venv.
- Palette: lipidomics `#2a78d6`, metabolomics `#eb6834`; groups and regions
  from `lpj_lipidomics.plotting` so app figures match the thesis figures.

### 4.2 The saved-vs-recompute rule (as Sadegh specified)

- A view uses the **saved** pipeline output whenever the current choice
  matches one: modality × population preset (all 60, T²-95, T²-99) ×
  contrast.
- Any choice that changes the computation recomputes **with the same
  package function**:
  - a custom sample selection;
  - a sex scope, or a region pair not saved;
  - metabolomics all-60 (D3).
- Every panel shows a badge: **Saved — pipeline output `<file>`, commit
  `<hash>`** or **Recomputed — exploratory (n = …, removed: …)**.
- Thresholds (|log2FC|, FDR, raw p) never trigger a recompute; they only
  colour and filter.
- Recompute results are cached by (modality, frozen sample set, analysis).

### 4.3 Tabs

A modality switch (Lipidomics / Metabolomics) in the navbar applies to every
tab.

1. **Overview.** Counts, the cage table (2 control vs 6 MIA cages, sexes,
   dates), the population rule, and what is saved vs recomputed. Links to
   `doc/analysis-state.md`.
2. **Select samples.**
   - Filters: region, group, sex, cage, collection date, T² flag (95 / 99),
     individual samples.
   - Preset buttons: *All 60*, *Remove T²-95 samples*, *Remove T²-99
     samples*.
   - Live summary: n per cell and per cage.
   - Warning if a selection removes every sample of a mouse (D6).
3. **Sample overview.**
   - PCA per region or pooled. Colour by region, group, sex, cage, date or
     T² flag, with marker shape = group, so region and case/control show on
     one plot (supervisor request §4.8 of the fixes plan).
   - Choice of PC pair (1–5), ellipses, labels, top-variable slider.
   - Beside it, a **variance-attribution heatmap** (R² of PC1–5 × region,
     group, sex, cage, date, tissue mass).
   - Below: per-sample distributions and missingness.
4. **Lipid explorer.**
   - Search by name or class.
   - Lines join each mouse's three regions; Control/MIA panels; sex as
     marker; cage in hover.
   - Value table, and a class-level view (class mean per sample).
5. **Differential.**
   - Region, effect (MIA vs Control, Female vs Male, interaction),
     population.
   - Table with class filter, estimate, SE, CI, p, q, cell n.
   - "Thresholds only highlight" note and design banner.
6. **Volcano & MA.**
   - FDR (default) or raw p on y; colour by significance or by lipid class.
   - Highlight box; PNG/PDF and table downloads.
7. **Cross plots — log2FC vs log2FC (requested).**
   - **Axis builder:** each axis = region × effect × population (and
     group, for region contrasts).
   - **Presets:**
     - (a) MIA effect, region A vs region B;
     - (b) **same effect, all 60 vs T²-95**. This is the exclusion-dependence
       view: points off the diagonal moved estimate; points on it with
       changed colour moved only significance. Optional colour by SE ratio.
     - (c) MIA effect vs Sex effect, same region;
     - (d) region contrast, Control vs MIA (links to tab 9).
   - **From bulkAnalyseR:**
     - four colour categories (not significant / both / x only / y only),
       using the FDR or raw-p rule and the |log2FC| threshold;
     - 1:1 axes; axis and diagonal guides;
     - optional auto-labels, *n* per each of the 8 regions;
     - highlight box; joined-table download.
   - **Added for lipids:**
     - colour by lipid class instead of category;
     - class filter;
     - Pearson and Spearman r shown on the plot;
     - a note that this is concordance, not an interaction test.
8. **Regional DE.**
   - Within-mouse paired contrasts (Cx−Cb, Hp−Cb, Cx−Hp) within Control,
     MIA or all mice, from `09_region_persistence` saved tests (recomputed
     for a custom selection).
   - Volcano/MA; a positive effect means higher in the first-named region.
   - Compositional caveat (A9).
9. **Regional differences (persistence).**
   - Per-feature Control vs MIA regional difference scatter, as in the
     colleague's tab.
   - The concordance panel: observed r, split-half reliabilities,
     attenuation ceiling, disattenuated estimate with interval, for each
     population.
   - Interaction q (raw and ICC-adjusted).
   - The counting-trap explanation (within-group counts are not compared).
10. **Outlier review.**
    - Per region: T² against the 95/99 limits, robust Mahalanobis, DModX,
      and the flags table.
    - A toggle shows the **difference-space screen** with two-contrast
      attribution, computed live and label-blind. It is labelled
      "proposed, not a permitted exclusion" until its decision doc is
      confirmed.
11. **QC.**
    - Missingness by sample/region/group.
    - Technical vs biological variance per lipid.
    - Tech-Mix CV and drift.
    - noisyR curve and thresholds, with the caveat that the cross-check
      compares two in-house implementations.
12. **Classes & structure.**
    - Class aggregates and structural indices (saved), with MIA/sex effects
      per region.
    - Placeholder for the composite panel (biology plan Part C) once it
      exists.
13. **Data & provenance.**
    - Downloads of the selected matrix, metadata and current result tables.
    - Every source file the app read, with modification time and the
      `provenance.json` commit.

**Not in v1:** bulkAnalyseR Patterns (the colleague found every feature
"stable", D2), Enrichment, GRN.

## 5. Files

**New:** `app/` (above), `tests/test_app_registry.py`,
`tests/test_app_compute.py`, this file,
`prompts/2026-10-07-pyshiny-explorer-app-plan-v1.md`.

**Changed:**
- `requirements.txt` (after D1);
- `doc/open-questions.md`;
- `doc/analysis-state.md` (after implementation);
- `README.md` (how to run the app).

**Not touched:** `data/`, `results/`, `src/` (the app imports the package and
does not modify it; any missing helper is proposed separately).

## 6. Validation (pre-declared 2026-10-07)

1. **Fidelity.** Recomputing each saved preset (lipidomics: all 60, T²-95,
   T²-99) with `compute.py` reproduces the saved `differential_effects.csv`
   estimate, SE, p and q to 1e-8. Region-persistence one-sample tests are
   checked the same way.
2. **Registry.** Requesting any excluded tree raises an error naming the
   population rule. A test enumerates every path the registry can return
   and asserts none is excluded.
3. **Badge correctness.** For each preset the badge says Saved; for any other
   selection it says Recomputed and lists removed samples.
4. **Cross plot join.** Features align by `Feature` id, not row order. A
   shuffled-row input gives an identical plot table.
5. **Thresholds.** Moving a threshold slider triggers no compute (call
   counter in tests).
6. **Smoke test.** `shiny run` starts. Every tab renders for both modalities
   with the all-60 preset (Playwright via `shiny.pytest`, if D1 includes it;
   otherwise a manual checklist in `app/README.md`).
7. **Performance target.** A full lipidomics per-region recompute in
   under ~10 s. If it is slower, use the vectorised `ols_t_statistics` path
   for display and keep the full function for downloads.

## 7. Decisions needed before implementation

**D1 — Dependencies.** Add `shiny`, `shinywidgets`, `plotly` (and optionally
`pytest-playwright` for the smoke test) to `requirements.txt` and the WSL
venv. *Recommendation:* approve the first three; Playwright optional.

**D2 — bulkAnalyseR Patterns tab.**
- (a) Skip in v1.
- (b) Port.
- *Recommendation: (a).* It adds little here, and the colleague's run shows
  why.

**D3 — Metabolomics all-60 differential.** None is saved (only T²-95).
- (a) Run the metabolomics pipeline variant `prevalence20_noexclusion`
  first, so it is saved.
- (b) Let the app recompute it.
- *Recommendation: (a).* Then the default view is a saved pipeline output in
  both modalities.

**D4 — Excluded trees.**
- (a) Hidden entirely, with "awaiting all-60 re-run" placeholders.
- (b) Shown with a warning.
- *Recommendation: (a).*

**D5 — Recompute model.**
- (a) The pipeline's OLS `BioGroup * Sex` via `fit_regionwise_differential`.
- (b) Also limma (R).
- *Recommendation: (a).* limma adds an R runtime to the app for a
  sensitivity that already exists as saved output.

**D6 — Manual whole-mouse removal.**
- (a) Allow, with a persistent banner "not a permitted population —
  exploratory".
- (b) Block it.
- *Recommendation: (a).* Removing a mouse's samples one region at a time is
  legitimate in per-region views. The banner prevents it being mistaken for
  a reportable result.

**D7 — Hosting.**
- (a) Local only (`shiny run`).
- (b) Later on the lab Shiny server next to the colleague's app.
- *Recommendation:* (a) now; decide (b) once the app is stable. Data
  sharing needs supervisor approval (`agent-rules.md`).

**D8 — Cross-plot presets.** Confirm (a)–(d) in §4.3 tab 7, or add others,
e.g. lipidomics vs metabolomics for a matched class.

**D9 — Branch and order.**
- Branch `task/explorer-app` after the fixes plan merges.
- Build order: registry, data and compute with tests → tabs 1–3 → 5–7
  (cross plot) → 8–9 → 4 → 10–13.
- *Recommendation:* as stated. The cross plot is usable after the first
  three steps.

## 8. Assumptions and limitations

- The colleague's app was reviewed from its rendered page only (tabs,
  controls, help text). Its code was not read, and its proteomics-specific
  model (robust-trend limma) is not copied.
- The app reflects the result trees as they are. When the fixes plan
  re-runs outputs, the app shows the new numbers and the provenance tab
  shows the new commit.
- Interactive inference here inherits every design limit of the study (8
  cages, date confound, compositional abundances). The banners say so; they
  do not fix it.
