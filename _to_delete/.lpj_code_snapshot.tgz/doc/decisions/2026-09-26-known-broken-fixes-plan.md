# Plan: fix the "known broken" items before relying on downstream results

**Status: CONFIRMED 2026-10-01 — implementation and validation in progress.** Sadegh asked
in a Claude Science session to fix the items listed under "Known broken — fix
before relying on" in `doc/analysis-state.md` (as of 2026-09-24), on a
separate branch. Sadegh confirmed §7 in OpenCode on 2026-10-01; see below.

Code changes go on branch `task/fix-known-broken` (§7 D1). Re-runs write to
new or regenerated trees as decided in §7 D3/D7. Nothing in `data/` is
touched.

**Amended 2026-10-01** to add §4.8–4.10: points raised by a second
supervisor (meeting reported 2026-10-01) on the pooled PCA, normalisation
and imputation. They are added here because they need the same all-60
re-run of `04_multivariate/` and `03_differential/` that item 1 enables.
D9–D11 were included in that confirmation. Amendment provenance:
`prompts/2026-10-01-supervisor-review-amendment-v1.md`.

---

## 1. Why this, and why now

Items 1–3 block every next step in `analysis-state.md`. The region-persistence
re-run, the figure 1 regeneration and the cage-aware re-run all need all-60
inputs, an unbiased bootstrap and contrast-specific pairing. Items 4–5 block
any use of the empirical permutation p-values and of `results/pipeline_test/`.
Items 6–7 are documentation and reproducibility. Items 8–10 answer the
second supervisor's review; 8 and 9 run on the all-60 tree that item 1
produces, 10 is documentation only.

| # | Item (from `analysis-state.md`) | Kind | This plan |
|---|---|---|---|
| 1 | `study_design.py` produces the 57-sample tree | code + re-runs | §4.1 |
| 2 | Disattenuation bootstrap biased downward | code + re-run | §4.2 |
| 3 | Region-persistence pairing drops whole mouse | code + re-run | §4.3 |
| 4 | Permutation file: no Region column; two FDR columns (G6, G7); 999-permutation floor (G8) | code + decision | §4.4 |
| 5 | `results/pipeline_test/` predates refactor (G9) | re-run + diff | §4.5 |
| 6 | `doc/project_summary.md` stale | doc | §4.6 — already marked SUPERSEDED 2026-09-24; no action proposed |
| 7 | Dependencies not pinned | environment (WSL) | §4.7 |
| 8 | Pooled PCA: show case/control alongside region (supervisor 2026-10-01) | figure | §4.8 |
| 9 | Normalisation: is log₂ enough; try PQN (supervisor 2026-10-01) | sensitivity arm | §4.9 |
| 10 | Which imputation was used (supervisor 2026-10-01) | documentation | §4.10 |

## 2. What was checked during planning (read-only, no computation of results)

- `analysis_metadata()` (`src/lpj_lipidomics/io/study_design.py`, l. 158–175)
  filters `OUTLIER_MOUSE = "C00431239 - 3"` (`config.py` l. 3) and asserts
  57. Callers: `run_mia_vs_control.py`, `run_cage_aware_sensitivity.py`,
  `run_qc_filters.py`, `run_specification_curve.py`; tests
  `test_cage_structure.py`, `test_run_mia_vs_control.py` (asserts 57).
  `run_abundance_similarity.py` builds its own 57-sample arm (l. 492–493).
  `run_cage_aware_sensitivity.py` writes `excluded_primary_mouse` to its
  manifest.
- The per-region T² screens that the region-persistence runner reads,
  `results/mia_vs_control/02_qc/outlier_screen_{cerebellum,cortex,hippocampus}.csv`,
  contain **20 samples per region (all 60)**, including `C00431239 - 3`.
  T²-95 flags: 35 (Cb), 25 and 37 (Cx), 9 and 6 (Hp). T²-99 flags: 25 and 37 (Cx).
  These match `doc/context/population-rule.md`. So the flag source is valid
  even though `00_inputs/` next to it is the 57-sample tree.
- `disattenuated_concordance()` (`region_contrast.py` l. 494–558) resamples
  mice for the numerator but draws reliabilities from the
  original-data split-half draws — the bug described in
  `doc/context/region-persistence.md`.
- `build_region_contrasts()` (l. 69–) keeps only mice with one sample in
  **every** region before forming any contrast (l. 101–114). This is the
  whole-mouse drop.
- `run_region_persistence.py` has two populations only:
  `prevalence20_noexclusion` and `prevalence20_hotelling95`. It has no T²-99 arm.
- `permutation_null_feature_statistics.csv` columns (all three
  `pipeline_test` variants): `Feature, Effect, …, p_value_empirical,
  null_exceedance_count, fdr_denominator, p_value_empirical_fdr,
  empirical_null_fdr, n_permutations, …`. There is no `Region` column. The
  regions are looped over in `run_permutation_null()` (`permutation.py`
  l. 446) but the region label is not written to the feature table.

No statistic was computed for this plan.

## 3. The threat that decides whether the fixes mean anything

The fixes change inputs, not questions, so the risk is silent drift. A
re-run could move a "settled" number without anyone noticing. The guard is
pre-declared regression checks (§6), each with a tolerance fixed now.
- The all-60 disattenuated intervals must agree with the exploratory
  reference `doc/context/reference/disattenuation_reference.csv` (all-60 rows
  only) to within Monte Carlo error.
- Point estimates must not change at all.

A second threat is the specification curve, the feature-PCA `primary` run
and `08_cage_structure/`. They are named as 57-sample outputs, and it is
tempting to re-run them all in this task. This plan fixes the code that
produces them. Re-running and re-evaluating them stays in next steps 2–3 of
`analysis-state.md`, so each re-run gets its own evaluation.

## 4. Proposed changes

### 4.1 Item 1 — retire the 57-sample population in code

- `analysis_metadata()` returns all 60 samples and asserts 60 samples, 20
  mice and 3 regions per mouse. The docstring states the population rule and
  points to `doc/context/population-rule.md`. Sample-level T² exclusion stays
  where it already lives: the variant runners select flagged samples
  explicitly. `analysis_metadata()` gains no exclusion option. Keeping
  exclusion out of the metadata loader is what stops the 57 tree from
  reappearing.
- `OUTLIER_MOUSE` is removed from `config.py` and from its importers (§7 D2).
- `run_abundance_similarity.py`: remove the `outlier_mouse_excluded` arm
  (§7 D2).
- `run_cage_aware_sensitivity.py`: remove `excluded_primary_mouse` from the
  manifest; record `analysis_sample_count` from the data.
- Tests: `test_run_mia_vs_control.py` asserts 60 and that no mouse is
  removed. `test_cage_structure.py` is adjusted to the 60-sample return.
- Downstream callers (`run_mia_vs_control`, `run_qc_filters`,
  `run_specification_curve`, `run_cage_aware_sensitivity`) keep their call
  sites and receive 60 samples. Their outputs change only when re-run (§7 D3).

### 4.2 Item 2 — unbiased disattenuation bootstrap

In `region_contrast.py`:

- New helper `_split_half_reliability(values, mouse_ids, n_splits, rng)`.
  It splits on **unique mouse IDs**, so all copies of a resampled mouse fall
  in the same half. It applies Spearman–Brown per split and returns the mean
  over valid splits. This is the pipeline's current point-estimate
  definition. The reference instead applies Spearman–Brown to the mean r
  (§7 D4).
- `disattenuated_concordance()`: for each bootstrap resample (mice with
  replacement, within group), recompute both group reliabilities on the
  resampled columns with the helper. Clip at 0 and set the ratio to NaN when
  the ceiling is 0, as now. The point estimate path is unchanged. The
  `reliability_draws` argument is no longer used for the interval. The
  signature is kept for callers, and the `bootstrap_method` string is
  updated.
- Output gains `point_inside_interval` (bool) and `n_inner_splits`.

### 4.3 Item 3 — contrast-specific pairing, and a T²-99 arm

- `build_region_contrasts()`: for each contrast, pair the mice that have
  one sample in **both** of its regions. Drop the all-regions requirement.
  The group/cage consistency checks stay per mouse. Add a per-contrast
  `n_mice` and a list of dropped mice to the returned metadata. A flagged
  cerebellum sample removes that mouse from Cx−Cb and Hp−Cb and keeps it in
  Cx−Hp.
- `run_region_persistence.py`: add `prevalence20_hotelling99`, which reads
  `hotelling_t2_99_flag` from the same screen files (§7 D5). Write a
  per-contrast pairing table (`02_qc/contrast_pairing.csv`: contrast, group,
  n_mice, dropped mouse, dropped sample, reason).
- Interaction FDR family unchanged: n_features × 3 contrasts.
- Expected pairing (from the flags in §2, before running):

  | Population | Cx−Cb ctl/MIA | Hp−Cb ctl/MIA | Cx−Hp ctl/MIA |
  |---|---|---|---|
  | all 60 | 10/10 | 10/10 | 10/10 |
  | T²-99 (25, 37 Cx; both MIA) | 10/8 | 10/10 | 10/8 |
  | T²-95 | 9/8 | 8/9 | 9/7 |

  T²-95 flags (from the screen files): 35 Cb `C00429562 - 5` (control); 25 Cx
  `C00431239 - 3` and 37 Cx `C01` (MIA); 9 Hp `C00429562 - 2` (control); 6
  Hp `C00431239 - 1` (MIA). T²-99 flags: 25 and 37 only. Compare the
  whole-mouse runner: 8/7 in every contrast (T²-95), 10/8 (T²-99).
- Out of scope: the difference-space screen. It needs its own decision doc
  (`analysis-state.md` next step 1) and is not a permitted arm yet.

### 4.4 Item 4 — permutation feature table (G6, G7, G8)

- G6 (defect): add `Region` as the second column in
  `run_permutation_null()` output. Assert that `Feature + Effect + Region` is
  unique before writing.
- G7: both FDR columns are kept and defined in a `fdr_definition` sidecar
  (`permutation_fdr_definitions.csv`) (§7 D6).
  - `p_value_empirical_fdr` is BH over per-feature empirical p. It is floored
    by `1/(B+1)`.
  - `empirical_null_fdr` is expected null exceedances / observed count at
    each |t| threshold, pooled over features within region × effect.
- G8: add `empirical_p_floor = 1/(n_permutations+1)` as a column. The
  permutation count is a decision (§7 D6).

### 4.5 Item 5 — `results/pipeline_test/` vs current code (G9)

Re-run `prevalence20_noexclusion` with the current `run_pipeline_variant`,
after §4.1–4.4, into a sibling tree (§7 D7). Diff the key tables against the
stamped `e16efa7` output:

- `03_differential/differential_effects.csv`: estimate, SE, p, q
- `02_qc/outlier_screen_*.csv`
- `05_diagnostics/permutation_effective_tests.csv`

Differences are expected only where §4.4 changed the permutation table.

### 4.6 Item 6 — `doc/project_summary.md`

Already carries a SUPERSEDED banner (2026-09-24) pointing to
`analysis-state.md`. No change proposed. Remove the item from the list.

### 4.7 Item 7 — pin dependencies (WSL, run by Sadegh)

```
cd "/mnt/d/#University/#MS-SystemsBio/Master_Thesis/repos/LPJ/lipidomics/LPJ_lipidomics"
/root/.virtualenvs/LPJ_lipidomics/bin/python -m pip freeze > requirements-lock.txt
Rscript -e 'renv::snapshot()'
```

These record the current environment; they do not change it.
`requirements.txt` stays as the loose list. Both new files are committed
only on explicit confirmation (§7 D8).

### 4.8 Item 8 — pooled PCA with case/control (supervisor, 2026-10-01)

**Request.** In the pooled (all-regions) PCA, show case/control as metadata
alongside region.

**What already exists.** `run_mia_vs_control.py` (`_write_pca_figures`,
scope `pooled`) already writes one score plot per variable
(`scores_pooled_{sample_type,bio_group,sex,...}`) and a factor-attribution
table (`pca_score_attribution_pooled.csv`: Region, Bio group, Sex, Tissue
mass, Cage, Collection date). The metabolomics pooled run
(`run_metabolomics_pca.py`) colours by Sample type, Bio group, Sex, Sample
number and Tissue mass only — no Cage or Date. Each figure shows one
variable, so region and group are never visible together, and only PC1–PC2
are plotted.

**Why PC1–PC2 alone would mislead.** Exploratory attribution on the all-60
inputs (Cowork, 2026-10-01; R² of each PC score on each factor):

| | Lipidomics | Metabolomics |
|---|---|---|
| PC1 (32.7% / 31.1%) | region 0.80, group 0.001 | region 0.85, group 0.002 |
| Group, best PC | 0.045 (PC4) | **0.21 (PC4)** |
| Same PC: cage / date | 0.36 / 0.31 | **0.70 / 0.57** |

Group is invisible on PC1–PC2. On metabolomics PC4 it looks partly
separated, but that PC is mostly cage and collection date, which are
confounded with treatment (`doc/context/design-constraints.md`). A group-only
colouring there would read as an MIA effect.

**Proposed.** One composite figure per modality,
`scores_pooled_region_group_composite`:
- Row 1, PC1–PC2 and PC3–PC4: colour = region, marker shape/fill = case vs
  control, so both are on one plot as she asked.
- Row 2, the same two PC pairs coloured by cage and by collection date.
- Right column: the attribution table as a heatmap (PC1–PC5 × region,
  group, sex, cage, date, tissue mass), R² printed in each cell.
- Caption states that group-associated variance on any PC is
  cage/date-aliased wherever cage/date R² on that PC exceeds group R².

Also: add `Cage` and `Date collected` to the metabolomics pooled colour list
and attribution table, and add `Date collected` to the lipidomics pooled
colour list, so both modalities have the same panels. Extend attribution
from PC1–4 to PC1–5 (D9). Descriptive only: no test is attached to the
figure.

### 4.9 Item 9 — normalisation and a PQN sensitivity arm (supervisor, 2026-10-01)

**Request.** Is PCA on raw data? Log transformation is a transformation, not
a normalisation. Try probabilistic quotient normalisation (PQN; Dieterle et
al. 2006, *Anal. Chem.* 78:4281).

**Current state, for the answer.** PCA is not on raw data. The core
delivered raw peak areas with no normalisation (`doc/methodology.md` §1).
Preprocessing is: blank-dominated features removed → below-detection values
masked → log₂ → **per-sample median normalisation** (subtract each sample's
median log₂ intensity; `preprocessing.median_normalize`) → autoscaling for
multivariate methods only (§2 steps 1–6). Step 4 is the normalisation; she is
right that log₂ alone is not one. Metabolomics normalises per acquisition
mode (`median_normalize_by_mode`). No internal-standard normalisation,
because it is not documented whether standards were spiked in (A9).

**PQN in this pipeline.** PQN estimates each sample's dilution factor as the
median, over features, of the quotient sample/reference. On log₂ data this
is defined here as a per-sample shift `s_i = median_j(x_ij − ref_j)`.
**Correction confirmed 2026-10-01:** conventional medians average the middle
two values for even counts and do not generally commute with log. Sadegh
selected this log-space definition, with explicit odd-count equivalence and
even-count non-equivalence tests. It is not claimed identical to arithmetic
raw-quotient PQN. No total-area pre-step is added. Re-estimating a reference
after sample-specific shifts can change it, so replacing normalization must
be checked on the original logged matrix, not inferred from shift additivity.

Proposed implementation: `pqn_normalize(log_intensity, groups)` in
`preprocessing.py`.
- Reference = feature-wise median over the samples of the same region
  (D10), then each region's reference is centred to median zero. Within a
  region this is ordinary PQN: it corrects dilution against that region's
  own typical profile. Between regions the only alignment is the region
  references' common median — the same assumption the current median
  normalisation makes, and unavoidable without an absolute anchor (A9).
  Without that centring, per-region PQN would leave raw loading differences
  between regions in every pooled analysis.
- Shift = median over features observed in both sample and reference.
- Require ≥ 50% of the panel per sample, otherwise raise.
- It replaces step 4 in a new arm. Metabolomics applies it within
  acquisition mode, as the median step does now.

**Reference choice matters with three regions.** PQN assumes most features do
not truly change between a sample and the reference. Across regions that is
false: hundreds of lipids differ between cortex and cerebellum.

Exploratory estimate (Cowork, 2026-10-01). PQN applied on top of the current
median normalisation, all-60 inputs. These are exploratory reference values;
re-estimating references on raw logged data need not give identical changes.

| Reference | Extra shift SD (log₂) lipid / metab | Max spread | R² region | R² group |
|---|---|---|---|---|
| pooled, all 60 | 0.078 / 0.083 | 1.40× / 1.26× | **0.26 / 0.50** | 0.006 / 0.003 |
| per region | 0.065 / 0.051 | 1.30× / 1.16× | 0.01 / 0.00 | 0.011 / 0.004 |

A pooled reference turns real regional composition into "dilution" and
shifts cerebellum by about −0.06 to −0.09 log₂. A per-region reference does
not. Either way, the change is ~5% per sample against a minimum detectable
effect of ~2×, so **the arm is not expected to change any inferential
result.** It is a robustness check that answers the question, not a rescue.

**Scope of the arm** (D11): `prevalence20_noexclusion_pqn`.
- Re-run `03_differential/` and `04_multivariate/` (per-region and pooled
  PCA, PERMANOVA) with PQN in place of median normalisation.
- Report beside the median arm: per-feature estimate difference, Spearman
  correlation of t-statistics per Region × Effect, q<0.05 count, minimum q.
- Region persistence is out of scope for this arm.

**Caveat to state in the thesis, independent of the method.** Median
normalisation and PQN both rescale each sample, and there is no absolute
anchor: no documented internal standards, and per-mg extraction is
unconfirmed. So every region difference reported is a **relative
(compositional)** difference, not an absolute one. Tissue mass (27–60 mg)
appears absorbed by the current normalisation: the residual PQN shift
correlates with mass at r ≈ −0.05 (lipidomics).

### 4.10 Item 10 — imputation (supervisor, 2026-10-01; documentation only)

**Request.** Which imputation was used? She recalled Random Forest applied to
MCAR, MAR and MNAR alike.

**Answer for the record; no code change.**
- The primary analysis imputes nothing ("exclude, don't impute",
  `doc/methodology.md` §2).
- Per-feature models use the observed samples. PCA and other multivariate
  methods use features with no missing value.
- RF-on-everything was one of four arms of the specification curve
  (§7.1): none, half-minimum, RF on missing-at-random cells with half-minimum
  for censored cells, and RF on everything.
- RF-on-everything is the questionable arm. About 85% of missing cells are
  left-censored (below detection: MNAR), and RF assumes MAR, so it imputes
  them too high. The masking test (RF RMSE ≈ 0.87 vs half-minimum ≈ 2.9)
  validates RF for MAR cells only.
- No arm produced a hit.
- The specification curve ran on the dismissed 57-sample population. Its
  all-60 re-run is already scheduled (`analysis-state.md` next steps; D3
  here). That re-run keeps the same four imputation arms, so her question is
  answered on the correct population.

Action: one paragraph in `doc/methodology.md` §2 making the missingness
mechanism and the no-imputation rule explicit. It goes in with the §1 update,
after the all-60 numbers exist. A register entry is recorded as answered.

## 5. Files

**Changed:**
- `src/lpj_lipidomics/io/study_design.py`
- `src/lpj_lipidomics/config.py`
- `src/lpj_lipidomics/runners/run_abundance_similarity.py`
- `src/lpj_lipidomics/runners/run_cage_aware_sensitivity.py`
- `src/lpj_lipidomics/statistics/region_contrast.py`
- `src/lpj_lipidomics/runners/run_region_persistence.py`
- `src/lpj_lipidomics/statistics/permutation.py`
- `src/lpj_lipidomics/runners/run_pipeline_variant.py` (sidecar and floor column; §4.9 PQN arm)
- `src/lpj_lipidomics/preprocessing.py` (§4.9 `pqn_normalize`)
- `src/lpj_lipidomics/metabolomics_preprocessing.py` (§4.9 PQN within acquisition mode)
- `src/lpj_lipidomics/runners/run_mia_vs_control.py` (§4.8 composite figure, Date panel, PC1–5 attribution)
- `src/lpj_lipidomics/runners/run_metabolomics_pca.py` (§4.8 Cage/Date panels, attribution, composite)
- `tests/test_preprocessing.py` (§4.9)
- `tests/test_run_mia_vs_control.py`
- `tests/test_cage_structure.py`
- `tests/test_region_contrast.py`
- `tests/test_permutation_null.py`
- `doc/open-questions.md`
- `doc/analysis-state.md` (after implementation)

**New:**
- this file
- `prompts/2026-09-26-known-broken-fixes-plan-v1.md`
- later `prompts/2026-09-26-known-broken-fixes-implementation-v1.md`
- `prompts/2026-10-01-supervisor-review-amendment-v1.md` (this amendment)
- `requirements-lock.txt` and `renv.lock` (§4.7)

**Not touched:**
- `data/`
- `.claude/`
- notebooks
- `doc/methodology.md` — §1 (and the §4.10 paragraph in §2) is updated
  once all-60 re-run numbers exist, not before.

## 6. Validation (pre-declared 2026-09-26, before any result exists)

Unit tests (synthetic data, no project data needed):

1. `analysis_metadata()` returns 60 rows, 20 mice, 3 regions per mouse;
   `C00431239 - 3` present.
2. Pairing: remove one mouse's cortex sample. Cx−Cb and Cx−Hp lose that
   mouse; Hp−Cb keeps it. `n_mice` per contrast is correct.
3. Id-aware split: with duplicated mouse columns, duplicates never straddle
   the halves.
4. Bootstrap: two groups drawn from one true profile plus noise.
   - The point estimate lies inside its own 95% interval.
   - The interval covers 1 in ≥ 90 of 100 seeds (nominal 95%; tolerance for
     Monte Carlo error).
5. Permutation table: `Region` present; `Feature+Effect+Region` unique;
   `empirical_p_floor == 1/(B+1)`.

Regression on project data (run in WSL after the unit tests pass):

6. All-60 region persistence, lipidomics:
   - Point estimates equal the existing `02_qc/disattenuated_concordance.csv`
     (all 60) to 1e-10.
   - Interval endpoints within **±0.05** of the reference CSV all-60 rows
     (Cx−Cb [0.93, 1.08], Hp−Cb [0.71, 1.03]).
   - Cx−Hp: the upper end is compared on the log scale, because the
     reference upper bound is 4.67 with ceiling ≈ 0.35. Within ±15%.
   - If a tolerance is exceeded, stop and investigate before accepting.
7. Positive control: Cx−Cb disattenuated concordance at all 60 ≈ 1 with an
   interval containing 1 (as in the reference).
8. `point_inside_interval` is True for every row, every population, both
   modalities.
9. All-60 per-feature interaction count at q<0.05 unchanged (0), because
   pairing is identical at all 60.
10. G9 diff: `differential_effects.csv` (all 60) estimate/SE/p equal to
    1e-8. Any larger difference is reported, not absorbed.

Supervisor items (pre-declared 2026-10-01, before any PQN run):

11. Unit: on synthetic data with a known per-sample dilution factor and
    20% of features truly changed, `pqn_normalize` recovers the factor
    to within 0.02 log₂. For odd reference and quotient counts, its log-space
    result equals raw-scale PQN to 1e-10. A separate even-count example
    explicitly verifies non-equivalence (user-confirmed correction above).
12. Unit: synthetic three-region data with 30% of features shifted in
    one region plus a known per-sample dilution. The per-region (centred)
    reference recovers dilution to within 0.02 log₂; the pooled
    reference shows a region-correlated bias. This is the reason for D10.
13. Project data: PQN shifts per sample match the exploratory table in
    §4.9 (SD within ±0.02 log₂ for the chosen reference) and have
    R² ≤ 0.05 with group.
14. Project data: Spearman ρ between median-arm and PQN-arm t-statistics
    ≥ 0.95 in every Region × Effect family. If any family falls below,
    stop and investigate before reporting. The prediction is no change in
    the q<0.05 count beyond the already fragile ChE(22:4) cortex result;
    any other change is reported with its estimate and SE in both arms.
15. Figure: the composite pooled PCA reproduces the attribution numbers
    in §4.8 to 0.01 (all 60).

## 7. Decisions needed before implementation

### Confirmed decisions — 2026-10-01

Sadegh approved the recommendations in OpenCode: D1(a), D2(a), D3(a),
D4 = 1,000 bootstraps × 100 inner splits with mean-of-Spearman–Brown,
D5(a), D6(a+i), D7(a), D8(a), D9(a), D10(a), D11(a).
He explicitly dismissed the mouse-only 57-sample arms again, and selected
**log-space shifts** in the follow-up PQN median question. The original
options below are retained as the decision history.

- Existing documentation baseline committed as `bae60c3`; fixes branch
  `task/fix-known-broken`.
- Environment snapshot committed separately as `e923b9d`. R library versions
  match the lock; `noisyr` 1.1.0 has an unknown installation source and remains
  a restoration limitation. No packages were installed or changed.
- Implementation provenance:
  `prompts/2026-10-01-known-broken-fixes-implementation-v1.md`.
- Reusable additions beyond the original file list: shared
  `multivariate/pca_metadata.py`, `runners/run_pqn_sensitivity.py`,
  `runners/check_known_broken_fixes.py`, `runners/run_known_broken_fixes.py`,
  and `tests/test_pqn.py`. Metabolomics median/PQN arms write to
  `results/metabolomics_pipeline_rerun/<variant>/`; lipidomics arms use the
  approved `results/pipeline_test_rerun/<variant>/`.
- The composite includes both PC pairs for cage **and** date (four companion
  panels beneath the two region/group panels), plus the attribution heatmap.
- The synthetic coverage check uses 100 datasets, 200 bootstraps × 40 inner
  splits per dataset; production regressions retain 1,000 × 100.

**Resolution clarification:** the 0.001 empirical-p floor is exact for 999
valid sampled permutations. It limits a *single isolated* minimum-p feature's
BH q; sufficiently many small p-values can still pass BH. It is not a proof
that no empirical BH discovery is possible regardless of the data.

### Original options

**D1 — Git baseline and branch.** `analysis-state.md` lists uncommitted
work (region-persistence runner, `region_contrast.py`, tests, results,
decks, docs). `AGENTS.md` asks for a clean tree before a task branch.
- (a) Commit the pending work on the current branch first, then
  `git switch -c task/fix-known-broken`. The branch diff then shows only
  these fixes.
- (b) Create the branch now, carrying the uncommitted work along. This
  mixes unrelated changes into this task's commits.
- (c) Stash, branch, fix, then pop. This risks conflicts in
  `region_contrast.py`, which both touch.
- *Recommendation: (a).* git cannot run from this Claude Science session;
  Sadegh runs the git commands in WSL.

**D2 — Removing `OUTLIER_MOUSE`.**
- (a) Delete the constant, its importers and the
  `run_abundance_similarity` 57-sample arm.
- (b) Keep the constant only as a historical label in comments.
- *Recommendation: (a).* A live constant is how the 57 tree came back.

**D3 — Existing 57-sample result trees**
(`results/mia_vs_control/00_inputs/` … `07_*`, `08_cage_structure/`,
specification curve, feature-PCA `primary`).
- (a) When each is re-run, regenerate in place and `git rm` the superseded
  files in the same pass (`agent-rules.md`, results organisation).
- (b) Move them now to `results/archive_57_dismissed/`.
- (c) Leave them until re-run.
- *Recommendation: (a)*, with the re-runs scheduled per `analysis-state.md`
  next steps. Until then the population rule already forbids using them.

**D4 — Bootstrap settings.**
- Resamples: keep 1,000.
- Inner split-halves per resample: 40 (reference), 100, or 200.
  Cost scales linearly. 1,000 × 100 × 2 groups × 3 contrasts is about 6 × 10⁵
  split correlations per population and modality, which takes minutes.
- Reliability definition: keep the pipeline's mean-of-Spearman–Brown, or
  switch to the reference's Spearman–Brown-of-mean-r.
- *Recommendation:* 1,000 × 100, pipeline definition for both point and
  interval, so the point estimate stays unchanged. Accept the small
  definitional offset against the reference inside the §6 tolerance.

**D5 — T²-99 arm in region persistence.**
- (a) Add `prevalence20_hotelling99`.
- (b) Keep two populations.
- *Recommendation: (a).* It is a permitted population, and the reference
  table already has a (whole-mouse) T²-99 row that needs a valid counterpart.

**D6 — Permutation FDR columns and count (G7, G8).**
- Columns:
  - (a) keep both and define them in a sidecar;
  - (b) drop `p_value_empirical_fdr`;
  - (c) drop `empirical_null_fdr`.
- Count:
  - (i) keep 999 and report the 0.001 floor;
  - (ii) 9,999 (about 10× runtime; the best achievable BH q for one feature
    over 964 is then ≈ 0.096);
  - (iii) 99,999 (about 100× runtime).
- *Recommendation: (a) + (i).* The study is reported as null with a power
  statement, and raising the count to make empirical BH reachable is not a
  question anyone has asked of the data. Raise it only if a per-feature
  empirical q is going to be reported.

**D7 — Where the G9 re-run writes.**
- (a) Sibling tree `results/pipeline_test_rerun/prevalence20_noexclusion/`,
  diff, then decide whether to replace `results/pipeline_test/`.
- (b) Overwrite in place and inspect the git diff.
- *Recommendation: (a).* Nothing is overwritten before the diff is seen.

**D8 — Lock files.**
- (a) Commit `requirements-lock.txt` and `renv.lock` on this branch.
- (b) A separate branch.
- *Recommendation: (a)*, as its own commit, after you confirm.

**D9 — Pooled PCA figure (§4.8).**
- (a) Composite: region × group on one plot (PC1–2, PC3–4), cage and
  date panels, attribution heatmap for PC1–5.
- (b) Only add a combined region × group panel for PC1–2.
- *Recommendation: (a).* (b) shows nothing for group and hides that
  the only group-associated PC is cage/date.

**D10 — PQN reference (§4.9).**
- (a) Per region: median of all samples of that region, both groups
  (label-blind), centred to median zero (§4.9).
- (b) Pooled: median of all 60.
- (c) Tech-Mix QC injections. Blocked by A2 (is Tech-Mix a pooled study
  aliquot?) and by its unknown regional composition.
- *Recommendation: (a).* (b) treats real regional differences as
  dilution (R² with region 0.26 / 0.50). Never a per-group reference: it
  would normalise towards each treatment group's own profile.

**D11 — PQN arm scope (§4.9).**
- (a) Sensitivity arm on all 60: differential + multivariate.
- (b) Also on T²-95/99.
- (c) Replace median normalisation as primary.
- *Recommendation: (a).* (c) would change the primary after looking at
  nothing new, and the expected difference is ~5% per sample.

## 8. Assumptions and limitations

- Implementation is written from Claude Science on Windows with read-only
  access to the repository root plus write access to `src/`, `tests/`,
  `doc/` and `prompts/` if granted.
- Tests and all re-runs must run in the WSL venv
  (`/root/.virtualenvs/LPJ_lipidomics/bin/python`) and renv R. The Python
  available to the agent is a different, unpinned environment. Any check the
  agent runs there is a pre-check, labelled as such.
- The ±0.05 / ±15% tolerances are judgement calls, set before results
  exist. The reference used 400 resamples and a different reliability
  definition, so exact agreement is not expected.
- The per-region screen reimplementation in `outlier-screening.md` found 56
  where the pipeline found 06 (hippocampus/cerebellum). This plan uses the
  pipeline's flags as-is and does not resolve that difference.
- The §4.8 and §4.9 tables are exploratory: computed in Cowork on
  `09_region_persistence/prevalence20_noexclusion/*/00_inputs/region_input_matrix.csv`
  (all 60, already median-normalised). The PCA there uses complete features
  only and the same autoscaling as the pipeline. Not pipeline outputs.
- The supervisor's points are recorded from Sadegh's meeting notes, not
  from her directly. A fourth bullet in the notes was empty.
- The fix to item 3 changes the T²-95 and T²-99 region-persistence numbers
  by design. The whole-mouse rows in `region-persistence.md` are superseded
  when the re-run lands.
