# Plan: standard QC feature filters — blank ratio and pooled-QC CV

Two filters that are standard practice in untargeted lipidomics and are
currently **not implemented**. Adds a third diagnostic (injection drift) that
surfaced while quantifying them.

## What already exists, so this is not confused with it

`src/preprocessing.py` has `exclude_below_detection`, a **value-level** rule:
an individual measurement below `max(3 × mean_blank, 1.0)` becomes `NaN`. That
is not the same operation as removing a whole lipid. Both are legitimate; they
answer different questions and this plan adds the feature-level one alongside,
without changing the existing value-level rule.

There is also `src/qc_variance.py`, which computes a technical/biological
**variance ratio** from the Tech-Mix replicates. That is also not a CV filter —
the ratio can flag a feature simply for having low biological variance. A
filter on that ratio was tested as exclusion condition B and **made results
worse** (Cortex PLS-DA permutation p 0.371 → 0.860). A pure QC-CV filter asks a
different question: can the instrument measure this feature reproducibly at
all. It uses no group labels, so it is not circular, and it is worth testing on
its own terms rather than being assumed to behave like condition B.

---

## Part 1 — Feature-level blank filter (adopt)

**Rule.** Remove a lipid entirely if it has non-zero blank signal *and* its
median across biological samples is below `blank_multiplier ×` its mean blank.

**Threshold.** `FEATURE_BLANK_MULTIPLIER = 3.0`. Schiffman et al. (2019,
*BMC Bioinformatics* 20:334) describe 2–5 as the conventional range for this
cutoff; the existing value-level rule already uses 3.0, so using the same
multiplier keeps the two consistent.

**Measured effect** (57 samples, 992 lipids):

| threshold | lipids removed |
|---|---|
| 3× | **11** (1.1%) |
| 5× | 15 (1.5%) |
| 10× | 21 (2.1%) |

**Recommendation: adopt at 3×.** Small, standard, uses no group labels, and
removes features that are majority background. Implement as
`exclude_blank_dominated_features(intensity, blank_intensity, *, blank_multiplier=3.0)`
in `src/preprocessing.py`, applied **before** `exclude_below_detection` in both
`preprocess_for_differential` and `preprocess_for_multivariate`.

Write the removed features with their signal-to-blank ratio to
`results/mia_vs_control/01_preprocessing/blank_dominated_features.csv`.

---

## Part 2 — Pooled-QC CV filter (compute and test, do not adopt blind)

**Source.** The six `Tech-Mix_N+.raw` injections. Confirm with the vendor that
Tech-Mix is a pooled aliquot of the study samples rather than an external
reference — if it is external, the CV is not comparable to a study-sample QC
and this filter's interpretation changes. Record the answer.

**The critical implementation detail.** CV must be computed **after
normalising the QC injections**, not on raw peak areas. Measured difference:

| CV computed on | median CV | share with CV > 30% |
|---|---|---|
| raw peak areas | 32.4% | **59%** |
| after median-normalising injections | **23.3%** | **28%** |

The raw figure is inflated by run drift (Part 3). Using it would discard 59%
of the panel for a reason that is partly instrumental, not per-feature.

**Rule.** For each lipid with ≥4 usable Tech-Mix injections:

1. Median-normalise the six injections (divide each injection by its median
   peak area, rescale to the overall median) to remove injection-to-injection
   intensity differences.
2. `CV% = 100 × SD / mean` on those normalised positive values.
3. Flag `CV > QC_CV_THRESHOLD` (default 30.0).

10 of 992 lipids have fewer than 4 usable injections — report them as
`cv_not_assessable`, do **not** silently treat them as passing.

**Validation against the vendor's own metric.** The workbook has a `%CV`
column (a fraction — multiply by 100). Our raw-scale CV correlates with it at
**r = 0.986**, medians 32.4% vs 32.5%. Reproduce this check in a test so the
computation is anchored to something external.

**Do not adopt on the first run.** Produce the CV table, then run the analysis
**both ways** and report:

- feature count before/after
- PLS-DA permutation p per region, filtered vs unfiltered
- number of FDR-significant lipids per region/effect, filtered vs unfiltered
- p-value histogram shape

Filtering at CV>30% cuts the panel from ~983 to roughly 700, which is a genuine
reduction in multiple-testing burden and should *help* power if the removed
features are pure noise. Condition B did the opposite, so this must be measured
rather than assumed. **Adoption is a separate decision after seeing the
numbers.**

---

## Part 3 — Injection drift diagnostic (report only)

Surfaced while computing Part 2. The Tech-Mix median peak area declines
monotonically across the run:

| injection | median peak area |
|---|---|
| Tech-Mix_1 | 17,173 |
| Tech-Mix_2 | 14,882 |
| Tech-Mix_3 | 15,665 |
| Tech-Mix_4 | 15,298 |
| Tech-Mix_5 | 11,664 |
| Tech-Mix_6 | 9,211 |

**1.86× decline, first to last.** Consistent with sensitivity loss across the
batch.

Produce a small diagnostic — table plus one figure of QC median signal against
injection index — written to `02_qc/`. **Do not attempt drift correction.**
Doing that properly needs the true acquisition order and QC positions within
the run, which we do not have; it is a question for the vendor. This is a
report-only diagnostic that documents a real property of the batch.

Also report whether `Sample number` correlates with each sample's median
signal, as a check on whether the drift propagated into the study samples after
median normalisation.

---

## Configuration

Add to `src/analysis_config.py`:

```python
FEATURE_BLANK_MULTIPLIER = 3.0   # feature-level S/B filter (Part 1, adopted)
QC_CV_THRESHOLD = 30.0           # pooled-QC CV cutoff (Part 2, tested not adopted)
QC_CV_MIN_INJECTIONS = 4         # of 6 Tech-Mix injections
APPLY_QC_CV_FILTER = False       # flip only after reviewing the comparison
```

`APPLY_QC_CV_FILTER = False` by default is deliberate: the code ships able to
run both ways, and adoption is an explicit recorded decision rather than a
side effect of implementation.

## File layout

- `src/preprocessing.py`: add `exclude_blank_dominated_features`.
- `src/qc_variance.py`: add `qc_injection_cv(techmix, *, min_injections=4)`
  returning per-feature normalised CV, raw CV, and injection count.
- `src/run_qc_filters.py`: standalone script producing the tables and the
  drift figure; does not modify the main pipeline.
- Tests:
  - blank filter removes a synthetic blank-dominated feature and retains a
    clean one
  - CV is computed after normalisation, verified against a hand-computed case
  - features with <4 usable injections are marked not-assessable, not passing
  - the r≈0.986 agreement with the workbook `%CV` column holds

## Outputs

```
results/mia_vs_control/01_preprocessing/blank_dominated_features.csv
results/mia_vs_control/02_qc/qc_injection_cv.csv
results/mia_vs_control/02_qc/qc_cv_filter_comparison.csv     # both-ways results
results/mia_vs_control/02_qc/qc_injection_drift.csv
results/mia_vs_control/02_qc/figures/qc_injection_drift.*
```

## Validation

- Blank filter removes exactly 11 features at 3×; confirm and list them.
- Normalised median CV ≈ 23.3%, raw ≈ 32.4%; both reported.
- Correlation with the workbook `%CV` ≈ 0.986.
- The both-ways comparison reports every metric listed in Part 2, including
  when the filter makes things worse.
- `pytest -q` passes.

## Open items

1. Whether Tech-Mix is a pooled study aliquot or an external reference —
   vendor question, changes how the CV should be read.
2. `QC_CV_THRESHOLD = 30` is the common convention; 20 would remove 64% of the
   panel even after normalisation, which is likely too aggressive here. Revisit
   after seeing the comparison.
3. Whether to adopt the CV filter at all. Explicitly deferred to a decision
   after the numbers exist.
