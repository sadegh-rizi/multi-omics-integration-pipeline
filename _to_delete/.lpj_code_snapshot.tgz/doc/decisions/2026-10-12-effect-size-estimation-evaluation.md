# Evaluation: what MIA effect sizes say when p-values cannot

**Status: EXPLORATORY EVALUATION 2026-10-12 — run, not pre-registered.**
Sadegh asked in a Cowork session what effect sizes (rather than p-values)
show, whether the biology makes sense, and whether proteomics agrees.
Runner: `src/lpj_lipidomics/runners/run_effect_size_estimation.py`.
Outputs: `results/mia_vs_control/15_effect_sizes/prevalence20_noexclusion/`.
Population: all 60 samples. Nothing existing was overwritten.

---

## 1. Why this, and what it is not

Cage-level permutation has a floor of p = 1/28 = 0.036 (register E6), so
per-feature or per-composite p-values cannot carry a claim. This run reports
estimates, robustness checks and literature fit instead.

**It is not the two-stage run of `2026-10-05-biology-in-the-data-plan.md`.**
The C1–C8 definitions and expected directions come from that plan (written
before this run), but the label-blind stage 1 was never frozen, and a post
hoc class-level scan (the ganglioside and plasmalogen shifts in §2.3) was
looked at first. **The composite panel is therefore no longer blind.** Any
future "pre-registered" run must say so, or move to an independent cohort.

## 2. What was computed and what it showed

Effect = sex-balanced MIA − control difference (mean of within-sex
differences), per region, 10 vs 10 mice. Mouse-level 95% CIs ignore litter
clustering and are optimistic. Robustness: leave-one-cage-out (LOCO) range,
males and females separately, and the 2024-06-11 litters only (the one date
with both groups: 2 MIA litters vs 1 control litter).

### 2.1 Lipid species (964)

- Median |fold change| 1.09–1.16× per region.
- Share of lipids whose CI excludes an effect larger than 2×: 65% (Cb),
  79% (Cx), 75% (Hp); larger than 1.5×: 23–44%; larger than 1.25×: 1–11%.
- MIA effects do not correlate between regions (r = −0.06 to −0.04): no
  brain-wide MIA signature.
- Largest raw fold changes are low-abundance, noisy species (CIs > ±10
  log2); rank by standardized effect, not fold change (winner's curse).

### 2.2 Pre-defined composites C1–C8 (`05_composites_C1_C8.csv`)

- No composite has cage-level p below 0.29; this is the expected resolution,
  not evidence of absence.
- Sign agreement with the plan's expected directions: 7/8 in hippocampus,
  5/8 cortex, 4/8 cerebellum. The composites share lipids and are not
  independent, so this count is descriptive only.
- Hippocampus C1 (myelin lipid index): 0.86× (−0.75 SD), mouse-level CI
  −0.47 to +0.04 log2, negative in every LOCO fit, in both sexes, and in the
  date-matched subset (−0.14 log2). Mouse permutation p 0.08, cage p 0.39.
- Hippocampus C8 (ganglioside maturity) ≈ 0.96×: the complex/simple ratio
  does not shift, so the ganglioside class drop in §2.3 is not a maturation
  delay in this sense.

### 2.3 Post hoc class shifts, hippocampus (`04_class_shifts_posthoc.csv`)

Lower in MIA: sulfatide ST 0.63×, PG 0.78×, GD1a 0.79×, GD1b 0.83×, ether-PE
0.84×, PS 0.86×; TG 1.27× higher (females only). Most are LOCO-stable; the
sulfatide drop disappears in the date-matched subset (0.96×). Found by
scanning ~28 subclasses × 3 regions; hypothesis-generating only.

### 2.4 Proteomics (`06_proteomics_*.csv`)

- Ganglioside synthases (St3gal5, St8sia1, B4galnt1, B3galt4, St3gal2) and
  most plasmalogen/PS enzymes are **not detected**; only catabolic Hexb, Gm2a,
  Psap and Gnpat, Agps, Far1 are. The ganglioside hypothesis cannot be tested
  at protein level.
- Myelin proteins (Mbp, Plp1, Mag, Mog, Cnp, Mobp, Ugt8) pass a region sanity
  check in controls: cerebellum > hippocampus > cortex for all seven, as
  expected at P14. (Calb1 does not differ by region — unexplained; A12.)
- Hippocampus myelin protein score: −0.48 SD in MIA (Mbp 0.72×, Mog 0.76×,
  Mobp 0.79×), negative in every LOCO fit, **but female-only (−1.11 vs
  +0.15 in males) and reversed in the date-matched subset (+0.23)**.

### 2.5 The threat that decides whether §2.2–2.4 mean anything

1. **Lipid and protein myelin signals are the same signal.** Within region,
   the lipid C1 index and the protein myelin score correlate r = 0.82–0.86
   (0.75–0.79 in controls alone). After regressing the protein score on C1,
   the hippocampus MIA difference is +0.10 SD. Proteomics therefore does not
   independently confirm the lipid result; both read the myelin content of
   the same tissue piece (register A4: shared extraction).
2. **Litter and date carry it.** The low-myelin hippocampi come from MIA
   litters C01 (2024-08-06) and C00462971 (2024-09-13), dates with no
   controls. The date-matched MIA litter C00431239 has the *highest* protein
   myelin score of all litters. At P14 myelination is steep, so litter-level
   differences in maturation, or in how much white matter the dissection
   included, would produce exactly this pattern.

## 3. Literature fit

- Makinodan et al. 2008 (J Neurosci Res 86:2190–2200): poly(I:C) MIA
  reduces MBP mRNA and protein and delays myelination in offspring
  hippocampus in early postnatal and juvenile ages, normalising by
  adulthood. Same agent (A11), region, age window and marker as §2.4, so the
  direction is biologically coherent.
- Gangliosides: CSF studies in autism report higher, not lower, GM1/GD1a
  (small samples; Puljko et al. 2025 review, IJMS 26:1322). No MIA brain
  ganglioside data were found. Weak literature support.

## 4. Reading

A hippocampal myelin signal, lower in MIA, with the direction and region the
literature predicts, seen in lipids and proteins — but the two are one
measurement of the same tissue, it is carried by litters from dates without
controls, and the only date-matched MIA litter shows the opposite. It is a
plausible, specific hypothesis, not a finding. Cerebellum and cortex show
nothing coherent.

## 5. Files

New: the runner above; `results/mia_vs_control/15_effect_sizes/prevalence20_noexclusion/`
(01–07 CSVs, `figures/`, `manifest.json`); this document; prompt record
`prompts/2026-10-12-effect-size-estimation-v1.md`.

## 6. Validation

- Lipid input `results/pipeline_test/prevalence20_noexclusion/00_inputs/differential_input_matrix.csv`
  is byte-identical (sha256 e4033257…) to `results/pipeline_test_rerun/`, i.e.
  reproduced under the current package layout (G9 concern does not apply to
  this file).
- Run in the Cowork VM with scipy 1.15.3, matplotlib 3.10.9 (lock pins
  scipy 1.18.0, matplotlib 3.11.1); re-run in the WSL venv before citing.

## 7. Decisions for Sadegh

- **D1 — status of the C1–C8 panel.** (a) declare it unblinded and report
  all eight as estimation only; (b) keep C1-hippocampus as a stated
  hypothesis for a future cohort. *Recommendation: (a) now, (b) in the
  discussion.*
- **D2 — ask the animal-work owner (A13):** hippocampal dissection
  boundaries (fimbria/white matter included?) and whether the same tissue
  homogenate fed lipidomics and proteomics.
- **D3 — metabolomics:** repeat §2.1 there? *Recommendation: yes, species and
  cross-region parts only.*

## 8. Assumptions and limitations

Mouse-level CIs ignore litters; cage-level p floor 0.036; 6 of 10 MIA mice
from dates without controls; `ST` assumed to be sulfatide (A10); ether lipids
not split O-/P- (A10); all ratios are compositional (median-normalized data,
no internal standards).
