# Plan: filtered pipeline re-run + differential analysis (pipeline-test)

**Status: CONFIRMED 2026-09-03 — implementation complete; execution pending the
source workbook.** The user
confirmed the blocking choices below before code changes. No source workbook
run has completed in this checkout because the workbook is not present.

Worktree: `lipidomics/pipeline-test` (branch `pipeline-test`).
Prompted by the 2026-09-03 discussion following the null FDR result.

## 0. Confirmation recorded

The user confirmed: prevalence is computed on all 60 samples before sample
exclusion and detection masking; outputs go under `results/pipeline_test/`
without changing `results/mia_vs_control/`; all variants remain sensitivity
analyses and the primary defaults stay unchanged; the sample-level outlier
selection framing is exploratory; permutation calibration uses 999
deterministic sex-stratified permutations; diagnostics use 12 deterministic
features plus leave-one-sample-out summaries; class summaries and structural
indices use unweighted log-scale/structural summaries; and power uses nominal
two-sided alpha 0.05 at 80% power with an illustrative n≈8 scale only.

---

## 1. Task as understood

1. Re-run the MIA-vs-control pipeline with the currently-decided lipid
   filtering steps, **plus** the prevalence filter (drop a lipid missing in
   >20% of samples), which is implemented but currently disabled.
2. Remove samples flagged as outliers at the 95% Hotelling's T² threshold.
3. Re-run differential analysis on the resulting matrix.
4. Add the follow-up analyses proposed in the 2026-09-03 discussion:
   p-value calibration diagnostics, a permutation null,
   lipid-class/structural aggregation, and a detectable-effect-size
   statement. **Litter-aware modelling is deferred by user decision
   2026-09-03** and is not part of this run (see §6.3).

Items 1–3 are a **sensitivity analysis**, not a replacement for the primary
analysis. Item 4 contains the parts most likely to change what the thesis can
claim. Part 0 explains why 1–3 must not silently become the headline result.

---

## 2. What is already established (do not re-derive)

Cited from files in this repo, inspected 2026-09-03.

**Design** (`results/mia_vs_control/00_inputs/differential_input_metadata.csv`)

- 3 regions (Cerebellum / Cortex / Hippocampus), 19–20 samples per region.
- Group×Sex cells of 4–5 per region; OLS residual df = 15; ~955 features
  tested per region×effect.
- Repeated measures: each mouse contributes all three regions. The per-region
  analysis avoids pseudoreplication across regions; it does **not** address
  the litter issue below.

**Litter structure — the dominant design constraint, and not yet documented
anywhere in the repo.** The `Mouse number` field carries a shared prefix with
a sequential suffix (`C00429562 - 1` … `- 6`; `C00462970 - 1` … `- 4`). If
that prefix identifies the dam/litter, then:

| Bio group | pups | distinct prefixes |
|---|---|---|
| Saline Control | 10 | **2** (`C00429562` ×6, `C00462970` ×4) |
| MIA | 9 | ~6 (`C00431239` ×2, `C00462971` ×3, `C00437351`, `C00462968`, plus `C00`, `C01`) |

MIA is administered to the dam, so litter — not pup — is the experimental
unit. Ten controls from two litters are not ten independent control
observations. Every model in the repo to date treats them as independent,
which makes existing results **optimistic**, not conservative. `C00` and `C01`
do not follow the pattern and are unresolved (Q1).

**Existing results — all null**

- Specification curve (`07_specification_curve/specification_results.csv`):
  144 specifications, **0 FDR-significant features in any of them**.
- The p-value distribution is *depleted*, not merely non-significant. Summed
  across all 144 specs, MIA vs control gives **42 features at p < 0.01
  against 397 expected under the null** — a ~10× deficit. Sex in cortex
  (148 vs 132) is the only cell showing any excess, and sex is the effect that
  should be easiest to detect in brain lipidomics.
- PERMANOVA on BioGroup (`04_multivariate/permanova_by_region.csv`):
  p = 0.66 / 0.29 / 0.08 (cerebellum / cortex / hippocampus).
- PLS-DA permutation, full panel
  (`04_multivariate/plsda_permutation_diagnostics.csv`): p = 0.63 / 0.37 /
  0.10. The `top50` rows (p = 0.004–0.014) are **selection-biased** — the 50
  features were chosen using the full labelled data before permutation — and
  must not be reported as evidence. Flagging this here so it is not carried
  into the new run.
- Effect-size scale (`03_differential/differential_effects.csv`): median
  |log2FC| 0.15–0.25 against median SE 0.29–0.44, i.e. roughly |log2FC| > 0.9
  is needed to reach nominal p < 0.05.

**Adopted policy this plan would change**

- `2026-08-07-full-data-policy-change.md`: **all 60 samples are the analysis
  population**; mouse `C00431239 - 3` is no longer excluded;
  `SAMPLE_OUTLIER_EXCLUSIONS = ()`. Its rationale rests partly on "Hotelling's
  T² flagged nothing at 95%", which holds for the 10-PC screen it describes but
  not for the adopted 3-PC screen, where 5 samples are flagged. See Q2.
- `src/analysis_config.py`: `APPLY_PREVALENCE_FILTER = False`,
  `MAX_MISSING_FRACTION = 0.20`, `MIN_PER_CELL = 3`.
- `2026-08-31-missingness-overview-and-filtering-confounding-plan.md`:
  prevalence filter stays off "unless a separate decision changes it later".
  This plan is that separate decision, and needs to be recorded as one.

---

## 3. Part 0 — Blocking open questions

These must be answered before any code is written.

**Q1 — Does the `Mouse number` prefix identify the dam/litter?** *(still open,
but no longer blocking this run.)*
Or is it a cage, a shipment, an ear-tag batch, or a vendor accession? And what
are `C00` and `C01` (no suffix, both MIA males)? Needs confirmation from
whoever ran the animal work — it cannot be resolved from the delivered data.
Tracked as A1 in `doc/open-questions.md`.

Litter-aware modelling is **deferred** by user decision (2026-09-03), so this
question does not block implementation. It does still govern how the results
are *described*: until A1 is answered, this pipeline's models treat pups as
independent, and every write-up must carry that assumption explicitly rather
than silently.

**Q2 — The 95% T² rule removes 5 of 60 samples, and the design survives it.**
From `02_qc/outlier_screen_*.csv`, `hotelling_t2_95_flag` (3 PCs, per
`OUTLIER_SCREEN_PCS = 3`; limit 6.82 in every region):

| Region | Sample | Mouse number | Bio group | Sex | T² | >99% limit? |
|---|---|---|---|---|---|---|
| Cerebellum | 35 | `C00429562 - 5` | Saline Control | Male | 8.30 | no |
| Cortex | 25 | `C00431239 - 3` | MIA | Male | 10.95 | **yes** |
| Cortex | 37 | `C01` | MIA | Male | 9.01 | **yes** |
| Hippocampus | 6 | `C00431239 - 1` | MIA | Male | 7.21 | no |
| Hippocampus | 9 | `C00429562 - 2` | Saline Control | Male | 7.09 | no |

Resulting Group×Sex cell sizes — **every cell stays at or above
`MIN_PER_CELL = 3`**, so the Group×Sex interaction remains estimable in all
three regions:

| Region | MIA F | MIA M | Ctrl F | Ctrl M |
|---|---|---|---|---|
| Cerebellum | 5 | 5 | 5 | 4 |
| Cortex | 5 | **3** | 5 | 5 |
| Hippocampus | 5 | 4 | 5 | 4 |

This is a much better-behaved rule than the robust-Mahalanobis alternative,
which flags 17 of 60 (28%) and drops two cells to n=2. At 95% with n=20 across
three regions you expect ~3 flags under the null; 5 observed is consistent
with a correctly calibrated threshold, in contrast to the 5–6-per-region
over-flagging that `2026-08-07-full-data-policy-change.md` attributes to MCD's
false-positive rate at this n. **The T² rule is the defensible choice and no
calibration correction is needed for it.**

Remaining questions:

- **Q2a — ANSWERED 2026-09-03: sample-level exclusion only.** The five
  flagged samples are dropped from their own region; the same mouse's other
  regions are retained. This matters more than usual here:
  `C00431239` appears twice (sample 25 in cortex, sample 6 in hippocampus) and
  `C00429562` twice (35 cerebellum, 9 hippocampus), so whole-mouse exclusion
  removes 5 mice × 3 regions = **15** samples, not 5, and would drop cells
  below `MIN_PER_CELL`. Whole-litter exclusion would remove one of the only
  two control litters entirely. Sample-level exclusion avoids both, and the
  cell table above is exactly what it produces. **Reporting obligation:** the
  repeated appearance of `C00431239` and `C00429562` across two regions each
  must be stated — a mouse being flagged in two of three regions is weak
  evidence of a mouse-level problem even though we are not acting on it.
- **Q2b.** All five flagged samples are **Male**. That is either a real
  sex-linked variance difference or coincidence (p ≈ 0.03 under a naive
  binomial), but either way the exclusion removes male samples preferentially
  and shifts the sex balance — Cortex MIA Male drops to 3. This must be
  reported, and it weakens the interaction term specifically.
- **Q2c.** Only samples 25 and 37 exceed the **99%** limit. 95% (5 samples) or
  99% (2 samples)? At 99% the rule removes only the two samples the repo has
  already independently characterised as high-leverage. Recommendation: run
  95% as primary and 99% plus no-exclusion as variants — the cost is one loop,
  and it turns the threshold into a reported sensitivity rather than a hidden
  decision.
- **Q2d — ANSWERED 2026-09-03: exploratory sensitivity framing accepted.** Removing samples chosen by a covariance-based screen and then
  testing for group differences on the survivors is a selection step applied
  before inference. This run is exploratory / sensitivity by construction and
  cannot be reported as a primary confirmatory result. Confirm you accept that
  framing.

For the record, not a question: at 2 PCs the flag set differs (cerebellum 2,
cortex 2, hippocampus 1). The plan uses 3 PCs because
`analysis_config.OUTLIER_SCREEN_PCS = 3` already decides it. Note also that
`2026-08-07-full-data-policy-change.md` says "Hotelling's T² flagged nothing
at 95%" — true of the 10-PC screen it was describing, but not of the adopted
3-PC screen. Enabling a T² exclusion therefore contradicts that document and
needs a superseding note.

**Q3 — ANSWERED 2026-09-03: missingness is computed across all regions
(pooled over all 60 samples).** A lipid missing in more than 20% of the 60
samples is dropped, and the **same feature list is applied to every region** —
one tested universe, not three. Consequence to verify and report: the FDR
denominator becomes identical across regions, and a lipid that is well-measured
in one region can still be removed because it is absent in another. That is the
accepted cost of a single consistent panel.

**Q4 — ANSWERED 2026-09-03: missingness is computed BEFORE detection-limit
masking.** The prevalence rule is applied to `exclude_nonpositive(raw)` only —
the same basis as the 2026-08-31 raw missingness overview — so it is not
inflated by values that masking later turns into NaN. `exclude_below_detection`
runs afterwards, on the surviving features.

Implementation note: `exclude_low_prevalence_features` must be verified against
both answers before use. The existing `prevalence_filter_features.csv` flags 22
lipids; whether it was produced on this basis has **not** been confirmed, so it
is regenerated rather than reused.

**Q4a — ANSWERED 2026-09-03: filter first.** The prevalence filter runs
*before* sample exclusion, so ">20% missing" is measured over all 60 samples
including the 5 that are later dropped. The alternative — exclude samples
first, then compute prevalence over
the surviving 55 — gives a slightly different feature list. Filtering first is
proposed here because it keeps the feature universe independent of the outlier
rule, so the three T² variants (95%, 99%, none) share one panel and stay
directly comparable. This choice is adopted for the run.

**Q5 — ANSWERED 2026-09-03: reviewed; no treatment-group missingness signal detected.**
`2026-08-31-...-confounding-plan.md` was written specifically to test whether
missingness is confounded with Bio group. It was run and reviewed before this
filter was switched on: the exploratory per-sample Wilcoxon check reports
p = 0.7788 and the raw stage summary has no whole-table group asymmetry. This
is not a guarantee that no individual biological feature is removed.

**Q6 — Output location.** Proposed
`results/pipeline_test/<variant>/00_inputs/ … 07_specification_curve/`, with
`<variant>` ∈ {`prevalence20_t2_95`, `prevalence20_t2_99`,
`prevalence20_noexclusion`} (the last isolating the effect of the sample
exclusion) and **identical filenames across
variants**, per
the `doc/agent-rules.md` results-organisation rule. Confirm the root name, and
confirm this does not overwrite `results/mia_vs_control/`.

**Q7 — ANSWERED 2026-09-03: sensitivity analysis.** The filtered run
is a sensitivity analysis, `results/mia_vs_control/` stays primary and
`analysis_config.py` is **not** changed (variants are passed as parameters).
If it becomes primary, the config flags change and the earlier decision
documents need superseding notes. These are different amounts of work.

---

## 4. Part 1 — Configuration and pipeline changes (after Part 0 is answered)

Assumes the sensitivity-analysis answer to Q7; adjust if Q7 says otherwise.

1. `src/analysis_config.py` — do **not** flip the module-level constants.
   Instead add explicit parameters so a variant is selected at call time and
   the adopted primary policy stays visible and unchanged in the file.
2. `src/preprocessing.py` — `exclude_low_prevalence_features` already exists.
   Verify it against the answers to Q3/Q4 and adjust if it disagrees:
   missingness fraction computed **pooled over all 60 samples** (not per
   region), on `exclude_nonpositive(raw)` **before** detection-limit masking,
   producing **one feature list applied to all three regions**. Regenerate
   `prevalence_filter_features.csv` on this basis rather than reusing the
   existing 22-lipid file, whose basis is unconfirmed.
3. New `src/run_pipeline_variant.py` (name TBC) — orchestrates one variant end
   to end, in this fixed order (the order matters, per Q3/Q4):

   1. `exclude_nonpositive` on raw values;
   2. **prevalence filter** — >20% missing pooled over all 60 samples, one
      list for all regions;
   3. `exclude_blank_dominated_features` (3× mean-blank, adopted);
   4. `exclude_below_detection` value-level masking;
   5. **sample exclusion** — `hotelling_t2_95_flag`, sample level only;
   6. differential → aggregation → diagnostics.

   Writing into `results/pipeline_test/<variant>/`. One script,
   plain functions, no config framework (`research-code-style`).
4. Exclusion table: every dropped feature and sample recorded with its reason,
   per `doc/agent-rules.md` ("Keep a sample/feature exclusion table with
   reasons"). Written to `01_preprocessing/feature_exclusions.csv` and
   `02_qc/sample_exclusions.csv`.

Stage outputs follow the existing `00_inputs/ … 07_` layout so the filtered
run is directly comparable to `results/mia_vs_control/` file by file.

---

## 5. Part 2 — Differential analysis

Unchanged in form from the current pipeline, so results are comparable:

- Per region, per feature: `~ BioGroup * Sex`, OLS, with limma-moderated
  variance as the parallel model (`src/differential_moderated.R`).
- Report estimate, SE, 95% CI, raw p, BH-adjusted p, and the FDR denominator.
- Multiple-testing family: features within one region × one effect, as now.
- `MIN_PER_CELL` guard retained; features failing it in a variant are recorded
  in the exclusion table rather than silently dropped.

Under the T² rule no cell falls below `MIN_PER_CELL`, so the full
`~ BioGroup * Sex` model is estimable in all three regions and no region-
specific model reduction is needed. If a variant ever does drop a cell below
3, the fallback to `~ BioGroup + Sex` **must be stated in the output, not
handled silently** — a model that differs by region is a reporting obligation.

---

## 6. Part 3 — New analyses

Ordered by expected value. 6.1–6.3 are diagnostics that determine how to read
everything else; 6.4 is the only item with a realistic chance of a positive
finding.

### 6.1 p-value calibration diagnostic — *do this first*

The 10× deficit of small p-values described in §2 is the most informative
thing in the current results and is currently unexplained. Before any new
model is fitted:

- p-value histograms per region × effect, for the current and the filtered
  run, with the uniform expectation drawn on.
- Observed vs expected counts at p < 0.05, 0.01, 0.001.
- Residual diagnostics on a sample of features: normality, variance
  homogeneity across cells, and whether a small number of samples inflate SE
  across many features simultaneously.
- Cross-check against `02_qc/qc_injection_drift.csv` and
  `technical_vs_biological_variance.csv` for an unmodelled technical term.

Candidate explanations to test explicitly: imputation / detection-limit
masking inflating within-group variance; residual injection-order drift;
a small number of high-leverage samples widening SE globally.

**Caveat that must be stated in the output:** with ~955 strongly correlated
features the effective number of independent tests is far below 955, so
counts of small p-values are over-dispersed and a deficit in a single cell is
weak evidence on its own. That is exactly why 6.2 is needed.

### 6.2 Permutation null

Not for the reason usually given. BH is valid under positive dependence, so
correlation is **not** why nothing survived. The purpose here is
**calibration**: if the theoretical SEs are inflated (6.1), an empirical null
will be narrower and power is recovered.

- Permute the Bio-group label, stratified by Sex, for the Bio-group and
  interaction effects **within region**, at the **sample level** (consistent
  with litter-aware modelling being deferred). For the separate Female vs Male
  effect, permute Sex within BioGroup; otherwise the tested sex label would not
  change. Both schemes preserve the other factor's observed cell counts.
- **Caveat that must appear on the output:** if A1 confirms the litter
  structure, a sample-level permutation on litter-structured data gives an
  **anti-conservative** null — it treats littermates as exchangeable when they
  are not. The resulting empirical p-values are therefore a lower bound on the
  true ones. This is acceptable for the calibration purpose above (we are
  asking whether the *theoretical* null is too wide), but it is not a valid
  significance test for a positive finding.
- Write the permutation function so the exchangeability unit is a parameter,
  so a litter-blocked scheme can be swapped in later without a rewrite.
- Output: empirical null distribution of the per-feature test statistic, and
  an empirical-null FDR alongside BH.

**Explicitly not doing: Storey's q-value.** It estimates π₀ from the p-value
distribution; with a depleted distribution π₀ estimates at or above 1 and the
q-values come out *more* conservative than BH, not less. It cannot help here
and would be misleading to present as a less-conservative alternative.

### 6.3 Litter-aware model — DEFERRED

**Not implemented in this run** (user decision, 2026-09-03). Recorded here so
the reasoning is not lost, and tracked as B1 in `doc/open-questions.md`.

When it is taken up, two forms reported together: a mixed model with dam as a
random intercept (`~ BioGroup * Sex + (1|dam)`, per region) and a
litter-mean aggregation (collapse each litter to its mean profile, then test —
fully conservative, but leaves ~2 vs ~6 units). Both need A1 answered first,
and both would widen CIs relative to the current model. `statsmodels` MixedLM
covers it, so no new dependency.

**Consequence for this run, which must be stated in any write-up:** every
model here treats pups as independent observations. If A1 confirms that
littermates share a dam, these results are anti-conservative — the p-values
are smaller than a correct analysis would give. Given that nothing reaches
significance even so, the null conclusion is unaffected; a positive finding
would not survive that assumption.

### 6.4 Lipid-class and structural aggregation — *the best chance of signal*

`Lipid Class` annotation is already attached to the differential output. Test
aggregate summaries instead of individual species:

- Class sums / medians (~30 classes vs ~955 species) — far fewer tests, and
  per-species noise averages out.
- Structural indices per sample: mean chain length, mean double-bond count,
  PUFA fraction, saturated/unsaturated ratio — computed per class and overall.
- Same `~ BioGroup * Sex` model as §5 (sample level, per §6.3), BH within the
  aggregate family (which must be declared as its **own** multiple-testing
  family, separate from the species-level family — not a subset of it).

Open sub-question: aggregate on the log scale (mean of log2) or the linear
scale (sum of intensities, then log)? These answer different biological
questions — the second is dominated by abundant species. Recommend reporting
the log-scale mean as primary and stating the choice explicitly.

This is the standard interpretable readout in MIA brain-lipidomics work and is
the item I would prioritise if only one from Part 3 is run.

### 6.5 Detectable-effect-size statement

Converts a null result into a defensible claim about what the experiment could
ever have shown:

- Minimum detectable |log2FC| at 80% power, per region, at the observed SE
  distribution, at the sample level (n≈19 before exclusion). A litter-level
  (n≈8) version is reported only as an illustration of what the design would
  support if A1 confirms the litter structure — clearly labelled as such, since
  the litter model itself is deferred.
- Volcano plots (effect size vs −log10 raw p) with the detectability boundary
  drawn on — flagging that the y-axis is the **raw** p-value and no point
  crosses FDR.
- One summary sentence for the thesis, of the form already used in
  `2026-08-07-full-data-policy-change.md`.

### Explicitly NOT proposed

- **Lasso / Elastic Net / Random Forest.** ~900 features, ≤19 samples,
  PERMANOVA and full-panel PLS-DA already flat. Any apparent performance is
  overfitting; doing it defensibly needs nested CV with litter-grouped folds
  plus permutation, which costs weeks to confirm the null already in hand.
  `doc/agent-rules.md` forbids leaking mouse-level information across folds,
  which makes this harder still at this n.
- **WGCNA / correlation-module clustering.** Needs 20+ samples minimum for
  stable modules, realistically 30+. Class aggregation (6.4) delivers the same
  variance reduction without the instability.
- **Re-running PCA / PLS-DA / PERMANOVA for discovery.** Already done, already
  null. They will be re-run on the filtered matrix only as a comparability
  check, and the `top50` PLS-DA panels stay out of any results narrative.
- **Robust regression / Mann–Whitney as a pivot.** Outlier screening in this
  repo is already extensive; Mann–Whitney cannot express the Group×Sex design
  and is less powerful at this n. One robust-regression sensitivity check is
  reasonable; a switch of primary method is not.

---

## 7. Files this plan would touch

Under the `pipeline-test` worktree only:

- `src/analysis_config.py` — add variant parameters (no change to adopted
  defaults, per Q7).
- `src/preprocessing.py` — verify/adjust `exclude_low_prevalence_features`.
- `src/run_pipeline_variant.py` — **new**, variant orchestration.
- `src/diagnostics_pvalue.py` — **new**, 6.1.
- `src/permutation_null.py` — **new**, 6.2.
- `src/aggregate_lipid_classes.py` — **new**, 6.4.
- `src/power_analysis.py` — **new**, 6.5.
- `tests/` — targeted tests for the new aggregation, permutation-scheme, and
  prevalence-filter logic.
- `results/pipeline_test/<variant>/…` — **new** outputs.
- `doc/decisions/` — this file, plus a superseding note against
  `2026-08-07-full-data-policy-change.md` **only if** Q7 makes the filtered
  run primary.

Out of scope: `data/` (immutable), `notebooks/`, existing
`results/mia_vs_control/`, `.idea/`, any dependency change.

---

## 8. Validation

Real commands, to be run and their actual output reported:

```
/root/.virtualenvs/LPJ_lipidomics/bin/python -m pytest tests/ -q
/root/.virtualenvs/LPJ_lipidomics/bin/python src/run_pipeline_variant.py --variant prevalence20_t2_95
```

Plus explicit assertions inside the run script, so a silent population change
fails loudly (the pattern `2026-08-07-full-data-policy-change.md` established):

- assert the input sample count matches the variant's expectation
  (60 − 5 = 55 for `prevalence20_t2_95`);
- assert the surviving feature list is **identical across the three regions**,
  which is the observable consequence of the pooled prevalence rule and would
  silently fail if it were computed per region;
- assert the prevalence fraction was computed before detection-limit masking,
  by checking the input NaN count against the raw-missingness table;
- assert the tested-feature universe size equals the FDR denominator written
  to disk;
- assert every excluded sample and feature appears in the exclusion tables
  with a reason.

Figures via `plot_config.save_figure` (PDF + presentation PNG + manuscript
PNG in one folder), colourblind-safe palette, per `doc/agent-rules.md`.

---

## 9. Residual risks — to be stated in any write-up

1. **The filtered run is very unlikely to produce FDR hits.** 144
   specifications already produced zero, and the changes here move power both
   ways — the prevalence filter shrinks the tested universe (smaller FDR
   denominator, helps) while removing 5 samples costs degrees of freedom
   (hurts). The realistic outcome is a better-characterised null,
   not a positive result. Framing this as a rescue attempt would be
   misleading.
2. **Selection before inference.** Both the prevalence filter and the T²
   exclusion are data-driven choices made before testing. This run
   is exploratory by construction.
3. **The litter constraint is deferred, not resolved.** If A1 confirms two
   control litters, no model recovers the power that the breeding design did
   not provide. The correct output is a clear statement of that limit.
4. **Unexplained p-value depletion.** Until 6.1 identifies its cause, every
   p-value in this project — old and new — is of uncertain calibration. This
   is the reason 6.1 comes first.
