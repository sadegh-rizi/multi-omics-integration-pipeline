# Plan: exploratory multi-omics integration — what structure do lipids, metabolites and proteins share within a brain region?

**Status: IMPLEMENTED WITH CORRECTIONS 2026-10-13 (revision 2).**
Sadegh asked in a Cowork session for a plan for further integration work. He
then asked that it not centre on myelin but be exploratory: "see what is
found in general". Revision 1 (myelin-led) is superseded by this text.
Section §7 was confirmed for the Python exploratory scope on 2026-10-13,
with the R benchmark arm deferred until the `irlba` issue is resolved.

Builds on the CONFIRMED `2026-10-11-multiomics-integration-plan.md`:

- D2: imputed proteomics;
- D3: complete features (842 lipids / 177 metabolites);
- D8: all 60 samples only.

Outputs would go to
`results/mia_vs_control/16_integration_extensions/prevalence20_noexclusion/`,
one numbered subfolder per work package. Nothing existing is overwritten.
Nothing in `data/` is touched.

---

## 1. Why this design

- **Region already dominates the first integration.** The 11 Oct MOFA+
  spends its first factors on region (F1/F2 region R² ≈ 1.0). Region is
  settled by ASCA and region persistence. The open territory is how mice
  differ *within* a region, and whether the three omics agree on that.
- **The approach is open discovery, not one hypothesis.** The aim is to
  find whatever shared structure exists, then describe it:
  - what features carry it;
  - what it is enriched for;
  - what covariate, if any, explains it: sex, litter, collection date,
    tissue mass, run order, tissue composition, or MIA.
- **MIA is one covariate among several,** not the target.
- **Exploratory is not the same as unconstrained.** The *procedure* is fixed
  here before any result is seen: settings, nulls, stability and replication
  rules. The *findings* are not, so anything can come out. A result is only
  called a finding if it passes the §4.6 rules.

Out of scope, with reasons:

- gene-regulatory or correlation-network inference (not identifiable at 20
  mice / ~8 litters);
- deep generative integration (too few samples);
- any supervised MIA classifier (it will learn litters).

## 2. What an exploratory dry run showed (2026-10-12) — approximations

Cowork VM, numpy/pandas, all 60 samples, delivered proteomics (log2 MaxLFQ,
ND-imputed), within-region z-scores. No model was fitted.

- **The myelin signal is there.** The hippocampal lipid myelin index and the
  myelin proteins correlate r = 0.86 (from
  `2026-10-12-effect-size-estimation-evaluation.md`). This is one candidate
  axis the discovery step should rediscover unprompted; it is a sanity check,
  not the target.
- **Only oligodendrocyte markers co-vary as a set.** Mean inter-marker r
  within region:

  | Marker set | Cerebellum | Cortex | Hippocampus |
  |---|---|---|---|
  | Oligodendrocyte | 0.69 | 0.50 | 0.66 |
  | Astrocyte | 0.11 | −0.02 | 0.11 |
  | Neuron | 0.11 | 0.04 | 0.05 |

  Random protein sets give about 0.01 ± 0.06. Microglia markers are not
  detected; only Hexb, which is not specific. Composition can therefore be
  used as one annotation (oligodendrocyte content), not as a full cell-type
  breakdown.
- **Many lipid-metabolism enzymes are detected:** Ugt8, Fa2h, Cers1/2/6,
  Sptlc2, Smpd2/3, Asah1, Sgpl1, Gnpat, Agps, Far1, Ptdss1, Pcyt1a, Pcyt2,
  Chkb, Etnk1, Pgs1, Cds1/2, Fads1/2, Elovl5, Acsl1/3/4/6, Agpat1/3/4, Gpat4.
  Ganglioside synthases, Gal3st1, Sgms1/2 and Elovl1/4 are not detected.
  These detected enzymes serve as positive controls for the association
  screen.

## 3. The threats that decide whether any of this means something

1. **Shared tissue (A4, A13).** If lipids and proteins come from one
   homogenate, cross-omics agreement can reflect what was in the tissue piece
   (dissection, maturity), not independent biology. Every shared factor is
   annotated with its association with tissue mass, the oligodendrocyte
   score and litter before it is interpreted.
2. **Proteomics run structure (A12).** All discovery here is *within region*,
   which avoids region-level technical differences. Only the benchmark's
   region positive control (WP5) depends on A12.
3. **n = 20 per region.** A factor explaining less than about 5% of
   variance, or a correlation below |r| ≈ 0.45, is indistinguishable from
   noise at this size. The replication and stability rules (§4.6) exist
   because one region's 20 mice cannot carry a discovery alone.
4. **Many looks.** The screen (WP2) makes tens of thousands of comparisons.
   Nothing from it is reported pair by pair. Results are summarized as
   modules and enrichments against a pairing-shuffle null.
5. **DIABLO bug (G19).** It blocks only WP5's DIABLO arm and the Option 3
   re-run, not the discovery work.

## 4. Proposed analysis

### 4.0 WP0 — prerequisites

- Fix G19 in `R/integration/run_diablo.R` and re-run DIABLO and Option 3.
- Send A12, A4 and A13.

Discovery (WP1–WP3) does not wait for the replies. Its interpretation does.

### 4.1 WP1 — joint structure within region (primary discovery engine)

**1a. Multi-group MOFA+.**

- `mofapy2` with:
  - three views: lipids 842, metabolites 177, proteins 3,821;
  - three groups: the regions;
  - `center_groups=True`, so region means are removed;
  - 15 initial factors, drop threshold 0.02;
  - 10 seeds; a factor is stable if recovered in ≥ 8/10 seeds by absolute
    score correlation.
- Per stable factor:
  - variance explained per view × region;
  - top-loading features per view;
  - enrichment (WP3).

**1b. Per-region MOFA+ as a replication check.**

- One model per region, same settings.
- Factors are matched across regions by loading correlation, over features
  shared by all regions.
- A factor that appears independently in ≥ 2 regions counts as internally
  replicated (§4.6).

**1c. Negative controls.**

- 20 shuffles of sample pairing between views within region. Shared
  (multi-view) factors should disappear; view-specific ones remain.
- Seed and leave-one-litter-out (LOLO) refits: factors must persist.

### 4.2 WP2 — cross-omics association screen

**Feature level** (D2):

- Lipids are summarized into about 60–80 interpretable features per sample
  (each a log2 within-sample share or ratio, so normalization-invariant):
  - class and subclass totals;
  - ether vs ester;
  - acyl chain length bins;
  - unsaturation bins;
  - 20:4 and 22:6 content;
  - very-long-chain sphingolipids.
- Metabolites and proteins enter at feature level.

**Statistic:** within region, Spearman correlation of every lipid feature ×
protein, and of every lipid feature × metabolite, across the 20 mice.

**Summaries** (no single pair is reported as a finding):

1. **Count of pairs above |r| = 0.6 against the pairing-shuffle null**
   (200 shuffles). This answers whether the omics share more than chance.
2. **Modules.** Hierarchical biclustering of the thresholded association
   matrix, keeping only modules that are:
   - stable under litter bootstrap (resampling whole litters, ≥ 70%
     co-membership);
   - present in ≥ 2 regions.
3. **Module enrichment** (WP3): which protein pathways travel with which
   lipid features.

**Positive controls:** the pre-declared enzyme–product pairs below should
rank high:

| Enzyme | Lipid product |
|---|---|
| Ugt8, Fa2h | Hex1Cer, ST |
| Gnpat, Agps, Far1 | ether-PE share |
| Cers2 | ≥ C22 sphingolipids |
| Cers6 | C16 sphingolipids |
| Ptdss1 | PS |
| Pcyt2, Etnk1 | PE |
| Pcyt1a, Chkb | PC |
| Pgs1 | PG + CL |
| Fads2, Elovl5 | PUFA share |

If they do not rank high, the screen has no power and is reported as such.

### 4.3 WP3 — annotation and enrichment

- **Proteins:** over-representation of GO Biological Process, GO Cellular
  Component and Reactome terms among the top-loading proteins of each
  factor or module.
  - Hypergeometric test against a background of the 3,821 detected
    proteins (not the genome).
  - BH correction within each factor.
  - Gene-set files are downloaded once and versioned (D3).
- **Lipids:** enrichment of class, subclass, chain-length, unsaturation and
  ether categories among top-loading lipids, against the 842-lipid
  background. Annotation comes from the existing lipid names; LION-style
  categories are built in-house, with no web service.
- **Metabolites:** enrichment of the vendor's metabolite classes, if they are
  annotated (to check).

### 4.4 WP4 — covariate map ("what explains each axis?")

- For every stable factor (WP1) and every module score (WP2), report R²
  with:
  - sex;
  - litter (cage);
  - collection date;
  - tissue mass;
  - sample number (run-order proxy, A3);
  - the oligodendrocyte marker score;
  - MIA.
- **MIA** gets the cage-level Welch permutation (`treatment_score_test`,
  floor 1/28), with LOLO and 2024-06-11 checks, exactly like the other
  covariates. It is one row of the table, not the headline.
- **Output:** a factors × covariates heatmap. This is the main figure of the
  exploratory chapter.

### 4.5 WP5 — methods benchmark and cross-omics predictability (methods chapter)

**Benchmark.**

- **Methods:**
  - MOFA+;
  - MFA (FactoMineR);
  - mixOmics `block.spls`;
  - DIABLO (after WP0);
  - concatenated-block PCA as the baseline.
- **Scored on:**
  - region recovery (positive control);
  - MIA false positives (negative control): label permutation by whole
    cage; for DIABLO, training separation vs litter-grouped CV;
  - stability (seeds, LOLO, top-loading Jaccard);
  - litter-level spike-in recovery (1.25×, 1.5×, 2× in 5% of features, 100
    simulations per size; D7).

**Predictability.** Within region, how well each view's top-5 PCs are
predicted from another view, with ridge regression or PLS and
leave-one-litter-out CV, against a pairing-shuffle null. This gives one
number for how much the omics share beyond region.

### 4.6 Rules for calling something a finding (fixed now)

A factor or module is reported as a **finding** only if all of these hold:

1. it is stable (≥ 8/10 seeds for factors; ≥ 70% litter-bootstrap
   co-membership for modules);
2. it survives LOLO refits (loading correlation ≥ 0.8 with the full fit);
3. it exceeds the pairing-shuffle null (variance explained or association
   count above the 95th percentile of shuffles);
4. it replicates in ≥ 2 regions, by loading correlation ≥ 0.5 on shared
   features.

Anything passing 1–3 but not 4 is reported as **region-specific,
unreplicated**. Everything else is listed in a supplement as **not
distinguishable from noise**. Covariate explanations (WP4) are descriptive.
MIA associations are never upgraded beyond the cage-level test.

## 5. Files

**New:**
- `src/lpj_lipidomics/runners/run_mofa_within_region.py` (WP1a–c; reuses the
  loader of `run_integration_mofa.py`)
- `src/lpj_lipidomics/runners/run_cross_omics_screen.py` (WP2)
- `src/lpj_lipidomics/annotation/lipid_features.py` (lipid summary features
  and categories, WP2–WP3)
- `src/lpj_lipidomics/runners/run_integration_enrichment.py` (WP3)
- `src/lpj_lipidomics/runners/run_covariate_map.py` (WP4)
- `src/lpj_lipidomics/runners/run_integration_benchmark.py` and
  `R/integration/run_benchmark_blocks.R` (WP5)
- `data/reference/` — versioned gene-set files (GO/Reactome GMT), recorded
  with source URL, date and checksum (D3)
- `tests/test_integration_extensions.py`
- `results/mia_vs_control/16_integration_extensions/prevalence20_noexclusion/{01_mofa_within_region,02_cross_omics_screen,03_enrichment,04_covariate_map,05_benchmark}/`,
  each with `manifest.json`

**Changed:**
- `R/integration/run_diablo.R` (WP0)
- `doc/open-questions.md`
- `doc/analysis-state.md`

## 6. Validation

- **Unit tests:**
  - MOFA groups wiring on synthetic data, with one planted shared factor and
    one region-specific factor (both recovered, correctly labelled);
  - lipid summary features on toy names;
  - hypergeometric enrichment against a hand-computed case;
  - pairing shuffle keeps each view's own covariance;
  - spike-in injector exact when there is no noise.
- **Positive controls:**
  - the enzyme–product pairs in WP2;
  - the myelin axis should be rediscovered by WP1 without being asked for;
  - region in WP5;
  - DIABLO region accuracy ≥ 0.90 after WP0.
- **Negative controls:**
  - pairing shuffles (WP1, WP2, WP5);
  - whole-cage MIA label permutation (WP4, WP5).
- **Every count, p-value or "replicated" claim** is read via
  `/null-calibration`.

## 7. Decisions needed before implementation

**D1 — order of work.**
- (a) WP0 → WP1 → WP2 → WP3 → WP4 → WP5.
- (b) WP5 benchmark first.
- *Recommendation: (a).* Discovery first; the benchmark reuses its outputs.

**D2 — lipid feature level for the screen.**
- (a) about 60–80 summary features, with species only to describe modules;
- (b) all 842 species × 3,821 proteins (≈ 3.2 M pairs per region).
- *Recommendation: (a).* It is interpretable, cuts the multiple-comparison
  burden about tenfold, and matches the compositional nature of the data.

**D3 — gene-set source.**
- (a) download mouse GO and Reactome gene sets once (MSigDB mouse
  collections or Reactome GMT), store them under `data/reference/` with
  version and checksum, and use the project's own hypergeometric code;
- (b) `gseapy` with the online Enrichr service (new dependency, network,
  results drift).
- *Recommendation: (a).*

**D4 — finding rules (§4.6).**
- Accept as written, or change thresholds before any run.
- *Recommendation: accept.*

**D5 — covariate list (§4.4).**
- (a) as written;
- (b) add others, e.g. body weight if it exists (A11).
- *Recommendation: (a)*, plus any covariate that arrives from A11.

**D6 — role of the oligodendrocyte score.**
- (a) one annotation column in the covariate map;
- (b) also a covariate adjusted for in the screen.
- *Recommendation: (a)*, with (b) as a sensitivity analysis only if a module
  is dominated by it.

**D7 — spike-in simulation in WP5.**
- (a) yes: 1.25 / 1.5 / 2×, 5% of features, litter-level, 100 simulations
  per size;
- (b) no.
- *Recommendation: (a).*

**D8 — benchmark methods.**
- (a) MOFA+, MFA, block.spls, DIABLO, PCA;
- (b) also SNF (`snfpy`, new dependency).
- *Recommendation: (a).*

**D9 — metabolomics view.**
- (a) include (177 complete features);
- (b) lipids and proteins only.
- *Recommendation: (a).*

**D10 — populations.** All 60 only, as in the 11 Oct plan D8.
- *Recommendation: keep.*

## 8. Implementation record

Confirmed 2026-10-13 for the current generation event:

- Bugs 1–4 were corrected: factor recovery requires `|r| >= 0.8`, the
  oligodendrocyte score is standardized within region, predictability uses
  fold-local PCA and pooled out-of-fold R², and modules use correlation
  distance (`1 - r`).
- Protein enrichment uses top 5% loadings as primary and top 10% as a
  sensitivity analysis.
- The R MFA/mixOmics benchmark arm remains deferred because of the `irlba`
  failure. DIABLO and spike-ins remain out of this generation event.
- Remaining plan items not regenerated here include LOLO refits, the observed
  MOFA shared-factor shuffle statistic, enzyme-product controls, lipid-category
  enrichment, and a fully executable R benchmark.
- Implementation provenance is recorded in
  `prompts/2026-10-13-integration-bug-fixes-v1.md`.

## 9. Assumptions and limitations

- Proteomics is the delivered ND-imputed matrix. Imputed values damp
  correlations.
- `ST` is assumed to be sulfatide; ether lipids are not split O-/P- (A10).
- Lipid data are compositional. Summary features are within-sample shares.
- With 20 mice per region, correlations have 95% CIs of about ±0.4. Only
  strong, replicated structure can be found; weak biology will be missed.
  That is stated as a limit, not reported as absence.
- The C1–C8 panel is unblinded (E6/E9). If a discovered factor resembles a
  composite, that is noted, not counted as confirmation.
- Enrichment uses top-loading features. The cut-off (top 5% per view) is
  fixed here, and sensitivity at 10% is reported.
- Dry-run numbers in §2 are feasibility checks with normal approximations,
  not results.
