# MIA vs control lipidomics: analysis plan

Date: 2026-07-21
Status: implemented; preprocessing and stable downstream analyses regenerated 2026-08-05

## Question

Does prenatal maternal immune activation (MIA) produce lipidomic differences in
offspring brain that could underlie later neurological consequences? The primary
deliverable is a list of lipids that differ between MIA and Saline Control,
per brain region, with sex examined as both a main effect and an effect
modifier (MIA x Sex).

Secondary: how much of the overall sample-to-sample variation is attributable
to MIA/control status vs. region vs. sex, and whether the MIA signature
differs across brain regions (rather than treating "are regions different"
as a standalone question — regions are structurally very different tissue
types and are expected to separate strongly on their own).

## Study design (confirmed from `data/1 MB2_088_Lalowski_Report_Final.xlsx`)

- 20 mice: 10 Saline Control, 10 MIA.
- 3 brain regions per mouse (Cerebellum, Cortex, Hippocampus) -> 60 lipidomics
  samples total, one sample per mouse per region.
- Sex balanced within each Region x BioGroup cell (5 Male / 5 Female).
- Each mouse contributes 3 correlated samples (one per region) -> region-level
  or pooled-region analyses are repeated-measures, not independent replicates.
- 992 lipid features, already QC-filtered by the core to <40% CV across
  technical replicates (row 1 of the Lipidomics sheet). Blank and Tech-Mix QC
  columns are present and excluded from sample-level analysis.

## Data provenance (verified by inspecting the workbook directly)

- The `MB2_088-##` sample columns are **raw peak areas**, not normalized or
  scaled. No auto-scaled or median-normalized version of the per-sample data
  exists in the file.
- Columns 78-95 of the Lipidomics sheet are a **group median summary table**
  (median intensity per Region x BioGroup, and per Region x BioGroup x Sex) —
  this is a reporting summary, not a normalization applied to the analysis
  data. It can be used as a sanity check against medians we compute ourselves,
  but is not an input to modelling.
- `doc/lipidomics.md`'s "Normalized by median" / "Auto-scaled" notes describe
  two normalization *options*, not something already applied in this file. We
  apply normalization ourselves, explicitly, below.

## Preprocessing (to be applied by us; nothing in `data/` is modified)

- Exclude non-positive / non-numeric intensities per feature-sample cell,
  consistent with `notebooks/sandbox.ipynb`'s existing convention. Missing
  values are not imputed. Open item: revisit if a differential test's
  per-group n drops too low due to exclusions.
- For differential testing (fold-change must be preserved): log2-transform,
  then median-normalize per sample.
- For PCA / PERMANOVA / distance-based variance partitioning: the above,
  plus auto-scaling (mean-center, unit variance) per lipid feature.
- Both pipelines are computed from the same raw input; only the final scaling
  step differs by downstream use.

## Analysis plan

1. **MIA vs control, primary.** Per lipid, per region, independently
   (60 samples split into 3 regions x 20 mice; one sample per mouse per
   region, so within a region the 10 vs 10 comparison is independent across
   mice). Model: `log2_intensity ~ BioGroup + Sex + BioGroup:Sex`. Extract the
   BioGroup coefficient (MIA main effect) and BioGroup:Sex interaction per
   lipid. BH-FDR correction applied within each region's test family
   (992 lipids), separately per region — 3 correction families, not one
   pooled universe.

2. **Sex.** Same model as (1) gives both the Sex main effect and the
   BioGroup:Sex interaction per lipid per region, addressing "what are sex
   differences" and "does the MIA effect differ by sex" in one pass.

3. **Pooled sensitivity check.** Mixed model across all 60 samples:
   `log2_intensity ~ BioGroup*Region + BioGroup*Sex + (1 | Mouse)`. With 20
   mice this is underpowered for interaction terms specifically — treat as a
   direction-of-effect sensitivity check, not a primary p-value source.

4. **Region, reframed.** Not tested as "are regions different" in isolation
   (expected trivially significant). Instead: compare per-region MIA effect
   sizes/hit-lists from (1) across regions to see whether the MIA signature is
   concentrated in a particular region.

5. **Variance partitioning.** PERMANOVA on the auto-scaled matrix, run
   separately per region. See "PERMANOVA method detail" below for the model,
   distance metric, permutation scheme, and implementation options.


## PERMANOVA method detail

### What it computes

Applies the same logic as ordinary ANOVA (partition variance into
between-group and within-group, compare as a ratio) to a multivariate
distance matrix instead of a single measured value, since each sample has
~992 lipid features rather than one number. Uses permutation to build the
null distribution of the resulting F-ratio ("pseudo-F"), rather than
assuming an F-distribution, since multivariate normality can't be assumed
for lipid intensities. Reports R^2 per model term: the fraction of total
sum-of-squared distances attributable to that term — the direct answer to
"how much does control/MIA drive the variation between samples."

### Model

Per region (primary analysis — 20 independent mice per region, no
repeated-measures issue within a single region):

`distance ~ BioGroup + Sex + BioGroup:Sex`

Sequential (Type I) sum-of-squares, matching R's `vegan::adonis2(..., by =
"terms")` convention: each term's SS is computed conditional on the terms
already in the model, in the order listed. Report the term order explicitly
(BioGroup first, as the primary question) and note that reordering changes
each individual term's R^2, though not the total explained.

Distance metric: Euclidean distance on the auto-scaled matrix (output of
`preprocess_for_multivariate`) — pairs naturally with the PCA already run in
`sandbox.ipynb`, which is also Euclidean-based (SVD on the same scaled
matrix), keeping PCA and PERMANOVA geometrically consistent.

### Permutation scheme

- **Per-region PERMANOVA:** free permutation is valid. The 20 samples in a
  region come from 20 different mice, so there is no repeated-measures
  structure to protect within a single region.
- **Pooled/omnibus cross-region PERMANOVA** (all 60 samples, if run — still
  an open item below): BioGroup and Sex are mouse-level properties, constant
  across a mouse's 3 region-samples. Naive per-sample permutation would let
  same-mouse correlation masquerade as a group effect (pseudo-replication).
  The correct restricted scheme permutes whole mice — reassign the
  BioGroup/Sex label once per mouse, then propagate it to all 3 of that
  mouse's region-samples. This is not the same as `vegan`'s `strata=`
  argument (which restricts permutation to *within* strata); what's needed
  here is closer to permuting the experimental unit itself, i.e. a
  repeated-measures/blocked permutation design. It needs a hand-written
  permutation loop — it isn't a single off-the-shelf option in the
  Python distance-based ANOVA tools checked so far.

### Implementation options — not yet decided

No actively-maintained multi-term PERMANOVA with per-term R^2 and custom
(mouse-blocked) permutation currently ships in the existing dependency set
(`numpy`, `pandas`, `scipy`, `matplotlib`, `openpyxl`). `scikit-bio`'s
`permanova` only supports a single one-way grouping factor, not the
`BioGroup + Sex + BioGroup:Sex` sequential model needed here. Two realistic
paths when `variance.py` implementation starts:

- (a) write a small custom sequential-SS + permutation implementation on
  top of `scipy`/`numpy` directly — no new dependency, full control over
  the mouse-blocked permutation.
- (b) add a package (e.g. `scikit-bio`) for distance-matrix utilities while
  still hand-writing the multi-term/blocked-permutation logic on top.

This is a dependency decision and needs sign-off per `AGENTS.md` before any
`requirements.txt` change — not decided here, only flagged for when
`variance.py` implementation actually starts.

### Output

Report per term, per region: pseudo-F, R^2, permutation p-value, and number
of permutations used. Multiple-testing family for this (across 3 regions x
however many terms) is a separate, still-open decision from the per-lipid
FDR already specified for the differential-abundance tests in item 1 above.

## Framing

All of the above is exploratory (hypothesis-generating), consistent with the
sample size (n=10/group/region) and `doc/agent-rules.md`. Report raw and
FDR-adjusted p-values, effect sizes, and the correction universe for every
test family. No causal or confirmatory claims from PCA/PERMANOVA separation
alone.

## File layout (confirmed 2026-07-21)

Flat `src/` modules (no package directory) — matches `src/plot_config.py`,
which was added independently via PyCharm/GPT-5.5 while this plan was being
drafted:

- `src/preprocessing.py` — positive-value filtering, log2 + median
  normalization, auto-scaling. Implemented; 9/9 tests passing.
- `src/plot_config.py` — shared Matplotlib style and categorical colour
  encodings (Sex/BioGroup/Region). Pre-existing, not part of this plan.
- `src/diffexp.py` (not yet started) — per-lipid linear model fitting, FDR
  correction, results table assembly.
- `src/variance.py` (not yet started) — PERMANOVA wrapper with
  mouse-blocked permutation option.
- `notebooks/sandbox.ipynb` (or a new `notebooks/mia_vs_control.ipynb`)
  orchestrates: calls the module functions, inspects diagnostics, produces
  figures. Notebook does not contain the modelling logic itself.
- `tests/` — synthetic fixtures (no real data), one test file per module.
  `tests/conftest.py` adds `src/` to `sys.path` (no editable install / no
  packaging changes). `pytest>=7` added to `requirements.txt` for this.

Note for multi-tool coordination: since GPT-5.5/PyCharm and Claude are both
writing into `src/` concurrently, check `git status` for new files before
adding another module here — this plan doc will fall out of sync if files
appear without a corresponding update to this section.

## Validation

- `pytest -q tests/` once the module + fixture exist.
- Execute the affected notebook cells and inspect printed diagnostics
  (sample counts, excluded features, correction universe size per family).
- Cross-check a handful of our computed group medians against the workbook's
  own "Median" summary block (columns 78-95) as an independent sanity check.

## Open items still pending explicit confirmation

- Missing-value handling if per-group n drops due to exclusions — currently
  "exclude, do not impute."
- Whether a pooled omnibus PERMANOVA (in addition to the per-region ones) is
  wanted for this pass, given the mouse-blocked permutation caveat.
- PERMANOVA implementation approach: custom scipy/numpy code vs. adding a
  new dependency (e.g. scikit-bio) — decide when `variance.py` starts.
- Multiple-testing family for the PERMANOVA terms/regions (separate from
  the per-lipid FDR already fixed for differential-abundance testing).

## Progress log

- 2026-08-05: Added six-blank, value-level detection-limit preprocessing before log2 transformation: values below `max(3 * mean_blank, 1.0)` become missing, never imputed. This is documented as reverting inferred gap-filled non-detects; the vendor's gap-filling setting remains unverified. The observed scope was 921/59,520 biological values (772 blank-derived, 149 absolute-floor) across 97 lipids; five features were entirely below detection. Regenerated OLS, limma, PERMANOVA, technical-variance QC, differential inputs, and dependent figures. The pooled mixed-model sensitivity output was deliberately not regenerated because of its documented widespread non-convergence.

- 2026-07-21: `src/preprocessing.py` implemented (exclude_nonpositive,
  log2_transform, median_normalize, drop_zero_variance_features, autoscale,
  preprocess_for_differential, preprocess_for_multivariate). Tests in
  `tests/test_preprocessing.py`, 9/9 passing (`pytest -q`). Flat `src/`
  layout adopted to match `src/plot_config.py`. `pytest>=7` added to
  `requirements.txt`. Not yet run inside the project's actual WSL venv —
  only verified in an isolated sandbox interpreter; re-run
  `pip install -r requirements.txt` and `pytest -q` in the real
  environment before relying on this.
