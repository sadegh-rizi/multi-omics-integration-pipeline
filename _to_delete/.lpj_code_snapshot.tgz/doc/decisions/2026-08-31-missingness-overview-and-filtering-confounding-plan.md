# Plan: raw missingness overview and treatment-group confounding report

Prompted by feedback received after the 4th presentation
(`doc/presentations/2026-08-27-meeting04-lipidomics.pptx`), ahead of the 5th
meeting (2026-09-03). This is a **reporting/diagnostic plan only** — nothing
here changes which filters are adopted for the primary analysis
(`APPLY_PREVALENCE_FILTER` stays `False`, `MAX_MISSING_FRACTION` stays 0.20
unless a separate decision changes it later). It answers "what does the
missingness look like, and is it confounded with treatment group" before any
removal, imputation, or filtering decision is revisited.

**Explicitly out of scope for this plan** (raised in the same feedback,
deferred to a later plan): the NMF bias-check analysis, and a lipid-named
version of the PCA loading-composition stacked bar chart
(`src/run_loading_composition.py`).

## Feedback this addresses

1. A missingness report across lipids and samples — an overview, produced
   before any removal/imputation/filtering.
2. Whether control and treatment (Bio group) get filtered differently in
   practice — insight into which samples carry blank/missing lipids, which
   lipids carry the most missingness, and whether there are confounding
   factors — before any filtering decision.
3. When the existing value-level and feature-level ("whole lipid") filters
   are applied, report how much missingness results, and confirm that
   missingness removed by those filters isn't concentrated in one Bio group.

## What already exists (not duplicating this)

- `src/preprocessing.py`: `exclude_nonpositive` (value-level, non-positive →
  NaN), `exclude_blank_dominated_features` (feature-level, 3× mean-blank
  rule), `below_detection_reasons` / `exclude_below_detection` (value-level,
  detection-limit masking), `exclude_low_prevalence_features` (feature-level,
  >20% missing — implemented but **not applied**, `APPLY_PREVALENCE_FILTER =
  False` in `src/analysis_config.py`).
- `results/mia_vs_control/01_preprocessing/`: `blank_dominated_features.csv`,
  `detection_limit_exclusions.csv` (per Sample × Feature × Region, **no Bio
  group column**), `detection_limit_exclusions_by_lipid_class.csv`
  (class-aggregated, **no Bio group column**),
  `detection_limit_fully_excluded_features.csv`,
  `prevalence_filter_features.csv` (22 lipids flagged at >20%, not applied),
  `preprocessing_diagnostics.csv` (`n_lipids_input=992,
  n_blank_dominated_removed=11, n_lipids_multivariate=977,
  n_below_detection_cells=412`).
- None of the above is broken out by Bio group, and none reports missingness
  on the **raw, pre-filter** data — every existing number is post-filter.
  Both gaps are what this plan closes.
- Possible pre-existing data-quality artifact to sanity-check while this code
  is written: `detection_limit_fully_excluded_features.csv` has 4 data rows,
  and the last one (`742, Lipid Name, Lipid Class`) looks like a duplicated
  header written as if it were a feature row. Flag and report, don't silently
  fix — confirm against `n_below_detection_cells`-derived counts first.

## Part 1 — Raw missingness overview (before any filtering)

Computed on `exclude_nonpositive(raw)` only: all 992 lipids × 60 samples,
non-positive/non-numeric values set to NaN, nothing else touched (no blank
filter, no detection-limit masking, no prevalence filter).

Outputs (`results/mia_vs_control/02_qc/missingness/`):

- `missingness_by_lipid.csv` — Feature, Lipid Name, Lipid Class, n_missing,
  pct_missing (of 60), sorted descending.
- `missingness_by_sample.csv` — Sample, Sample number, Sample type (Region),
  Bio group, Sex, n_missing, pct_missing (of 992).
- `missingness_summary.csv` — overall % cells missing, % lipids fully
  complete, % samples fully complete, % lipids fully missing (if any).

Figures (`.../missingness/figures/`, via `plot_config.save_figure`):

- `missingness_per_lipid_histogram` — distribution of % missing per lipid.
- `missingness_per_sample_histogram` — distribution of % missing per sample,
  colored/faceted by Bio group so the confounding question is visible in the
  same figure.
- `missingness_heatmap` — lipids-with-any-missingness (rows, grouped by Lipid
  Class) × samples (columns, ordered by Region then Bio group), binary
  present/missing. This is the figure that most directly answers "which
  samples have these lipids blank."

## Part 2 — Confounding check (descriptive-first, lightweight)

Per your call: descriptive tables/plots as the primary output, with one
simple exploratory test per comparison — not a formal model, not
multiple-testing corrected, reported as a hint not a claim (consistent with
how the rest of this repo labels exploratory results).

On the same raw pre-filter missingness matrix from Part 1:

- `missingness_by_sample_and_group.csv` — mean/median/IQR of per-sample %
  missing by Bio group (and, secondarily, by Region and Sex). One Wilcoxon
  rank-sum test, MIA vs control, on per-sample % missing.
- `missingness_by_class_and_group.csv` — pivot of % missing by Lipid Class ×
  Bio group. One chi-square (or Fisher's exact where counts are small) test
  per class on pooled missing-vs-observed counts, MIA vs control.
- Region and Sex get the same descriptive tables (mean % missing per cell);
  no formal test for these unless the descriptive numbers make one worth
  asking for.
- Plot: box/strip plot of per-sample % missing, one panel per Region, points
  colored by Bio group (`BIO_GROUP_COLORS` from `plot_config.py`) — the main
  "is missingness confounded with treatment" figure.

## Part 3 — Missingness impact of each filter, split by Bio group

For each filtering stage, recomputed independently in the new script (not by
editing the existing pipeline output — see Implementation), report n_lipids
remaining / n_cells affected / % affected, plus a Bio-group breakdown:

- **Value-level (below-detection masking).** Re-derive
  `below_detection_reasons` and join to Bio group (this table currently only
  carries Region). Report masked-cell counts and % by Bio group × Region.
- **Feature-level, blank-dominated (11 lipids).** For each removed lipid,
  report the per-Bio-group median biological intensity (not just the pooled
  median the filter itself uses) — so we can see whether a "background"
  lipid is genuinely low in both groups or only in one, which the filter
  itself can't distinguish since it uses a single pooled median.
- **Feature-level, prevalence (22 lipids flagged, not applied).** Same
  per-Bio-group breakdown for each of the 22: is the >20% missingness that
  flags it spread across both groups or concentrated in one? A lipid whose
  missingness is concentrated in one group is a candidate for being *signal*
  (a group-specific absence) rather than noise, and that's worth knowing
  before anyone decides to turn the filter on.
- **Stage summary table** — `filtering_stage_summary.csv`: raw → blank-filter
  → detection-limit-masked → prevalence-filter-if-applied, with n_lipids,
  n_cells_missing, pct_missing, and the largest observed
  `|pct_missing_MIA - pct_missing_control|` at each stage, so group asymmetry
  across the whole pipeline is visible in one table.

## Implementation

New files:

- `src/missingness.py` — reusable, generic functions: `missingness_by_feature`,
  `missingness_by_sample`, `missingness_by_group` (takes any boolean
  missing/exclusion mask + metadata + a grouping column, so it works for Bio
  group, Region, or Sex without three near-duplicate functions), and
  `filtering_stage_summary`.
- `src/run_missingness_report.py` — orchestrates Parts 1–3: reads the
  workbook via `lipidomics_io.read_lipidomics_tables` /
  `lipidomics_measurement_columns`, builds metadata the same way
  `run_mia_vs_control.full_analysis_metadata` does (60-sample population,
  current adopted policy), calls `src/preprocessing.py`'s existing filter
  functions to reproduce each stage's mask, and writes the CSVs/figures
  above. Does **not** edit `run_mia_vs_control.py` or any existing output —
  it independently recomputes the same masks from the same functions, so the
  settled pipeline numbers are never at risk of changing.
- `tests/test_missingness.py` — unit tests on small synthetic intensity
  frames with a known missing pattern and a 2-level group column, asserting
  exact % and grouped counts, plus one test that
  `run_missingness_report`'s post-filter counts reproduce
  `preprocessing_diagnostics.csv`'s existing `n_blank_dominated_removed=11`
  and `n_below_detection_cells=412` exactly (internal consistency check
  against the settled pipeline).

Output location: `results/mia_vs_control/02_qc/missingness/`, tables at that
level and figures in `figures/` beneath it, per the numbered-stage /
figures-subfolder convention in `doc/agent-rules.md`. Figures saved as PDF +
presentation PNG + manuscript PNG via `plot_config.save_figure`, colorblind
palette, Bio group encoded with `BIO_GROUP_COLORS` plus a non-color cue
(marker shape or panel) rather than color alone.

## Validation

- `pytest tests/test_missingness.py`
- Run `src/run_missingness_report.py` and confirm: total lipids = 992, total
  samples = 60; `n_blank_dominated_removed` and `n_below_detection_cells`
  from the new report match `preprocessing_diagnostics.csv` exactly (11 and
  412) as an internal consistency check that the independently-recomputed
  masks agree with the settled pipeline.

## Residual risks to state alongside the results

- Per-sample missingness comparisons treat the 60 samples as independent
  observations. They aren't fully independent — each mouse contributes 3
  correlated samples across regions — so the Wilcoxon test in Part 2 is a
  descriptive/exploratory signal, not a mouse-level inferential claim.
- The blank-dominated and prevalence filters both use a single pooled median
  across all samples. The per-Bio-group breakdown in Part 3 is diagnostic —
  it does not mean the filters themselves are "biased" toward a group, only
  that we can now see when a removed/flagged lipid's low signal or
  missingness happens to sit mostly in one group.
- No multiple-testing correction is applied to the Part 2 tests (one
  Wilcoxon, one chi-square/Fisher per class) since these are exploratory
  screens, not a confirmatory family — consistent with how the rest of this
  repo separates exploratory diagnostics from the pre-registered differential
  testing family.

## Decisions already made (not open questions)

- Deliverable is code + result tables + figures only, matching every other
  analysis in this repo — no slides.
- Confounding analysis is descriptive-first with one simple, uncorrected test
  per comparison; not a formal model.
- NMF and the lipid-named PCA loading-composition chart are deferred to a
  separate plan.
- Git branching/staging for this and the prior in-flight work on
  `task/mahalanobis-calibration-fix` is being handled by the user directly;
  this plan file was added without creating a branch or committing.

## Awaiting explicit go-ahead

Per `doc/agent-rules.md` / `.claude/skills/careful-planning/SKILL.md`, no code
in `src/` or `tests/` will be written until this plan is explicitly confirmed.
