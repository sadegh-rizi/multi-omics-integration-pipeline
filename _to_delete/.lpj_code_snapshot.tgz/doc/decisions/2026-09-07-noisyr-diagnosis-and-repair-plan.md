# Plan: noisyR cross-check diagnosis and repair

**Status: PROPOSED 2026-09-07 — diagnosis complete, implementation NOT
authorized.** No code has been changed. This document records why the noisyR
cross-check (`doc/decisions/2026-08-26-cross-modality-outliers-loadings-noisyr-plan.md`
Part C) returns unusable results, and proposes an ordered repair. Confirm the
scope before any implementation, per `/careful-planning`.

Nothing in `results/` is to be overwritten by this work until a variant path is
agreed (see §6).

---

## 1. What is currently wrong

Three independent defects, in increasing order of scientific consequence.

| # | defect | consequence |
|---|---|---|
| D1 | A failed run is written to the results table as the number `0.0` | `noisyr_comparison.csv` publishes a fabricated threshold difference of −9.95 log2 |
| D2 | Missing values propagate through the windowed correlation | 2 of 4 scopes produce a curve that is 100% `NA`; 33 of 36 parameter combinations fail |
| D3 | The similarity-versus-abundance curve is not monotone, so the "first crossing of 0.25" rule fires at the lowest window | The manual noise threshold is the bottom of the abundance range — i.e. "filter nothing" — in all three regions |

D3 is the one that matters. D1 and D2 are mechanical.

---

## 2. Evidence

All figures below were measured from the delivered inputs in
`results/mia_vs_control/02_qc/noisyr_work/` and
`results/mia_vs_control/02_qc/abundance_similarity_curve.csv` on 2026-09-07.

### D1 — a failure reported as a value

`noisyr_comparison.csv` records, for cerebellum and hippocampus:

```text
status                                  = no_finite_noisyr_similarity
noisyr_threshold_log2_abundance_median  = 0.0
threshold_difference_log2               = -9.951 / -9.842
```

Those runs produced no threshold. `0.0` is a default being written where `NA`
belongs, and the difference column is then computed from it. The `techmix` and
`cortex` rows carry an empty threshold and an empty difference, which is the
correct behaviour — so the handling is inconsistent as well as wrong.

### D2 — missing-value propagation

The count of missing cells is not the problem; their **spread across the
abundance ranking** is.

| scope | NaN cells | features with ≥1 NaN | span of abundance ranking | finite curve points delivered |
|---|---|---|---|---|
| cerebellum | 117 | 34 of 987 | 57% | **0 of 45** |
| cortex | 191 | 48 of 987 | 69% | 42 of 42 |
| hippocampus | 138 | 37 of 987 | 86% | **0 of 45** |
| techmix | 38 | 16 of 987 | 39% | 44 of 44 |

`n.elements.per.window = 100` on a 987-feature panel makes each window 10% of
the range, so nearly every window contains at least one NaN-bearing feature.
R's `stats::cor()` defaults to `use = "everything"`, which returns `NA` if
either vector contains a single `NA`.

Simulating that rule on the delivered input matrices reproduces the observed
pass/fail pattern: at `window = 100, step = 20` it kills 45/45 cerebellum rows,
45/45 hippocampus rows, 40/45 cortex rows and 25/45 techmix rows. It also
reproduces the window-size sensitivity — at `window = 25` the kill rate falls
to ~91% — which is why `noisyr_parameter_sensitivity.csv` shows sporadic
survival at small windows and none at large ones.

`R/run_noisyr_crosscheck.R` compounds this at the final step:

```r
median_pearson = apply(summary$expression.levels.similarity, 1, median)
```

R's `median` defaults to `na.rm = FALSE`, so one `NA` nulls a curve point even
when 19 of 20 samples computed successfully.

### D3 — the curve is not monotone

noisyR's threshold rule assumes sample-to-sample similarity rises with
abundance, and takes the first window where it exceeds 0.25. The observed
curve is J-shaped:

| region | first window | trough | top | Pearson(abundance, similarity) |
|---|---|---|---|---|
| Cerebellum | 0.443 | 0.111 @ log2 13.6 | 0.784 | 0.660 |
| Cortex | 0.409 | 0.169 @ log2 15.1 | 0.786 | 0.796 |
| Hippocampus | 0.439 | 0.133 @ log2 11.8 | 0.811 | 0.716 |

Because the first window already exceeds 0.25, the rule fires at window index 0
and returns the lowest abundance present. This is exactly what
`abundance_similarity_thresholds.csv` records —
`threshold_window_index = 0.0` for the `pearson_gt_0_25` rule in every region —
and it is why the manual thresholds are 9.95 (cerebellum), 9.51 (cortex) and
9.84 (hippocampus) log2.

**The spike is shared background, not shared biology.** At the bottom of the
abundance range every sample is measuring the same blank/carryover signal, so
samples correlate with each other there. This is a false positive for the
method's core assumption. Two observations pin it down:

- masking only the extreme gap-filled non-detects (values < 0 log2, ~20 cells
  per region) does **not** remove the spike — the first window stays at
  0.39–0.45;
- masking the whole sub-detection band (values < 9.9 log2) **does** — the first
  window falls to 0.167 / 0.205 / 0.155, below the 0.25 threshold, and the
  curve becomes monotone. For cortex and hippocampus the first crossing and the
  sustained crossing then coincide.

### Thresholds under each rule

Authoritative current values, from `abundance_similarity_thresholds.csv`:

| rule | Cerebellum | Cortex | Hippocampus |
|---|---|---|---|
| `pearson_gt_0_25` (current default) | 9.95 | 9.51 | 9.84 |
| `pearson_gt_0_50` | 20.30 | 18.88 | — |
| `pearson_90pct_plateau` | 9.95 | 18.55 | — |
| `bio_tech_gap_le_0_05` | 11.91 | 11.46 | — |

Approximate reproduction from this diagnosis (a simplified re-implementation of
the windowing, **not** the repo's curve code — it sits ~1.4 log2 above the
official `pearson_gt_0_25` values and the implementer must re-derive these with
`abundance_similarity.py` rather than copy them):

| rule / input | Cerebellum | Cortex | Hippocampus |
|---|---|---|---|
| first crossing, raw input | 11.33 | 10.81 | 11.28 |
| first crossing, detection-masked input | 15.73 | 12.04 | 12.33 |
| sustained crossing (5 consecutive windows), raw input | 17.44 | 15.97 | 16.90 |

For cross-reference: where the noisyR package itself completed, its own
`Boxplot-IQR` estimator returned 17.15–18.38 (cortex) and 14.93–16.00
(techmix) — the same neighbourhood as the sustained-crossing rule. **The
package's threshold estimator is not the fragile part; the 0.25 first-crossing
rule used for comparison is.**

---

## 3. Proposed repair, in order

### R1. Report failures as failures (fixes D1)

Write `NA`, not `0.0`, when no threshold was obtained, and leave
`threshold_difference_log2` empty in that case. Add an assertion that a
non-`completed` status cannot carry a finite threshold.

### R2. Pairwise-complete correlation with an explicit overlap guard (fixes D2)

In `R/run_noisyr_crosscheck.R`:

- compute similarity with `use = "pairwise.complete.obs"`;
- require a minimum number of non-missing pairs per correlation (proposed: 10)
  and a minimum number of usable comparator samples per curve point
  (proposed: 3), matching the guards the manual implementation already applies
  (`min_comparators_per_reference = 2`,
  `min_pairwise_correlations_per_point = 10`);
- aggregate with `na.rm = TRUE`;
- emit the backing counts per curve point so a thin point is visible rather
  than silently equal-weighted.

In simulation this recovers 45 of 45 curve points in every region. The
alternative — restricting to complete features only (939–953 of 987) — is
simpler but drops precisely the low-abundance features the method exists to
characterise, and would bias the threshold upward. Not proposed.

### R3. Run the curve on both raw and detection-masked input (addresses D3)

The 2026-08-26 plan fixed the input as "log2 positive raw peak areas, before
the detection-limit filter" so that the manual and package implementations saw
an identical matrix. That was correct for a like-for-like comparison and should
stay. But it also feeds the method the exact artifact it is meant to detect, so
add a second input arm using the detection-masked matrix and report both. The
divergence between the two arms is a result, not a nuisance.

### R4. Replace first-crossing with sustained-crossing (addresses D3)

Add a `pearson_sustained_gt_0_25` rule: the first window whose similarity
exceeds 0.25 **and stays above it for k consecutive windows** (proposed
k = 5, to be justified against window overlap rather than assumed). Report it
alongside the four existing rules in `abundance_similarity_thresholds.csv`
rather than replacing them.

The existing `n_later_windows_failing_rule` and
`threshold_persists_through_high_abundance` columns already record that the
current rule does not persist — 30, 24 and 26 later windows fail it in the
three regions. That column should become the basis of the rule, not a footnote
to it.

**No rule is to be selected on the basis of which threshold it produces.** The
four-plus-one rules are reported together and the choice is argued from curve
shape, per `doc/agent-rules.md`.

### R5. Scale the window to the panel, not to a fixed count (the [a] generalisation)

`n.elements.per.window = 100` is a noisyR default tuned for RNA-seq panels of
20,000–60,000 genes, where 100 features is 0.2–0.5% of the panel and yields
hundreds of windows. On 987 lipids it is 10% of the panel and yields ~45
windows — a curve too coarse to locate a knee and, per D2, maximally exposed to
missingness.

Proposed: express the window as a fraction of the panel with a floor on
absolute count, record both the fraction and the resulting window count in the
manifest, and re-run the existing parameter sensitivity across that
parameterisation. This is the part of the supervisor's item [a] ("refine the
noisyR approach + optimise on higher number of samples/genes") that is testable
on the data now, without waiting for a transcriptomics dataset.

---

## 4. Files

- `R/run_noisyr_crosscheck.R` — R2 (correlation `use=`, guards, `na.rm`,
  backing counts).
- `src/lpj_lipidomics/noisyr.py` — R1 (status/threshold contract; never emit a
  numeric threshold for a failed run).
- `src/lpj_lipidomics/qc/abundance_similarity.py` — R3, R4 (second input arm;
  sustained-crossing rule).
- `src/lpj_lipidomics/runners/run_noisyr_crosscheck.py` — R1, R3 (comparison
  table columns and the second arm).
- `src/lpj_lipidomics/runners/run_noisyr_parameter_sensitivity.py` — R5.
- `src/analysis_config.py` — window fraction, floor, overlap guards, `k`.
- `tests/` — see §5.

---

## 5. Validation

- Unit test on a synthetic matrix with injected NaNs: assert the curve is
  finite where the overlap guard is satisfied and `NA` where it is not, and
  that no curve point is emitted with fewer than the minimum backing pairs.
- Unit test on a synthetic **J-shaped** curve: assert first-crossing returns
  the leftmost window and sustained-crossing does not. This is the regression
  test for D3 and should be written before the rule is implemented.
- Contract test: a `status` other than `completed` must produce an empty
  threshold and an empty difference. This is the regression test for D1.
- Re-run all four scopes and the parameter sensitivity; confirm every scope now
  yields a finite curve, and record how many points are backed by fewer than
  the full comparator set.
- Confirm `results/mia_vs_control/` and `results/pipeline_test/` are unchanged
  unless §6 is agreed.

---

## 6. Open question before implementation

**Where do the outputs go?** The repaired cross-check changes numbers that are
already published in `results/mia_vs_control/02_qc/`. Per
`doc/agent-rules.md` ("when a restructure coincides with a regeneration, do
both in one pass"), the options are to regenerate in place and `git rm` the
superseded files, or to write to a sibling variant path. Not decided here.

---

## 7. Assumptions and limitations

- **The diagnosis was not produced by running R.** No R runtime was available
  in the environment used for this analysis. D2's mechanism is a simulation of
  `use = "everything"` NA propagation applied to the delivered input matrices;
  it reproduces the observed per-scope pass/fail pattern and the window-size
  sensitivity, but the exact internal NA handling of
  `calculate_expression_similarity_counts` has **not** been read from the
  noisyR source and must be confirmed before R2 is implemented. If noisyR's
  internals differ, R2's guards remain correct but the explanation in §2 needs
  amending.
- The reproduction thresholds in §2 come from a simplified re-implementation of
  the windowing and are offset by roughly 1.4 log2 from the repo's own
  `pearson_gt_0_25` values. They establish the *direction and magnitude* of the
  rule change, not the values to report. Re-derive with
  `abundance_similarity.py`.
- `k = 5`, the 10-pair overlap floor, the 3-comparator floor and the window
  fraction in R5 are proposed defaults, not values validated against this
  dataset. R5's sensitivity sweep is what would validate them.
- The detection-limit boundary used in the masking experiment (9.9 log2) is the
  cerebellum `pearson_gt_0_25` threshold used as a convenient proxy. The
  implementation should use the actual per-lipid detection limit from
  `01_preprocessing/detection_limit_exclusions.csv`, not a single scalar.
- Whether the low-abundance correlation spike is blank carryover, vendor
  gap-filling, or both is unresolved and bears on open questions A6 and the
  gap-filling item in `doc/methodology.md` §10. Repairing the rule does not
  answer it.
- None of this changes any inferential result. The noise threshold feeds
  feature filtering, and the specification curve already shows that filtering
  choices move the best q-value by less than a factor of two
  (`doc/methodology.md` §7.1). This work is about the method being correct, not
  about recovering a signal.
