# Plan: external database annotation for lipid species (KEGG/HMDB/pathway context)

## Motivation

`differential_effects.csv` and other result tables already carry `Lipid Name`,
`Lipid Class`, and `Polarity` from the source workbook, but nothing links a
lipid species to external database identifiers or pathway context. Two uses
motivate closing that gap:

1. Intoerpreting individual candidates (including the sub-threshold, nominal
   candidates already produced) benefits from knowing what pathway/functional
   category a lipid belongs to, not just its shorthand name.
2. `doc/agent-rules.md` already requires, for any enrichment/pathway work,
   recording "the identifier mapping, universe/background, enrichment method,
   database/version/date, and how ambiguous/unmapped lipids were handled."
   This plan produces the identifier-mapping half of that requirement.

## Scope: annotation now, enrichment testing later

This plan covers **identifier mapping and descriptive pathway labeling only**.
It does not run a pathway enrichment test (e.g. over-representation analysis
of significant hits against a background). That test needs a validated
FDR-significant candidate list, which the current analysis does not have —
every effect/region/method combination is null after correction (see
`doc/methodology.md`). Enrichment testing is a separate, later step, to be
planned once/if a candidate list exists.

## Proposed architecture (pending confirmation)

- **Hub: LIPID MAPS REST API** (`https://www.lipidmaps.org/resources/rest`,
  `compound` context), queried by shorthand abbreviation
  (e.g. `PC(16:0_18:1)`), `output_type=all`/JSON. This nomenclature matches
  the workbook's `Lipid Name` column directly. A single successful match
  returns `lm_id`, `hmdb_id`, `kegg_id`, `chebi_id`, and `pubchem_cid`
  together, which is why it is preferred over querying HMDB/KEGG by name
  directly (their native identifiers are not lipid-shorthand-keyed, so
  direct name lookups would have a much lower hit rate).
- **Pathway step**: for every lipid that resolves to a `kegg_id`, query
  KEGG's REST API (`https://rest.kegg.jp/link/pathway/<kegg_id>`) to get
  KEGG pathway membership (e.g. map00564 Glycerophospholipid metabolism).
  Also capture LIPID MAPS' own functional-category hierarchy (independent of
  KEGG) as a second, always-available pathway-adjacent label, since KEGG's
  lipid coverage is coarser than LIPID MAPS' and many species will resolve
  in LIPID MAPS but not reach a KEGG pathway.
- **Not used**: MetaFetcheR (R package unifying HMDB/ChEBI/PubChem/KEGG/LIPID
  MAPS). Considered because R tooling already exists in this repo from the
  limma work, but rejected for this task — LIPID MAPS alone already reaches
  everything needed (including the KEGG cross-reference), so adding a second
  R dependency for the same outcome isn't justified. Revisit if LIPID MAPS'
  direct match rate turns out to be poor.

**Environment note**: Claude's own sandbox cannot reach `lipidmaps.org`,
`hmdb.ca`, or `rest.kegg.jp` (connection failures tested on all three), so
this cannot be implemented or verified from within a Claude Cowork session.
It needs to run in the WSL2/opencode environment, same as the R/limma work.
The exact current REST endpoint syntax should be re-verified live at
implementation time rather than trusted from this plan.

## Matching strategy

- Query by the exact `Lipid Name` shorthand string first.
- Lipid nomenclature has known edge cases this dataset already exhibits:
  ether-linked species (`PC(O-13:1_22:4)`), and molecular-species-level
  naming (individual chains resolved, e.g. `PS(22:5_22:6)`, rather than bulk
  sum composition like `PS 44:11`). If direct matching has a poor hit rate,
  consider normalizing names first with Goslin (a published lipid shorthand
  nomenclature parser/normalizer) before falling back to a class-level-only
  match. **Open item**: only worth adding if the plain-string match rate is
  actually low — check first, don't add the dependency preemptively.
- Never fall back to a class-level ID silently when a species-level match
  fails (see unmapped-handling decision below).

## Unmapped/ambiguous lipids

- No match: `hmdb_id`, `kegg_id`, etc. left blank/NA.
- Every row gets an explicit `mapping_status` column:
  `matched` / `unmapped` / `ambiguous` (more than one plausible database
  entry for the same shorthand name — e.g. isomers sharing a sum
  composition). Never silently drop a lipid from the annotation table or
  infer an identifier.

## Output

- New table, one row per `Feature` (987 rows), joinable onto any existing
  results file by `Feature` — mirrors how the existing `annotations` table
  (`Lipid Name`/`Lipid Class`/`Polarity`) already works, so this is an
  extension of the same pattern rather than a new one.
- Columns: `Feature`, `Lipid Name`, `lm_id`, `hmdb_id`, `kegg_id`,
  `chebi_id`, `pubchem_cid`, `kegg_pathways` (semicolon-joined pathway
  IDs/names, if any), `lipidmaps_functional_category`, `mapping_status`,
  `database_query_date`.
- Written to `results/mia_vs_control/lipid_database_annotations.csv`.
- Cache raw API responses (e.g. `results/mia_vs_control/lipid_id_mapping_raw/`
  or similar) so the mapping is reproducible without re-querying every time,
  and so a future re-run can detect if the source databases changed.

## Recording database version/date (per agent-rules.md)

Since this queries live REST APIs rather than a static downloaded snapshot,
record the date the queries were run (`database_query_date` column, plus a
note in the script/output header) as the closest available proxy for a
database version, since LIPID MAPS/KEGG do not expose a simple version
number through these endpoints.

## File layout

- `src/lipid_annotation.py` (flat, matching the existing `src/` convention):
  `query_lipid_maps(name: str) -> dict`, `map_lipid_ids(annotations: pd.DataFrame) -> pd.DataFrame`,
  `attach_kegg_pathways(mapped: pd.DataFrame) -> pd.DataFrame`.
- `tests/test_lipid_annotation.py`: unit tests against mocked API responses
  (not live calls) for the matching/parsing logic, plus explicit tests for
  the unmapped/ambiguous flagging behavior.
- Notebook: a short new section in `mia_vs_control.ipynb` that loads the
  cached mapping table and merges it into the candidate-review view; the
  live API-querying step itself should be a standalone script run
  (`python src/lipid_annotation.py`), not something the notebook re-executes
  on every run, to avoid hammering a public API repeatedly.

## Validation

- Report a match-rate summary by `Lipid Class` (e.g. "PC: 41/41 matched,
  GD1a: 0/6 matched") so coverage gaps are visible rather than averaged away.
- Spot-check a handful of well-known lipids (e.g. a common PC/PE species)
  against manually looked-up LIPID MAPS/HMDB entries to confirm the
  matching logic is doing what it claims before trusting it on all 987.

## Open items

1. Plain-string matching vs Goslin normalization — decide after seeing the
   initial match rate, not before.
2. Rate limiting/backoff parameters for the ~987 LIPID MAPS queries (and
   however many follow-on KEGG pathway queries) — needs a reasonable default
   (e.g. a short delay between requests) to avoid hitting any public API too
   hard; exact values TBD at implementation time.
3. Whether `kegg_pathways` should store pathway IDs only, names only, or
   both — leaning both (id + name) for readability, open to confirmation.
