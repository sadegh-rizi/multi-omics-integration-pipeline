# Plan: feature-space PCA and lipid co-abundance modules

**Status: PROPOSED 2026-09-08 — implementation NOT authorized.** No code has
been changed. This responds to the supervisor's item [c], "try applying the PCA
also on genes, not only on samples — this will give us an initial, high-level
overview of co-regulated entries." Confirm §8 before any implementation, per
`/careful-planning`.

Outputs would go under a new `results/mia_vs_control/04_multivariate/features/`
subfolder. Nothing existing is overwritten.

---

## 1. What "PCA on features" actually is, and why the naive version adds nothing

This needs stating before any code, because the obvious reading of the request
— transpose the matrix and re-run PCA — produces no new information.

For a centred matrix `X` (samples x features), the singular value
decomposition is `X = U S Vᵀ`. The sample PCA already in the repo reports
scores `U S` and loadings `V`. Running PCA on `Xᵀ` returns feature scores
`V S` and loadings `U`: **the same singular values, the same subspace, the same
decomposition, read from the other side.** The feature view is already fully
contained in `pca_loadings_<region>.csv`.

What *does* change the answer is the **preprocessing margin** — which axis is
centred and scaled. Measured on `00_inputs/differential_input_matrix.csv`:
the existing sample-space PCA reports cortex PC1 at **35.7%** of variance; an
SVD of the same matrix centred per feature instead gives **14.9%**. Same data,
same algorithm, different decomposition, because "co-abundance across samples"
and "sample similarity across features" are different questions about the same
numbers.

So this plan is not "run PCA on the transpose". It is three things:

1. **Make the feature view visible** from the decomposition already computed
   (§4.1) — cheap, and it is what the request literally asks for.
2. **Re-centre for the co-abundance question** and measure whether the result
   is stable at this sample size (§4.2, §4.3).
3. **Deliver modules rather than axes** (§4.4), because §3 shows the axes are
   not reproducible but the pairwise structure is real.

---

## 2. What is already in the repo (do not re-derive)

Measured 2026-09-08.

- `04_multivariate/pca_loadings_<region>.csv` — per-PC feature loadings with
  `Lipid Name`, `Lipid Class`, and a `technical_dominated` flag. This is
  already the feature view of PC space.
- `pca_loading_concentration.csv` — squared-loading share carried by the top
  10/25/50 features per PC.
- `pca_class_composition.csv` — squared-loading share per lipid class per PC,
  with `enrichment_vs_panel`.
- `pca_score_attribution_<region>.csv` — R² of each PC score against Bio group,
  Sex and Tissue mass. Cortex: Bio group explains 0.08% of PC1, 0.2% of PC2,
  23.4% of PC3.
- `pca_scree_<region>.csv`, `02_qc/technical_vs_biological_variance.csv`.
- `multivariate/pca.py` (`fit_pca`, `_complete_numeric`, `loadings_table`) and
  `multivariate/loadings.py` (`align_loading_signs`, `top_loadings`,
  `loading_concentration`, `class_composition`, `cumulative_share_curve`).

No correlation, clustering, or module analysis exists anywhere in the package.

---

## 3. Preliminary measurements that shape the design

Computed on the 57-sample primary input, per region, complete features only.

| region | samples | complete features | rank ceiling | nonzero singular values |
|---|---|---|---|---|
| Cerebellum | 19 | 901 of 981 | 18 | 18 |
| Cortex | 19 | 897 of 981 | 18 | 18 |
| Hippocampus | 19 | 898 of 981 | 18 | 18 |

Three findings follow, and each one constrains the plan.

**(a) Real co-abundance structure exists.** Fraction of feature pairs with
|r| > 0.5, against a null that permutes samples independently within each
feature:

| region | observed | permuted null | enrichment |
|---|---|---|---|
| Cerebellum | 22.7% | 3.0% | **7.5x** |
| Cortex | 16.1% | 3.0% | **5.3x** |
| Hippocampus | 18.6% | 3.0% | **6.2x** |

This is the strongest justification for the analysis: there is far more
pairwise structure than chance, so there is something to find.

**(b) The leading component is not reproducible.** A crude split-half check
(samples split at random, PC1 feature loading computed in each half) gives an
absolute correlation between halves of **0.14 (cerebellum), 0.24 (cortex),
0.19 (hippocampus)**. With n≈9–10 per half this is a harsh test and the honest
statement is "preliminary, to be measured properly by bootstrap" — but it
points the same way as the rank ceiling: a 900x900 feature covariance estimated
from 19 observations does not support interpreting a PC axis. **Stability is
therefore a first-class deliverable, not a robustness appendix.**

**(c) Closure is a smaller threat than feared.** Mean feature-feature
correlation is +0.008 to +0.014 with 49.6–51.1% of pairs negative — i.e. median
normalisation across ~900 features does not induce the strong global negative
correlation that it does across 38 class aggregates (`doc/methodology.md` §7).
The *direction* of any module-level shift still cannot be interpreted without
an external anchor, but the correlation structure itself is not dominated by
the constraint.

---

## 4. Proposed analysis

### 4.1 Feature view of the existing decomposition (no new modelling)

Plot features in `PC1 x PC2` loading space, per region, coloured by lipid class
and shaped/marked by `technical_dominated`. Report, per PC, the existing
`class_composition` enrichment alongside. This is the direct answer to the
request and requires no new statistics — only a figure and a table that read
`pca_loadings_<region>.csv`.

State explicitly on the figure that this is the same decomposition as the
sample PCA viewed from the feature side, not a second analysis.

### 4.2 Feature-centred decomposition as a declared second preprocessing arm

Recompute the SVD with features centred and scaled across samples (the
co-abundance margin) and report its own scree, loadings and class composition
into `features/`. Keep it clearly separate from the sample-space results and
state the 35.7% vs 14.9% contrast so nobody reads the two PC1s as the same
quantity.

Both arms use complete features only, matching `_complete_numeric`; record the
~80-feature loss per region rather than silently dropping it.

### 4.3 Stability, computed before anything is interpreted

- **Bootstrap over samples** (proposed 1,000 resamples, deterministic seed
  recorded in the manifest). Per feature, report the distribution of its PC1
  and PC2 loading after sign alignment (`align_loading_signs` already exists);
  summarise as the fraction of resamples in which the feature stays in the top
  decile of |loading|.
- **Split-half correlation** of the loading vector, reported per PC, as the
  headline stability number.
- Both are reported **per region and per PC**, and no PC whose stability falls
  below a pre-declared floor is interpreted. The floor is set in §8, before the
  numbers are seen.

### 4.4 Co-abundance modules

Because §3(b) says axes are unstable while §3(a) says pairwise structure is
real, the deliverable is modules, not components.

- Feature-feature Spearman correlation per region (Spearman, not Pearson, to
  limit single-sample leverage at n=19).
- Hierarchical clustering on `1 - |r|`, or Leiden on a thresholded correlation
  graph. **Choose one and declare it in §8**; do not run both and pick.
- **Module stability by bootstrap co-membership**: for each feature pair,
  the fraction of resamples in which the two land in the same module. Report a
  per-module mean co-membership and treat modules below a pre-declared floor as
  not reportable.
- **Null comparison**: run the identical pipeline on sample-permuted matrices
  and report module count and size distribution against it. A module structure
  that a permuted matrix reproduces is not a finding.

### 4.5 Two mandatory confounder checks

These decide whether a module means anything biological, and both use tables
that already exist.

- **Lipid class.** Report each module's class composition and its enrichment
  against the panel. A module that is essentially one lipid class may reflect
  shared ionisation and extraction behaviour on a single platform rather than
  shared regulation.
- **Technical variance.** Report each module's share of features flagged
  `technical_dominated` (technical variance ≥ biological, from
  `02_qc/technical_vs_biological_variance.csv` — 71% of cortex and 69% of
  hippocampus lipids). A module built mostly from those features is an assay
  artifact and must be labelled as one.

### 4.6 Scope

Per region. **No pooled cross-region feature PCA in this plan**: region is 33%
of total variance and would dominate any pooled decomposition, and each mouse
contributes all three regions, so a pooled feature correlation mixes
within-mouse and between-mouse structure. A region-centred pooled arm is
deferred to §8.

---

## 5. Figures

Per `doc/agent-rules.md` and `/publication-plot`: colorblind-safe palette, a
second cue beyond colour, axis labels carrying units and transformation, and
vector PDF plus presentation and manuscript PNGs via `plot_config.save_figure`,
all three in the same `features/figures/` folder.

1. Feature loading scatter, PC1 x PC2, per region (§4.1).
2. Loading-stability plot: bootstrap |loading| distribution per feature, per PC.
3. Correlation heatmap ordered by module, per region, with class and
   `technical_dominated` annotation tracks.
4. Module co-membership stability, observed against the permuted null.

Every caption states n = 19 and that these are **co-abundance associations, not
regulatory relationships**.

---

## 6. Files

- `src/lpj_lipidomics/multivariate/features.py` — new: feature-margin SVD,
  bootstrap stability, correlation and module assignment.
- `src/lpj_lipidomics/multivariate/loadings.py` — reuse `align_loading_signs`,
  `class_composition`; extend only if a second caller appears.
- `src/lpj_lipidomics/runners/run_feature_pca.py` — new runner writing
  `04_multivariate/features/` plus a `feature_pca_manifest.json` recording
  seed, resample count, clustering method, thresholds and stability floors.
- `src/lpj_lipidomics/config.py` — bootstrap count, seed, correlation and
  stability floors.
- `tests/test_feature_pca.py` — see §7.

Keep it to one new module and one runner. Per `/research-code-style`, do not
split further until a second caller exists — and note that
`runners/pipeline_stages.py` is already a 130-line module with one caller.

---

## 7. Validation

- **Duality test**: on a synthetic complete matrix, assert that the feature
  loadings from the sample-space fit equal (up to sign) the feature scores from
  the transposed fit, and that the singular values match. This is the
  regression test for the §1 claim and should be written first.
- **Stability test**: on a synthetic matrix with one planted, strong module and
  otherwise independent noise, assert the planted module is recovered with high
  bootstrap co-membership and that noise features are not.
- **Null test**: on a matrix of pure independent noise, assert no module clears
  the co-membership floor. This is the test that stops the pipeline inventing
  structure.
- **Sign-alignment test**: bootstrap loading distributions must be computed
  after `align_loading_signs`, or the distributions are meaningless. Assert it.
- Confirm nothing outside `04_multivariate/features/` changes.

---

## 8. Decisions needed before implementation

1. **Clustering method** — hierarchical on `1 - |r|`, or Leiden on a
   thresholded graph? One, declared now. (Leiden connects to the Network
   Biology coursework and to `robin` for the later item [e]; hierarchical is
   simpler and has no resolution parameter to tune.)
2. **Stability floors** — the minimum split-half loading correlation for a PC
   to be interpreted, and the minimum bootstrap co-membership for a module to
   be reportable. Set before seeing results.
3. **Correlation threshold** for graph construction, if Leiden is chosen.
4. **Signed or unsigned correlation** — `|r|` merges anti-correlated features
   into one module, signed keeps them apart. WGCNA convention is signed;
   unsigned is more common in lipidomics. Consequential, and a scientific call.
5. **Analysis population** — the 57-sample primary, or one of the
   `results/pipeline_test/` variants? Given that
   [[project_pipeline_test_evaluation]] shows sample exclusion drives every
   result in the differential analysis, the feature correlation should be
   checked against at least two variants before anything is reported.
6. Whether a region-centred pooled arm is wanted (§4.6).

---

## 9. Assumptions and limitations

- **The rank ceiling is 18.** A ~900x900 feature covariance is being estimated
  from 19 observations. Everything here is descriptive; no p-value on a module
  is planned, and none should be added without a design that supports it.
- **PC axes are not to be interpreted biologically** unless §4.3 clears the
  §8.2 floor. The preliminary split-half values of 0.14–0.24 suggest they may
  not.
- **"Co-regulated" is not what this measures.** These are co-abundance
  associations across 19 animals on one platform. Shared biosynthetic precursor
  pools, shared extraction and ionisation efficiency within a lipid class, and
  shared measurement noise all produce correlation without regulation. §4.5 is
  what separates the interpretable case from the artifact, and the wording in
  every output must say co-abundance.
- **Litter structure remains unmodelled** (open question A1). If the `Mouse
  number` prefix is the dam, the effective number of independent observations
  is below 19 and every stability estimate here is optimistic.
- **Direction cannot be interpreted.** Median normalisation makes the data
  compositional; §3(c) shows the global closure bias is small, but a module's
  direction of change still needs an external anchor
  (`doc/methodology.md` §7, §10).
- **Complete-case only.** ~80 features per region are dropped for having any
  missing value, and they are disproportionately low-abundance
  ([[project_noisyr_diagnosis]]), so modules at the low-abundance end are
  under-sampled by construction.
- This analysis **cannot recover the null differential result** and is not
  intended to. It is a structural description of the panel, and if a module
  turns out to separate MIA from control that is a hypothesis for a future
  cohort, not a finding in this one.
