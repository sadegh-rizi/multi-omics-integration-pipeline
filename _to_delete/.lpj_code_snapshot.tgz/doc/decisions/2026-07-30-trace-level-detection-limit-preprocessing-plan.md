# Plan: exclude trace-level (near-zero artifact) values before log2 transform

## Motivation

Four lipids with unusually large, unstable standard errors in both
`differential_effects.csv` and `differential_effects_limma.csv` (Features
345, 784, 791, 838) were traced back to their raw, untransformed peak areas.
In each case, a subset of that lipid's samples report peak areas around
10⁻⁷, while the rest of the same lipid's samples sit in a normal range
(hundreds). Example: Feature 784 (`Hex1Cer(d18:1_14:0)`), 8 of 20 Cortex
samples at ~1–2×10⁻⁷ vs the other 12 at 200–900 — a 5.8-billion-fold gap
that does not correlate with BioGroup, Sex, sample number, or tissue mass,
and is not biologically plausible as a real measurement.

A systematic scan of all 992 lipids (looking for a ≥1000-fold gap splitting
a lipid's positive raw values into two populations) found 13 lipids (1.3%)
with this signature, including all four of the previously-flagged
worst-SE lipids. This is almost certainly a peak-integration artifact — the
acquisition software reporting a spurious near-zero "peak" instead of
correctly marking a non-detect — not a real quantitative measurement.

`exclude_nonpositive` (`src/preprocessing.py`) only filters values ≤ 0, so
these technically-positive trace values pass through untouched and become
enormous, spurious outliers once log2-transformed, inflating the standard
error for the specific lipids affected. `doc/agent-rules.md` already
requires establishing "below-detection and censored-value encoding" before
trusting preprocessing; this closes that specific gap.

**Scope check, stated plainly**: this affects a small minority of lipids
(13/992, 1.3%). It is not expected to change the overall null result across
the ~900 tested lipids — the previously-established power ceiling and
diffuse technical noise remain the dominant explanation for that. This fix
is about not letting a fixable data-quality artifact continue to distort
the specific lipids it touches, not about resolving the broader null result.

## Correction: blank runs ARE available (earlier draft of this plan was wrong)

An earlier draft stated no blank-run or detection-limit data existed,
based on checking only the workbook's *sheet* list. That was incorrect —
the `Lipidomics` sheet itself contains six blank-injection columns:
`PreRunBlank_1+.raw` through `PreRunBlank_5+.raw`, plus
`PostRunBlank+.raw`. These are the standard basis for an empirical
detection limit and must inform the method.

What the blanks actually contain:

- They carry real signal — 612 of 992 lipids have non-zero blank signal,
  with positive blank values ranging up to ~6×10⁵ (median positive blank
  ~364). This is carryover/background contamination, a genuinely
  *separate* data-quality problem from the trace-level artifact.
- A conventional signal-to-blank feature filter would remove 11 lipids at
  S/B < 3×, 14 at < 5×, and 21 at < 10× — i.e. ~1–2% of the panel is
  contamination-dominated and arguably should not be analyzed at all.

## Why blanks alone are not sufficient

Tested directly against the 13 known trace-artifact lipids: a 3×-blank
rule catches only **5 of 13**. The reason is structural — for the other 8
(including `Hex1Cer(d18:1_14:0)`, `PC(22:6_14:1)`, `PC(44:8)`), the blank
value is exactly **0**. The blank correctly recorded no signal, so it
provides no threshold to compare against, yet the biological sample still
received a spurious ~10⁻⁶ "peak." A blank-derived limit cannot catch an
artifact the blank itself didn't exhibit.

## Proposed method: blank-derived limit combined with an absolute floor

A value is treated as below detection if it falls under
`max(blank_multiplier × mean_blank_for_that_lipid, absolute_floor)`:

1. **Blank-derived component** — `blank_multiplier` (proposed default: 3,
   the most common convention in MS-based omics; 5 and 10 are also
   defensible and were quantified above). Per-lipid mean across the six
   blank injections, treating missing/zero blank entries as zero, since a
   blank with no detected peak genuinely *is* zero signal.
2. **Absolute floor** — proposed default `1.0` raw peak-area units. This
   covers the blank-is-zero cases. It is justified by the observed
   magnitude separation rather than picked arbitrarily: across all 59,280
   measurements the 5th percentile is ~1.5×10³ and the median ~4.4×10⁴,
   while only 1.1% of values fall below 1.0 and 0.86% below 10⁻³. There
   is a wide empty band between plausible peak areas (10³–10⁷) and these
   artifacts (10⁻⁶), so the floor sits inside a real gap, not in the
   middle of a continuous distribution.
3. Flagged values become missing (NaN), exactly like `exclude_nonpositive`
   already does for ≤0 values — never imputed, never silently zeroed.

Verified behaviour of the combined rule (3× blank OR floor 1.0):

- All **13/13** known trace artifacts fully resolved — every artifact
  lipid's trace cluster falls below the limit while its normal cluster
  stays above it.
- **921 of 59,520** values flagged (1.55%) — 772 blank-derived, 149
  absolute-floor — touching **97 lipids**.
- **5 lipids** have all 60 values flagged and drop out entirely.

> **Corrected 2026-08-05.** An earlier draft of this section stated 1,367
> values across 146 lipids. That estimate was wrong: it counted values with
> `notna()` rather than `> 0`, so it included all 446 exact zeros in the
> matrix — and 1,367 − 921 = 446 exactly. Those zeros are already removed
> upstream by `exclude_nonpositive`, which runs *before*
> `exclude_below_detection` in `preprocess_for_differential`, so counting
> them here double-counted values that were already gone. The 49 extra
> lipids in the old figure were, every one of them, lipids whose only
> sub-limit values were zeros. The percentage was also computed against the
> non-null denominator (59,280) rather than all cells (59,520).
>
> The implementation is correct; this plan's estimate was not. Recorded
> because the wrong number propagated into
> `prompts/2026-08-05-trace-detection-and-figure-reproduction-implementation.md`
> and was briefly treated as an unexplained implementation discrepancy.

An earlier draft proposed a purely relative per-lipid gap rule
(`min_gap_ratio = 1000`). That is now **superseded** — it was a reasonable
heuristic in the absence of blanks, but it is self-referential and has no
external grounding, whereas blanks are the actual measured background.
The relative-gap scan remains useful as a *validation* cross-check (it is
how the 13 lipids were found), not as the production rule.

`blank_multiplier` and `absolute_floor` are named constants meant to be
tunable, same pattern as `PRESENTATION_DPI`/`MANUSCRIPT_DPI` in
`plot_config.py` — defaults now, not fixed specs.

## How published practice handles this

**Blank-ratio filtering is well established.** Schiffman et al. (2019),
reviewing filtering procedures for untargeted LC-MS data, describe it
plainly: *"A common filtering method is to use a fold-change (biological
signal/blank signal) cutoff to remove features that are not sufficiently
abundant in biological samples."* On threshold choice they note the
convention is *"to arbitrarily select a cutoff (2–5) for the ratio between
average biological and blank sample abundances."* The proposed 3× here
sits inside that conventional range.

**Absolute intensity floors are standard, but normally applied upstream at
peak detection, not post-hoc.** Vendor/processing software applies a
minimum intensity at the peak-picking stage (e.g. MS-DIAL's "minimum
threshold," commonly ~250 counts, raised toward ~1000 for large cohorts).
Post-hoc abundance filtering of an already-exported table is usually
expressed *relatively* rather than absolutely — MetaboAnalyst's standard
recommendation, for instance, is to drop the lowest ~40% of features by
mean/median abundance for datasets with >1000 features. A fixed absolute
floor applied after export, as proposed here, is therefore **not the
textbook default** and needs its own justification rather than a citation.

**The literature actively warns against arbitrary fixed thresholds.**
Schiffman et al.'s central argument is that filtering should be
data-adaptive rather than default-driven (*"Rarely does the user examine
the data to determine a suitable cutoff"*), and the exposomics literature
raises the same caution about arbitrarily chosen intensity thresholds
materially changing which biology is recoverable. Notably, their
recommended approach filters on **two axes simultaneously** — blank
difference *and* average abundance, via a mean-difference plot — which is
structurally the same two-criteria design proposed here, just with
data-derived rather than fixed cutoffs.

### Reframing: these are probably gap-filled non-detects, not low-abundance measurements

The stronger justification for the absolute floor is not "these values are
too low to trust" but "these values are not measurements at all."
Standard untargeted workflows align peaks across files and then
**gap-fill** — force an integration at the expected retention time in
files where no peak was detected — which by construction produces a tiny,
meaningless area rather than an honest missing value. The observed
signature here fits that mechanism exactly: values around 10⁻⁶ in a
distribution whose real values run 10³–10⁷, appearing in a subset of
samples for a lipid that is otherwise normally abundant, uncorrelated with
BioGroup, Sex, run order, or tissue mass.

Read that way, the operation being performed is *reverting gap-filled
non-detects back to missing*, which is squarely conventional — and it is
consistent with the repo's existing exclude-don't-impute rule, since it
restores a missing value rather than inventing one. (Note this is the
opposite of MetaboAnalyst's default, which *replaces* missing/zero values
with half the minimum positive value; that default would be actively
harmful here, as it would manufacture yet more fake near-zero values.)

**Open question this raises**: whether the vendor's processing software
gap-filled is not documented anywhere in the workbook or the figures deck.
Worth asking Molly Boettiger / the CU Anschutz facility directly — a
one-line answer ("yes, MS-DIAL with gap-filling on") would convert this
from a well-supported inference into a documented fact, and would also
settle whether an absolute floor is the right instrument or whether the
non-detects can be identified more precisely from the processing software's
own output.

### References

- Schiffman C, Petrick L, Perttula K, Yano Y, Carlsson H, Whitehead T,
  Metayer C, Hayes J, Rappaport S, Dudoit S. "Filtering procedures for
  untargeted LC-MS metabolomics data." *BMC Bioinformatics* 2019;20:334.
  doi:10.1186/s12859-019-2871-9 — read in full; source of the quoted
  conventions above and of the two-axis MD-plot approach.
- Patterson RE, Kirpich AS, Koelmel JP, et al. "Improved experimental data
  processing for UHPLC-HRMS/MS lipidomics applied to nonalcoholic fatty
  liver disease." *Metabolomics* 2017;13(11):142.
  doi:10.1007/s11306-017-1280-1 — lipidomics-specific blank-filtering
  reference cited by Schiffman et al.; **its exact threshold was not
  independently verified here** and should be checked before citing a
  specific number from it.
- "How Low Can You Go? Selecting Intensity Thresholds for Untargeted
  Metabolomics Data Preprocessing." *Analytical Chemistry*
  2022;94(51):17964. doi:10.1021/acs.analchem.2c04088 — directly on
  intensity-threshold selection; **abstract-level only, full text not
  read** — worth retrieving before relying on it.

## Separately: a feature-level contamination filter

Distinct from the value-level rule above, consider dropping lipids whose
*typical* signal is not meaningfully above blank (median sample signal
< 3× mean blank: 11 lipids; < 10×: 21 lipids). These are lipids where the
measurement is largely background, independent of any trace artifact.
Flagged as a **separate open decision** rather than bundled in, since it
removes whole features rather than individual values and therefore has a
different justification burden.

## Where this fits in the pipeline

- New function `exclude_below_detection(raw_intensity: pd.DataFrame, blank_intensity: pd.DataFrame, *, blank_multiplier: float = 3.0, absolute_floor: float = 1.0) -> pd.DataFrame`
  in `src/preprocessing.py`, operating on raw (pre-log2) peak areas.
  Note this takes the blank columns as an explicit argument, so the
  workbook-reading step must now also extract the six `*Blank*.raw`
  columns alongside the 60 biological samples and 6 Tech-Mix columns.
- Runs immediately after `exclude_nonpositive` and before `log2_transform`
  in both `preprocess_for_differential` and `preprocess_for_multivariate` —
  ratios are only meaningful pre-log-transform.
- Also apply to the Tech-Mix QC intensities in the notebook's QC section
  (`techmix_raw = exclude_nonpositive(...)` → add the detection-limit step
  before `techmix_log2 = log2_transform(...)`), so `qc_variance.py`'s
  technical-variance estimates aren't contaminated by the same artifact.
- Record the exclusion in whatever exclusion/QC tracking table already
  exists (`differential_feature_qc.csv` / `preprocessing_diagnostics.csv`)
  with an explicit reason (e.g. `below_blank_limit` vs `below_absolute_floor`,
  kept distinct so the two mechanisms stay separable), consistent with
  "keep a sample/feature exclusion table with reasons" in `doc/agent-rules.md`.
  Do not just silently drop the values with no record.

## Validation

- Confirm all 13 previously-identified lipids are fully resolved (trace
  cluster below the limit, normal cluster above it) — verified in principle
  during planning, must be re-confirmed by the implementation.
- Report the total count of values excluded, split by which criterion
  fired (blank-derived vs absolute floor), plus a per-`Lipid Class`
  breakdown, so the scope stays visible rather than averaged away.
- Report the 5 lipids that lose all 60 values, by name — dropping a whole
  feature deserves individual review, not a summary count.
- Re-run differential testing (both OLS and limma) and confirm the standard
  errors for Features 345, 784, 791, 838 drop substantially compared to
  the current `differential_effects.csv`/`differential_effects_limma.csv` —
  this is the direct smoke test that the mechanism works as diagnosed.
- Report whether the overall p-value histogram / FDR picture changes at
  all globally — report the actual before/after numbers rather than assuming.

## Blast radius — regeneration required

This changes a shared preprocessing step, so every downstream result that
depends on it needs regenerating to stay internally consistent:
`differential_effects.csv`, `differential_effects_limma.csv` (and its
inputs `differential_input_matrix.csv`/`differential_input_metadata.csv`,
which means re-running `src/differential_moderated.R` too),
`permanova_by_region.csv`, `permanova_diagnostics.csv`,
`pooled_mixed_sensitivity.csv`, `preprocessing_diagnostics.csv`,
`technical_vs_biological_variance.csv`, `technical_vs_biological_summary.csv`,
`technical_cv_sanity_check.csv`, `differential_nominal_candidates_with_qc.csv`,
and both the volcano and ECDF figures. 1.55% of individual values are
affected across 97 lipids, with 5 lipids dropping out entirely — the change
is localized rather than a wholesale shift, but not purely cosmetic.
Confirm, don't assume, once regenerated.

Per the git workflow rules in `AGENTS.md`: this work happens on a
`task/<short-name>` branch, and every regenerated results/data file is
committed only after your explicit go-ahead, not automatically.

## Impact on reproducing the vendor's figures

This is not hypothetical for
`doc/decisions/2026-07-30-reproduce-lipidomics-figures-plan.md` — checked
directly whether artifact lipids reach a "top 50" list of the kind the
vendor's heatmaps use:

- Ranking by naive |log2 fold-change| on raw data: **3 artifact lipids in
  Cortex's top 50, 4 in Cerebellum, 4 in Hippocampus** — including
  `SM(t40:0)` and `PC(44:8)` in all three regions.
- Ranking by nominal p-value (what this repo would use): 4 artifact lipids
  in Cerebellum's top 50; none in Cortex or Hippocampus.

So the vendor's published heatmaps very plausibly contain several rows
whose apparent group difference is a peak-integration artifact, not
biology. This confirms the sequencing dependency already stated in the
reproduction plan — the detection-limit fix must land **before** any
top-N-based figure reproduction, or the reproduction will faithfully
reproduce the artifacts too.

It also means the "faithful replication" tier of that plan will likely
*not* match the vendor's figures exactly once this fix is applied, and
that divergence is a finding worth reporting rather than a failure to
reconcile.

## File layout

- `src/preprocessing.py`: add `exclude_below_detection`.
- Workbook reading (currently in the notebook) must also extract the six
  `*Blank*.raw` columns; consider moving that extraction into a small
  named function rather than another inline column-filter expression.
- `tests/test_preprocessing.py`: unit tests — a value below 3× blank is
  flagged, a value above it is not, a value below the absolute floor is
  flagged even when its blank is zero, a lipid with zero blank and all
  normal values is untouched, flagged values become NaN rather than being
  dropped as rows or imputed.
- Update `doc/decisions/2026-07-21-mia-vs-control-lipidomics-plan.md`'s
  progress log once implemented, since this changes the preprocessing
  pipeline that plan describes.

## Open items

1. `blank_multiplier = 3` and `absolute_floor = 1.0` are proposed
   defaults. 3× is the most common convention but 5× and 10× are equally
   standard; the quantified effect of each is in the correction section
   above. The floor at 1.0 sits inside a genuine empty band in the value
   distribution, but its exact position within that band is a judgment
   call.
2. Whether to use `PreRunBlank` only (5 injections) or include
   `PostRunBlank` (6 total). Including it is proposed, since carryover
   after the run is as informative as before it — but if the post-run
   blank systematically shows more carryover (plausible, since it follows
   60 sample injections), pooling them could inflate the limit. **Worth
   checking empirically before committing**, not assumed either way.
3. The separate feature-level contamination filter (drop lipids whose
   median signal is < 3–10× blank: 11–21 lipids) — a distinct decision
   from the value-level rule, deliberately not bundled in.
4. Whether to also re-run the pooled mixed-effects sensitivity check
   (`fit_pooled_mixed_sensitivity`), given it already fails to converge for
   87% of features independent of this issue — likely not worth the effort,
   but noting it as a loose end.
