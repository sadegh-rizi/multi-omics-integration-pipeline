# Plan: a multivariate test of region, treatment and their interaction (ASCA)

**Status: PROPOSED 2026-10-08. Implementation NOT authorized.**

Sadegh asked in a Cowork session whether ASCA (ANOVA–simultaneous component
analysis) suits this design, then asked for a plan. Confirm §7 before
implementation, per `/careful-planning`.

- Outputs would go to a new tree, `results/mia_vs_control/13_asca/`.
  Number 10–12 are reserved by `2026-10-05-biology-in-the-data-plan.md`.
- Nothing existing is overwritten. Nothing in `data/` is touched.

---

## 1. What ASCA adds, and why now

The region-persistence analysis (`09_region_persistence/`) asks, feature by
feature and through one concordance number, whether the regional lipid
pattern differs between MIA and control. Both answers are null in all three
populations: every disattenuated-concordance interval includes 1, and no
per-feature interaction has q < 0.05.

ASCA asks the same question once, for the whole panel. It does three things:

1. It fits one ANOVA model to the feature matrix.
2. It splits the data into one effect matrix per design term (Region, Group,
   Sex and their interactions) and reports each term's share of the
   structured variance.
3. It runs a PCA on each effect matrix, which gives one interpretable
   direction per effect and the lipids that drive it.

This adds three things to what exists:

- **One multivariate test of Region × Group.** It sidesteps both the 964-test
  multiplicity and the "count comparison" trap (`null-calibration` §3).
- **A principled version of the supervisor's pooled-PCA request.**
  `2026-09-26-known-broken-fixes-plan.md` §4.8 showed group is invisible on
  PC1–PC2 and aliased with cage and date where it appears. ASCA takes the PCA
  of the Group effect itself instead of hoping a variance-ranked PC isolates
  it.
- **A calibration exercise that fits the thesis framing.** Region is the
  positive control; MIA is the negative control. ASCA should find the first
  and not the second. If it finds the second, §3 explains why that would not
  mean what it seems to.

## 2. What was checked during planning (read-only)

No ASCA model and no group comparison were computed for this plan.

**Complete features.** ASCA needs a complete matrix. From
`09_region_persistence/<population>/<modality>/00_inputs/region_input_matrix.csv`:

| Population | Lipidomics (of 964) | Metabolomics (of 248) |
|---|---|---|
| All 60 | 842 | 177 |
| T²-95 (55 samples) | 851 | 177 |
| T²-99 (58 samples) | 844 | 177 |

**Design structure** (all 60; mice from `region_input_metadata.csv`):

- 20 mice, 3 regions each, so Region is a within-mouse factor.
  Group and Sex are between-mouse factors.
- **Control:** 2 cages (C00429562: 3 F + 3 M; C00462970: 2 F + 2 M). Both
  cages are mixed-sex.
- **MIA:** 6 cages and every one is single-sex. Females are in C00437351 (1),
  C00462968 (1) and C00462971 (3). Males are in C00 (1), C00431239 (3) and
  C01 (1). **In MIA, sex is a cage property.** The IDs `C00`/`C01` are the
  placeholder IDs from the cage table; register A1a still applies.
- **Collection date:**
  - Control mice were collected on 2024-06-11 (6) and 2024-10-23 (4).
  - MIA mice were collected on 2024-06-11 (4), 2024-08-06 (2) and
    2024-09-13 (4).
  - Only 2024-06-11 has both groups.
- **Whole-cage group assignments:** 2 of 8 cages control gives 28. The
  smallest attainable cage-level p is 1/28 ≈ 0.036 (`clustered.cage_group_assignments`,
  `cage_permutation_ceiling`; register E6).

**Software.** ALASCA (R; Jarmund et al. 2022, *Front. Mol. Biosci.*
9:962431) fits RM-ASCA+ with linear mixed models (`(1|ID)` random
intercepts).
- It validates by stratified cluster bootstrap or jack-knife.
- **It has no permutation tests.** The paper defers them.
- It does not describe missing-value handling.

So it cannot give the cage-level inference this design needs (§3). It can
serve as an independent cross-check of effect estimates and loadings.

## 3. The threats that decide what any result means

1. **Group is inseparable from cage and collection date.** Every cage is
   collected on one date, and treatment was assigned per dam/cage. Any Group
   or Region × Group effect matrix therefore also contains cage and date
   differences. §4.8 of the fixes plan already showed metabolomics PC4
   carrying group R² 0.21 next to cage R² 0.70 and date R² 0.57. ASCA cannot
   separate these; only the permutation unit can make the test honest about
   it.
2. **The cage-level floor.** With 28 assignments, a Group-related p can never
   be below 0.036. With any correction across two modalities or two effects,
   nothing Group-related can reach significance.
   - This is a property of the design, not of ASCA.
   - It is the same constraint E6 records for the composite panel.
3. **Sex in MIA is cage.** Sex and Region × Sex can be tested at mouse level
   in controls only. Within MIA, a "sex" difference is a difference between
   three cages and three cages.
4. **Mouse-level permutation is anti-conservative for Group.** Pups share a
   dam. Permuting Group across mice treats 20 mice as independent units when
   the treatment unit is 8 cages. It may be reported, labelled as such
   (§4.4), never as the primary result.
5. **Region is relative.** Each sample was median-normalised within its own
   panel, so the Region effect describes composition, not absolute amount.
   Tissue mass was not used as a covariate (persistence manifest).
6. **Complete-feature selection is not neutral.** It drops 122 lipids and
   71 metabolites, mostly those absent in one region. These carry regional
   information, so the Region effect will be somewhat understated.

## 4. Proposed analysis

### 4.1 Data and preprocessing (pre-declared)

- **Input:** the persistence inputs, `09_region_persistence/<population>/<modality>/00_inputs/region_input_matrix.csv`
  (log2, prevalence-20 filtered, median-normalised, no imputation), with
  matching `region_input_metadata.csv`. These already exist for all three
  permitted populations and both modalities.
- **Features:** complete across all samples of the population (§2 table).
- **Scaling:**
  - Primary: each feature autoscaled (mean 0, SD 1) over all samples of the
    population, so every lipid has equal weight.
  - Sensitivity: centred, unscaled log2, which weights high-variance
    features more (D3).
- **Populations:** all 60 primary; T²-95 and T²-99 as sensitivity analyses.
  No other populations.

### 4.2 Model: ASCA+ with a nested mouse term

One general linear model per feature, fitted jointly because the design is
the same for every feature:

```
y = Region + Group + Sex + Group:Sex + Mouse(Group:Sex)
    + Region:Group + Region:Sex + Region:Group:Sex + error
```

- **Coding:** sum-to-zero (effect) coding for every factor. With effect
  coding, the effect matrices of an unbalanced design remain interpretable
  (ASCA+; Thiel et al. 2017). This matters because T²-95/T²-99 remove
  single samples.
- **Mouse(Group:Sex):** a fixed nested factor. It absorbs between-mouse
  variation, so within-mouse effects (Region and its interactions) are
  estimated against within-mouse error, as in a split-plot ANOVA or a
  random-intercept model.
- **Cage** is not a model term. It is aliased with Group × Sex in MIA. It
  enters through the permutation unit instead (§4.4).
- **Effect matrices** come from the fitted model, one per term.
- **Variance share** of each effect: SSQ(effect matrix) / SSQ(centred data).
  The between-mouse residual (Mouse) and within-mouse residual are reported
  too.
- **For all 60**, every mouse has all three regions and the design is
  balanced. The GLM decomposition then equals the classical split-plot sums
  of squares, which is the first validation check (§6).

### 4.3 Components

Each effect matrix has rank at most its degrees of freedom. So the number of
components is fixed by the design, not chosen:

- Region: 2
- Group: 1
- Sex: 1
- Group:Sex: 1
- Region:Group: 2
- Region:Sex: 2
- Region:Group:Sex: 2

**Reported per effect:**
- scores for the factor levels;
- loadings for every feature;
- the effect-plus-residual projection: each sample's score from (effect +
  residual) on the effect loadings, so the separation is shown against the
  noise.

### 4.4 Inference (pre-declared)

Statistic: SSQ of the effect matrix. Every p is k/N, with the observed
labels included in N.

| Effect | Permutation unit | N | Role |
|---|---|---|---|
| Region | region labels permuted within each mouse | 9,999 random + observed | positive control |
| **Group** | group label permuted across whole cages | 28 (exact) | **primary** |
| **Region:Group** | group label permuted across whole cages | 28 (exact) | **primary** |
| Group, Region:Group (sensitivity) | group label permuted across mice, within sex | 9,999 random + observed | labelled anti-conservative (§3.4) |
| Sex, Region:Sex | sex permuted among mice within each control cage; MIA cages kept intact | 9,999 random + observed | secondary; the MIA half is cage-confounded (§3.3) |
| Group:Sex, Region:Group:Sex | (no test) | | descriptive only |

**Decision rule, fixed now, before results:**

- Group and Region:Group are reported as their exact cage-level p (k/28) with
  their variance share. **No multiplicity correction is applied, and no
  "significant" label is used.** With a floor of 0.036 the honest reading is
  only whether the observed statistic is the largest of the 28.
- A claim that MIA changes the regional architecture would need all three of:
  - the observed Region:Group SSQ is the largest of 28;
  - the mouse-level sensitivity p < 0.05;
  - the same in both modalities.

  Even then it would be called "consistent with a group difference that is
  not separable from cage and date", not an MIA effect.
- Region is expected to be the largest effect, with p at the floor of its
  permutation set. If it is not, stop and investigate before reading any
  other effect.

### 4.5 Loading stability

- Cluster bootstrap over mice, stratified by Group × Sex (5 mice per stratum),
  1,000 resamples, all three regions of a drawn mouse kept together.
- Loadings are Procrustes-aligned to the full-data solution with sign
  matching, as in ALASCA.
- Report 95% percentile intervals for loadings and for each level's score.
- **Caveat, stated with every interval:** resampling mice does not resample
  cages. Intervals for Group-related effects are too narrow, by the same
  argument as §3.4.

### 4.6 Read-outs and links to existing results

- **Region:** compare the Region effect contrasts (cortex − cerebellum and
  so on, from the effect matrix) with the per-feature mean regional
  differences in `03_differential/within_group_region_tests.csv`. They come
  from the same data, so the correlation should be ≥ 0.99.
- **Region:Group:** compare its variance share with the disattenuated
  concordance, and list its top-loading features next to their per-feature
  interaction q in `region_interactions.csv`.
- **Group:** compare with §4.8's per-PC attribution. Report the Group
  effect's correlation with cage-mean and date-mean profiles, which is the
  aliasing made visible.
- **Lipid classes:** class composition of the top-loading lipids per effect
  (`multivariate/loadings.class_composition`). This is descriptive.

### 4.7 Figures

One composite per modality (all 60):

- **(a)** Variance-share bar per effect, with the permutation null for each
  as an interval.
- **(b)** Region effect-plus-residual scores, PC1–PC2, coloured by region,
  marker by group.
- **(c)** Region:Group scores per group, with bootstrap intervals.
- **(d)** Top loadings of Region PC1 with class colouring.

T²-95/T²-99 appear only in a sensitivity table of variance shares and p
values.

## 5. Files

**New**
- `src/lpj_lipidomics/multivariate/asca.py`:
  - effect-coded design builder (with nested Mouse);
  - joint GLM fit and effect matrices;
  - SSQ and variance shares;
  - per-effect SVD (scores, loadings, effect-plus-residual projections);
  - Procrustes alignment.
- `src/lpj_lipidomics/statistics/asca_permutation.py`: the permutation
  engines in §4.4. These reuse `clustered.cage_group_assignments` and
  `exact_empirical_p_value`, plus the within-mouse region shuffle and the
  within-control-cage sex shuffle.
- `src/lpj_lipidomics/runners/run_asca.py`: three populations × two
  modalities, writes provenance, refuses to overwrite.
- `tests/test_asca.py`: the checks in §6.
- `results/mia_vs_control/13_asca/<population>/<modality>/`:
  - `effect_variance.csv`
  - `permutation_tests.csv`
  - `permutation_null_ssq.csv`
  - `scores.csv`
  - `loadings.csv` (with bootstrap intervals)
  - `effect_residual_projection.csv`
  - `region_consistency.csv`
  - `manifest.json`
  - `figures/`
- `results/mia_vs_control/13_asca/provenance.json`
- `prompts/2026-10-08-asca-region-group-implementation-v1.md` (at
  implementation)

**Changed:** none. The explorer app is out of scope until results are
reviewed (D8).

## 6. Validation

1. **Decomposition identity (all 60, balanced).** Per feature, the effect
   sums of squares equal the classical split-plot ANOVA sums of squares
   (statsmodels), to 1e-10. The effect matrices are mutually orthogonal and
   sum with the residuals to the centred data.
2. **Unbalanced fit.** On T²-95, effect estimates for a sample of features
   equal statsmodels OLS with `Sum` coding and the nested mouse term, to
   1e-10.
3. **Region consistency.** The positive control in §4.6: correlation ≥ 0.99
   with the persistence within-group regional differences.
4. **Permutation engines.**
   - The cage-level engine yields exactly 28 distinct assignments that
     preserve group counts.
   - The within-mouse engine never moves a sample between mice.
   - The control-cage sex engine never changes an MIA label.
5. **Calibration under a simulated null.** Gaussian data with the real
   design and a feature correlation matrix estimated from the residuals,
   200 datasets:
   - Region, Region:Group and Group p-values (mouse-level engines) are
     uniform: KS p > 0.01, rejection rate at 0.05 within 0.02–0.08.
   - The cage-level engine's p is uniform on {1/28 … 28/28}.
6. **Spike-in power.** Add a Region:Group shift of size d (0.25, 0.5, 1 SD)
   to k features (10, 50, 200). Report the detection rate for the cage-level
   rule and the mouse-level sensitivity rule. This says what size of
   regional rewiring the study could have seen, for the power-and-design
   deliverable (analysis-state next step 6).
7. **Independent cross-check (D1).** ALASCA on all-60 lipidomics: Region and
   Region:Group effect estimates agree with the Python fit (correlation
   ≥ 0.99), and loading directions agree after Procrustes alignment. This
   check covers estimation only; ALASCA has no permutation test.

## 7. Decisions needed before implementation

Recommendations are separate from the options; Sadegh decides.

**D1. Implementation**
- (a) Python ASCA+ in the package, with the permutation engines above.
- (b) ALASCA (R) as primary.
- (c) (a) plus an ALASCA cross-check on all-60 lipidomics only.
- *Recommendation: (c).* Only (a) can run cage-level permutations, and the
  pipeline is Python. The cross-check costs one R script, using the existing
  renv.

**D2. Missing values**
- (a) Complete features only.
- (b) (a) plus a half-minimum-imputation sensitivity.
- (c) Impute for the primary.
- *Recommendation: (a).* The pipeline does not impute. §3.6 is stated as a
  limitation.

**D3. Scaling**
- (a) Autoscale primary, unscaled log2 sensitivity.
- (b) Pareto.
- (c) Unscaled only.
- *Recommendation: (a).*

**D4. Model terms**
- (a) Full Region × Group × Sex with nested Mouse.
- (b) Drop Sex.
- *Recommendation: (a).* Sex is balanced in the design; dropping it moves
  its variance into the residual and the Mouse term.

**D5. Primary inference**
- (a) Cage-level exact (28) for Group and Region:Group, mouse-level as a
  labelled sensitivity, decision rule as in §4.4.
- (b) Mouse-level primary.
- *Recommendation: (a).* Same reasoning as E6 and the cage-structure plan.

**D6. Populations**
- (a) All 60 primary; T²-95/T²-99 as sensitivity.
- (b) All 60 only.
- *Recommendation: (a).*

**D7. Loading intervals**
- (a) Mouse cluster bootstrap, 1,000 resamples, with the §4.5 caveat.
- (b) No intervals.
- *Recommendation: (a).*

**D8. Explorer app**
- (a) Add an ASCA tab after results are reviewed.
- (b) Never.
- (c) Build it with the analysis.
- *Recommendation: (a).*

**D9. Collection-date sensitivity**
- (a) Skip.
- (b) Descriptive ASCA on the 2024-06-11 subset only (10 mice; 1 control
  cage), with no test.
- *Recommendation: (a).* With one control cage in that subset, Group cannot
  be separated from that cage either.

## 8. Assumptions and limitations

- **Additive model on log2 values with homogeneous residual variance across
  cells.** ASCA does not model the MIA-vs-control variance difference seen
  in the persistence analysis (MIA SD 0.70 vs 0.55 for cortex −
  hippocampus).
- **Mouse as a fixed nested term.** This matches a random intercept for
  within-mouse effects in the balanced case. Under imbalance (T²-95/99) the
  two differ slightly; the cross-check in §6.7 bounds this on all 60 only.
- **Grounding.** The cage IDs (`C00`, `C01`) and the cage-equals-dam mapping
  follow `doc/context/design-constraints.md` and remain subject to
  register A1a.
- **Exploratory, not confirmatory.** The analysis was proposed after the
  per-feature and concordance analyses were seen to be null. It is a
  multivariate re-expression of the same question on the same data, not new
  evidence. Its value is calibration and a clearer figure, not a second
  chance at significance.

## References

- Smilde AK et al. (2005). *Bioinformatics* 21:3043–3048 (ASCA).
- Thiel M, Féraud B, Govaerts B (2017). *J. Chemometrics* 31:e2895 (ASCA+).
- Madssen TS et al. (2021). *PLoS Comput. Biol.* 17:e1009585 (RM-ASCA+).
- Jarmund AH et al. (2022). *Front. Mol. Biosci.* 9:962431 (ALASCA).
- Martin M, Govaerts B (2020). *J. Chemometrics* 34:e3232 (LiMM-PCA).
