# Plan: restructure the PLS-DA work as an argument, not a figure grid

Supersedes the 4-condition × 3-region figure grid in
`doc/decisions/2026-08-05-outlier-policy-pca-and-figure-reproduction-plan.md`.
The exclusion policy, PC counts, and outlier-screen outcome in that document
all still stand. What changes is the shape of the deliverable.

## Why the grid was the wrong structure

The grid answers "what does it look like under each cleaning combination?"
That is a browsing question. It produces 24 figures, invites comparing them by
eye, and offers no defence against picking the most favourable panel — which is
precisely the reasoning this analysis exists to argue against.

The actual goal is a chain of specific claims, each of which needs one exhibit
and a number. Restructured that way the same evidence takes ~6 figures and
2 tables, and reads as an argument rather than a gallery.

## The finding the grid was burying

`results/mia_vs_control/04_multivariate/plsda_permutation_diagnostics.csv`
(already generated) contains this:

| Region | full-panel p | top-50 panel p | ratio |
|---|---|---|---|
| Cerebellum | 0.629 | 0.075 | 8× |
| Cortex | 0.371 | **0.014** | 26× |
| Hippocampus | 0.101 | **0.004** | 25× |

Same data, same test, same 1000 permutations. The difference is entirely the
feature panel.

**Mechanism, verified in the code.** `select_top_n_by_nominal_p`
(`src/reproduce_vendor_figures.py`) ranks features by nominal MIA-vs-control
p-value — computed using the group labels. `permutation_test_plsda` then
receives an already-selected matrix and permutes **only the labels**; the
selection is outside the loop and stays fixed across all 1000 permutations.
The features were chosen *because* they separate under the true labels, so the
permuted null cannot reproduce that separation, the null distribution is
artificially narrow, and the p-value is anticonservative by construction.

**Consequence.** The top-50 permutation p-values must **not** be reported as
evidence of group separation. Reporting Hippocampus `p = 0.004` as a finding
would be reporting an artifact. They should be reported only as the
demonstration *of* the artifact, beside the full-panel values.

**Why this is the strongest exhibit available.** "We found nothing" is a weak
claim. "The apparent separation in the source figures is reproducible as a
feature-selection artifact, and here is the same effect produced on demand in
our own data" is a positive, mechanistic result that explains the discrepancy
between the vendor deck and this analysis. It is the centrepiece, not a caveat.

## The argument, claim by claim

| # | Claim | Exhibit | Status |
|---|---|---|---|
| 1 | Same data; our pipeline reproduces theirs | Our PLS-DA beside the vendor panel | figure exists, needs pairing |
| 2 | The separation is not statistically supported | Full-panel permutation p (0.63 / 0.37 / 0.10) | **done** |
| 3 | The "significant" version is a selection artifact | full vs top-50 p, side by side | **done**, needs presenting |
| 4 | The unsupervised view agrees | PCA scores + variance explained | scree/loadings exist; scores figure needed |
| 5 | No individual lipid survives correction | Volcano + FDR | **done** |
| 6 | This is a power/noise result, not "no biology" | Min detectable effect ≈2-fold; 71%/69% technical-dominated | **done**, needs assembling |
| 7 | Cleaning does not rescue it | Sensitivity table across conditions | **done**, needs reformatting as a table |

Most of the evidence already exists. The remaining work is assembly and
presentation, not generation.

## Exclusion conditions become a table, not a display axis

One table, all conditions as rows, permutation p as the value. Not four
galleries of plots. This answers "does cleaning help?" quantitatively and
removes the opportunity to eyeball a preferred panel.

When presenting that table, state plainly:

- Conditions C and D are byte-identical to A and B, because the outlier screen
  justified no sample exclusions (see the 2026-08-05 plan). Do not ship the
  duplicate files.
- Condition B removes 77% of Cortex features (897 → 205) and 71% of
  Hippocampus (898 → 263), versus 17% of Cerebellum (901 → 749). That is the
  technical-variance filter acting, and it matches the independently measured
  technical-dominated fractions (Cortex 71%, Hippocampus 69%, Cerebellum 19%).
  State this, or a reader will wonder why the panel shrank.

## Figures to keep

Per region (3 regions), on the primary dataset only — mouse `C00431239 - 3`
excluded, detection-limit filter applied:

1. PLS-DA scores, **full panel**, with permutation p and cumulative variance
   explained printed in the caption.
2. PCA scores, same samples, with variance explained and confidence ellipses.

Plus, once, not per region:

3. The vendor-comparison figure (claim 1).
4. The full-vs-top-50 permutation comparison (claim 3) — a small paired bar or
   dot plot over the six values in the table above.
5. Volcano (already exists).

Total ~9 panels rather than 24 figures, and every one of them is attached to a
numbered claim.

## What NOT to do

- Do not present top-50 PLS-DA scores plots as primary evidence. If shown at
  all, they belong next to claim 3, labelled as the artifact demonstration.
- Do not report the top-50 permutation p-values without the full-panel value
  immediately beside them.
- Do not generate C/D outputs while `SAMPLE_OUTLIER_EXCLUSIONS` is empty.

## Optional, only if the circularity claim needs strengthening

A properly nested permutation — redo the top-50 feature selection *inside* each
permutation, using the permuted labels — would give the honest p-value for the
"select then project" procedure, and would be expected to land near the
full-panel value. That converts claim 3 from an argument into a direct
measurement. It costs 1000 × (differential fit + selection + PLS-DA), so only
worth it if a reviewer or supervisor pushes back on the mechanism. Flagged as
optional, not planned.
