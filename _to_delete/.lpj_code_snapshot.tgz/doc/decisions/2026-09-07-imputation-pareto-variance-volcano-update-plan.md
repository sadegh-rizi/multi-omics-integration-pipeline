# Plan: RF imputation, IQR filtering, Pareto sensitivity, and FDR-hit labelling

**Status: CONFIRMED 2026-09-07 -- implementation authorized.** This is an
exploratory sensitivity analysis. The existing primary outputs and the earlier
`results/pipeline_test/` sensitivity outputs remain unchanged.

## Scope

Run a 12-cell sensitivity matrix under `results/pipeline_test_rf/`:

| Imputation | Sample variant | Scaling branches |
|---|---|---|
| `rf_mar_only` | `prevalence20_t2_95`, `prevalence20_t2_99`, `prevalence20_noexclusion` | `standard`, `pareto` |
| `rf_all` | `prevalence20_t2_95`, `prevalence20_t2_99`, `prevalence20_noexclusion` | `standard`, `pareto` |

The output path is therefore:

```text
results/pipeline_test_rf/<imputation>/<sample_variant>/<scaling>/
```

The existing `results/mia_vs_control/` and `results/pipeline_test/` trees are
not overwritten.

## Fixed Processing Order

1. Convert source intensities to numeric and mask non-positive values.
2. Apply the pooled 20% prevalence filter across the 60 raw biological samples.
3. Remove blank-dominated features.
4. Apply value-level detection-limit masking.
5. Apply the selected sample-level T-squared exclusion variant.
6. Log2-transform and median-normalize the surviving matrix.
7. Impute missing cells separately within each brain region.
8. Apply the pooled unsupervised IQR feature filter to the completed matrix.
9. Fit differential models and run multivariate analyses on the retained panel.

The prevalence rule remains independent of the sample-exclusion variant. The
IQR filter is applied after imputation and sample exclusion because it is an
analysis-panel filter, not a raw missingness filter.

## Imputation

- `rf_mar_only`: RF-impute genuinely MAR cells; retain half-minimum values for
  left-censored/detection-limit cells.
- `rf_all`: RF-impute every remaining missing cell as a deliberately labelled
  contrast.
- Imputation is label-free: BioGroup and Sex are not predictors.
- Imputation is performed on the log2, median-normalized matrix, separately by
  brain region.
- Persist imputation routes, cell counts, random seed, and method in each
  output manifest.

## IQR Filter

- Use `var.filter = "iqr"`.
- Compute each feature's IQR across the surviving, completed biological sample
  matrix without using labels.
- For fewer than 1,000 input features, remove the bottom 25% by IQR. With the
  current 964-feature panel, this removes 241 features and retains 723.
- Resolve tied IQR values deterministically by Feature ID.
- Persist the IQR table and feature-exclusion reasons.
- The same retained panel is used for differential and multivariate analyses
  within each imputation/sample/scaling run.

## Scaling Branches

### `standard`

- Differential testing retains the current normalized log2 scale.
- Multivariate analyses retain the current autoscaling convention.
- Existing effect-size and fold-change interpretation is preserved.

### `pareto`

- Pareto-scale each retained feature by mean-centering and dividing by the
  square root of its across-sample standard deviation.
- Apply Pareto-scaled values to both differential and multivariate analyses.
- Report differential coefficients and MDEs as Pareto-scaled units; do not
  label them as log2 fold changes or calculate `2 ** estimate` fold changes.
- Volcano x-axis labels explicitly state that the coefficient is Pareto-scaled.

## Volcano and FDR Hits

- Define hits as `p_value_fdr < 0.05` within the existing Region x Effect FDR
  family.
- Rank hits by FDR, then raw p-value, then Feature ID.
- Annotate the top 10 hits per Region x Effect using the supplied Lipid Name,
  with Feature ID as fallback.
- Write the complete hit table to `07_specification_curve/fdr_hits.csv`.
- Save scale-specific volcano figures with readable labels and the same PDF,
  presentation PNG, and manuscript PNG outputs.
- Explicitly write an empty hit table when no feature survives correction.

## Files

- `src/analysis_config.py`: RF, IQR, scaling, and top-hit constants.
- `src/preprocessing.py`: IQR filtering and Pareto scaling helpers.
- `src/run_pipeline_variant.py`: sensitivity-run orchestration and output
  layout.
- `src/power_analysis.py`: scale-aware volcano plots and FDR-hit tables.
- `src/imputation.py`: validate and reuse existing RF implementations.
- `src/differential_moderated.R`: preserve scale metadata and avoid fold-change
  claims for Pareto-scaled inputs.
- `tests/test_preprocessing.py`, `tests/test_imputation.py`,
  `tests/test_power_analysis.py`, and runner/output contract tests.

## Validation

- Run targeted preprocessing, imputation, differential, and plotting tests.
- Run the complete Python test suite.
- Execute all 12 sensitivity configurations.
- Verify expected sample counts, retained feature counts, imputation routes,
  FDR denominators, top-hit tables, and scale labels.
- Confirm `results/mia_vs_control/` and `results/pipeline_test/` remain
  unchanged.

## Assumptions and Limitations

- RF imputation is exploratory and does not resolve the unresolved litter
  structure; pups remain the model's nominal observational units.
- Sample-level permutations remain anti-conservative if Mouse number prefixes
  identify litters.
- Pareto-scaled coefficients are not directly interpretable as abundance fold
  changes.
- IQR filtering changes the differential testing universe and is therefore part
  of the declared sensitivity analysis, not the unchanged primary analysis.
