# Plan: QC-CV filter, missing-value imputation, and a specification curve

Covers two preprocessing options that have been requested, plus the reporting
structure that keeps them honest.

## Read this first — why this plan is framed as a specification curve

By the time this runs, the following will all have been tried:

| variant | effect on the result |
|---|---|
| technical-variance filter (condition B) | Cortex PLS-DA p 0.371 → **0.860** (worse) |
| limma empirical-Bayes moderation | no change, 0 FDR hits |
| lipid-class aggregation (25× fewer tests) | 4 nominal hits vs 5.7 expected by chance |
| QC-CV filter at 30% | 981 → 697 features, p 0.369 → 0.345, 0 FDR hits |
| whole-mouse exclusion | no change |
| detection-limit filtering | no change |

Adding imputation makes seven. Each is individually defensible and
label-free. But "run another preprocessing variant and see if anything comes
up" is, cumulatively, a garden of forking paths: with enough specifications,
one will eventually produce a hit, and that hit will not be trustworthy.

**Therefore this is planned and reported as a specification-curve (multiverse)
analysis, not as a search.** Every combination is run, and **all** results are
reported together. Pre-commitment, recorded here before the numbers exist:

- If nothing is FDR-significant in any specification, that is the headline —
  and it is a much stronger null than any single analysis, because it
  demonstrates the result is not an artifact of preprocessing choice.
- If something is significant in **one** specification out of eight, it is
  reported as *one of eight*, with the other seven visible. It is a
  hypothesis, not a finding.
- No specification is promoted to "primary" after seeing its result. The
  primary specification is fixed **now**: no imputation, no QC-CV filter —
  i.e. the current pipeline.

## Part 1 — QC-CV filter

Already implemented (`APPLY_QC_CV_FILTER`, default `False`) and already
measured: at CV>30% it removes 284 of 981 features and changes nothing
(permutation p 0.369 → 0.345 in Cortex, 0 FDR-significant either way, no
enrichment of small p-values).

**Recommendation: leave it off as the primary specification**, and include it
as one axis of the curve. Removing 29% of the panel for no change in any
conclusion costs coverage and buys nothing. Its value is as a robustness
statement — "the null survives standard QC-CV filtering" — which the curve
delivers without adopting it.

No new implementation needed; it is a flag.

## Part 2 — Imputation

### The problem with applying Random Forest here

Missingness in this dataset, measured:

| origin | cells | share of total |
|---|---|---|
| blank/non-numeric in the source workbook | 228 | 0.40% |
| exact zero | 423 | 0.75% |
| set to NaN by our detection-limit rule | 880 | 1.56% |
| **total missing** | **1,531** | **2.71%** |

**85% of the missing cells are left-censored** — we know the true value is
below the detection limit. Random Forest (missForest-style) imputation assumes
missing-at-random and predicts each cell from other features and samples. On
left-censored data it imputes toward the observed range, i.e. **systematically
too high**, and it would specifically overwrite the 880 cells we deliberately
identified as non-detects. Applying it blindly would undo the detection-limit
work.

This is not an argument against running it — it is an argument for running it
**correctly**, and for reporting the naive version as a clearly-labelled
contrast.

### Four imputation specifications

| # | label | method |
|---|---|---|
| 0 | `none` | current behaviour: leave `NaN`; differential path tolerates per-fit, multivariate path uses complete cases. **Primary.** |
| 1 | `mnar_halfmin` | left-censored cells (zero + below-detection) → half the minimum observed positive value for that feature. MAR cells → also half-min. Standard MS-data convention. |
| 2 | `rf_mar_only` | **the methodologically correct RF variant**: Random Forest imputes only the 228 genuinely-MAR cells; the 1,303 left-censored cells get half-min. |
| 3 | `rf_all` | RF imputes everything, ignoring censoring. Included **only** as the contrast showing what the naive application does. Not to be used for inference. |

Specification 2 is the one to take seriously. Specification 3 exists so the
difference is measurable rather than asserted.

### Implementation notes

- `sklearn.experimental.enable_iterative_imputer` →
  `IterativeImputer(estimator=RandomForestRegressor(...))` is the practical
  missForest equivalent and avoids a new dependency (`scikit-learn` is already
  installed).
- **Impute on the log2 scale, after median normalisation, before scaling.**
  Imputing raw right-skewed peak areas distorts the distribution.
- **Impute without group labels.** `BioGroup`/`Sex` must not be predictors, or
  the imputation manufactures the group difference it is later tested for.
  This is the single most important correctness constraint here.
- **Impute per region**, matching the analysis unit. Imputing across regions
  would let Cortex values inform Cerebellum cells.
- Fixed `random_state`; RF imputation is stochastic.
- Record, per specification, how many cells were imputed and by which route.

### Diagnostic worth running

Mask a random 1% of **observed** values, impute, and compare imputed vs true.
Report RMSE per specification. This measures whether RF is actually better
than half-min *on this dataset* rather than assuming it. Given 85% censoring
and n=20 per region, do not be surprised if it is not.

## Part 3 — The specification curve

2 (QC-CV on/off) × 4 (imputation) = **8 specifications**, each run through the
full pipeline.

Report per specification, per region, per effect:

- number of features entering the test
- number FDR-significant at q<0.05
- smallest q-value observed
- count of nominal p<0.01 vs chance expectation
- PLS-DA permutation p
- number of cells imputed

Present as one table plus one specification-curve figure: specifications on
the x-axis ordered by smallest q-value, the q-value on the y-axis, with a
marker panel below showing which choices each specification used. This is the
standard multiverse presentation and makes cherry-picking visually impossible.

## File layout

- `src/imputation.py`: `impute_none`, `impute_mnar_halfmin`,
  `impute_rf_mar_only`, `impute_rf_all`, plus `censoring_mask(...)` returning
  which cells are left-censored versus genuinely MAR.
- `src/run_specification_curve.py`: loops the 8 specifications, writes the
  table and the figure.
- `tests/test_imputation.py`:
  - group labels are never passed to the imputer (assert on the fitted
    feature set)
  - left-censored cells receive values below the feature's observed minimum
    under `mnar_halfmin` and `rf_mar_only`
  - `rf_all` demonstrably imputes censored cells higher than `rf_mar_only` —
    the contrast the specification exists to show
  - imputation is deterministic given `random_state`
  - masked-value recovery RMSE is computed and finite

## Outputs

```
results/mia_vs_control/01_preprocessing/imputation_summary.csv
results/mia_vs_control/01_preprocessing/imputation_recovery_rmse.csv
results/mia_vs_control/07_specification_curve/specification_results.csv
results/mia_vs_control/07_specification_curve/figures/specification_curve.*
```

## Validation

- Missingness accounting reproduces: 228 MAR, 423 zero, 880 below-detection.
- Under `none`, results reproduce the current pipeline exactly.
- No specification passes group labels into imputation.
- All 8 specifications reported, including any that produce hits and any that
  fail.

## Open items

1. If a specification does produce FDR-significant lipids, the follow-up is
   **not** to adopt that specification. It is to check whether those lipids
   are ones whose values were largely imputed — which would identify the hit
   as an imputation artifact. Build that check into the reporting.
2. Whether to include the class-level aggregation as a fifth axis. Leaning no
   — it changes the unit of analysis rather than the preprocessing, and
   belongs in its own analysis.
