# Cleanup task: reduce the figure set to what is actually used

Confirmed scope reduction. Implements decisions made 2026-08-06.

## 1. PLS-DA and heatmap reproduction — keep only the vendor-matched set

**Keep** `results/mia_vs_control/05_figure_reproduction/vendor_matched/`
(3 heatmaps, 3 PLS-DA, `heatmap_column_order.csv`,
`plsda_permutation_diagnostics.csv`). Vendor inputs: sample 26 excluded in
Cerebellum only, samples 25 and 27 retained, no lipid-level removal, full
lipid panel.

**Delete** all four condition directories — 108 files:

```bash
git rm -r results/mia_vs_control/05_figure_reproduction/{A_baseline,B_lipid_filtered,C_sample_filtered,D_both_filtered}
```

Rationale: the reproduction exists to show the vendor's figure is reproducible
and then refute it by permutation. The exclusion-condition variants answered a
question that has since been settled — the outlier screen justified no sample
exclusions, so C and D were byte-equivalent to A and B anyway, and the lipid
filter's effect is already quantified numerically.

**Keep** `results/mia_vs_control/04_multivariate/plsda_permutation_diagnostics.csv`
with all condition rows intact. It is the sensitivity record — "cleaning does
not rescue the separation" — and costs one CSV rather than 108 figure files.

Also remove the corresponding generation code paths in
`src/run_mia_vs_control.py` so the conditions are not silently regenerated on
the next run.

## 2. PCA scores — restrict to three meaningful colourings

`src/run_mia_vs_control.py` line ~123 currently iterates:

```python
for variable in ("Sample type", "Sample number", "Tissue mass (mg)", "Mouse number"):
```

Replace with region / bio group / sex. Note two things that make this more
than a substitution:

- **`Bio group` and `Sex` are not currently produced at all.** Two of the three
  wanted colourings must be added, not just filtered to.
- **Region colouring is degenerate within a region.** A Cortex-only PCA
  coloured by `Sample type` has exactly one colour. Region belongs on the
  **pooled** PCA only.

Target set:

| Scope | Colourings | Figures |
|---|---|---|
| Pooled | region, bio group, sex | 3 |
| Cortex | bio group, sex | 2 |
| Cerebellum | bio group, sex | 2 |
| Hippocampus | bio group, sex | 2 |
| | **total** | **9** |

Down from 16. Dropped: `Sample number` (run order), `Tissue mass (mg)`,
`Mouse number`, and the three degenerate per-region `Sample type` plots.

Use the existing palettes in `src/plot_config.py` (`BIO_GROUP_COLORS`,
`SEX_COLORS`, `BRAIN_REGION_COLORS`) rather than new ones. Keep the confidence
ellipses and the variance-explained axis labels.

Note for the record: run order and tissue mass were included as batch-effect
diagnostics, not as biological variables. Dropping their figures is fine —
but if a reviewer later asks whether PC1 tracks injection order, that check
will need re-running. Cheap to redo; worth knowing it is no longer standing.

## 3. Scree plots — keep as-is

All four (pooled + 3 regions). No change.

## 4. Loadings — delete the plots, keep the tables

**Delete** the 4 loadings figures (12 files):

```bash
git rm results/mia_vs_control/04_multivariate/figures/pca/loadings_*
```

**Keep** `results/mia_vs_control/04_multivariate/pca_loadings_*.csv`. The
underlying per-feature loadings are still needed — only the unreadable
all-features scatter is being dropped. A readable presentation of the
important features will be designed separately.

Remove the loadings-plot generation from `src/run_mia_vs_control.py`; keep the
loadings-table export.

## 5. Code hygiene, same pass

- `_plot_plsda` and `_plot_heatmap` are each defined twice
  (`run_mia_vs_control.py`, `run_vendor_fidelity.py`) and have legitimately
  diverged (vendor mimicry vs project style). **Do not merge them.** Rename to
  `_plot_plsda_vendor_style` / `_plot_plsda_project_style` (same for heatmap)
  so the split reads as deliberate rather than as drifted copy-paste.
- `run_vendor_fidelity._plot_plsda` negates `PLS 1` twice for Hippocampus
  (once conditionally, once unconditionally), so Hippocampus flips only
  `PLS 2` while other regions flip both. Replace with an explicit constant:

  ```python
  VENDOR_SIGN_FLIP = {"Cortex": (-1, -1), "Cerebellum": (-1, -1), "Hippocampus": (1, -1)}
  ```

  Verify each region's orientation against the source figure before fixing the
  values — the current net behaviour may be correct, but it is unreadable.

## Expected outcome

| | before | after |
|---|---|---|
| Files in `results/` | 224 | ~83 |
| PLS-DA / heatmap figures | 5 dirs | 1 dir |
| PCA scores figures | 16 | 9 |
| PCA loadings figures | 4 | 0 |
| Scree figures | 4 | 4 |

## Validation

- `results/mia_vs_control/05_figure_reproduction/` contains only
  `vendor_matched/`.
- Nine PCA score figures exist, each with more than one colour in its legend.
- `pca_loadings_*.csv` still present; no `loadings_*.pdf`.
- `pytest -q` passes; no test references a deleted output path.
- Re-running `run_mia_vs_control.py` regenerates exactly the reduced set and
  does not recreate the deleted conditions.
