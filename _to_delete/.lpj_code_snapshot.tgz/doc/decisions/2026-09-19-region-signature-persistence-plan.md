# Plan: does the regional lipid signature persist under MIA?

**Status: PROPOSED 2026-09-19 — implementation NOT authorized.** Responds to
the supervisor's suggestion of 2026-09-19: find the differential across regions
within saline, within MIA, and see whether those differences persist. Confirm
§7 before implementation, per `/careful-planning`.

Outputs would go to `results/mia_vs_control/09_region_persistence/`. Nothing
existing is overwritten.

---

## 1. Why this design is the right one for this dataset

Every analysis so far has hunted a weak main effect directly and found nothing
(`doc/methodology.md` §7, §7.2). This one inverts the approach: it uses the
**strongest effect in the data as the readout** and asks whether MIA perturbs
it.

Two structural advantages:

- **The region contrast is within-mouse.** Each animal contributes all three
  regions, so a region difference is a paired quantity and between-animal
  variance drops out of it entirely. This is the only contrast in the project
  with that property.
- **It has a built-in positive control.** If cortex versus cerebellum does not
  light up, the pipeline is broken. In the dry run it produced **552/859
  lipids at q<0.05 in MIA and 563/859 in control**.

## 2. What the exploratory dry run showed — and what it cost

Run 2026-09-19 on the 19 mice with all three regions (9 MIA, 10 control),
normal approximation, complete-case, no clustering. **Exploratory only; the
numbers below are not results.**

### 2.1 The global answer to "do the differences persist"

Correlation between the MIA and control mean region-difference profiles:

| contrast | Pearson r | Spearman | slope (MIA ~ control) | median \|effect\| |
|---|---|---|---|---|
| Cortex − Cerebellum | **0.921** | 0.926 | 0.865 | 0.73 / 0.76 |
| **Cortex − Hippocampus** | **0.284** | 0.352 | 0.251 | 0.25 / 0.28 |
| Hippocampus − Cerebellum | **0.848** | 0.837 | 0.761 | 0.55 / 0.59 |

Two signatures persist almost intact; the cortex–hippocampus one largely does
not. This single number per contrast answers the supervisor's question
directly and is far more robust than any per-lipid test.

### 2.2 The per-lipid interaction does not survive honest correction

Uncorrected, Cortex − Hippocampus gave 16 lipids at q<0.05 (min q 0.0003) with
203/871 nominal p<0.05 against ~44 expected. Both required corrections erase
almost all of it:

| correction | q<0.05 | min q |
|---|---|---|
| none (as dry-run) | 16 | 0.00031 |
| cage design effect at the measured ICC of 0.115 | **1** | 0.0048 |
| cage design effect at ICC 0.25 | 1 | 0.036 |
| FDR across all three contrasts (2,598 tests) | **4** | 0.00093 |

Applying both would plausibly leave none. **The per-lipid interaction is
therefore a secondary, descriptive endpoint, not the analysis.**

### 2.3 Checks that survived

- **Not a noise asymmetry.** SD of the Cx−Hp difference vector: MIA 0.571 vs
  control 0.525, ratio 1.01, a 52/48 split across lipids.
- **Directionally reproduced in the date-matched cohort.** All 16/16 hits kept
  their sign in the 2024-06-11 subset (3 MIA vs 6 control) — sign-test
  p ≈ 1.5 × 10⁻⁵ against a 50% expectation.
- **No collection-date artifact in the negative control.** Controls only, June
  (6 mice) vs October (4): 27/871 at p<0.05 against ~43 expected, below chance,
  nothing at q<0.05.

### 2.4 Two things the dry run got wrong, recorded so they are not repeated

- **Collapsing to cage means is invalid here.** It returned *more* hits (76,
  min q 0) — an artifact of estimating the control variance from **2 cages,
  df = 1**. Same σ̂-instability as `2026-09-07-noisyr-diagnosis...` and
  [[project_pipeline_test_evaluation]]. This arm must not be used.
- **Cage ICC is higher for differences than for raw values** — 0.115 for the
  Cx−Hp difference against 0.002 for raw cortex abundance. Within-mouse
  differencing removes between-animal offsets but *not* cage-level
  region-contrast effects, plausibly dissection consistency varying by
  collection day. Pairing buys precision, not independence.

## 3. The threat that decides whether §2.1 means anything

**The low Cx−Hp concordance may be attenuation, not biology.** Cortex −
Hippocampus has by far the smallest effect (median |effect| 0.25 against 0.73
for Cx−Cb). The correlation between two independently estimated noisy vectors
is attenuated by their reliability:

`r_observed ≈ r_true × sqrt(reliability_MIA × reliability_control)`

so a low r is exactly what a low signal-to-noise contrast produces **whether or
not the underlying signatures differ.** Nothing in §2.1 distinguishes the two.

**This is the single most important analysis in the plan (§4.2).** Without it,
the headline table is uninterpretable.

## 4. Proposed analysis

### 4.1 Region differential within each group (the supervisor's step 1)

Per mouse, form the three pairwise region-difference vectors. Within each
treatment group, one-sample t per lipid on the difference, **t-distribution not
normal approximation** (at n = 9/10 the approximation is anti-conservative).
Report per group and per contrast, with the Cx−Cb result labelled as the
pipeline positive control.

### 4.2 Reliability and disattenuation — the decisive step

Within each treatment group, split mice at random into halves, compute the mean
difference profile in each half, and correlate. Repeat over many splits
(proposed 1,000, seed recorded) to estimate the **reliability** of that group's
region-difference profile.

Then report, per contrast:

- observed between-group concordance `r_obs` (§2.1);
- the attenuation ceiling `sqrt(rel_MIA × rel_control)`;
- the disattenuated estimate `r_obs / ceiling`, with a bootstrap interval.

**Interpretation, written before the run:** if `r_obs` sits at its ceiling, the
low Cx−Hp concordance is measurement noise and there is nothing to report. If
`r_obs` is clearly below the ceiling, the signatures genuinely diverge, and
that is the finding. Cx−Cb and Hp−Cb serve as internal references where the
ceiling is known to be high.

### 4.3 Per-lipid interaction (secondary, descriptive)

One test per lipid per contrast: (region difference in MIA) − (region
difference in control).

- **Not** a comparison of two significance lists. "Significant in saline but
  not MIA" is the difference-of-significance fallacy; at 10 versus 9 mice those
  lists track power, not biology.
- FDR family = **all three contrasts together** (2,598 tests), declared now,
  because the dry run examined all three (§6).
- Variance inflated by the cage design effect using the ICC estimated in §4.4,
  reported at the point estimate and both interval ends.

### 4.4 Cage structure

Estimate the ICC of each difference vector by cage and report its distribution;
apply it as a design effect in §4.3. This shares machinery with
`2026-09-17-cage-and-collection-date-structure-plan.md` §5.3 and should reuse
it rather than duplicating it.

**Cage-level permutation cannot confirm anything here** — C(8,2) = 28
assignments gives a p-floor of 0.036, so q<0.05 is unreachable by construction.
State this wherever a cage-level empirical p appears; do not run it and report
the ceiling as if it were a result.

### 4.5 Independent confirmation in metabolomics

The same 60 samples have metabolomics (246 features, differential already run
in the sibling worktree). Repeat §4.1–4.3 there and ask whether the **same
contrast** shows the same concordance pattern.

This is the strongest confirmation available and the data already exists.
Caveat per open question A4: the modalities may share one biphasic extraction,
so this is not fully independent — but for a *regional* signature, shared
extraction is a much weaker confound than it is for the sample-level outlier
concordance where it was fatal. Do every analysis you do for lipidomics for metabolomics as well. 

### 4.6 Annotation, only if §4.2 clears

If and only if the disattenuated concordance shows real divergence: report
which lipid classes carry it, using the existing `class_composition` machinery,
and whether the classes are consistent with a known regional biology
(myelin-associated lipids, gangliosides). Not before — class stories on
unstable features are how this project would generate its first false positive.

## 5. Files

- `src/lpj_lipidomics/statistics/region_contrast.py` — **new**: difference
  vectors, within-group tests, concordance, split-half reliability,
  disattenuation.
- `src/lpj_lipidomics/statistics/clustered.py` — ICC, shared with the cage plan.
- `src/lpj_lipidomics/runners/run_region_persistence.py` — **new**: writes
  `09_region_persistence/` and a manifest recording seeds, split count,
  contrast set, FDR family and ICC.
- `tests/test_region_contrast.py` — see §6.

## 6. Validation

- **Pairing test**: assert each difference vector uses the same mouse on both
  sides, and that a mouse missing any region is dropped from all contrasts
  rather than silently from one.
- **Attenuation test**: on synthetic data where two groups share an *identical*
  true profile but differ in noise, assert the observed concordance falls while
  the disattenuated estimate stays near 1. This is the regression test for §3
  and should be written first.
- **Fallacy test**: assert the reported interaction comes from a single
  two-group contrast, not from differencing two significance indicators.
- **Selection disclosure**: the manifest must record that the exploratory dry
  run examined all three contrasts, so the Cx−Hp result is **not**
  pre-registered and the three-contrast FDR family is not a post-hoc choice.
- Confirm nothing outside `09_region_persistence/` changes.

## 7. Decisions needed before implementation

1. **Primary endpoint** — the disattenuated concordance (§4.2), as proposed, or
   the per-lipid interaction? They give different answers and the choice must
   be made before the run.
2. **Analysis population** — 57-sample primary, `prevalence20_noexclusion`, or
   both? The Cx−Hp contrast lost one MIA mouse to the whole-animal exclusion,
   taking the date-matched MIA cohort from 4 to 3.
3. **Sex** — MIA cages are single-sex, so a sex-stratified interaction is
   confounded with cage. Report stratified as a declared sensitivity, or omit?
4. **Does metabolomics confirmation run in the same pass** (§4.5) or after the
   lipidomics result is settled?

## 8. Assumptions and limitations

- **The selection problem is already present.** The dry run looked at all three
  contrasts and Cx−Hp is the one that worked. The three-contrast FDR family and
  the disclosure in §6 mitigate this; they do not remove it. A genuinely
  confirmatory result requires either the metabolomics arm (§4.5) or a new
  cohort.
- **Two control cages.** No method gives clean between-group inference at
  2 versus 6 clusters; §4.3 reports a design-effect-adjusted range rather than
  pretending to a single correct p-value.
- **The date confound persists.** §2.3 shows it does not generate this
  signature within controls, but that check has 6 versus 4 mice and is itself
  underpowered.
- **Region differences are compositional.** Median normalisation is per sample,
  so a within-mouse region difference compares two separately normalised
  profiles; direction is interpretable only relative to the panel.
- **Tissue mass differs by region** (cerebellum ~44–50 mg, hippocampus ~39 mg),
  so part of any region contrast may be extraction efficiency. Tissue mass is
  already a covariate in the score attribution and should be carried here.
- **This does not reopen the MIA main effect.** It asks a different question —
  whether regional specialisation is perturbed — and a positive answer would be
  a hypothesis for a properly powered cohort, not a finding in this one.
