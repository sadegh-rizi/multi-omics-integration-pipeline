# Spec: exact visual reproduction of the vendor PLS-DA and heatmap

Companion to `doc/decisions/2026-08-06-plsda-argument-structure-plan.md`.
That document covers the argument; this one covers making two figures look
like the source so the "same data" claim is visually checkable.

## Correction to the argument plan

The vendor's **PLS-DA uses the full lipid panel**, not the top-50 subset. An
earlier draft of the argument plan assumed otherwise. Consequences:

- The honest comparison to the vendor PLS-DA is the **full-panel** permutation
  p-value, already computed: Cerebellum 0.629, Cortex 0.371, Hippocampus 0.101.
  None significant. This is a simpler and stronger argument than the one
  previously drafted — same features, same method, separation does not survive
  permutation.
- The top-50 circularity critique still holds but applies to the **heatmap**,
  where features are selected by group difference and then clustered, making
  group-wise clustering guaranteed rather than informative. Keep the two
  critiques separate; they are different objections to different figures.

## Which exclusion policy for the fidelity figures

For the **fidelity reproduction only**, match the vendor's own choices:
sample 26 excluded in Cerebellum, all other samples retained, including
25 and 27. The point of these two figures is to demonstrate that our pipeline
reproduces theirs from the same input — that claim is only checkable if the
inputs match.

Every other figure in the analysis uses the project policy (whole mouse
`C00431239 - 3` excluded). Label the fidelity figures explicitly as
"vendor-matched inputs" so the two are never confused.

## Heatmap

### The one substantive fix

`cluster_heatmap` in `src/reproduce_vendor_figures.py` currently Ward-clusters
**both** axes. The vendor clusters rows only. Column order is a deterministic
sort, verified against the Cortex panel:

```
BioGroup (Saline Control, then MIA)
  -> Sex (Male, then Female)
    -> sample number ascending
```

Decoded vendor Cortex order: Saline-Male 1, 7, 28, 34, 40 · Saline-Female 16,
22, 46, 52, 58 · MIA-Male 4, 10, 25, 31, 37 · MIA-Female 13, 19, 43, 49, 55.
Exact match. Replace `leaves_list(column_linkage)` with this sort and drop the
column dendrogram entirely.

This matters beyond appearance: clustering columns lets the reader believe the
grouping was *discovered*. Sorting columns by group makes it obvious the
grouping was *imposed*, which is the honest presentation for a top-50 panel
selected on that same grouping.

### Remaining elements

| Element | Spec |
|---|---|
| Row clustering | Ward linkage, Euclidean distance (already correct) |
| Row dendrogram | left side, no row labels on that side |
| Row labels | lipid names, **right** side |
| Column labels | sample number, bottom, horizontal |
| Values | row-wise z-score, colour range clipped to ±3 |
| Colormap | diverging blue (low) → white → mid → red (high); `RdBu_r` is the closest matplotlib match |
| Class strip | thin bar above the matrix, light green = Saline Control, dark green = MIA |
| Legends | right side: continuous colour bar labelled −3…3, plus a class key |

Group labels in the legend read `1- Saline Control` and `2- MIA` in the source
(MetaboAnalyst's numbered-factor convention). Match the strings if the goal is
visual identity.

## PLS-DA scores plot

| Element | Spec |
|---|---|
| Title | `Scores Plot` |
| Axis labels | `Component 1 ( 23 % )` — note the spaces inside the parentheses |
| Points | open circles (unfilled markers, coloured edge) |
| Point labels | sample number as text immediately right of each marker |
| Colours | two-tone green: light for Saline Control, dark for MIA |
| Ellipses | filled, translucent, one per group, drawn **behind** the points |
| Legend | upper right, `1- Saline Control` / `2- MIA` |
| Grid | light dotted, both axes |
| Frame | full box border |

### Ellipse definition — check this against the source

The vendor's ellipses contain essentially all of their group's points and
extend beyond them, so they are **data/tolerance ellipses**, not confidence
regions for the group mean. Two standard constructions:

- χ² form: radius `sqrt(chi2.ppf(0.95, 2))` = 2.448 — smaller
- Hotelling/F form: radius `sqrt(2(n-1)/(n-2) · F(0.95, 2, n-2))` ≈ 3.17 at
  n = 10 — larger

Start with the F form; it matches the visual scale of the source. Whichever is
used, the caption must say it is a data ellipse and **not** a confidence
interval for the mean — the latter is far smaller, and conflating them
overstates separation, which is the exact failure this analysis is arguing
against.

At n = 10 per group an ellipse is a weak summary regardless. Say so in the
caption.

## Validation

- Overlay or side-by-side the reproduced Cortex heatmap against the vendor
  panel and confirm the column order matches sample-for-sample.
- Confirm the reproduced PLS-DA places the same samples in the same relative
  positions (sign flips on a component are arbitrary in PLS and are not a
  discrepancy — note this rather than chasing it).
- Print the full-panel permutation p-value in the caption of every reproduced
  PLS-DA, including the vendor-matched ones. A reproduced figure without its
  p-value is the original problem restated.
