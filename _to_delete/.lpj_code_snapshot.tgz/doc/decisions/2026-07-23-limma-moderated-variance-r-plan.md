# Moderated-variance differential testing via R/limma

Date: 2026-07-23
Status: implemented — awaiting execution on the study data

## Question

`src/diffexp.py`'s per-lipid OLS models use each lipid's own residual
variance, estimated from as few as 16 residual degrees of freedom per
region. That is the likely source of the instability already documented in
this project's methods discussion: per-lipid standard errors ranged from
0.07 to 9.7 log2 units, the raw p-value histogram was depleted at both
tails relative to a uniform null, and even the Sex effect — ordinarily one
of the most robust signals in rodent lipidomics — showed nothing (best
FDR q = 0.41 across ~2,934 tests). `limma`'s empirical Bayes moderation
(`eBayes`) is designed for exactly this failure mode: it borrows strength
across all fitted features to shrink each feature's noisy individual
variance estimate toward a shared prior, before computing a moderated
t-statistic. This plan adds a moderated-variance analysis alongside (not
replacing) the existing OLS results, so the two can be compared directly.

## Scope of this change — bigger than a Python dependency

Every prior change in this project has stayed inside the existing Python
WSL virtual environment. This one does not: `limma` is an R/Bioconductor
package with no canonical, actively-maintained Python port of `eBayes`'s
moderation math. This plan therefore introduces a second language runtime
(R) into the project, not just a new package. That is a materially
different kind of environment change from anything done so far and needs
explicit sign-off before implementation, per `AGENTS.md`'s "do not alter
dependencies or environments without approval" — flagging it here rather
than deciding it silently.

## Architecture decision — proposed default

**Standalone R script, run via `Rscript`, reading/writing CSVs that
already exist or are added as a small export step from the Python side.**
Not an in-notebook `rpy2` bridge. Reasoning: `rpy2` adds a binary
cross-language dependency that is a common source of fragility in WSL2
environments specifically, and mixes two language paradigms inside one
notebook in a way that works against the project's "simple to read and
modify" style goal (`research-code-style` skill). A plain `.R` script that
a reader can run and inspect on its own, independent of the Python
notebook, is more in keeping with that. This is a real design choice, not
a formality — confirm before implementation, since it changes the shape of
the deliverable.

## Data flow

Preprocessing logic stays in Python — it is already implemented and
tested (`src/preprocessing.py`) — and is not duplicated in R. The
interface between the two languages is plain CSV:

1. A small Python export step (a notebook cell, not a new module function
   — this is one-off orchestration, not reusable logic) writes:
   - `results/mia_vs_control/differential_input_matrix.csv`: the output of
     `preprocess_for_differential(raw_intensity)` (log2, median-normalized,
     not auto-scaled — fold-change must be preserved for this to be a fair
     comparison against the existing OLS results), features as rows,
     samples as columns.
   - `results/mia_vs_control/differential_input_metadata.csv`: `Sample`,
     `Region` (`Sample type`), `BioGroup` (`Bio group`), `Sex`, `Mouse
     number` — the same metadata `diffexp.py` already uses.
2. The R script reads those two files. It does not touch
   `data/1 MB2_088_Lalowski_Report_Final.xlsx` directly, keeping the
   "inspect the actual source once, in one place" rule intact.

## R script contents

Per region (matching `diffexp.py`'s primary per-region framing, for direct
comparability — pooling regions here would reintroduce the same
repeated-measures problem the OLS analysis was designed to avoid):

1. Build the design matrix: `model.matrix(~ BioGroup * Sex, data = ...)`,
   with `BioGroup` releveled so `"Saline Control"` is the reference and
   `Sex` releveled so `"Male"` is the reference — matching
   `diffexp.py`'s `Treatment(reference=...)` choices exactly, so the two
   sets of coefficients are directly comparable term-for-term.
2. `lmFit(expression_matrix, design)` — per-feature linear models, all
   features in one call (this is the same linear model `diffexp.py` fits
   one lipid at a time; `limma` vectorizes it).
3. `eBayes(fit)` — empirical Bayes moderation of the per-feature variance
   estimates.
4. `topTable(fit, coef = ..., number = Inf, sort.by = "none")` extracted
   separately for each of the three coefficients (MIA main effect, Sex
   main effect, MIA:Sex interaction) — `topTable`'s default
   `adjust.method = "BH"` gives the moderated, FDR-corrected result
   per term per region, mirroring `differential_effects.csv`'s structure.
5. Write `results/mia_vs_control/differential_effects_limma.csv`: one row
   per lipid x region x effect, with moderated t-statistic, moderated
   p-value, BH-adjusted p-value, and log fold-change — column names aligned
   to `differential_effects.csv` where they represent the same quantity, so
   the two files can be joined directly for comparison.

This is additive: `differential_effects.csv` (the OLS result) is not
modified or replaced.

## Comparison step (the actual point of doing this)

Once both files exist, join them on `Feature`/`Region`/`Effect` and check,
at minimum:

- Does the moderated standard error/variance shrink the extreme per-lipid
  values seen in the OLS fit (some SEs reached 9.7 log2 units)?
- Does the pooled p-value histogram look closer to uniform under the
  moderated model than the OLS one did?
- Does the Sex effect — the "positive control" that showed nothing under
  OLS — produce any FDR-significant hits under moderation? This is the
  single most informative check: if moderation recovers a known, expected
  signal that OLS missed, that is strong evidence the OLS flatness was
  substantially a small-sample variance-estimation problem rather than a
  true absence of signal.
- Whether the previously-identified (and QC-retracted) Cortex MIA-x-Sex
  interaction candidates look any different under moderation — informative
  but secondary, since those lipids were already shown to be
  technical-noise-dominated independent of which testing method is used.

## Environment and dependency management

- The approved WSL2 bootstrap command is:
  `sudo apt-get update && sudo apt-get install -y r-base r-cran-renv r-cran-testthat r-bioc-limma libuv1-dev`.
- Dependencies are pinned in the project-scoped `renv.lock`. Recreate the
  project library with `Rscript -e "renv::restore(prompt = FALSE)"`.

## Testing

Mirror the Python testing convention (`tests/test_*.py`, synthetic
fixtures, no real data in tests) with `testthat`: a small synthetic
expression matrix and metadata (a handful of features with known,
hand-picked group differences), asserting the design matrix has the
expected four columns, `eBayes` runs without error, and `topTable`
returns the three expected coefficients with plausible p-values.

## Proposed file layout

- `results/mia_vs_control/differential_input_matrix.csv`,
  `results/mia_vs_control/differential_input_metadata.csv` — Python export
  step (added to `notebooks/mia_vs_control.ipynb`, not a new module).
- `src/differential_moderated.R` — the analysis script (kept in `src/`
  alongside the Python modules for now, flat, matching the existing
  convention across languages; open to a separate `r/` directory instead —
  see open items).
- `tests/test_differential_moderated.R` — `testthat` suite.
- `results/mia_vs_control/differential_effects_limma.csv` — output.
- A short comparison section added to `notebooks/mia_vs_control.ipynb`
  (plain Python, reads both CSVs, does the checks listed above).

## Validation

- `Rscript src/differential_moderated.R` runs without error and produces
  `differential_effects_limma.csv`.
- `testthat::test_dir("tests")` (or the R-appropriate equivalent) passes.
- The comparison checks above are executed and reported, not just the
  script running successfully — a script that runs is not evidence the
  moderation helped, per `doc/agent-rules.md`'s completion standard.

## Confirmed decisions and deferred scope

- Use WSL2 system packages for the initial R installation and a project-local
  `renv` lockfile for reproducible R dependencies. A future Conda environment
  may replace the system runtime.
- Use standalone `Rscript` and `src/differential_moderated.R`.
- This first pass is limited to region-wise models. A pooled cross-region
  moderated model remains out of scope; the existing pooled OLS sensitivity
  check (`fit_pooled_mixed_sensitivity`) was mostly unusable for unrelated
  reasons (convergence, not variance moderation) — `limma`'s `duplicateCorrelation`
  can handle repeated measures and may be worth considering in a later plan.
