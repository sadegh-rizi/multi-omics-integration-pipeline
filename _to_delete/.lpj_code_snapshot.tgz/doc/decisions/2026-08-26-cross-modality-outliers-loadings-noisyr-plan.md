# Plan: cross-modality outlier screen, PCA loading composition, noisyR cross-check, tissue-mass PCA

Implementation plan covering four requested items. All counts below were
measured from the source workbook on 2026-08-26 and should reproduce exactly.

## Standing constraints


- Per the standing policy, outlier screening runs on the **full sample set**
  with the outlier mouse retained.

---

## Part 0 — Prerequisite: fix the Hotelling T² critical value

Everything in Part A depends on the screen being calibrated, so this goes
first.

`pca_hotelling_t2.csv` currently uses the F form,
`p(n-1)/(n-p) · F(α; p, n-p)`. That is the reference distribution for an
observation **not** used to fit the model. Our samples define the centroid and
covariance and are then scored against them, so T² is bounded above by
`(n-1)²/n` and the correct reference is Beta:

```
T²_crit = (n-1)²/n · Beta(1-α; p/2, (n-p-1)/2)
```

Measured calibration on clean multivariate-normal data, 4000 replicates:

| n, p  | form                   | limit | flags on clean data |
| ----- | ---------------------- | ----- | ------------------- |
| 20, 2 | F (current per-region) | 7.504 | **1.04%**           |
| 20, 2 | Beta                   | 5.361 | 5.06%               |
| 60, 3 | F                      | 8.591 | 2.81%               |
| 60, 3 | Beta (current pooled)  | 7.495 | 4.99%               |

`pooled_outlier_diagnostics_3pc.csv` already uses Beta, so the two committed
files disagree with each other on convention.

**Fix:** use the Beta form everywhere, and align the component count — the
per-region table currently uses 2 PCs while the pooled one uses 3. Adopt
**p = 3** for both, matching the scree elbow.

**Expected after fix:** per-region 95% flags go from 1 sample to 5
(25, 35, 56, 33, 10). That is not five new outliers — 5 of 60 is what a
calibrated 5% screen should produce. Sample 25 remains clearly first at
T² = 10.78, roughly 60% of the theoretical ceiling of 18.05.

Add a regression test asserting the limit matches the Beta closed form and
that a simulated clean matrix is flagged at 5% ± 1.5%.

---

## Part A — Metabolomics preprocessing and cross-modality outlier concordance

### A0. What the metabolomics sheet actually contains

Verified structure, so the plan does not assume symmetry that isn't there:

|                   | Lipidomics                         | Metabolomics                                                                         |
| ----------------- | ---------------------------------- | ------------------------------------------------------------------------------------ |
| Features          | 992 rows (987 named + 5 artefacts) | **267, no artefact rows**                                                            |
| Sample columns    | `MB2_088-01` … `-60`               | `MB2_088-1` … `-60` (**not zero-padded**)                                            |
| Blanks            | 6 (5 pre + 1 post)                 | 6 (5 pre + 1 post)                                                                   |
| Tech-Mix          | 6                                  | 6                                                                                    |
| Annotation        | Lipid Name, Lipid Class            | Metabolite, Metabolite ID, Molecular formula, **Pathway**, **m/z**, **r.t.**, Method |
| Acquisition modes | not recorded                       | **2** — `5MM_LB_Exp3-` (152), `5MM_LB_Exp3+` (115)                                   |
| Zeros             | 446                                | **17**                                                                               |
| Missing (NaN)     | 240                                | **0**                                                                                |
| Value range       | trace values near 1e-7             | min positive **783**, median **2.0e6**                                               |

Three consequences that must be handled explicitly rather than inherited:

1. **Column naming differs.** `lipidomics_measurement_columns` constructs
   `f"MB2_088-{n:02d}"` and will silently match nothing. Write a separate
   reader. Join the two modalities on the **integer sample number**, not the
   string ID.
2. **The absolute floor of 1.0 is meaningless here.** It exists to catch
   lipidomics' inferred gap-filled trace values around 1e-7. The smallest
   positive metabolomics value is 783. Applying `max(3 × mean_blank, 1.0)`
   would leave the floor inert — `3 × mean_blank` sets the limit for 237 of
   267 metabolites, and for the other 30 the mean blank is zero so nothing is
   masked at all. **Do not silently carry the 1.0 across.** Either drop the
   floor for metabolomics and document that the blank rule alone applies, or
   re-derive a floor on the metabolomics intensity scale. Report which was
   chosen and why in the diagnostics CSV.
3. **Two acquisition modes.** Positive and negative mode are separate
   injections with different intensity scales. Median-normalise **within
   mode**, not across the pooled 267. Normalising across modes would let a
   mode-level intensity difference masquerade as a per-sample loading effect.
   Record the per-mode medians so the choice is auditable.

### A1. Apply the same filter chain

Same order as the lipidomics chart, with the floor decision from A0:

1. blank-dominated features — median positive signal < 3 × mean blank
2. non-positive values → missing, never imputed
3. below-detection values → missing
4. drop features left with no values
5. log2, then median-normalise **within acquisition mode**
6. zero-variance drop

**Measured expectations on the full 60 samples:**

| step                                     | metabolomics                                          |
| ---------------------------------------- | ----------------------------------------------------- |
| blank-dominated removed                  | **19** of 267 (7.1%; lipidomics was 11 of 992 = 1.1%) |
| non-positive values masked               | 17                                                    |
| values below `3 × mean_blank`            | 1246 of 16 020 cells (7.8%)                           |
| metabolites where the blank sets a limit | 237 of 267                                            |
| metabolites with mean blank = 0          | 30                                                    |

The blank-dominated proportion is roughly seven times the lipidomics rate.
State that in the output; it is a real difference between the two panels and a
reader will ask.

Write `metabolomics_preprocessing_diagnostics.csv` with the same column names
as the lipidomics one so the two are directly comparable.

### A2. Run the identical outlier screen

Same statistics, same p = 3, same Beta limits, per region and pooled:
Hotelling T², normalised DModX, and the T²-versus-DModX influence plot.

**Do not re-tune anything for metabolomics.** The value of this exercise comes
entirely from the screen being identical; a screen tuned per modality cannot
support a concordance claim.

### A3. The validation that makes this worth doing

The vendor excluded **sample 26** on metabolomics grounds (meeting02 slides).
That is an independent expert judgement on the exact dataset we are about to
screen.

So the headline question is not "what is on the list" but:

> Does our screen, applied to metabolomics, reproduce the vendor's sample-26 call?

Report sample 26's rank and T²/DModX percentile explicitly, whether or not it
crosses the limit. Three outcomes, all informative:

- **26 is flagged** — the method is validated against an outside call, and
  every other flag it produces gains credibility.
- **26 is not flagged but ranks high** — partial support; report the rank.
- **26 is unremarkable** — either the vendor used a criterion we have not
  reproduced, or their call rested on something not in the delivered table.
  Both are vendor questions worth asking, and neither is a reason to hide the
  result.

Note that in lipidomics sample 26 ranks 9th and 12th of 20 across our screens,
so a null result here would not be surprising.

### A4. Concordance rule — fix before looking

Pre-specify, and record in the plan file before running:

- A sample is **concordant** if it exceeds the 95% limit on the same statistic
  (T² or DModX) in both modalities, in the same region.
- Report the **expected** number of concordant samples under independence
  (≈ 0.05 × 0.05 × 60 = 0.15 for a single statistic) alongside the observed
  count, so a coincidence cannot be read as corroboration.
- Report per-modality flag counts and the 2×2 contingency, not only the
  intersection.

### A5. The independence caveat — must appear on every output

Metabolomics and lipidomics are commonly produced from a **single biphasic
extraction**: polar phase to metabolomics, organic phase to lipidomics. If
that is the case here, a dissection, freezing or storage problem is shared by
construction, and "flagged in both modalities" is far weaker evidence than it
appears — the two screens are not independent replicates.

**This is unconfirmed.** Add to the vendor question list:

> Were the metabolomics and lipidomics measurements made from the same tissue
> extraction, split into phases, or from separate aliquots?

Until answered, phrase every conclusion as "concordant across two assays of
possibly shared provenance", never as "independent confirmation".

Also worth raising with the vendor while the list is open: the metabolomics
table ships `m/z` and `r.t.` for all 267 features, which the lipidomics table
omits entirely. That strengthens the existing request — the information
demonstrably exists in their pipeline.

---

## Part B — PCA loading composition

Visualisation only, on existing models. Three panels, primary first.

**Blocking issue:** `pca_loadings_*.csv` currently stores only the **top 20
features per component**. None of these plots can be built from it. Persist
the full loading matrix first (`pca_loadings_full_{scope}.csv`), or compute
loadings inside the plotting script.

### B1. Primary — class-segmented stacked bar

- x: PC1–PC4. y: proportion of that component's variance, 0–100%.
- Segment heights: squared loadings summed **by lipid class**. Because
  loadings are unit-norm, `Σⱼ pⱼₐ² = 1`, so the bar fills to exactly 100%
  with no residual needed.
- Show the ~6 largest classes named, collapse the rest into "other".

**Measured, pooled model, 844 complete-case features:**

| | composition of that PC's variance |
|---|---|
| PC1 (33.1% var) | PC 23%, PE 13%, TG 9%, PS 8%, DG 4%, other 43% |
| PC2 (15.5%) | PC 16%, PS 12%, TG 8%, FA 7%, PI 7%, other 50% |
| PC3 (8.6%) | PC 30%, PE 15%, **LPC 10%**, AcCa 8%, TG 5%, other 31% |

**Print an enrichment column, not just the share.** A class's share is only
interpretable against its share of the panel (PC 26% of features, TG 12%,
PE 9%, PS 6%, DG 5%). PC1 is roughly proportional across classes — a broad
axis, not a phosphatidylcholine axis.

**PC3 is the one to look at.** LPC is ~3% of the panel and carries 10% of
PC3's variance, roughly 3× enrichment. LPC is the lysophospholipid
degradation marker from Part E of the QC-completion plan. That makes
"PC3 is a sample-handling axis rather than a biological one" a concrete,
testable hypothesis. Cross-reference the two analyses explicitly; if the
lyso/parent ratios flag the same samples that sit at the extremes of PC3,
that is the first mechanistic explanation this project has had for any
component.

### B2. Cumulative share curve

- x: N, number of features (log scale, 1 → all). y: cumulative share of
  squared loading.
- One line per PC, plus the **uniform diagonal** `N / n_features` as
  reference. Concentration reads directly as distance above the diagonal.

**Measured (844 features; uniform top-10 share = 1.18%):**

| PC  | var explained | top 10 | top 25 | top 50 | top-10 vs uniform |
| --- | ------------- | ------ | ------ | ------ | ----------------- |
| PC1 | 33.1%         | 3.2%   | 7.9%   | 15.3%  | 2.7×              |
| PC2 | 15.5%         | 5.7%   | 13.4%  | 24.2%  | 4.8×              |
| PC3 | 8.6%          | 8.8%   | 19.0%  | 32.6%  | 7.5×              |
| PC4 | 5.5%          | 8.4%   | 18.9%  | 32.3%  | 7.1×              |

The headline is a clean negative result and should be stated as one: **no
component is driven by a small set of lipids.** PC1's top 10 carry under 4% of
its variance. Nobody should go hunting for "the five lipids behind PC1".

### B3. Supporting panel — per-feature stacked bar with residual

The literal version requested: x = PC1–PC4, y = 0–100%, segments = the top 10
features by |loading|, height = squared loading, **plus a grey "all other
features" block** that makes the bar reach 100%.

Be aware before building it that the coloured portion will be 3–9% of each bar
and the grey block 91–97%. That is the honest picture and it carries the same
message as B2, but it will not distinguish the PCs from one another visually.
Keep it as a supporting panel; do not lead with it.

### B4. Three things that will otherwise be wrong

**Use squared loadings for every share, never absolute.** Loadings are
unit-norm, so `Σⱼ pⱼₐ² = 1` and `Σ_topN pⱼₐ²` is a genuine variance share.
Summing `|pⱼₐ|` produces a number that is not a share of anything. Multiply by
the eigenvalue if the share of **total** dataset variance is wanted rather
than share of that component.

**Use |loading| to rank, but keep the sign in any per-feature display.** The
sign is what links a loading to the scores plot. The existing lollipop plots
must keep it.

**Fix the sign convention and state it.** Component signs are arbitrary and
can flip between runs or regions. Force the largest absolute loading on each
PC positive, and say so in the caption.

Also merge `technical_dominated` from `technical_vs_biological_variance.csv`
and report, per PC, what fraction of the top 25 are technically dominated. The
existing concentration file already shows PC3 at 0.28 — over a quarter of its
top features are noise-dominated, which is a second reason to treat PC3 as
technical rather than biological.

---

## Part C — noisyR package cross-check

The manual implementation stays. This runs the reference implementation
**alongside** it and compares.

### C1. Scope

- Use only noisyR's **threshold-finding** step (the count-matrix approach,
  `noisyr_counts` / `calculate_threshold_noise`).
- **Do not use its noise-removal step.** It adds the average threshold to
  every entry, which is a count-data operation and is wrong for log-scale peak
  areas. Take the curve and the threshold; do not let it transform the matrix.
- The package is already present in the mounted `noisyR` repo and `renv/` is
  configured, so this is an R script invoked from the pipeline, not a new
  dependency negotiation.

### C2. Inputs must match exactly

Feed noisyR the **same matrix** the manual implementation uses: log2 of
positive raw peak areas, before the detection-limit filter and before median
normalisation, full 60 samples, outlier mouse retained. Any difference in
input makes a disagreement uninterpretable.

Run per region and on the 6 Tech-Mix injections, matching the manual run.

### C3. What to compare and report

- Overlay both curves per region on one figure: correlation versus abundance,
  manual in one colour, noisyR in another.
- Report both thresholds under noisyR's default rule (correlation first
  exceeds 0.25) and the difference between them in log2 abundance units.
- Report Spearman correlation between the two curves' y-values at matched
  abundance windows.

**Interpretation, written before seeing the result:**

- **Curves agree** — cite Moutsopoulos et al. (2021), keep whichever
  implementation is cleaner, and the "did you code it correctly" question is
  closed.
- **Curves disagree** — this is a finding, not a failure. Chase it. The most
  likely causes are noisyR's count assumptions applied to non-count data, or a
  difference in how missing comparator values are handled. Report the
  diagnosis rather than picking the flattering curve.

Keep the planted-noise-floor test that validates the manual implementation
end to end. It is the only thing establishing that either curve is correct in
an absolute sense, and it is not replaceable by agreement between two
implementations.

### C4. Still not adopted

No abundance filter is adopted in this pass, by either implementation. If one
is ever adopted it goes through the specification curve like the others.

---

## Part D — Tissue-mass PCA, discretised

Smallest item. Continuous colour over 57 points is unreadable; three bins are
not.

**The check that would have made this a bad idea passes.** Tissue mass does
not differ by region (Kruskal-Wallis H = 1.6, p = 0.45), so a pooled tertile
split will not quietly re-encode region:

| region | min | median | max | sd |
|---|---|---|---|---|
| Cerebellum | 27.5 | 40.2 | 60.1 | 11.2 |
| Cortex | 29.8 | 40.8 | 62.8 | 8.1 |
| Hippocampus | 25.4 | 37.2 | 57.3 | 7.8 |

- **Three bins, not more.** Pooled tertiles, cut points near **36.6** and
  **43.3 mg**. Roughly 19 samples per bin.
- Label bins with their ranges in the legend (`25–37 mg`), not `low/mid/high`
  alone — a reader should not have to guess what the bins mean.
- Use a sequential palette, not the categorical one, so the ordering is
  visible.
- **Print the numeric correlation of tissue mass with PC1 and PC2 on the
  figure.** Binning makes a pattern easier to see and equally easier to
  over-read; the correlation is what the conclusion rests on.
- Apply to the **pooled** PCA only, as with the run-order figure. Tissue mass
  is a confounder check, not a design variable.

---

## File layout

- `src/metabolomics_io.py` — reader for the Metabolomics sheet;
  `metabolomics_measurement_columns`, integer-sample-number join key
- `src/metabolomics_preprocessing.py` — filter chain with per-mode
  normalisation and the documented floor decision
- `src/run_metabolomics_outlier_screen.py` — Part A2
- `src/cross_modality.py` — `concordance_table`, `expected_under_independence`
- `src/pca_loadings.py` — extend with `class_composition`,
  `cumulative_share_curve`, `enrichment_vs_panel`
- `src/run_loading_composition.py` — Part B
- `R/run_noisyr_crosscheck.R` — Part C, invoked from
  `src/run_abundance_similarity.py`
- `src/outlier_screen.py` — Part 0 Beta-limit fix
- `src/run_mia_vs_control.py` — persist full loadings; tissue-mass bins

## Outputs

```
results/metabolomics/01_preprocessing/metabolomics_preprocessing_diagnostics.csv
results/metabolomics/01_preprocessing/blank_dominated_features.csv
results/metabolomics/02_qc/outlier_screen_{region}.csv
results/metabolomics/02_qc/figures/influence_t2_vs_dmodx_{region}.*
results/cross_modality/concordance_table.csv
results/cross_modality/vendor_sample26_check.csv
results/cross_modality/figures/concordance_{statistic}.*
results/mia_vs_control/04_multivariate/pca_loadings_full_{scope}.csv
results/mia_vs_control/04_multivariate/pca_class_composition.csv
results/mia_vs_control/04_multivariate/figures/pca/loadings_class_stacked_{scope}.*
results/mia_vs_control/04_multivariate/figures/pca/loadings_cumulative_share_{scope}.*
results/mia_vs_control/04_multivariate/figures/pca/loadings_feature_stacked_{scope}.*
results/mia_vs_control/04_multivariate/figures/pca/scores_pooled_tissue_mass_binned.*
results/mia_vs_control/02_qc/noisyr_comparison.csv
results/mia_vs_control/02_qc/figures/noisyr_vs_manual_{region}.*
```

## Sequencing

1. **Part 0** — Beta-limit fix. Prerequisite for Part A; nothing else is
   trustworthy until the screen is calibrated.
2. **Part D** — tissue-mass bins. Half an hour, no dependencies.
3. **Part B** — loadings. Needs the full-loadings persistence fix first.
   Highest value per effort and directly requested.
4. **Part A** — metabolomics. The largest piece and the only genuinely new
   information.
5. **Part C** — noisyR. Confirmatory, so last.

## Validation

- Part 0: Beta limit matches the closed form; simulated clean data flags at
  5% ± 1.5%; per-region flags become {25, 35, 56, 33, 10}.
- Part A: metabolomics reproduces 19 blank-dominated, 17 non-positive, 1246
  below-limit cells, 237 blank-set limits, 30 zero-blank features.
- Part A: sample 26's rank in the metabolomics screen is reported whether or
  not it is flagged.
- Part A: concordance count is reported next to its expectation under
  independence.
- Part B: every class-composition bar sums to 1.0 ± 1e-9; cumulative shares
  are monotone in N and bounded by 1; sign convention is deterministic
  across reruns.
- Part B: reproduces PC1 top-10 = 3.2%, PC3 LPC share = 10%.
- Part C: both implementations receive a byte-identical input matrix;
  disagreement is diagnosed, not averaged away.
- Part D: tertile cut points reproduce at 36.6 and 43.3 mg; bin sizes within
  ±1 of 19.
- `pytest -q` passes.

## Explicitly out of scope

- Differential testing on metabolomics.
- Adopting any new filter into the primary analysis.
- Proteomics. There is no proteomics data in either repo or the workbook; if
  it arrives, Part A extends to it unchanged.
