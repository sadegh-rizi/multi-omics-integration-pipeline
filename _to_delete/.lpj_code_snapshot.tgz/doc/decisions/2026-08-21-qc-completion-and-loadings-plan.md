# Plan: complete the standard QC workflow, and visualise PCA loadings

Implementation plan. Covers the gaps in the seven-step QC checklist plus a
readable treatment of PCA loadings.

## Status against the checklist — read first

Most of this is already implemented. Planning it as a rebuild would waste
effort and risk changing settled results.

| Step | Status |
|---|---|
| 1. MS pre-processing | done by the measuring core; software and parameters undocumented |
| 2. Blank inspection (< 3× mean blank) | **done** — 11 lipids removed feature-level, 412 values masked value-level |
| 3. PCA with confounder metadata | **partial** — region/group/sex done; run order, tissue mass, mouse deliberately deleted |
| 4a. Remove > 20% missing | **not done** — no prevalence filter exists |
| 4b. Impute the rest | implemented (4 methods), run through the specification curve, **not adopted** |
| 5a. Outside 95% Hotelling T² ellipse | **done** |
| 5b. T² range plot | values exist, **no figure** |
| 5c. DModX plot | values computed, **no figure** |
| 6. Pre-analytical markers | **not done** |
| 7a. Verify QC clustering | **done — and it fails** (QC spread is 0.76 of biological on PC2) |
| 7b. Exclude tech > bio variation | **done**, tested as exclusion condition B — made results worse |
| PCA loadings | tables exist; plots were deleted as unreadable |

So the real work is: **one bug fix, one new filter, four figures from existing
numbers, and one genuinely new analysis.**

## Standing constraint

The null result is settled across 8 pre-specified preprocessing
specifications. Nothing here is expected to change it, and no new filter is
adopted directly — if a filter is added it goes through the specification
curve like the others. This plan is for completeness of the QC record and for
presentation, not for another attempt at significance.

---

## Part A — Fix the blank-filter reporting bug (prerequisite)

`run_mia_vs_control.py:146-147` computes the detection-limit report from
unfiltered `raw`, skipping `exclude_blank_dominated_features`. The analysis
matrix is correct; only the report is wrong, and the 11 blank-dominated lipids
get counted twice.

**Fix:** apply the blank filter before `below_detection_reasons`, and subset
`blanks` to the surviving index as `preprocess_for_differential` does at line
219.

**Expected after fix (60 samples):** 412 values masked (263 blank-derived /
149 floor) across 86 lipids, 4 losing all values, **977 surviving**. Currently
reported: 880 / 96 / 5.

Also add the missing `detection_limit_fully_excluded_features.csv`, and add a
`n_blank_dominated_removed` column to `preprocessing_diagnostics.csv`.

Do this first — the other counts depend on it.

---

## Part B — Prevalence filter (step 4a)

**Rule:** remove a lipid if more than `MAX_MISSING_FRACTION` of its values are
missing after the blank and detection-limit filters.

**Measured effect** (60 samples, post-filter panel of 977):

| threshold | lipids removed | remaining |
|---|---|---|
| > 20% missing | **22** | 955 |
| > 50% missing | 3 | 974 |

For reference, 842 of 977 lipids (86%) are fully complete.

**Why this matters beyond the count.** The pipeline currently has *no*
prevalence rule, and its two paths sit at opposite extremes: differential
testing accepts any lipid meeting `min_per_cell = 3`, while the multivariate
path silently demands 100% completeness via `dropna`. A 20% rule is the
conventional middle ground and makes the implicit `dropna` explicit.

**Do not adopt directly.** Add `MAX_MISSING_FRACTION = 0.20` and
`APPLY_PREVALENCE_FILTER = False` to `analysis_config.py`, implement
`exclude_low_prevalence_features` in `preprocessing.py`, and add it as a
**third axis** to the specification curve. That takes the curve from 8 to 16
specifications — still cheap at roughly 8.5 minutes per 8.

**Ordering:** after the detection-limit filter, before log2. Missingness must
be counted on the post-detection-limit matrix, since that filter creates
missing values.

---

## Part C — Outlier figures from existing values (steps 5b, 5c)

No new computation. `outlier_screen.py` already produces T² and DModX.

**C1. T² range plot** — samples on the x-axis in sample-number order, T² on
the y-axis, horizontal lines at the 95% and 99% limits. Use the **Beta**
critical value for individual observations, not the F form (corrected
earlier — the F version is calibrated to 0.88%, not 5%).

**C2. DModX plot** — same layout, normalised DModX on the y-axis, limit at
the F-based 95% line.

**C3. T² versus DModX scatter** — the standard "influence plot", with both
limits as quadrant lines. This is the one that reads best in a presentation
because it shows the two failure modes as separate axes.

Use **p = 3 components** for both, matching the scree elbow, and full 60
samples per the standing policy. Label every point with its sample number.

**Expected:** sample 25 top-right in the influence plot; sample 31 high DModX
with near-zero T²; nothing else consistent.

---

## Part D — Restore confounder colourings (step 3)

Three PCA scores figures were deleted in the earlier cleanup: coloured by
`Sample number` (run-order proxy), `Tissue mass (mg)`, and `Mouse number`.

Restore **run order and tissue mass** on the **pooled** PCA only — those are
the two genuine confounder checks. Skip mouse number, which is a design
variable rather than a confounder.

The numeric version already passes: no PC in any region correlates with sample
number (pooled PC1 r = +0.10, p = 0.47; strongest anywhere is Hippocampus PC2
at r = −0.40, p = 0.09). The figures let you *show* the negative result rather
than assert it.

State on the figure that sample number is a **proxy** for acquisition order,
not the confirmed order — that remains an open vendor question.

---

## Part E — Pre-analytical markers (step 6) — genuinely new

The only item here that asks a question nothing else in the pipeline asks:
**was any sample handled or stored badly?**

**Method.** Lysophospholipids are degradation products of their parent
phospholipids via phospholipase activity during dissection, freezing or
storage. An elevated lyso-to-parent ratio is a standard pre-analytical marker.

Per sample, compute the log2 ratio of summed lyso-class intensity to summed
parent-class intensity for each usable pair:

| pair | species available |
|---|---|
| LPC / PC | 29 / 256 |
| LPE / PE | 12 / 78 |
| LPS / PS | 3 / 54 |
| LPA / PA | 2 / 29 |
| LPG / PG | 2 / 16 |
| LPI / PI | 1 / 40 |

**Use LPC/PC and LPE/PE as primary** — they have enough species on both sides
to be stable. Report the other four but treat them as unreliable; a ratio
built on 1–3 lyso species is dominated by single-feature noise and must not
be interpreted as a degradation signal on its own.

**Output:** box plot per region with ±3×IQR whiskers, samples outside flagged
and labelled. Plus a table of per-sample ratios.

**Two things worth checking beyond outlier flagging:**

1. Whether any sample already flagged by T², DModX or leverage also shows an
   elevated ratio — that would give an outlier a *mechanism* rather than just
   a distance, which is what the whole outlier discussion has lacked.
2. Whether ratios differ systematically **by region**. Cerebellum has markedly
   lower biological variance than cortex and hippocampus (19% versus 71% and
   69% technical-dominated) and that difference has never been explained.
   A dissection or handling difference between regions would be a candidate
   explanation, and this is the first analysis able to test it.

**Caveat to state plainly:** lyso species are also genuine biological
constituents, so an elevated ratio is suggestive of degradation, not proof.

---

## Part F — PCA loadings, made readable

Loadings tables already exist at `04_multivariate/pca_loadings_*.csv`. This is
visualisation only.

**Universal first step:** rank by absolute loading and keep the top N. Never
plot all ~950 features with arrows.

### F1. Lollipop plot — one PC in isolation

Top 25 features by |loading| on the y-axis, signed loading on the x-axis,
ordered by value so positive and negative separate visually. Point plus thin
stem, not bars. Label with `Lipid Name`, not `Feature` number.

Produce for **PC1 and PC2**, pooled and per region.

### F2. Loading scatter — PC1 versus PC2

All features as small semi-transparent grey points at their (PC1, PC2)
loading coordinates. Highlight and label the top 15 by distance from the
origin, `sqrt(PC1² + PC2²)`. Keeps the full context without arrow clutter.

### F3. Clustered heatmap — several PCs at once

Union of the top 20 features from each of PC1–PC4 (expect 50–70 unique
features). Rows = features, columns = PCs, diverging colour scale centred at
zero. Cluster rows only. Shows at a glance which features are specific to one
component versus spread across several.

### Three things that will otherwise be got wrong

**Sign is arbitrary.** PCA component signs carry no meaning — a loading can
flip sign between runs or regions. Fix a convention (e.g. force the largest
absolute loading on each PC to be positive) and state it in the caption.
Without this, "positive loading" is uninterpretable next to a scores plot.

**Flag noise-driven components.** Merge `technical_dominated` from
`technical_vs_biological_variance.csv` onto the loadings and report, per PC,
what fraction of the top 25 are technically dominated. A PC built mainly from
noisy lipids is a noise axis and must be labelled as such rather than
interpreted biologically.

**Add a concentration statistic.** For each PC report the share of total
squared loading carried by the top 10, 25 and 50 features. That single number
answers "is this PC driven by a handful of lipids or by everything at once" —
which is the actual question behind wanting the loadings — without needing to
read any plot.

---

## File layout

- `src/preprocessing.py` — add `exclude_low_prevalence_features`
- `src/analysis_config.py` — `MAX_MISSING_FRACTION`, `APPLY_PREVALENCE_FILTER`
- `src/pre_analytical.py` — `lyso_parent_ratios`, `flag_abnormal_ratios`
- `src/pca_loadings.py` — `top_loadings`, `loading_concentration`,
  `align_loading_signs`
- `src/run_qc_completion.py` — standalone script producing Parts C–F
- `src/run_mia_vs_control.py` — Part A fix only
- `src/run_specification_curve.py` — add the prevalence axis
- Tests: prevalence filter removes exactly the expected count on synthetic
  data; lyso ratio is computed on sums not means; sign alignment is
  deterministic; concentration statistics sum correctly.

## Outputs

```
results/mia_vs_control/01_preprocessing/detection_limit_fully_excluded_features.csv
results/mia_vs_control/01_preprocessing/prevalence_filter_features.csv
results/mia_vs_control/02_qc/pre_analytical_lyso_ratios.csv
results/mia_vs_control/02_qc/figures/t2_range_plot.*
results/mia_vs_control/02_qc/figures/dmodx_plot.*
results/mia_vs_control/02_qc/figures/influence_t2_vs_dmodx.*
results/mia_vs_control/02_qc/figures/pre_analytical_lyso_ratios.*
results/mia_vs_control/04_multivariate/pca_loading_concentration.csv
results/mia_vs_control/04_multivariate/figures/pca/loadings_lollipop_{scope}_{pc}.*
results/mia_vs_control/04_multivariate/figures/pca/loadings_scatter_{scope}.*
results/mia_vs_control/04_multivariate/figures/pca/loadings_heatmap_{scope}.*
results/mia_vs_control/04_multivariate/figures/pca/scores_pooled_{sample_number,tissue_mass}.*
```

## Sequencing

1. **Part A** — bug fix, prerequisite for every count downstream
2. **Part F** — loadings; pure visualisation of existing tables, highest value
   per effort, and directly requested
3. **Part E** — pre-analytical markers; the only new information here
4. **Part C** — outlier figures from existing values
5. **Part D** — restore two confounder colourings
6. **Part B** — prevalence filter; last, because it changes the feature set
   and requires re-running the specification curve

## Validation

- Part A reproduces 412 / 86 / 4 / 977 on 60 samples
- Prevalence filter at 20% removes exactly 22 lipids
- Loading sign convention is deterministic across reruns
- Concentration shares are monotone increasing in N and bounded by 1
- Lyso ratios computed from class sums, with per-pair species counts reported
  alongside so thin pairs are visibly thin
- `pytest -q` passes
