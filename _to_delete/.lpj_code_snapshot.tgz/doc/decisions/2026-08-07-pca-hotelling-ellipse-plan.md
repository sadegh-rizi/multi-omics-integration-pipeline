# Plan: per-region PCA scores plot with Hotelling's T² ellipse

Unsupervised PC1-vs-PC2 scores plot, one per brain region, with a Hotelling's
T² confidence ellipse and every sample labelled. This is the standard
chemometric outlier-diagnostic figure.

## Disambiguation — two different things are called "the T² ellipse"

They are not interchangeable and the repo will end up with both, so name them
distinctly:

| | **Hotelling T² ellipse (this plan)** | Per-group data ellipse (existing PLS-DA figures) |
|---|---|---|
| How many | **one**, around all samples in the region | one per group (MIA, Control) |
| Built from | covariance of *all* scores | covariance of that group's scores |
| Answers | "is any sample atypical of the batch?" | "how spread out is each group?" |
| Group labels | **not used** — fully unsupervised | required |
| Where used | this figure | `run_vendor_fidelity._plot_plsda_vendor_style` |

This plan implements the first. Do not reuse `f_data_ellipse` from the vendor
figures — it computes the second, and silently swapping them would produce a
plot that looks right and means something else.

## The one thing most likely to be got wrong

**The ellipse must be computed with p = 2**, matching the two components being
displayed.

`src/outlier_screen.py` currently computes T² with `OUTLIER_SCREEN_PCS = 10`.
That value is correct for its own purpose (a numeric screen over a 10-D
subspace) but **wrong for this figure**: an ellipse drawn on a 2-D plot using a
10-dimensional boundary does not correspond to the region a viewer is looking
at, and samples would appear inside or outside the line for no visible reason.

Take `p = 2` from the number of plotted components, not from config. Add a
comment in the code saying why, because it looks like an inconsistency.

## Method

For a region with `n` samples, on the auto-scaled matrix
(`preprocess_for_multivariate`, complete features only):

1. PCA; keep scores on PC1 and PC2, and their explained-variance fractions.
2. Because PCA scores are orthogonal, the ellipse is **axis-aligned in score
   space** — no rotation term needed:

   ```
   (t1 / s1)² + (t2 / s2)² = T²_crit
   ```

   where `s_i` is the SD of the scores on component *i*.
3. Boundary:

   ```
   T²_crit = p(n − 1) / (n − p) × F(α, p, n − p),   p = 2
   ```

4. Semi-axis along PC*i* = `s_i × sqrt(T²_crit)`.
5. Draw at **95% (solid)** and **99% (dashed)**.
6. Per-sample `T² = (t1/s1)² + (t2/s2)²`; flag `T² > T²_crit`.

## Expected values — verified, use these to check the implementation

Current analysis population (mouse `C00431239 - 3` excluded, n = 19 per region):

| Region | PC1 | PC2 | T² 95% | T² 99% | outside 95% | highest T² |
|---|---|---|---|---|---|---|
| Cerebellum | 27.6% | 21.0% | 7.61 | 12.94 | none | 35 (6.74), 56 (6.50) |
| Cortex | 27.8% | 12.8% | 7.61 | 12.94 | **22** | 22 (9.23), 10 (5.74) |
| Hippocampus | 28.8% | 16.1% | 7.61 | 12.94 | none | 33 (6.93), 21 (4.51) |

T²_crit is identical across regions because it depends only on `n` and `p`,
both of which are the same — a useful correctness check.

**Note sample 22 (Cortex) falls outside the 95% ellipse.** It did *not* appear
in the earlier 3-PC or 10-PC screens. That is expected behaviour, not a
contradiction: a sample can be extreme in the PC1–PC2 plane while unremarkable
once further components are included. Report it, do not act on it — one sample
outside a 95% boundary among 19 is the definition of the nominal false-positive
rate (0.05 × 19 = 0.95 expected).

## Also produce the full-data version

Run the same figure on all 60 samples (n = 20 per region, before the mouse
exclusion), into a clearly separate output. That is the version showing where
samples 25, 26 and 27 actually sit, and it is the more useful diagnostic for
the vendor discussion. Label it unambiguously so it is never mistaken for the
analysis population.

## Figure specification

- One figure per region. Points coloured by `Bio group` using
  `BIO_GROUP_COLORS` from `plot_config`; marker shape by `Sex`.
- **Every sample labelled with its sample number**, offset to avoid the marker.
- Axis labels: `PC1 (27.8% explained variance)` — always state the percentage.
- Equal aspect ratio, or the ellipse is visually distorted and unreadable as a
  distance boundary.
- 95% ellipse solid, 99% dashed, both in a neutral grey drawn **behind** points.
- Caption: n, number of features, both boundary values, and any sample outside.
- Saved via `plot_config.save_figure`.

Colour encodes group only so the reader can see group membership. **The ellipse
itself must not be computed per group** — that is the whole point of the
unsupervised diagnostic.

## File layout

- `src/pca_analysis.py`: add
  `hotelling_ellipse(scores, *, alpha=0.95)` returning boundary points plus the
  `T²_crit` value, and `hotelling_t2_2d(scores)` returning per-sample T².
  Both take exactly two score columns and derive `p = 2` from that.
- `src/run_pca_ellipse.py`: standalone script, both populations, both figures.
- Tests:
  - a synthetic isotropic 2-D cloud puts ≈5% of points outside the 95% ellipse
  - `T²_crit` matches `p(n−1)/(n−p)·F` for a hand-checked n
  - the ellipse is axis-aligned in score space (zero off-diagonal covariance)
  - the function refuses more or fewer than two score columns, so the p=2
    assumption cannot be violated silently

## Outputs

```
results/mia_vs_control/04_multivariate/pca_hotelling_t2.csv
results/mia_vs_control/04_multivariate/figures/pca/
    hotelling_{cerebellum,cortex,hippocampus}.*
    hotelling_fulldata_{cerebellum,cortex,hippocampus}.*
```

`pca_hotelling_t2.csv`: one row per sample per population — Region, Sample,
PC1, PC2, T², `T²_crit_95`, `T²_crit_99`, flags, population label.

## Validation

- Reproduce the expected-values table above exactly.
- `T²_crit = 7.61` (95%) and `12.94` (99%) in all three regions at n = 19.
- Sample 22 outside the Cortex 95% ellipse; nothing outside elsewhere.
- Synthetic isotropic test gives ≈5% exclusion.
- Ellipse renders as an ellipse, not an oval distorted by unequal axis scaling.

## Open items

1. Whether to add the T²-vs-DModX ("influence") plot, the usual companion that
   separates samples extreme *within* the model from samples poorly described
   *by* it. `dmodx` already exists in `outlier_screen.py`. Not included here to
   keep this one figure per region; easy to add later.
2. Whether the full-data version belongs in the thesis or only in the vendor
   discussion. Presentation decision, not a methods one.
