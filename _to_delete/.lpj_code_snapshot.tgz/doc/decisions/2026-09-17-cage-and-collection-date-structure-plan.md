# Plan: cage clustering and collection-date confound

**Status: CONFIRMED 2026-09-17 — implementation in progress.**
`data/Samples for metabolomics.xlsx` supplies the cage and
collection-date fields that resolve open question A1 and expose a new
treatment/date confound. Confirm §8 before any implementation, per
`/careful-planning`.

Outputs would go to a new `results/mia_vs_control/08_cage_structure/`.
Nothing existing is overwritten; this is a sensitivity and diagnostic layer on
the current primary, not a replacement for it.

---

## 1. What the new file contains

`data/Samples for metabolomics.xlsx`, sheet `Samples to be shipped`, 60 rows.
Despite the filename it covers **all 60 samples and the same 20 mice**, so it
applies to lipidomics identically. Columns: `Sample no`, `Tissue type`,
`Weight`, `Date collected`, `Cage no`, `Age`, `Sex`, `MIA or Control`,
`Date processed`.

Two handling notes for the implementer:

- **Metadata appears only on the first of each mouse's three tissue rows** and
  must be forward-filled before use. A naive read gives 40 rows of NaN.
- The join key is `Sample no` → the existing `Sample number`, which produces
  `MB2_088-NN` exactly as `full_lipidomics_metadata` already does.

`data/` is immutable per `doc/agent-rules.md`; this file is read, never edited.

## 2. What it establishes — A1 is answered

**The `Mouse number` prefix is the cage number.** The `Cage no` values are
identical as a set to the prefixes in
`results/mia_vs_control/00_inputs/differential_input_metadata.csv`. `C00` and
`C01` are two separate cages collected 2024-08-06, one MIA male each — they
were never truncated identifiers.

**Every animal is P14**, which is pre-weaning. Pups remain with the dam until
roughly P21, so a cage at P14 is a dam plus her litter. **Cage is therefore the
clustering unit and the exchangeability block**, by identification rather than
assumption. This closes A1 and unblocks B1.

| group          | cages | pups per cage    | sexes within cage         |
| -------------- | ----- | ---------------- | ------------------------- |
| Saline Control | **2** | 6, 4             | both                      |
| MIA            | **6** | 3, 3, 1, 1, 1, 1 | **single-sex, every one** |

Four of six MIA cages are singletons and contribute no within-cluster
information. Only four cages have more than one pup, which is the entire basis
for any ICC estimate.

**Residual uncertainty, and the one question still worth asking the animal-work
owner:** six of eight cages are single-sex. For whole litters that is
improbable — a litter of three being all one sex is about 25%, two such cages
about 6% — so most likely only a sex-selected subset of each litter was
sampled. Cage remains the correct block either way, but because MIA is
administered *per dam*, whether one cage is exactly one dam should be
confirmed before the experimental-unit count of 8 is stated as fact.

## 3. The new problem: collection date is partly confounded with treatment

| Date collected | MIA | Control |
|---|---|---|
| 2024-06-11 | 4 | 6 |
| 2024-08-06 | 2 | **0** |
| 2024-09-13 | 4 | **0** |
| 2024-10-23 | **0** | 4 |

Each cage has exactly one collection date, so cage is nested within date: 8
cages inside 4 dates. Six of ten MIA pups come from dates with no control
animal; four of ten controls from a date with no MIA animal. The span is
roughly five months and carries dam cohort, season, reagent lot and possibly
operator.

**The only date-matched treatment comparison in the study is 2024-06-11: 4 MIA
versus 6 control, from 3 cages.**

Not confounded: `Date processed` is `2025-02-17` for all 60 samples, so
extraction and instrument processing were a single batch. This is a genuine
strength and should be reported alongside the confound rather than buried.

## 4. Two results that can be derived before any code is written

Both are properties of the design, not of the data, and both belong in the plan
so that nobody reads them later as a finding.

**Cage-level permutation cannot produce a discovery.** Permuting cage labels
for the MIA contrast gives C(8,2) = **28** distinct assignments, so the
smallest attainable empirical p-value is 1/28 ≈ **0.036**. Benjamini–Hochberg
across a ~950-feature panel then has a floor of 0.036 × 950 ≈ 34, so
**q < 0.05 is unreachable by construction**. Restricted to 2024-06-11 the
space collapses to C(3,1) = 3 and the floor becomes 0.33. This is the same
class of limitation as the 999-permutation resolution floor in
`2026-09-07-noisyr-diagnosis-and-repair-plan.md` §2, and it must be stated
wherever a cage-level empirical p-value is reported.

**Adjusting for date removes most of the data from the treatment estimate.**
With date as a fixed effect, the three single-group dates are absorbed entirely
by their own date coefficients and contribute nothing to the MIA contrast. The
estimate then rests only on the within-2024-06-11 comparison. So the date
confound **cannot be adjusted away; it can only be quantified and reported.**
The deliverable is a measurement of how much date explains, not a corrected
treatment estimate.

## 5. Proposed work

### 5.1 Join cage and date into the analysis metadata (prerequisite)

Extend `full_lipidomics_metadata` with `Cage`, `Date collected` and
`Collection cohort` (the date as an ordered factor), sourced from the new
workbook and joined on sample number. Assert the cage set matches the existing
`Mouse number` prefixes, and fail loudly if it does not — that assertion is the
regression test for the join.

### 5.2 Variance attribution — do this first, it needs no identifiability

Add `Cage` and `Collection date` to the existing
`pca_score_attribution_<region>.csv` factors alongside Bio group, Sex and
Tissue mass. This is descriptive R² of each PC against each factor and does not
require the treatment contrast to be estimable, so it is the lowest-risk and
highest-value item.

The comparison that matters: Bio group currently explains **0.08%** of cortex
PC1. If collection date explains substantially more, there is a real batch
effect partly aliased with treatment — a finding in its own right, and one that
reframes the null rather than merely caveating it.

### 5.3 Intraclass correlation

Estimate per-feature ICC = between-cage variance / total variance from the four
multi-pup cages, and report the distribution across the panel per region.

This is weak — two control cages and two MIA cages with 3 pups each — and the
plan must say so. It is reported as a **design parameter with an interval, not
a point estimate**, and its purpose is to feed §5.5 and the eventual
sample-size recommendation. Brain-lipid litter ICC is not something the
literature reports, so even a wide interval is useful.

### 5.4 Cage-aware refits, as declared arms

| arm | model                                                      | what it costs                            | what it buys                                     |
| --- | ---------------------------------------------------------- | ---------------------------------------- | ------------------------------------------------ |
| A   | collapse to cage-level means, fit at the experimental unit | lowest power; n = 8 clusters             | always fits; exactly correct unit                |
| B   | OLS + cage random intercept                                | expect many singular fits                | uses within-cage information where it exists     |
| C   | add collection date as a fixed effect                      | treatment estimate reduces to 2024-06-11 | shows the size of the confound                   |
| D   | restrict to 2024-06-11                                     | 4 vs 6 pups, 3 cages                     | the only unconfounded comparison, stated plainly |

**Arm A is proposed as the primary litter-aware analysis**, not arm B. With two
control cages, four singleton MIA cages and a 2-vs-6 split, a mixed model has
almost nothing to estimate between-cage variance from and will frequently
return boundary fits that collapse back toward the pooled analysis. The repo
has the precedent: the earlier pooled cross-region mixed model failed for 87%
of features (`doc/methodology.md` §9). Arm B is retained as a sensitivity that
**reports its singular-fit proportion as a headline number**, not as a
footnote.

### 5.5 Permutation schemes

Replace the sample-level scheme for the MIA contrast with **cage-level label
permutation**, and record the 28-assignment ceiling from §4 in the manifest
next to every empirical p-value.

Sex needs a decision rather than a default (§8.2): it varies within cage in the
two control cages but is a cage-level label throughout MIA, so no single
exchangeability unit is correct for it. Whatever is chosen must be recorded per
effect, as the existing manifest already does.

This change propagates to PERMANOVA, the PLS-DA permutation test, `m_eff`, and
the feature-module co-membership nulls — every inferential statement in the
project, not just the differential.

### 5.6 Written before the results are seen

Per `doc/agent-rules.md`:

The genuine open outcomes are: how much variance date explains (§5.2), what the
ICC interval is (§5.3), and how many features arm B can fit at all.

## 6. Files

- `src/lpj_lipidomics/io/study_design.py` — cage/date join and the set-match
  assertion.
- `src/lpj_lipidomics/config.py` — workbook path, cluster and cohort column
  names, arm definitions.
- `src/lpj_lipidomics/statistics/clustered.py` — **new**: cage collapse, ICC,
  cage-level permutation.
- `src/lpj_lipidomics/statistics/permutation.py` — cage-level schemes and the
  ceiling record.
- `src/lpj_lipidomics/runners/run_mia_vs_control.py` — added attribution
  factors.
- `src/lpj_lipidomics/runners/run_cage_aware_sensitivity.py` — **new**: arms
  A–D and a `cage_structure_manifest.json`.
- `tests/test_cage_structure.py` — see §7.

One new statistics module and one new runner. Per `/research-code-style`, do
not split further until a second caller exists.

## 7. Validation

- **Join test**: assert the cage set from the new workbook equals the
  `Mouse number` prefix set, and that forward-fill yields 60 non-null rows.
  Write this first; it is the regression test for §5.1.
- **Permutation-ceiling test**: on the actual design, assert the number of
  distinct cage-level assignments is 28 and that no empirical p below 1/28 can
  be emitted. This is the test that stops §4 being rediscovered as a result.
- **Nesting test**: assert every cage maps to exactly one BioGroup and exactly
  one collection date, so the nesting the models assume is real.
- **ICC test**: on synthetic data with a known planted between-cluster
  variance, assert recovery within tolerance; and on data with zero cluster
  effect, assert the estimate is near zero rather than negative or NaN.
- **Singular-fit accounting**: arm B must report fitted / singular / failed
  counts per region; a run where most features fail is a reportable outcome,
  not an error to suppress.
- Confirm nothing outside `08_cage_structure/` changes.

## 8. Confirmed decisions

1. **Arm A collapse unit:** cage means.
2. **Sex exchangeability:** report both within-cage and cage-level schemes;
   cage-level sex exchangeability is explicitly marked non-identifiable for the
   two mixed-sex control cages.
3. **Primary tree:** unchanged; cage-aware analyses are a sensitivity layer.
4. **Cage/dam mapping:** one cage equals one dam is confirmed by the animal-work
   owner.
5. **Sibling metabolomics pipeline:** apply the same metadata and sensitivity
   support in the same pass.

## 9. Assumptions and limitations

- **Cage = litter rests on the P14 age**, not on a statement from the
  animal-work owner. It is a strong inference, not a confirmation (§2).
- **The date confound is not removable.** Any treatment estimate in this
  project is either partly aliased with cohort (arms A, B) or based on 10 mice
  from 3 cages (arms C, D). No model resolves this; the plan quantifies it.
- **Eight clusters, split 2 versus 6, with four singletons** is below what any
  clustered method estimates well. Every number produced here carries wide
  uncertainty and none of it should be reported as a point estimate without an
  interval.
- **This cannot recover the null result and is not intended to.** Its purpose is
  to convert an assumption — that pups are independent — into a measured
  statement, so the null can be defended rather than merely asserted.
- The ICC and the attribution results feed the sample-size recommendation in
  [[project_strategic_direction]]; that recommendation should not be written
  until §5.2 and §5.3 have run.
