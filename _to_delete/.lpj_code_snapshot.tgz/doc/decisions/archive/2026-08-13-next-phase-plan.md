# Plan: next phase — outlier characterisation, noise floor, variance sources

Planning only. Nothing here is implemented. Items are grouped by what they
are for, because they do not all serve the same purpose and should not be
prioritised as if they did.

## Framing: what is already settled

Before adding analyses, it is worth being explicit about what will and will
not move.

**Settled and unlikely to change:**
- No lipid reaches FDR q < 0.05 for any effect in any region.
- This holds across 8 pre-specified preprocessing specifications (72 results).
- Observed treatment fold-changes match what permuted labels produce
  (cerebellum 0.213 observed vs 0.215 permuted; cortex 0.145 vs 0.138).
- Removing the least reproducible third of the panel (QC-CV > 30%) changes
  nothing.

**Therefore**: none of the work below is likely to produce significant hits.
Planning it as "one more thing that might find something" would be the
garden-of-forking-paths problem the specification curve was designed to avoid.
The honest purposes are:

- **(A) Defensibility** — make existing conclusions harder to challenge.
- **(B) Characterisation** — understand *why* the data behave as they do,
  which is thesis content in its own right.
- **(C) Deliverables** — slides and figures for the group.

One item (the noise floor, Group 2) has a genuine, if small, chance of
changing a downstream number. It is flagged as such.

---

## Group 1 — Outlier characterisation

### 1.1 Leave-one-out Hotelling's T² *(purpose: A)*

**The concern, restated precisely.** T² compares each sample to a centroid and
covariance estimated from *all* samples, including that sample. An outlier
therefore pulls the centroid toward itself and inflates the covariance in its
own direction — it partially hides from the statistic meant to detect it. This
is the masking problem.

**Approach.** For each sample i, recompute the mean and covariance from the
other n−1 samples, then compute T² for sample i against that. This is the
standard "new observation" formulation, and it has its own critical value:

```
T²_crit = p(n+1)(n−1) / (n(n−p)) · F(α, p, n−p)
```

rather than the within-sample Beta form currently used. Both should be
reported so the difference is visible.

The user's suggested variant — repeated 95% subsampling — is a jackknife
generalisation of the same idea and gives a *distribution* of T² per sample
rather than a point value. Worth adding as a stability measure: a genuine
outlier should have a consistently high T² across subsamples, a borderline
one should not.

**Note on redundancy.** Robust Mahalanobis (MCD) already addresses masking by
a different route, and it also ranked sample 25 first. Leave-one-out is
expected to confirm rather than revise. Its value is that it is easier to
explain to a supervisor than MCD, and it does not carry MCD's small-sample
calibration problems.

**Expected outcome:** sample 25 confirmed; no new samples identified.

### 1.2 Are outliers driven by few lipids or many? *(purpose: B — genuinely new)*

Currently unanswered, and the more interesting of the two.

**Contribution analysis.** For a flagged sample, decompose its T² (or its
residual) into per-lipid contributions and rank them. This is the standard
chemometric "contribution plot". Two very different pictures are possible:

- **Concentrated** — a handful of lipids dominate. Suggests a specific
  technical cause (contaminant, integration failure in one class).
- **Diffuse** — hundreds of lipids each contribute a little. Suggests a
  global cause (extraction efficiency, tissue amount, dissection).

For sample 25 we have a partial answer already: its 11 leverage points spread
across 8 lipid classes with no class above 27%, which leans diffuse. A proper
contribution plot would settle it and is directly reportable.

**Deliverable:** contribution plot per flagged sample, plus a concentration
statistic (e.g. what fraction of total T² comes from the top 10 lipids).

### 1.3 PC loadings structure *(purpose: B)*

Related but distinct: are the principal components themselves defined by a few
lipids or many?

- Per PC, rank absolute loadings; report the fraction of squared loading
  carried by the top 10, 50, 100 lipids.
- A Lorenz-curve / Gini-style summary makes "concentrated vs spread" a single
  number, comparable across PCs and regions.
- Cross-reference the top loadings against the technical-variance table — a PC
  driven mainly by `technical_dominated` lipids is a noise axis and should be
  labelled as such.

**Note:** the loadings *plots* were deliberately deleted earlier as
unreadable; the loadings *tables* (`04_multivariate/pca_loadings_*.csv`) were
kept for exactly this. The output here should be ranked tables and a
concentration curve, **not** a restored all-features scatter.

---

## Group 2 — Noise floor: abundance versus reproducibility

**Items 3 and 4 in the request are the same analysis.** noisyR's method *is*
the abundance-versus-similarity relation: it computes similarity between
sample pairs as a function of abundance and selects the abundance below which
similarity is unacceptable. Point 4 is the manual diagnostic; noisyR is the
packaged version. Plan them together.

### 2.1 Sample-pair similarity versus abundance *(purpose: B, possibly A)*

**Method.** For each pair of samples within a region, bin lipids by mean
abundance and compute the correlation (Pearson on log2, and Spearman as a
rank-based check) within each bin. Plot correlation against abundance bin.

**What it shows.** In most MS data the curve rises from near-zero at low
abundance to a plateau. The abundance at which it plateaus is an empirical
noise floor, derived from the data rather than from a blank or a CV threshold.

**Why this is worth doing.** It is a *different* criterion from the two
filters already tested. The blank filter asks "is this above background"; the
CV filter asks "is this reproducible in the QC pool". This asks "at what
abundance do two real biological samples start agreeing with each other" —
which is closer to what actually limits detection.

**This is the one item that could change a downstream number.** If the floor
sits well above the current detection limit, a principled abundance filter
would remove more lipids than anything tried so far. Given that neither
previous filter moved the result, the expectation should still be "no change",
but it is not a foregone conclusion.

### 2.2 noisyR evaluation *(purpose: B)*

**What it is.** An R package (Core-Bioinformatics; *Nucleic Acids Research*
2021) implementing the above as a pipeline: expression-similarity calculation,
threshold determination, then noise removal.

**Applicability caveat — check before adopting.** noisyR was built for
sequencing count data. Two things need verifying against lipidomics:

1. Whether its similarity computation assumes count-like properties
   (discreteness, mean-variance relationship).
2. Its noise-removal step **adds the average noise threshold to every entry**
   to avoid fold-change bias at low abundance. That is a sensible operation
   for counts; for log-scale continuous peak areas it needs thought before
   being applied blindly.

**Recommendation:** run 2.1 manually first. If the abundance-similarity curve
looks like the ones noisyR is designed for, adopt the package for the
threshold selection. If not, the manual version is sufficient and avoids
importing assumptions.

**Reference:** Moutsopoulos et al., *Nucleic Acids Research* 49(14):e83, 2021.

---

## Group 3 — Variance decomposition *(purpose: B — high value)*

"Characterise the data and model sources of variation." This is arguably the
most valuable item in the list, because it answers the top-level question
directly rather than another sub-question.

**Method.** A variance-components model per lipid, or on summary coordinates,
partitioning total variance into:

- brain region
- mouse (the repeated-measures grouping)
- treatment group
- sex
- technical/residual

with the technical share anchored by the Tech-Mix replicates.

**Existing pieces to consolidate rather than redo:**
- PERMANOVA R² per term per region (3–8.5% for treatment + sex + interaction)
- Technical versus biological variance ratios per lipid per region
- PCA between/within ratios (region 2.83, treatment 0.11)

**What is new:** a single coherent decomposition, expressed as percentages
summing to 100, rather than several separate ratios. That is the figure that
answers "what actually drives variation in this dataset" in one image, and it
is the natural centrepiece of a results presentation.

**Caution:** mixed-model variance components failed to converge previously
(87% of lipids). Prefer a simpler approach — e.g. nested ANOVA on complete
lipids only, or variance components on PC scores rather than per lipid.
Do not retry the model that already failed.

---

## Group 4 — Descriptive and presentation work *(purpose: C)*

### 4.1 CV histograms per tissue
Straightforward; data already computed in `02_qc/qc_injection_cv.csv`. One
histogram per region plus the pooled QC CV, with the 20% and 30% conventional
thresholds marked.

**Note:** Tech-Mix is a single shared pool, so QC CV is *not* region-specific.
Per-tissue CV histograms would have to use biological CV within region, which
is a different quantity — that distinction must be stated on the slide or it
will mislead.

### 4.2 Normalisation review
Systematic comparison of median normalisation (current) against alternatives —
PQN, total ion current, and internal-standard-based if standards exist. Report
effect on abundance distributions and on the CV.

**Blocked:** the internal-standard option depends on the vendor answering
whether standards were spiked. Plan the comparison, run the IS arm only if
the answer is yes.

### 4.3 PCA versus PLS-DA comparison
Material already exists — PCA scores, PLS-DA scores, permutation p-values.
Needs presenting as a side-by-side with the point that PLS-DA is supervised
and produces separation regardless. **Needs input:** Eleanor's slides, which
I have not seen.

### 4.4 Jaccard similarity index
**Needs clarification before planning.** Jaccard is a set-overlap measure, so
it needs a binary definition. Plausible readings:

- overlap of *detected* lipids between sample pairs (presence/absence),
  which would be a detection-consistency measure; or
- overlap of top-N lipid lists between conditions or methods.

Also unclear what "bulk analyzer" refers to. Both need pinning down before
this can be specified.

### 4.5 MetaboAnalyst outlier guidance
Review their documented workflow and check it against what has been done.
Expected outcome: mostly already covered (PCA, T², QC clustering). Worth doing
to be able to state explicitly that the standard workflow was followed.

### 4.6 Pipeline slides
Deliverable summarising noise/outlier handling and normalisation. The
`doc/preprocessing-flow.mermaid` diagram is a starting point; this would add
the QC and outlier branches that diagram deliberately omits.

---

## Suggested sequencing

**First — highest value per effort:**
1. Group 3 (variance decomposition) — answers the biggest question, mostly
   consolidates existing results.
2. Item 1.2 (outlier contribution plots) — genuinely new, directly
   interpretable, small effort.
3. Item 2.1 (abundance–similarity curve) — new criterion, the only item with a
   real chance of changing a number.

**Second — defensive:**
4. Item 1.1 (leave-one-out T²) — expected to confirm; makes the outlier
   argument easier to defend.
5. Item 1.3 (loadings concentration) — feeds 1.2 and the presentation.

**Third — presentation:**
6. Items 4.1, 4.3, 4.6 — mostly assembly of existing material.

**Blocked or needs clarification:**
- 2.2 noisyR — do 2.1 first, decide after.
- 4.2 normalisation — internal-standard arm blocked on the vendor.
- 4.4 Jaccard — needs definition.
- 4.3 — needs Eleanor's slides.

## Standing constraint

Everything above is characterisation, not a new attempt at significance. If
any item does produce a significant result, it must be reported as one
specification among all those already run — not promoted to primary. That
commitment was made before the specification curve and still holds.

# Questions (written by the user)
- Is this critical T approach used by any other previous research
- what would the Pc loading plots look like? what is Lorenz and gini style summary 
- what is the metaboanalyis documented workflow>? 