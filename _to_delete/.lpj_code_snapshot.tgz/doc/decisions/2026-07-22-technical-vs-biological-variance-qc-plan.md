# Technical-vs-biological variance QC check

Date: 2026-07-22
Status: proposed — implementation not yet started (intended for the opencode agent)

## Question

The primary MIA-vs-control and Sex differential tests (see
`2026-07-21-mia-vs-control-lipidomics-plan.md`) came back essentially flat
after FDR correction, including for Sex — normally one of the most robust
signals in rodent lipidomics. Before concluding the biological effect is
genuinely small, quantify how much of the variance seen across biological
samples is actually assay/instrument noise rather than real mouse-to-mouse
difference, using the pooled QC replicate injections already present in the
source workbook.

This was prototyped ad hoc in chat (not committed, no saved prompt) on all
992 lipids pooled across regions; this plan formalizes and refines that
check into the actual pipeline.

## Data already available (no new measurements needed)

`data/1 MB2_088_Lalowski_Report_Final.xlsx`, sheet `Lipidomics`:

- Columns `Tech-Mix_1+.raw` through `Tech-Mix_6+.raw` (6 columns): the same
  pooled QC sample, injected 6 separate times. Any spread across these 6
  values for a given lipid is pure instrument/assay noise — the material is
  physically identical each time.
- The 60 `MB2_088-##` biological sample columns (already used by
  `preprocessing.py`/`diffexp.py`): carry instrument noise *plus* real
  mouse-to-mouse biological variation.
- A `%CV` column (used by the core to pre-filter the panel to <40% CV) whose
  computation basis (which QC set it was derived from) is not documented in
  the workbook — treat as unknown; do not assume it was computed from these
  same Tech-Mix replicates. Comparing our own computed technical CV against
  this column is a useful sanity check, not a given match.

## Method

For each lipid, and separately per brain region (to match how the
differential tests are actually run — pooling regions would mix in
region-to-region shift, inflating the biological estimate and understating
technical noise's share for any single region's comparison):

1. Reuse `preprocessing.exclude_nonpositive` and `preprocessing.log2_transform`
   on both the Tech-Mix columns and the biological columns, for consistency
   with the rest of the pipeline. Do not impute.
2. Technical SD (log2): std across the 6 Tech-Mix replicates, requiring at
   least 4 of 6 present; else NaN for that lipid (do not impute).
3. Biological SD (log2), per region: std across that region's 20 samples,
   requiring at least 15 of 20 present; else NaN for that lipid/region.
4. Variance ratio = `technical_sd^2 / biological_sd^2`, per lipid per
   region. Report the **raw, unclipped** ratio (a value above 1 is itself
   informative — it means technical noise alone is at least as large as the
   observed spread across mice, an even stronger signal-is-noise
   indicator) — do not clip to 1.0 as the ad hoc chat version did. Add a
   separate boolean flag column `technical_dominated = ratio >= 0.5` for
   quick filtering, rather than truncating the underlying number.
5. Sanity check: compare the median computed technical CV against the
   workbook's own `%CV` column where lipids overlap; note any large
   systematic mismatch rather than silently ignoring it (see "known vs
   unknown" above).

## Deliverables

- `results/mia_vs_control/technical_vs_biological_variance.csv` — regenerated
  via the module (not the ad hoc chat script), one row per lipid per region:
  `technical_sd_log2`, `biological_sd_log2`, `variance_ratio`,
  `technical_dominated`, `n_techmix_used`, `n_biological_used`.
- `results/mia_vs_control/technical_vs_biological_summary.csv` — one row per
  region: median/IQR of the ratio, and the fraction of lipids with
  `technical_dominated == True`, mirroring the style of
  `preprocessing_diagnostics.csv`.
- A plot (per `publication-plot`'s rules — show the distribution, not a bar
  of the mean): one panel per region, distribution (e.g. ECDF or histogram)
  of the variance ratio, colorblind-safe, saved as a figure alongside the
  existing `mia_effect_volcanoes.pdf`.
- An annotation step in the notebook (not a new module function — a plain
  merge) that joins `variance_ratio`/`technical_dominated` onto
  `differential_effects.csv`'s nominal-p<0.05 candidate rows, so any future
  "top hits" list is flagged by this QC metric rather than needing a
  one-off check each time (this is what caught 3 of 6 "top" Cortex
  MIA-x-Sex-interaction hits being 100%-technical-noise in the chat
  prototype).

## Proposed file layout

- `src/qc_variance.py` (flat, matching `preprocessing.py`/`diffexp.py`/
  `variance.py`/`plot_config.py`):
  - `technical_variance(techmix_intensity, *, min_replicates=4) -> pd.Series`
  - `biological_variance_by_region(biological_intensity, metadata, *, region_column="Sample type", min_per_region=15) -> pd.DataFrame`
  - `variance_ratio_table(technical_sd, biological_sd_by_region) -> pd.DataFrame` — combines the two into the deliverable table above, including the `technical_dominated` flag.
- `tests/test_qc_variance.py` — synthetic fixture (a handful of lipids with
  known, hand-picked technical/biological spreads), same style as
  `tests/test_preprocessing.py`.
- Notebook: extend `notebooks/mia_vs_control.ipynb` (not `sandbox.ipynb`) —
  add a QC section that calls the module, displays the summary table and
  plot, and does the candidate-annotation merge described above.

## Validation

- `pytest -q` once the module and fixture exist.
- Execute the new notebook cells; inspect the summary table and plot.
- Spot-check the computed technical CV against the workbook's `%CV` column
  for a handful of lipids as the sanity check described above.

## Open items still pending explicit confirmation

- Minimum-replicate thresholds (4-of-6 Tech-Mix, 15-of-20 biological) are
  proposed defaults, not confirmed. 
- Per-region biological variance (vs. the ad hoc chat version's all-60-pooled
  estimate) is a refinement proposed here — confirm this is wanted before
  `qc_variance.py` is built, since it changes the numbers from what was
  discussed in chat.
- Whether the candidate-annotation step should also retroactively flag
  `differential_effects.csv`/`permanova_by_region.csv` rows in place, or
  stay a separate join done fresh in the notebook each time.
