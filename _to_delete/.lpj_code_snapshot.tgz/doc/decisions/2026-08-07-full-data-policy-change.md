# Policy change: full data (60 samples) becomes the analysis population

Reverses the whole-mouse exclusion adopted 2026-08-05
(`2026-08-05-outlier-policy-pca-and-figure-reproduction-plan.md`). That
document's method decisions — PC counts, T² usage, the outlier-screen
findings — all still stand. What changes is which samples are analysed.

## Decision

**All 60 samples are the analysis population.** Mouse `C00431239 - 3`
(samples 25, 26, 27) is no longer excluded.

## Why this is defensible — and arguably better

- **No sample ever crossed a properly-calibrated threshold convincingly.**
  Hotelling's T² flagged nothing at 95% in the earlier 10-PC screen. Robust
  Mahalanobis flags were shown by simulation to be MCD's false-positive rate
  at n≈19, not outliers. The leverage screen ranked sample 25 first but on a
  smooth gradient with no natural break, and 14 other samples scored ≥5.
- **The vendor's exclusion of sample 26 is not reproducible** from anything in
  the delivered data — it ranks 9th of 20 by T² and 12th by robust Mahalanobis.
- **Sample 27 was never independently flagged at all.** It was only ever
  removed for consistency of the experimental unit.
- **Retaining data and reporting diagnostics is more conservative** than
  removing it on sub-threshold evidence.
- **The design returns to balanced 5/5/5/5** per region, which strengthens the
  interaction term, and the 11 feature-region fits lost to `min_per_cell = 3`
  become eligible again.

## The cost, which must be reported not ignored

Sample 25 measurably distorts the Cortex PCA:

| | PC1 | PC2 |
|---|---|---|
| with sample 25 (n=20) | **36.7%** | 10.3% |
| without (n=19) | 27.0% | 12.6% |

A single sample moving PC1 by ~10 percentage points is the signature of a
genuine high-leverage point — it bends the axis toward itself. Including it is
fine, but any Cortex PCA or PLS-DA figure must carry a caveat naming sample 25
as high-leverage, and the T² diagnostic figure (where it sits outside the 95%
ellipse) is the evidence for that caveat.

**Handle it as a sensitivity statement, not a parallel figure set.** Because
every result is null under both populations, one sentence suffices:

> "Analyses were run on all 60 samples. Sample 25 is high-leverage in the
> Cortex PCA (PC1 36.7% with, 27.0% without); excluding its mouse changes no
> conclusion — no lipid reaches FDR significance and no PLS-DA permutation test
> is significant under either population."

Do not regenerate a second full set of figures for the excluded population.

## Code changes

1. `src/run_mia_vs_control.py` — remove the line 56 filter and the line 58
   assertion expecting 57 samples. Replace the assertion with one expecting
   **60**, so a silent population change still fails loudly.
2. `src/run_outlier_screen.py` — remove the line 32 filter.
3. `src/analysis_config.py` — do **not** delete `OUTLIER_MOUSE`. Retain it,
   documented as *not currently applied*, so the sensitivity check can be
   re-run without reconstructing the identifier:

   ```python
   # Retained for the sensitivity check only; NOT applied to the primary
   # analysis. The full 60-sample dataset is the analysis population as of
   # 2026-08-07 - see doc/decisions/2026-08-07-full-data-policy-change.md
   OUTLIER_MOUSE = "C00431239 - 3"
   APPLY_OUTLIER_MOUSE_EXCLUSION = False
   ```

4. `src/run_vendor_fidelity.py` — **no change.** Its `VENDOR_EXCLUDED_SAMPLE`
   removal of sample 26 is definitional: those figures exist to match the
   vendor's inputs. Cerebellum stays at n=19 there while the primary analysis
   uses n=20. Note this explicitly in the figure captions so the two are never
   confused.

## Also fix while regenerating: the Hotelling T² threshold

`hotelling_ellipse` currently uses `p(n−1)/(n−p)·F`, which is the sample-*mean*
distribution. For screening an individual observation that was itself used to
estimate the mean and covariance, the correct form is Beta-based:

```python
# individual observation in the estimating sample -> Beta, not F
t2_crit = (n - 1) ** 2 / n * stats.beta.ppf(alpha, p / 2, (n - p - 1) / 2)
```

Verified by simulation on clean bivariate normal data: the F form flags 0.88%
of points, the Beta form 5.02%, against a 5% target.

At n=20, p=2 the 95% boundary becomes **5.36**, not 7.50. Cortex then flags
samples **10 and 25** rather than 25 alone. This does not change any
conclusion — 2 flags among 20 at a 95% boundary is the expected
false-positive rate — but the ellipse must be drawn at the correct radius.

## Regeneration

Everything in `results/mia_vs_control/` outside `05_figure_reproduction/`
needs regenerating on 60 samples: preprocessing diagnostics, detection-limit
tables, QC, differential (OLS and limma, so re-run
`src/differential_moderated.R`), PERMANOVA, PCA, outlier screens, all figures.
Use `@regenerate` to keep the logs out of the main session.

## Validation

- 60 samples, 20 mice, cells 5/5/5/5 in every region.
- The 11 previously-dropped feature-region fits are eligible again; confirm
  and list them.
- Cortex PCA reports PC1 ≈ 36.7%.
- T² 95% boundary at n=20, p=2 equals 5.36; Cortex flags 10 and 25.
- Conclusions unchanged: zero FDR-significant lipids, no significant PLS-DA
  permutation test.
- `05_figure_reproduction/vendor_matched/` is byte-unchanged.
