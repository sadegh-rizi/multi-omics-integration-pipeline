# Plan: outlier policy, PCA suite, and per-region figure reproduction

Supersedes the figure-reproduction scope in
`doc/decisions/2026-07-30-reproduce-lipidomics-figures-plan.md` (that plan's
two-tier faithful/rigor-added framing and its hard dependency on the
detection-limit fix still stand; this plan replaces its exclusion policy and
figure grid).

## Confirmed decisions

1. **Exclude the whole outlier mouse `C00431239 - 3`** — samples 25 (Cortex),
   26 (Cerebellum), 27 (Hippocampus) — from every analysis, unconditionally.
   This is now the analysis population, not a filtering condition to toggle.
2. "Outlier" from here on means **any other sample, or a lipid-level outlier** —
   never mouse `C00431239 - 3`, which is already gone.
3. Every PCA and clustering figure carries **confidence ellipses**.
4. The uploaded vendor plot being reproduced is **PLS-DA**. PCA is additionally
   wanted, on other metadata and features — a separate deliverable, not a
   substitute.

## Why the whole mouse, recorded for the write-up

Two independent QC approaches converged on this animal: the vendor excluded
sample 26 (Cerebellum) by an undocumented criterion, and this repo's MAD-based
per-lipid leverage screen independently flagged sample 25 (Cortex) as the single
strongest outlier in the dataset — worst point in 11 of 987 Cortex lipids, a
rate chance alone produces with p = 0.0001. Two different tissues from one mouse
flagged by two different methods is an animal-level signal, so the animal goes.

Sample 27 (Hippocampus) was never independently flagged; it is removed for
consistency of the experimental unit, not because it failed QC. State it that
way in the methods — removing it is a design choice, not a QC finding.

## Design impact (verified, not assumed)

Verified against `differential_input_metadata.csv`:

- 60 → **57 samples**; every one of the 20 mice contributes all 3 regions, so
  removing this mouse costs exactly one sample per region.
- Per-region cell counts become **MIA-Male 4, MIA-Female 5, Control-Male 5,
  Control-Female 5** (was 5/5/5/5).
- Minimum cell size per region is now **4**, still above `min_per_cell = 3` in
  `src/diffexp.py` and `src/differential_moderated.R`, so no feature should be
  newly excluded on cell-count grounds. Confirm this empirically rather than
  trusting the arithmetic.
- The design is now **slightly unbalanced** in the MIA-Male cell. This weakens
  the interaction term more than the main effects, and is worth one sentence in
  the limitations section.

## Blast radius

Changing the analysis population invalidates every existing result. All of
`results/mia_vs_control/` must be regenerated: differential (OLS and limma,
including re-running `src/differential_moderated.R`), PERMANOVA, the pooled
mixed sensitivity check, preprocessing diagnostics, the technical-vs-biological
QC tables, and all figures. Sequence this **after** the detection-limit
preprocessing fix so the pipeline is regenerated once, not twice.

Use `@regenerate` (`.opencode/agents/regenerate.md`) for the run so the log
volume stays out of the main session.

---

## Part 1 — PCA suite

Unsupervised, on `preprocess_for_multivariate` output (log2 → median-normalise →
autoscale), per region and pooled across regions.

### Colour/stratify by metadata other than BioGroup and Sex

Available in the Sample Sheet and verified present:

| Variable | Type | Why it matters |
|---|---|---|
| `Sample type` (Region) | 3 levels | Pooled PCA coloured by region — expect this to dominate PC1/PC2; if it does not, something is wrong upstream. |
| `Sample number` | 1–60 | Proxy for **injection/run order**. A gradient along a PC is the classic signature of instrument drift or batch effect. Highest-value check here. |
| `Tissue mass (mg)` | 25.4–62.8, continuous | Sample-prep covariate. If PC1 tracks tissue mass, normalisation is not fully removing a loading effect. |
| `Mouse number` | 20 levels | Shows the repeated-measures structure — the 3 samples from one mouse should cluster if biology dominates. |

Not used: `MeOH (45 mg/mL)` and `1/2 of MeOH` are deterministic functions of
tissue mass (verified: 57 unique values matching tissue mass), so they carry no
independent information. `Notes` is constant across all 60 samples.

### Scree/elbow AND loadings — these are two different things

The request "elbow/scree plot to find the features contributing to PCs"
combines two distinct diagnostics. Produce both, labelled distinctly:

- **Scree / elbow plot** — variance explained per component, plus cumulative.
  Answers *how many components are worth interpreting*. Does not say anything
  about which lipids drive them.
- **Loadings** — per-lipid contribution to each retained PC. Answers *which
  lipids drive a component*. Report as a ranked table (top ±N by absolute
  loading, annotated with `Lipid Name` and `Lipid Class`) plus a loadings plot
  for PC1/PC2.

Cross-check the top loadings against `technical_vs_biological_variance.csv`:
a PC driven mainly by `technical_dominated = True` lipids is a noise axis, not
a biological one, and should be labelled as such.

### Confidence ellipses

Draw **95% normal-theory data ellipses per group** (the region containing ~95%
of that group's samples), matching what MetaboAnalyst-style plots show. Note in
the caption that this is a data/tolerance ellipse, **not** a confidence interval
for the group mean — the latter is much smaller, and conflating them overstates
separation. With n = 4–5 per cell an ellipse is a weak summary; say so in the
caption rather than letting the shape imply more than it supports.

---

## Part 2 — Outlier screen (beyond mouse `C00431239 - 3`)

Run **per region**, on the same autoscaled matrix as the PCA, after the whole
mouse is already removed.

**Sample-level.** Two complementary criteria, reported together:

1. **Hotelling's T²** on the retained PCs (the standard multivariate-model
   outlier statistic; flag samples beyond the 95% and 99% limits).
2. **Robust Mahalanobis distance** in PC space (MCD-based), which resists
   the masking problem where outliers inflate the covariance estimate used to
   detect them.

Also report **DModX** (distance to the model plane) if straightforward — a
sample can sit inside the score plot yet be poorly described by the model.

### Number of PCs — CONFIRMED: 3, for both statistics

**Use `N_OUTLIER_PCS = 3` for Hotelling's T² and for robust Mahalanobis.**
Not 5, and not 10. Grounded in the actual data rather than convention:

Per-region scree on the autoscaled matrix after the permanent mouse exclusion
(n = 19 per region, complete features only) shows the elbow at PC3 everywhere:

| Region | PC1 | PC2 | PC3 | PC4 | PC5 |
|---|---|---|---|---|---|
| Cerebellum | 27.6 | 21.0 | 15.3 | **6.1** | 4.8 |
| Cortex | 27.8 | 12.8 | 8.8 | **6.9** | 5.5 |
| Hippocampus | 28.8 | 16.1 | 9.0 | **6.6** | 5.9 |

**Why 5 PCs fails for MCD.** A p-dimensional covariance has p(p+1)/2 free
parameters; MCD's default support keeps h ≈ (n + p + 1)/2 observations. At
n = 19:

| p | cov params | default h | h > p? | h / params |
|---|---|---|---|---|
| 2 | 3 | 11 | yes | 3.67 |
| **3** | **6** | **11** | **yes** | **1.83** |
| 4 | 10 | 12 | yes | 1.20 |
| 5 | 15 | 12 | yes | **0.80** — under-determined |
| 10 | 55 | 15 | yes | 0.27 |

At p = 5, MCD estimates 15 covariance parameters from ~12 retained
observations. Because h > p it is not singular, so it will run without error —
it simply will not produce a meaningful covariance. Non-singularity is the
wrong feasibility test here; the observations-per-parameter ratio is the right
one.

**Why 10 PCs fails for T².** 55 covariance parameters from 19 samples, and the
F-test residual df collapses to n − p = 9. At p = 3, df = 16.

**Why the same p for both.** T² and robust Mahalanobis are both
Mahalanobis-type distances differing only in the covariance estimator. Running
them at different dimensionalities makes disagreement uninterpretable — you
cannot tell whether the methods disagree or the dimensions do. Their agreement
is the whole point of running both.

**MCD tuning.** Set `support_fraction ≈ 0.75` explicitly (h = 14, ratio 2.33)
rather than accepting the default. This lowers the breakdown point from ~42% to
~26%, which is more than sufficient when one or two outliers are expected among
19 samples, and materially stabilises the estimate. Report whether MCD
converged; do not silently accept a failed fit.

### What happens to flagged samples — CONFIRMED: report first, then a fixed explicit list

**Do not auto-remove at the 95% threshold.** At n = 19, a 95% cutoff flags
0.05 × 19 = **0.95 samples per region under the null, by construction** —
about **2.9 samples across the three regions with nothing whatsoever wrong**.
Auto-removal at 95% would therefore delete roughly three legitimate samples for
purely mechanical reasons and rerun the whole analysis on the survivors. The
threshold, not the data, would be choosing the analysis population.

Sequence instead:

1. **Pass 1** — run the outlier screen standalone. It writes the per-region
   evidence table and changes nothing else.
2. **Review** — the user reads the table, cross-checks each candidate against
   run order, tissue mass, and technical variance for a *mechanism*, and
   decides.
3. **Pass 2** — the figure grid runs with the confirmed list.

Implement the exclusions as a named module constant:

```python
# Populated only after reviewing the Pass-1 outlier report. Each entry needs a
# recorded mechanism, not just a large distance. Empty until then.
SAMPLE_OUTLIER_EXCLUSIONS: dict[str, list[str]] = {
    "Cerebellum": [], "Cortex": [], "Hippocampus": [],
}
```

This blocks nothing: the code runs today with the list empty, in which case
conditions C and D degenerate to A and B — which is the honest state of affairs
until a removal has actually been justified. No code change is needed between
passes, only the constant.

**If a threshold-driven rule is wanted anyway**, use the **99%** limit (0.19
expected false flags per region) **and** require T² and robust Mahalanobis to
agree, rather than flagging on either alone.

### OUTCOME (2026-08-05): no additional samples excluded

**`SAMPLE_OUTLIER_EXCLUSIONS` in `src/analysis_config.py` stays empty `()`.**
Conditions C and D therefore reproduce A and B exactly. That is the honest
result of the screen, not a failure to decide.

**As run.** 10 PCs for Hotelling's T² and DModX, 3 PCs for robust Mahalanobis
(the T²/DModX dimensionality deviates from the p = 3 confirmed above).
Hotelling's T²: **no sample exceeded the 95% limit in any region.**
Robust Mahalanobis at 99% flagged Cortex 13/16/19/22/37/49, Cerebellum
14/17/20/35/56/59, Hippocampus 6/9/15/33/42/48/51 — 6, 6 and 7 of 19.

**Why those flags carry no information.** 6/19 is ~32% flagged by a threshold
labelled 99%, i.e. ~32× its nominal rate. Simulating the exact configuration
(n = 19, p = 3, MCD h = 11, χ² 99% cutoff) on **clean multivariate normal data
with zero outliers**, 400 replicates:

| Quantity | Value |
|---|---|
| Nominal flags per region | 0.19 |
| **Simulated median on clean data** | **6** |
| Clean datasets flagging ≥ 5 | 82.8% |
| Clean datasets flagging ≥ 6 | 60.0% |
| Observed | 6, 6, 7 |

The observed counts are the null expectation for this procedure at this sample
size. Mechanism: MCD estimates the covariance from only the h = 11 most
concentrated points, so the 8 excluded points receive inflated distances by
construction, and the χ² cutoff assumes a *known* covariance — badly violated
when it came from 11 observations. Correct small-sample cutoffs exist
(Hardin & Rocke's F-approximation for MCD distances); the plain χ² quantile
used here is not calibrated for n = 19.

**The apparent mouse cluster is also chance.** Mouse `C00462971 - 1` was
flagged in all three regions (13/14/15), superficially resembling how mouse
`C00431239 - 3` was identified. But at these flag rates the expected number of
mice hitting all three regions is 0.70, and exactly 1 was observed. The
genuine outlier mouse was flagged by two *independent* methods, one at
p = 0.0001, and had a mechanism. This one has neither. Flags also distribute
across groups (MIA 11 / Saline Control 8) with no systematic pattern.

**Lesson worth carrying forward.** A robust method is not automatically the
conservative choice. At small n, MCD's own estimate is noisy enough that the
standard cutoff over-flags severely, and "robust" flags can look like findings.
Any distance-based screen at this sample size needs its false-positive rate
checked by simulation before its output is read as evidence — the check costs
minutes and prevented three legitimate samples per region from being discarded
here.

**Lipid-level.** Reuse the existing MAD-based per-lipid leverage screen
(the one that found mouse `C00431239 - 3`) plus the trace-level/detection-limit
flags from
`doc/decisions/2026-07-30-trace-level-detection-limit-preprocessing-plan.md`.

**Output:** one table per region listing every sample with its T², robust
distance, and DModX, sorted worst-first, with the 95%/99% thresholds marked —
not a bare list of "outliers". The user decides what to exclude; the screen
reports evidence.

**Guard against circularity:** a sample being far from others in a score plot is
not by itself misconduct evidence. Before recommending any exclusion, check
whether the sample is also flagged by run order, tissue mass, or technical
variance — a mechanism, not just distance. Record the reason in the exclusion
table per `doc/agent-rules.md`.

---

## Part 3 — Figure reproduction grid

Per region (Cerebellum, Cortex, Hippocampus): **1 heatmap + 1 PLS-DA scores
plot with sample labels** = 6 figures per condition.

Exclusion conditions, all on top of the always-removed mouse:

| # | Lipid-level removal | Sample-outlier removal |
|---|---|---|
| A | no | no |
| B | **yes** | no |
| C | no | **yes** |
| D | **yes** | **yes** |

**4 conditions × 6 figures = 24 figures**, each written by
`plot_config.save_figure` as PDF + presentation PNG + manuscript PNG = 72 files.

This is what the request specifies literally, and the full factorial is what
makes the effect of each filter separable. **Open item:** if that is more than
is useful to review, the natural reduction is dropping condition C
(sample-outlier-only), giving a none → lipid-only → both progression at 18
figures. Say which you want before implementation starts.

### Method notes

- **Heatmap**: top-50 feature selection must use a documented, non-circular
  criterion (ranked by nominal p-value from the regenerated
  `differential_effects.csv`), with the caption stating plainly that it is
  uncorrected and selected from ~880 lipids — per the framing already
  established in `doc/methodology.md`. Euclidean distance, Ward linkage, both
  axes, scaling documented. But In addition, generate them once without removing any lipids as well
- **PLS-DA**: `sklearn.cross_decomposition.PLSRegression` on one-hot labels,
  scores from `x_scores_`, samples annotated with their sample number to match
  the vendor figure. **A permutation test is required on every PLS-DA** —
  shuffle labels ~1000×, refit, compare observed separation against the null,
  and print the p-value in the caption. PLS-DA is supervised and will show
  apparent separation on pure noise; an unvalidated scores plot is the specific
  failure mode already identified in the vendor deck. Also report variance
  explained per component.
- **Do not** report a PLS-DA component's variance-explained as if it were a PCA
  component. In the uploaded vendor Cortex plot, Component 1 explains 6.2% and
  Component 2 explains 30.8% — impossible in PCA, and a useful tell that the
  figure is supervised.

---

## Source file layout

- `src/outlier_screen.py`: `hotelling_t2`, `robust_mahalanobis`, `dmodx`,
  `sample_outlier_table`.
- `src/pca_analysis.py`: `fit_pca`, `scree_table`, `loadings_table`,
  `confidence_ellipse`.
- Extend `src/reproduce_vendor_figures.py` for the 4-condition grid rather than
  duplicating it.
- Tests for each: ellipse geometry on synthetic data with known covariance,
  T² flagging a planted outlier, scree values summing to 1, permutation test
  returning ~uniform p on label-shuffled data.
- A single `EXCLUSIONS.md` or exclusion table recording every removed sample and
  lipid with its reason — required by `doc/agent-rules.md` and needed for the
  thesis methods section.

## Results directory layout — restructure required

`results/mia_vs_control/` is currently **107 files in one flat directory**, all
tracked in git. This plan adds ~72 more figure files (24 figures × PDF +
presentation PNG + manuscript PNG) plus PCA tables, which makes a flat layout
unusable. Adopt this structure, numbered so the pipeline order is readable
top-to-bottom:

```
results/mia_vs_control/
├── 00_inputs/                 differential_input_matrix.csv, ..._metadata.csv
├── 01_preprocessing/          preprocessing_diagnostics.csv,
│                              detection_limit_exclusions*.csv
├── 02_qc/                     technical_vs_biological_*.csv,
│   │                          technical_cv_sanity_check.csv,
│   │                          outlier_screen_<region>.csv
│   └── figures/               technical_vs_biological_variance_ecdf.*
├── 03_differential/           differential_effects.csv,
│   │                          differential_effects_limma.csv,
│   │                          differential_feature_qc.csv,
│   │                          differential_nominal_candidates_with_qc.csv,
│   │                          pooled_mixed_sensitivity.csv
│   └── figures/               *_volcanoes.*
├── 04_multivariate/           permanova_by_region.csv, permanova_diagnostics.csv,
│   │                          pca_scree_<scope>.csv, pca_loadings_<scope>.csv,
│   │                          plsda_permutation_diagnostics.csv
│   └── figures/
│       ├── pca/               scree, scores (per metadata colouring), loadings
│       └── plsda/
├── 05_figure_reproduction/    heatmap_selection.csv
│   ├── A_baseline/            heatmap_<region>.*  plsda_<region>.*
│   ├── B_lipid_filtered/      (identical filenames)
│   ├── C_sample_filtered/     (identical filenames)
│   └── D_both_filtered/       (identical filenames)
└── 06_annotation/             lipid_database_annotations.csv,
                               lipid_id_mapping_raw/
```

**The design property that matters**: inside the four condition folders the
filenames are *identical*. Comparing `heatmap_cortex_presentation.png` across
exclusion conditions means opening the same filename in four sibling folders,
rather than parsing four long suffixed names in one flat listing. Condition
belongs in the path, not the filename.

`05_figure_reproduction/` has no `figures/` subfolder because it is entirely
figures — the condition directories are its organisation. Elsewhere, tables sit
at the analysis level and figures go in that analysis's `figures/`.

### Required code change

`plot_config.save_figure` does **not** create parent directories — it calls
`fig.savefig` directly, so any nested path raises `FileNotFoundError`. Add
`path.parent.mkdir(parents=True, exist_ok=True)` before the writes. This is a
one-line change but blocks the whole layout, so do it first.

### Migration

All 107 existing files are tracked in git, and essentially all of them are
invalidated anyway by the whole-mouse exclusion and the detection-limit fix. So
do **not** run a separate rename-only migration commit — restructure and
regenerate in one pass.

Critically: `git rm` the old flat files as part of that pass. Regenerating into
new subdirectories without removing the old flat copies leaves a full set of
stale results sitting alongside the new ones with no visible marker of which is
which — the single worst outcome available here. After regeneration,
`results/mia_vs_control/` should contain *only* directories from the tree above,
no loose files at its root.

Per the git workflow in `AGENTS.md`, committing regenerated results/data needs
your explicit per-commit approval.

## Validation

- Confirm 57 samples and 4/5/5/5 cells per region after exclusion.
- Confirm no feature is newly dropped for `min_per_cell` reasons.
- Pooled PCA coloured by region must separate by region; if it does not,
  stop and investigate before proceeding.
- Report the permutation p-value for every PLS-DA, including when
  non-significant.
- Report which conditions changed the top-50 heatmap membership, and by how much.

## Open items

1. ~~Figure count: full 4-condition grid (24 figures)~~ — **now moot.** With
   `SAMPLE_OUTLIER_EXCLUSIONS` empty, conditions C and D are byte-identical to
   A and B. Generate **only A and B** (12 figures: 2 types × 3 regions × 2
   lipid-filter states) and state in the caption that no sample-level
   exclusions were justified beyond the permanently removed mouse. Producing
   C and D as duplicates would imply a distinction the data does not support.
2. ~~Number of PCs for the outlier screen~~ — **resolved: 3 for both T² and
   robust Mahalanobis**, see the section above.
3. Whether the PLS-DA should use the same top-50 feature subset as the heatmap
   or the full lipid panel. Leaning **full panel** (feature selection before a
   supervised projection compounds the circularity problem), but flagging it.
4. How many PCs to *display and describe* in the descriptive PCA output is a
   separate question from the outlier-screen dimensionality. Showing scree and
   loadings for more components (say 5) is harmless because nothing is being
   estimated from a covariance; the p = 3 constraint applies only to the
   distance statistics.
