# Plan: abundance–similarity curve (empirical noise floor)

Single-step implementation plan. Scope is deliberately narrow: produce the
diagnostic, report it, and **do not** adopt any filter from it in this pass.

## The question

At what abundance do two real biological samples start agreeing with each
other?

This is a different question from the two filters already in the pipeline:

| criterion | asks |
|---|---|
| blank filter (implemented) | is this lipid above background? |
| QC-CV filter (implemented, off) | is this lipid reproducible in the pooled QC? |
| **abundance–similarity (this plan)** | **at what abundance do independent samples start correlating?** |

The third is closest to what actually limits detection, because it measures
reproducibility on the real samples rather than on a blank or a single pooled
QC. It is also the method underlying `noisyR`
(Moutsopoulos et al., *Nucleic Acids Research* 49(14):e83, 2021), so
implementing it manually first gives a basis for deciding whether that package
adds anything.

## Correction (2026-08-21): noisyR count-matrix ordering

The pairwise mean-abundance ordering originally described below is superseded.
Ranking a window by the mean of the two values later correlated conditions on
both variables and can induce a collider/selection artifact. In this project it
produced a strongly negative curve even for independent null columns, so it is
not a valid similarity diagnostic.

The manual implementation follows the noisyR count-matrix approach described
by Moutsopoulos et al. (2021, Methods: "Count matrix approach"):

1. For each reference sample, sort its observed lipids in descending order of
   that sample's own log2 positive raw peak area.
2. Slide the fixed-size window through that reference ranking.
3. For each window, correlate the reference values with the values in every
   other sample, excluding a feature only where that comparator is missing.
4. Take the arithmetic mean of valid comparator correlations for that
   reference-window, requiring at least two comparators.

For this LPJ report-only diagnostic, reference-sample curves are then summarized
within each region by their median and IQR. The x-coordinate for each reference
window is the arithmetic mean abundance required by noisyR; the reported
`median_log2_abundance` is the median of those reference-window means. This is
a descriptive regional summary, not a claim that region measurements are
independent biological replicates. Aggregate points require at least 10 directed
reference-comparator correlations. Tech-Mix follows the same calculation.

For the biological-technical gap candidate, linearly interpolate the Tech-Mix
median correlation at each biological window abundance, without extrapolating
beyond the shared abundance range. No noisyR package is added and no abundance
filter is adopted.

## Method

For a given set of samples (one region at a time):

1. Take **log2 of positive raw peak areas**. See "which data version" below.
2. For each **reference** sample *i*:
   a. Keep its observed lipids and rank them by that sample's own log2
      abundance.
   b. Slide a window of `WINDOW_SIZE` lipids along the reference ranking,
      stepping by `WINDOW_STEP`.
   c. In each window correlate the reference values with every other sample
      *j*, omitting a lipid only where that comparator is missing.
   d. Take the arithmetic mean of valid comparator correlations, requiring at
      least `MIN_COMPARATORS_PER_REFERENCE` comparators.
   e. Record the reference-window mean abundance and mean correlation.
3. Aggregate reference-sample values at each abundance rank: report the
   **median** correlation and 25th–75th percentile band across references.

The expected shape is a curve rising from ≈0 at low abundance to a plateau.
The abundance at which it stabilises is the empirical noise floor.

### Reference curve from the Tech-Mix injections — do not skip this

Run the identical procedure on the **6 Tech-Mix injections** (6 references and
30 directed reference-comparator correlations). Those are the same material
injected repeatedly, so their correlation at a given abundance is a technical
repeatability reference. Its provenance as pooled study material is unconfirmed,
so it is not assumed to be a strict ceiling for biological correlation.

Plotting both curves together separates two things that are otherwise
confounded:

- where the **technical** curve rises → the instrument's detection floor
- the **gap** between technical and biological curves → genuine
  mouse-to-mouse variation

If the two curves coincide at all abundances, biological variation is
indistinguishable from technical noise across the whole panel — which would be
a strong and reportable finding. If the biological curve sits below the
technical one only at high abundance, that is where real biology lives.

## Parameters

```python
WINDOW_SIZE = 100        # lipids per window
WINDOW_STEP = 20         # slide increment
CORRELATION = "pearson"  # on log2 values; spearman reported alongside
MIN_COMPARATORS_PER_REFERENCE = 2
MIN_PAIRWISE_CORRELATIONS_PER_POINT = 10
```

`WINDOW_SIZE = 100` against ~950 lipids gives ~43 windows per pair — enough
resolution without windows so narrow the correlation is unstable. **Report a
sensitivity check at 50 and 200**; if the inferred floor moves materially with
window size, say so rather than picking the flattering value.

## Which data version — important

Run on **log2 of positive raw peak areas, before the detection-limit filter
and before median normalisation.**

Before conversion, exclude the report's embedded non-feature metadata rows and
repeated header row using `Lipid Name`; do not silently coerce them into missing
lipid measurements. The retained report rows must convert to numeric peak areas
or explicit missing values.

Rationale:

- Running after the detection-limit filter would pre-empt the answer: those
  values were removed *because* they were judged noise, so the curve could not
  discover an independent floor.
- Median normalisation is a per-sample shift on the log scale. It barely
  affects within-window correlation but does shift the abundance axis, making
  the resulting threshold harder to interpret in original units.

**Sensitivity check**: repeat on median-normalised values and confirm the
inferred floor is essentially unchanged. If it is not, that itself is worth
reporting.

Use the **full 60-sample dataset** per the standing full-data policy, with the
outlier mouse retained. Note in the output that it was retained, and run one
sensitivity check with it excluded.

## Outputs

```
results/mia_vs_control/02_qc/abundance_similarity_curve.csv
results/mia_vs_control/02_qc/abundance_similarity_thresholds.csv
results/mia_vs_control/02_qc/abundance_similarity_filter_overlap.csv
results/mia_vs_control/02_qc/figures/abundance_similarity_{region}.*
results/mia_vs_control/02_qc/figures/abundance_similarity_summary.*
```

**`abundance_similarity_curve.csv`** — one row per (source, region, window):
`source` (`biological` / `techmix`), `region`, `window_index`,
`median_log2_abundance`, `median_pearson`, `q25_pearson`, `q75_pearson`,
`median_spearman`, `n_reference_samples`, `n_pairwise_correlations`,
`n_lipids_in_window`, `median_lipids_in_correlation`, `window_size`,
`ordering_method`, `reference_window_abundance`,
`correlation_aggregation`, `min_comparators_per_reference`, and
`min_pairwise_correlations_per_point`.

**`abundance_similarity_thresholds.csv`** — candidate floors per region under
several rules, reported side by side rather than one chosen:
- abundance where median correlation first exceeds 0.25 (noisyR's default)
- where it first exceeds 0.5
- where it reaches 90% of its plateau value
- where the biological and linearly abundance-aligned technical curves converge
  to within 0.05 in their shared abundance range

Every non-persistent candidate remains in the overlap output for sensitivity
reporting, but is explicitly labeled `nonpersistent_candidate_not_a_floor` and
is not an adopted abundance floor.

**`abundance_similarity_filter_overlap.csv`** — the cross-check that makes this
worth doing (see below).

**Figures** — per region, both curves overlaid, correlation on y, median log2
abundance on x, IQR band shaded, candidate thresholds as vertical lines.
Summary figure: all three regions on one panel, biological curves only.

## The cross-check that matters

Three independent noise criteria now exist. Do they identify the same lipids?

For each lipid compute:
- median log2 abundance, and whether it falls below each candidate threshold
- whether it was flagged by the blank-based detection limit
- its pooled-QC CV, and whether it exceeds 30%

Report the 2×2×2 contingency, plus pairwise Jaccard overlap between the three
flag sets.

**Interpretation guide, written before seeing the result:**
- **High overlap** → the three criteria are measuring one underlying property
  (low abundance). The existing filters already capture it and nothing new is
  needed.
- **Low overlap** → they capture different failure modes, and the union may be
  a better filter than any one alone. That would be a genuine finding.

## What is explicitly NOT in scope

**No filter is adopted in this pass.** The deliverable is the curve, the
candidate thresholds, and the overlap analysis. Whether to filter on abundance
is a separate decision made after seeing those, and if taken it must be run
through the existing specification-curve machinery rather than adopted
directly.

This follows the standing commitment made before the specification curve: new
preprocessing options are reported as specifications, not promoted to primary.

**noisyR itself is not used in this pass.** Implement the method manually
first. Decide about the package afterwards, informed by whether the curve looks
like what it expects. Two of its behaviours would need scrutiny before use: it
assumes count-like data, and its noise-removal step adds the average threshold
to every entry, which is not obviously right for log-scale peak areas.

## File layout

- `src/abundance_similarity.py`:
  - `pairwise_window_correlation(values, *, window_size, step, method)` →
    directed reference-comparator, per-window correlations for one matrix
  - `abundance_similarity_curve(values, *, ...)` → aggregated curve
  - `candidate_thresholds(curve, *, rules)` → the threshold table
  - `compare_noise_criteria(abundance_flags, blank_flags, cv_flags)` → overlap
- `src/run_abundance_similarity.py` — standalone script producing all outputs.
- `tests/test_abundance_similarity.py`.

## Tests

The important one is a **planted noise floor**:

> Generate a synthetic matrix where lipids above a known abundance `X` are
> correlated across samples and lipids below `X` are independent noise. Verify
> the recovered threshold is close to `X`.

That test validates the whole method end to end and is worth writing first.

Also:
- windowing covers every lipid exactly once per step position, no gaps
- a comparator missing a lipid excludes it from that correlation, not the
  reference window
- reference samples use their own rankings rather than pair means
- comparator means require at least two valid comparators, and aggregate points
  with fewer than `MIN_PAIRWISE_CORRELATIONS_PER_POINT` directed correlations
  are dropped
- Tech-Mix and biological paths produce identically-shaped output
- the function refuses a window size larger than the lipid count rather than
  silently returning one window

## Validation

- Both curves should show a broadly positive abundance-correlation trend. A
  flat or decreasing curve requires review before interpretation.
- Review any abundance range where biological correlation exceeds the Tech-Mix
  reference; this can reflect pairing/input issues or the unconfirmed Tech-Mix
  provenance and is not itself a basis for filtering.
- Threshold stability across window sizes 50 / 100 / 200 reported explicitly.
- Median-normalised sensitivity check reported.
- Outlier-mouse-excluded sensitivity check reported.

## Expected outcome

Given that neither the blank filter nor the CV filter changed any conclusion,
the most likely result is a floor that overlaps heavily with what is already
excluded, and no change to the null. That would still be worth having: it is a
third independent line of evidence characterising the detection limit, derived
from the biological samples themselves rather than from QC material.

The outcome that would be genuinely new is **low overlap** in the cross-check —
lipids that are abundant enough to pass the blank filter and reproducible
enough to pass the CV filter, yet still fail to correlate between samples.
Those would be a class of feature the current pipeline does not catch.
