> **SUPERSEDED 2026-09-24 — do not use.** This summary predates the 2026-08-07
> all-60 policy and describes the dismissed 57-sample exclusion and an early
> specification curve. Current state: `doc/analysis-state.md`; reasoning:
> `doc/context/`.

# Project Summary: MIA vs Control Brain Lipidomics

Based on the documentation in your `doc/` folder, here is a consolidated summary of the project's methodology, the results generated across the analysis pipelines, and the overarching goals.

## 1. What We Want to Achieve
- **Primary Objective:** Determine whether maternal immune activation (MIA) during pregnancy significantly alters the brain lipid composition of the offspring.
- **Analytical Rigor:** Establish a highly rigorous, reproducible analysis pipeline that avoids common pitfalls like silent data imputation, forking paths in analytical choices, and over-interpreting supervised models (like PLS-DA) without proper validation.
- **Immediate Next Steps:** 
  - Complete a discussion with the vendor/measuring core to clarify undocumented upstream processing steps, specifically regarding potential gap-filling of non-detects and the use of internal standards.
  - Finalize external lipid annotation, mapping the measured species to LIPID MAPS, KEGG, and HMDB identifiers to provide pathway context.

## 2. Our Methods
- **Study Design:** The dataset consists of 60 samples from 20 mice (10 MIA, 10 control, perfectly sex-balanced). Three correlated brain regions (cortex, cerebellum, and hippocampus) were measured per mouse, yielding 992 lipid species.
- **Outlier Handling & Quality Control:** 
  - **Sample Level:** Excluded one entire animal (mouse `C00431239 - 3`, encompassing samples 25, 26, 27) because independent screens (vendor's own exclusion + our MAD-based leverage screen) consistently flagged it as a severe outlier. Extensive multivariate screening (Hotelling's T², robust Mahalanobis) confirmed no other genuine outliers existed.
  - **Value Level:** Adopted a strict **"exclude, don't impute"** rule. Trace values falling below an empirical detection limit (`max(3 × blank, 1.0)`) were set to missing (`NaN`) rather than imputed, removing likely gap-filled noise.
- **Preprocessing:** Applied log2 transformation and median normalization per sample to correct for loading differences.
- **Statistical Modeling:** 
  - Ran per-region ordinary least squares regressions (`log2(intensity) ~ treatment group × sex`) to maintain independence, followed by Benjamini-Hochberg FDR correction.
  - Employed a **specification curve analysis** (testing 72 different analytical choices) to ensure findings were robust to preprocessing decisions.
  - Verified multivariate group separations (PLS-DA) using rigorous label-permutation testing.

## 3. Our Results (across `results/` folders)
- **MIA vs. Control Lipidomics (`results/mia_vs_control`):**
  - **Null Result:** No individual lipid reached statistical significance (FDR q < 0.05) for the MIA effect, or even the sex effect, in any region. The median observed fold-change was ~1.15x, which falls well below the study's minimum detectable effect size of ~2x at 80% power.
  - **No Real Multivariate Separation:** While PLS-DA produced visually convincing separations between treatment groups, permutation testing proved these were not statistically supported (p-values ranging from 0.10 to 0.63).
  - **Validation of the Pipeline:** The assay and pipeline *do* work. When testing for brain regions (a known large biological effect), the pipeline detected it cleanly with a massive variance explanation (between/within ratio of 2.83). The null result for MIA is a reflection of the small effect size and high technical noise, not a pipeline failure.
- **Quality Control Findings (`results/02_qc` & `results/01_preprocessing`):** 
  - Technical noise in the assay is substantial. For 71% of cortex lipids and 69% of hippocampus lipids, technical variance equaled or exceeded the biological variation.
- **Cross-Modality Analyses (`results/cross_modality`):**
  - The project maintains parallel analyses (including metabolomics) and computes cross-modality concordance tables (e.g., matching Hotelling's T² and DModX outliers across platforms) to ensure a holistic view of sample integrity.
