# Working conventions for AI-assisted sessions

How work is done in this repository, independent of which tool runs it
(Claude Code, Cowork, Claude Science, OpenCode, Codex).

## Read order at session start

1. `doc/analysis-state.md` — where the analysis stands.
2. `AGENTS.md`, `doc/agent-rules.md`, `CLAUDE.md` — rules.
3. The relevant `doc/context/*.md` file for the task.
4. The project skills in `.claude/skills/` for the category of work.

## Project skills take priority over generic ones

Before building any deliverable, check `.claude/skills/` for a project skill
and read it. Generic account-level skills do not know this repo's rules. (A
first slide deck was built with a generic pptx skill and had to be redone
with `scientific-slides`.)

| Work | Skill |
|---|---|
| any implementation | `careful-planning` (first gate) |
| a plan / decision document | `decision-doc` |
| statistical inference or models | `statistics-review`, then `null-calibration` |
| sample exclusion / outliers | `outlier-screen` |
| region contrasts | `region-persistence` |
| lipid preprocessing, annotation, interpretation | `lipidomics-analysis` |
| Python modules / notebook refactors | `python-analysis`, `research-code-style` |
| figures | `publication-plot`, `scientific-visualization` |
| slides | `scientific-slides` |
| committing AI-generated work | `ai-provenance` |

## Plans before code

Non-trivial work starts as a plan in `doc/decisions/` with status PROPOSED
and is not implemented until Sadegh confirms it. Every plan gets a matching
`prompts/` provenance file. Open questions go to `doc/open-questions.md`, not
only into the plan.

## Scientific habits this project relies on

- State the population (all 60 / T²-95 / T²-99) with every number.
- Judge an exclusion by whether the estimate moves or only the SE moves.
- Compare observed counts to a permutation null, not a uniform one.
- Never compare significance counts between groups; test the difference.
- State empirical-p floors (999 permutations → 0.001; cage permutation →
  1/28) wherever an empirical p appears.
- Report nulls with a power statement, not "no differences".
- When a dry run uses approximations (normal instead of t, single-contrast
  FDR), say so, and expect the pipeline numbers to differ.

## Communication with Sadegh

- He decides scientific and statistical choices; present options with the
  trade-off, then a recommendation.
- When correcting an earlier statement, say so explicitly.
- Don't re-introduce dismissed choices (the 57-sample population above all).

## Environment

WSL2 venv `/root/.virtualenvs/LPJ_lipidomics/bin/python` (see `AGENTS.md`);
R via `renv` for limma and the noisyR cross-check. The Cowork device mount
has no scipy/pytest — tests run in the WSL venv. Do not change dependencies
without approval.
