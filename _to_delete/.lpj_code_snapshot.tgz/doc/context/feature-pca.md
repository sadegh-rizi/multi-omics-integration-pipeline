# Feature-space PCA and co-abundance modules

Plan: `doc/decisions/2026-09-08-feature-space-pca-and-coabundance-modules-plan.md`.
Implemented 2026-09-10; results in
`results/mia_vs_control/04_multivariate/features/{primary,t2_99}/`. 100
bootstraps, 100 permuted nulls, stability floor 0.8, minimum module size 3 —
all pre-declared. Evaluated 2026-09-10.

**Caveat:** `primary` here is the 57-sample tree (see `population-rule.md`).
Conclusions are qualitative and unlikely to change, but numbers should be
regenerated on all 60 before being quoted.

## One line

Lipid co-abundance structure is strongly non-random, but at n ≈ 19 no
individual module is reproducible, and in cortex and hippocampus most
large-module features are technically dominated.

## Three tiers

1. **PC axes are uninterpretable** (pre-declared). `interpretation_allowed =
   False` everywhere. Split-half loading correlations: cerebellum PC1 0.143 /
   PC2 0.104; cortex 0.135 / −0.208; hippocampus −0.568 / 0.302. "Which lipids
   drive PC1" has no answer at this n. Do not interpret
   `feature_view_loadings_*`.
2. **Module structure is real against the null.** Observed 210 / 360 / 328
   modules (Cb / Cx / Hp), largest 57 / 52 / 64 features. Permuted null
   largest 3.1 ± 0.3; z ≈ +179 to +191. Pair co-membership 0.52 vs 0.0004.
3. **No module is reproducible.** Zero `reportable` modules. Bootstrap
   co-membership median 0.36–0.45, max 0.73–0.76 against the 0.8 floor. You
   can detect *that* lipids clump, not *which* clump each belongs to.

## The confounder check that fired

Median technical-dominated fraction among modules ≥10 features: cerebellum
0.091, cortex 0.800, hippocampus 0.857 — matching `doc/methodology.md` §5
(technical ≥ biological variance for 71% of cortex and 69% of hippocampus
lipids vs 19% of cerebellum). **Cerebellum is the only region where module
structure is predominantly biological.** Two modules are 100% TG — shared
chemistry, not shared regulation.

## Figure problems (unfixed)

- Correlation heatmap falls back to loading-rank ordering when nothing clears
  the stability floor, which has no block structure by construction — reads
  as "no structure", the opposite of the finding. Order by observed module
  assignment; keep the caveat in the caption.
- `feature_view_loadings_*`: 33 classes on a recycling palette; ring shape is
  a rank artifact. Demote or drop.
- `module_comembership_stability_*`: replace with per-module co-membership
  distributions against the 0.8 floor.

## Standing rules and next tests

Do not lower the stability floor to make something reportable (plan §8.2).
Next: restrict to biologically dominated features and re-run; subsample and
extrapolate to estimate the n needed for 0.8 co-membership (a design number).
