# Design and statistical constraints

Established 2026-09-06 to 2026-09-19. Read before proposing any model.

## Cage is the clustering unit (A1, resolved 2026-09-17)

`data/Samples for metabolomics.xlsx`, sheet "Samples to be shipped": 60 rows,
metadata on the first row of each mouse's three tissue rows — **forward-fill
before use**. Columns: Sample no, Tissue type, Weight, Date collected, Cage
no, Age, Sex, MIA or Control, Date processed.

- `Cage no` is identical as a set to the `Mouse number` prefix. `C00` and
  `C01` are two separate single-pup MIA cages, not truncated IDs.
- **All animals are P14 (pre-weaning)**, so a cage is a dam plus her litter.
  MIA is administered per dam, so the experimental unit is the cage.

| Group | Cages | Pups per cage | Sexes within cage |
|---|---|---|---|
| Saline control | 2 | 6, 4 | both |
| MIA | 6 | 3, 3, 1, 1, 1, 1 | single-sex, every one |

Consequences:

- Effective n for treatment is ~8 clusters, split 2 vs 6. Four MIA cages are
  singletons; only 4 cages have >1 pup, so ICC is barely estimable.
- Sex is confounded with cage inside MIA, so MIA × Sex is not cleanly
  identifiable.
- **Cage-level permutation cannot produce a discovery:** C(8,2) = 28 distinct
  assignments, minimum empirical p = 1/28 ≈ 0.036; the smallest BH q a single
  feature could reach over ~950 features is ≈ 34, i.e. capped at 1 — no
  discovery is possible. Restricted to 2024-06-11 the space is 3. State this wherever
  a cage-level empirical p appears (register B4).
- Open (A1a): is one cage exactly one dam? Six of eight cages are single-sex,
  which suggests sex-selected sampling. The OpenCode implementation of
  2026-09-19 *assumed* cage = dam.

## Collection date is partly confounded with treatment (A8)

| Date collected | MIA | Control |
|---|---|---|
| 2024-06-11 | 4 | 6 |
| 2024-08-06 | 2 | 0 |
| 2024-09-13 | 4 | 0 |
| 2024-10-23 | 0 | 4 |

The only date-matched comparison is 2024-06-11 (4 MIA vs 6 control, 3
cages). Date as a fixed effect reduces the MIA estimate to that subset.
`Date processed` is a single value (2025-02-17) for all 60 samples:
extraction/processing was one batch — a genuine strength.

## Effective number of tests

`m_eff = Var(|t|) / Var(mean |t| across permutations)` gives 16–135 per
Region × Effect family against a nominal 964 (filtered pipeline). The
small-p depletion is one correlated draw from an over-dispersed null
(|z| ≤ 1.31 against the permutation null in every family), not an SE
artifact. Recorded in `05_diagnostics/multiple_testing_caveat.csv`.

## The cage-aware sensitivity layer (08_cage_structure) — not yet usable

Implemented 2026-09-19 (commit `7a6429d`, OpenCode, `openai/gpt-5.6-luna`).
Four arms: A cage means; B cage random intercept; C collection-cohort fixed
effect; D 2024-06-11 subset.

- It ran on the **57-sample population** — violates `population-rule.md`.
  Must be re-run on all 60 (and T² variants) before any number is used.
- Not yet evaluated. Surface observations only: arm B fitted 71–87 of ~976
  features per region; arms A and C show isolated q<0.05 results (min q
  0.002–0.018) that are unvetted. Arm C's cohort term is partly aliased with
  treatment, so its treatment coefficient is essentially the 2024-06-11
  contrast with a shrunken residual — treat any hit there with the same
  suspicion as the σ̂-shrinkage artifacts below.

## Results that must not be reported

- **Cer(m22:0) cortex Sex and interaction** (q = 0.011 / 0.007 under T²-95 and T²-99):
  σ̂-shrinkage artifact, and confounded with cage. Estimate identical to 3 dp
  across variants; only the SE moves.
- **ChE(22:4) cortex MIA** as a finding: q = 0.045 under all 60 but q = 0.48
  after removing two cortex samples. Mention it as a fragile single result.
- **PLS-DA `top50` panels** (p = 0.004–0.014): feature selection before
  permutation. Fixed in code.
- **Cross-modality concordance as independent confirmation:** samples are
  annotated "For Metabolomics, Lipidomics, and Proteomics", so extraction may
  be shared (A4). Empirically T² flags concordant in 0 of 3 regions.
- **Within-group significance counts compared across groups** (e.g. Cx−Hp
  control 152 vs MIA 6): threshold artifact; see `region-persistence.md`.
- **Cage-mean collapse with control df = 1** (dry run 2026-09-19): invalid.
