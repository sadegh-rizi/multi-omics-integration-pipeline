import pandas as pd, numpy as np, sys
# Run from the repository root. Exploratory reference, written 2026-09-21 (Cowork); see doc/context/region-persistence.md.
# The T2 rows drop whole mice (mirrors the current runner) and are NOT a permitted population.
R="results/mia_vs_control/09_region_persistence/prevalence20_noexclusion/lipidomics/00_inputs"
SLUGS={"Cortex - Cerebellum":"cortex_minus_cerebellum","Hippocampus - Cerebellum":"hippocampus_minus_cerebellum","Cortex - Hippocampus":"cortex_minus_hippocampus"}
DROP={"all 60":[], "T2-99":["C00431239 - 3","C01"],
      "T2-95":["C00429562 - 2","C00429562 - 5","C00431239 - 1","C00431239 - 3","C01"]}
def corr(a,b):
    ok=np.isfinite(a)&np.isfinite(b); return np.corrcoef(a[ok],b[ok])[0,1]
def reliability(X,rng,nsplit=200,ids=None):
    n=X.shape[1]; ids=np.arange(n) if ids is None else np.asarray(ids); u=np.unique(ids); rs=[]
    for _ in range(nsplit):
        p=rng.permutation(u); h=len(u)//2; A=np.isin(ids,p[:h]); B=~A
        rs.append(corr(np.nanmean(X[:,A],1),np.nanmean(X[:,B],1)))
    r=np.nanmean(rs); return max(2*r/(1+r),0)            # Spearman-Brown, clipped at 0 like the pipeline
def disatt(C,M,rng,nsplit=200,ic=None,im=None):
    r=corr(np.nanmean(C,1),np.nanmean(M,1)); rc,rm=reliability(C,rng,nsplit,ic),reliability(M,rng,nsplit,im)
    ceil=np.sqrt(rc*rm); return r,rc,rm,ceil,(r/ceil if ceil>0 else np.nan)
rng=np.random.default_rng(20260921); out=[]
for pop,drop in DROP.items():
    for con,slug in SLUGS.items():
        D=pd.read_csv(f"{R}/difference_matrix_{slug}.csv",index_col=0)
        m=pd.read_csv(f"{R}/paired_metadata_{slug}.csv").set_index("Sample")
        keep=[c for c in D.columns if c not in drop]
        C=D[[c for c in keep if m.loc[c,"Bio group"]=="Saline Control"]].to_numpy(float)
        M=D[[c for c in keep if m.loc[c,"Bio group"]=="MIA"]].to_numpy(float)
        r,rc,rm,ceil,dz=disatt(C,M,rng)
        boots=[]
        for _ in range(400):                              # resample mice within group
            ic=rng.integers(0,C.shape[1],C.shape[1]); im=rng.integers(0,M.shape[1],M.shape[1])
            boots.append(disatt(C[:,ic],M[:,im],rng,nsplit=40,ic=ic,im=im)[4])
        lo,hi=np.nanpercentile(boots,[2.5,97.5])
        out.append(dict(population=pop,contrast=con,n_ctl=C.shape[1],n_mia=M.shape[1],r_obs=r,rel_ctl=rc,rel_mia=rm,
                        ceiling=ceil,disattenuated=dz,ci_lo=lo,ci_hi=hi,ci_includes_1=(lo<=1<=hi)))
T=pd.DataFrame(out); pd.set_option("display.width",250)
print(T.round(3).to_string(index=False))
T.to_csv("doc/context/reference/disattenuation_reference.csv",index=False)
