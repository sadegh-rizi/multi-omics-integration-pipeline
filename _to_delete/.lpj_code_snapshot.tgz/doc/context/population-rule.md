# Analysis population rule

Established by Sadegh, 2026-09-21. Binding for every analysis.

## The rule

- **Permitted:** all 60 samples, **or** sample-level removal of the samples
  flagged by Hotelling T² at 95% or at 99%.
- **Never:** whole-mouse removal. Remove the flagged *sample*, not the mouse.
- **Dismissed and must not be used for anything:** the 57-sample population
  (whole mouse `C00431239 - 3`, samples 25/26/27, excluded).

## Why the 57-sample population keeps reappearing

It is a codebase defect, not a policy:

- `analysis_metadata()` in `src/lpj_lipidomics/io/study_design.py` still
  filters `OUTLIER_MOUSE = "C00431239 - 3"` and asserts 57 samples. The
  2026-08-07 policy change to all 60 (`doc/decisions/2026-08-07-full-data-policy-change.md`)
  was never implemented there.
- Consequently `results/mia_vs_control/00_inputs/` is the 57-sample tree, and
  anything built on it inherits the exclusion. This includes
  `results/mia_vs_control/08_cage_structure/` (its manifest records
  `analysis_sample_count: 57`, `excluded_primary_mouse: C00431239 - 3`).
- `doc/project_summary.md` also still describes the 57-sample exclusion and is
  superseded.

## Where the permitted populations live

| Population | Path |
|---|---|
| all 60 | `results/pipeline_test/prevalence20_noexclusion/`; `results/mia_vs_control/09_region_persistence/prevalence20_noexclusion/` |
| T²-95 | `results/pipeline_test/prevalence20_t2_95/`; `results/mia_vs_control/09_region_persistence/prevalence20_hotelling95/` |
| T²-99 | `results/pipeline_test/prevalence20_t2_99/` |
| metabolomics T²-95 | sibling worktree `metabolomics-pipeline/results/metabolomics_pipeline/prevalence20_t2_95/` |

## What the T² flags are (lipidomics, per-region screen, 3 PCs)

- **T²-95:** samples MB2_088-09, -35, -06, -25, -37 — five male mice:
  `C00429562 - 2`, `C00429562 - 5` (control); `C00431239 - 1`,
  `C00431239 - 3`, `C01` (MIA).
- **T²-99:** MB2_088-25 and -37 — `C00431239 - 3` and `C01`, both MIA male.
- `t2_99` removes the same two cortex samples as `t2_95` in cortex, and
  nothing elsewhere, so the three-variant sensitivity is really two.

## In paired (within-mouse) designs

The current region-persistence runner requires all three regions per mouse,
so a flagged sample removes the whole mouse from every contrast — which
breaks the rule above. T²-95 then leaves 8 control + 7 MIA mice; T²-99
leaves 10 control + 8 MIA. The fix is contrast-specific pairing: see
`outlier-screening.md`.
