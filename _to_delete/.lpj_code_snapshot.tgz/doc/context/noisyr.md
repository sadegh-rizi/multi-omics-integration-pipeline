# noisyR cross-check

Diagnosed 2026-09-07 (`doc/decisions/2026-09-07-noisyr-diagnosis-and-repair-plan.md`,
`prompts/2026-09-07-noisyr-diagnosis-v1.md`; register G10–G12, A7). Repair
implemented 2026-09-08, regenerating `results/mia_vs_control/02_qc/` in place.

## Why noisyR fits this data poorly

noisyR assumes low-abundance noise is random and sample-specific, so
between-sample similarity rises monotonically with abundance. In LC-MS the
low-abundance signal is partly **shared** (blank carryover, background,
possible vendor gap-filling), so samples agree at the very bottom of the
range. The curve is J-shaped: first window Pearson 0.41–0.44, trough
0.11–0.17, top 0.78–0.81. The "first crossing of 0.25" rule therefore fires at
window 0 and returns the bottom of the abundance range.

## Original defects

- D1: a failed run written as `0.0`, producing a fabricated threshold
  difference of −9.95 log2.
- D2: NaN propagation with R `cor()` default `use = "everything"` — two of
  three region curves 100% NA; 33 of 36 parameter combinations failed.
- D3: the J-shape above.

## After the repair

- 96/96 sensitivity runs and 8/8 comparison runs complete; 45/45 curve points.
- `pearson_sustained_gt_0_25` rule: cerebellum 17.29 / cortex 15.94 /
  hippocampus 16.59 log2, within 0.15 of the diagnosis's prediction.
- **Detection masking does not remove the low-end spike** (13 of 16 cells
  identical) — the low-abundance correlation is not merely sub-detection
  noise. Strengthens A7.
- **Window size dominates every other choice** — ~11 log2 of spread, not
  plateaued at the largest window tested (10% of panel). Extend to 15/20/25%
  before adopting any threshold.

## The catch — the cross-check no longer cross-checks noisyR

`R/run_noisyr_crosscheck.R` reimplements the windowing
(`calculate_guarded_expression_similarity_counts`) and calls the package only
for `calculate_noise_threshold`. The reported `curve_spearman` 0.936–0.987
measures agreement between two in-house implementations of one algorithm —
near-tautological. Do not present it as validation. G12 (does noisyR's own
function fail the same way?) is bypassed, not answered.

## Loose ends

- `threshold_difference_log2` still compares against the deprecated
  first-crossing rule (8.45 / 7.66 / 8.56); against the sustained rule it is
  1.09 / 1.21 / 1.79.
- Manual curve still runs the raw arm only.
- `doc/methodology.md` does not yet describe the sustained rule, the two
  input arms, or the reimplementation.

None of this changes an inferential result: the threshold feeds filtering,
and the specification curve shows filtering moves the best q by <2×.
