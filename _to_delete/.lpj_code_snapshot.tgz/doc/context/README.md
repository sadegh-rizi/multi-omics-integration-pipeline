# doc/context/ — durable findings, one file per topic

These files hold what was established across AI-assisted analysis sessions
(Cowork, Claude Code, OpenCode) and previously lived only in session memory.
They are the record a new tool or a new session needs to be current. Start
with `doc/analysis-state.md`; come here for the reasoning behind each line.

| File | Covers | Read before |
|---|---|---|
| `population-rule.md` | Which sample populations are permitted; why the 57-sample tree keeps reappearing | loading any data or result tree |
| `design-constraints.md` | Cage = litter, collection-date confound, m_eff, results that must not be reported | proposing any model |
| `pipeline-test-evaluation.md` | Why the MIA result is null and every hit is exclusion-dependent | citing any differential result |
| `outlier-screening.md` | Per-region, pooled, and difference-space T² screens; what each flags and why | changing the exclusion policy |
| `region-persistence.md` | Region-signature persistence results and the disattenuation bootstrap bug | interpreting `09_region_persistence/` |
| `feature-pca.md` | Feature-space PCA and co-abundance modules: structure real, resolution not | interpreting `04_multivariate/features/` |
| `noisyr.md` | noisyR diagnosis, repair, and what the cross-check does and does not show | touching the noise threshold |
| `strategic-direction.md` | Why the thesis is a methods/diagnostics thesis; work order | planning next steps |
| `working-conventions.md` | How to work in this repo: skills, provenance, decision docs, communication | any session |

**Status convention.** Each file states the date its content was
established. Most numbers are copied from the result files named in the text. Some are
from exploratory computations done in a session (marked "exploratory" or
"reference implementation" where they appear — notably the corrected
disattenuation intervals and the outlier-screen comparison); their code is in
`doc/context/reference/` where it was preserved. If a result tree has been
regenerated since, re-check before quoting.

**Provenance.** Written 2026-09-24 from Cowork session memory (model
`claude-opus-5-5`); see `prompts/2026-09-24-claude-science-migration-v1.md`.
