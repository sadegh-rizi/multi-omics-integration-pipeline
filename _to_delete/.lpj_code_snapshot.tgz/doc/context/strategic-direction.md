# Strategic direction

Assessed 2026-09-17; updated 2026-09-24 for the region-contrast design.

## "Null" is three separate statements

1. **No robust MIA effect** — both modalities, all exclusion variants,
   permutation-calibrated. One fragile lipid (ChE(22:4) cortex, q = 0.045
   under all 60) does not survive removing two samples.
2. **Underpowered for plausible effects** — MDE 1.8–2.3× (sample level),
   2.5–3.5× (cage level) against the 20–80% effects typical of
   neuroinflammatory models. This is the actual finding.
3. **Dataset devoid of structure** — **false.** Region between/within ratio
   2.83 (PC1, 33% of variance); co-abundance modules z ≈ +180 over null; sex
   structure in cortex; region signature preserved under MIA.

## Why integration cannot rescue the biology

- Nothing to aggregate: small p-values are not in excess. Against a uniform
  null they even look depleted (lipidomics MIA, three regions pooled, 44
  observed vs 143 expected at p<0.05), but against the permutation null the
  count is ordinary (|z| ≤ 1.31 per family). A diffuse sub-threshold MIA
  signal would produce an excess against the permutation null; there is
  none.
- Integration adds features, not samples: n stays ~20 mice / ~8 cages.
- Shared provenance: possible single biphasic extraction (A4); T² outlier
  flags concordant across modalities in 0 of 3 regions.

## Why it is still worth building — as a validation exercise

The dataset supplies both controls in one place: region as a strong positive
control, MIA as a well-characterised negative, plus per-feature
technical/biological variance, blanks, QC injections and m_eff. The question
a framework should answer: **does it correctly find nothing?** DIABLO, MOFA
and sPLS will return components on noise; showing which do, and supplying the
stability machinery that catches it, is the contribution.

## Thesis spine

A methods/diagnostics thesis with the dataset as calibration substrate. The
modality-agnostic results already in hand:

- exclusion manufactures significance via σ̂ shrinkage;
- m_eff 16–135 vs nominal 964;
- noisyR's assumption inverts on shared-background platforms;
- module structure real but unresolvable at n ≈ 20;
- the region signature survives MIA; per-feature interaction is zero;
  significance counting across groups is a threshold artifact.

## Work order

1. Integration-as-negative-control: 2–3 standard integration methods on
   lipidomics + metabolomics, region positive / MIA negative,
   permutation-validated.
2. Power-and-design deliverable: the n this study would have needed, from
   m_eff, variance ratios, and module stability.
3. **Hold GRN work** (GENIE3, hdWGCNA, robin): needs hundreds of profiles or
   metacells; unreachable at n ≈ 20.

## Still to settle (emails)

- A1a: is one cage exactly one dam?
- A4: shared extraction between metabolomics and lipidomics?
- A8: why collection dates are treatment-split, and what else differed.
- What data is actually coming — proteomics is on the sample sheet but never
  delivered; there is no transcriptomics.

Supervisor's original next-steps list (2026-09): (a) noisyR, (b) outlier
detection, (c) PCA on features, (d) multivariate DE, (e) multi-omics GRN
(GENIE3, hdWGCNA, robin). (a)–(c) done; (d) is the region-persistence line;
(e) held as above.
