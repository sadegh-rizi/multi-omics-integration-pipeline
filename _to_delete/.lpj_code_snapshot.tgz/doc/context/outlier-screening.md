# Outlier screening under the region-contrast design

Evaluated 2026-09-21 on the all-60 region-persistence inputs
(`results/mia_vs_control/09_region_persistence/prevalence20_noexclusion/{lipidomics,metabolomics}/00_inputs/region_input_matrix.csv`).
Screen as in `src/lpj_lipidomics/outliers/screen.py`: autoscale, complete
features, 3 PCs, Hotelling T² with the Beta limit
`((n-1)^2/n) * beta.ppf(alpha, p/2, (n-p-1)/2)`. Exploratory computation;
not yet in the pipeline.

## Question

With the design now comparing regions within mouse, should outliers be
screened pooled across all regions — either all 60 together, or controls
only + MIA only?

## Answer

**No to both.** Screen in the space the test uses: within-mouse region
differences, blind to group, per contrast. Keep all 60 as primary.

### Pooled across regions — why it fails

- Region explains ~30% of total variance in both modalities; an uncentred
  pooled covariance is mostly the region axis.
- Even region-centred, the noisiest region dominates. Within-region variance
  (lipidomics) cerebellum 0.69 vs cortex 0.57 / hippocampus 0.53; metabolomics
  0.21 vs 0.13 / 0.14. Six of seven lipidomics pooled flags are cerebellum.
- Those flags come in cage/date blocks (17, 59, 35: control cage C00429562,
  2024-06-11; 14, 20, 56: MIA, 2024-09-13). The screen is detecting collection
  cohort, not failed samples.
- The three samples of one mouse are not independent (metabolomics
  within-mouse cross-region residual correlation 0.38; lipidomics 0.08), so
  the Beta limit is mis-calibrated.

### Controls-only + MIA-only — why it is worse

It defines "normal" per label and removes each group's extremes, shrinking
each group's variance: the same σ̂-shrinkage mechanism that manufactured the
Cer(m22:0) hits, now inside the interaction test. It also flags the most
samples (8–9 in lipidomics), again in cage blocks. **Any screen must be
label-blind.**

## The recommended screen: difference space with attribution

1. For each contrast (Cx−Cb, Hp−Cb, Cx−Hp), build the 20 mouse difference
   vectors; centre and scale across all mice (not by group); 3 PCs; T² with
   the Beta limit at n = 20.
2. Attribute. Each region appears in two contrasts, so a bad sample leaves a
   signature:

   | Flagged | Attribution |
   |---|---|
   | Cx−Cb and Cx−Hp, not Hp−Cb | cortex sample |
   | Cx−Cb and Hp−Cb, not Cx−Hp | cerebellum sample |
   | Hp−Cb and Cx−Hp, not Cx−Cb | hippocampus sample |
   | one contrast only | no attributable sample — take no action |

   With 20 mice at 95%, about one single-contrast flag per contrast is
   expected by chance.
3. Drop only the attributed sample's pairs (contrast-specific pairing). A
   bad cerebellum sample removes that mouse's Cx−Cb and Hp−Cb pairs and keeps
   Cx−Hp.

**Rule fixed before looking at outcomes:** act only on attributable
(two-contrast) flags. The top single-contrast lipidomics Cx−Hp flags are MIA
mice `C00431239 - 3` and `C00` — the mice driving the unresolved Cx−Hp
concordance — so acting on single-contrast flags would trim the result's own
tail.

## What it finds on all 60 (T² as a multiple of the 95% limit)

- **Lipidomics:** one attributable sample — cerebellum of `C00429562 - 5`
  (control; 1.11 in Cx−Cb, 1.15 in Hp−Cb) = sample 35, also flagged
  per-region. Four single-contrast flags.
- **Metabolomics:** two, both cerebellum — `C00431239 - 3` (MIA; 2.4× and
  2.3×) and `C00429562 - 2` (control; 1.3× and 1.7×). Both also flagged
  per-region. Two single-contrast flags.

## Comparison table (95% cut)

| Screen | Lipidomics flags | Metabolomics flags |
|---|---|---|
| Per region (current) | 35 Cb-C, 56 Cb-M, 25 Cx-M, 37 Cx-M, 09 Hp-C | 8 Cb-C, 26 Cb-M, 4 Cx-M, 48 Hp-C, 21 Hp-M |
| Pooled, uncentred / region-centred | 35, 17, 59, 14, 20, 56 (all Cb), 25 | 26 / 8, 26 |
| Pooled, centred + scaled per region | 35, 17, 59, 20 (Cb), 25 | 26, 4, 6, 21 |
| Region-centred, split by group | 9 samples (8 Cb), incl. 25 | 26, 2, 8, 3 |

Mouse `C00431239 - 3` is flagged by every variant in both modalities
(lipidomics cortex 25, metabolomics cerebellum 26). It alone accounts for the
excess MIA variance in Cx−Hp (SD ratio 1.16 → 1.00 without it).

Note: this reimplementation reproduces the pipeline's per-region lipidomics
T²-95 set except 56 in place of 06 — a small preprocessing difference not
yet traced.

## Implementation (proposed, not authorized)

A `screen_difference_space()` step in
`src/lpj_lipidomics/statistics/region_contrast.py`, then contrast-specific
pair construction replacing the all-three-regions requirement. Write a
decision doc first.
