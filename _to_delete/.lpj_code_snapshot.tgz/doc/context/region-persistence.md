# Region-signature persistence

Plan: `doc/decisions/2026-09-19-region-signature-persistence-plan.md`
(supervisor suggestion: region differential within saline, within MIA, do the
differences persist?). Results:
`results/mia_vs_control/09_region_persistence/{prevalence20_noexclusion,prevalence20_hotelling95}/{lipidomics,metabolomics}/`.
Evaluated 2026-09-21; point estimates reproduced independently.

## Why this design

The region contrast is within-mouse (between-animal variance drops out) and
has a built-in positive control: region is the strongest effect in the data
(between/within ratio 2.83 on PC1, ~33% of variance).

## Findings (lipidomics)

Disattenuated concordance (control vs MIA mean difference profiles), with
**corrected** bootstrap 95% intervals from the reference implementation in
`doc/context/reference/` (400 mouse resamples, reliability recomputed inside
each; exploratory, not a pipeline output):

| Population | n ctl / MIA | Cx−Cb | Hp−Cb | Cx−Hp |
|---|---|---|---|---|
| all 60 | 10 / 10 | 1.03 [0.93, 1.08] | 0.88 [0.71, 1.03] | 1.10 [0.26, 4.67] |
| T²-99 † | 10 / 8 | 1.03 [0.92, 1.10] | 0.89 [0.64, 1.07] | 0.75 [0.23, 1.65] |
| T²-95 † | 8 / 7 | 1.02 [0.88, 1.09] | 0.89 [0.71, 1.11] | 0.59 [0.05, 1.30] |

† These rows drop the **whole mouse** for any flagged sample, as the current
runner does — which the population rule forbids. They show what the runner
currently produces, not a permitted population. Re-run with
contrast-specific pairing. There is no T²-99 tree under
`09_region_persistence/`; that row exists only in the reference output.

- **Cx−Cb and Hp−Cb signatures preserved**: point estimates near 1, every
  interval includes 1. Hp−Cb sits consistently below 1 (0.88–0.89) with
  intervals reaching ~0.64–0.71, so "preserved" there is "not detectably
  altered", not "identical".
- **Cx−Hp unresolved.** Reliability of the Cx−Hp profile is low (control
  0.47, MIA 0.26 at all 60), so the ceiling is ~0.35 and the interval is
  huge. The point estimate drifts with exclusion; the mice T²-95 removes
  (`C00431239 - 1`, `C00431239 - 3`, `C01`) sit at the MIA extreme of this
  contrast. (The difference-space screen ranks `C00431239 - 3` and `C00`
  highest — a different statistic, so the two lists need not match.)
- **Per-feature region × treatment interaction: 0 at q<0.05** everywhere,
  both modalities, in the two pipeline populations (`noexclusion`,
  `hotelling95`).
- Metabolomics concordance values are in the result tree and not
  transcribed here.
- **Within-group count gap is a threshold artifact.** Cx−Hp all 60: control
  152 vs MIA 6 features at q<0.05. A ~30% shift in t moves counts 25× near
  the threshold. Label-shuffle null: ≥25× count ratios in 36% of splits; gap
  ≥146 in 8%. Never compare significance counts across groups (difference of
  significance is not significance of difference).
- The extra MIA variance in Cx−Hp comes entirely from `C00431239 - 3` (SD
  ratio 1.16 → 1.00 without it).

## Method notes

- Split-half reliability of each group's mean profile, Spearman–Brown
  corrected. Attenuation ceiling on observed concordance =
  `sqrt(rel_C × rel_M)`. Disattenuated = observed / ceiling.
- Cage ICC is reported in `02_qc/cage_icc.csv`; `03_differential/region_interactions.csv`
  carries `q_value_raw` and ICC-adjusted `q_value_icc_point/_lower/_upper`.

## BUG — disattenuation bootstrap is biased downward

In `src/lpj_lipidomics/statistics/region_contrast.py`,
`disattenuated_concordance` resamples mice with replacement for the
numerator but draws the reliability denominator from split-half draws on the
**original** data. Resampling makes group means noisier and lowers the
numerator; the denominator never sees it. Symptom: point estimates sit above
their own upper bound (all 60 Cx−Cb 1.031 vs [0.805, 1.021]). Consequence:
pipeline T²-95 Cx−Hp interval [−0.005, 0.870] falsely excludes 1.

Fix: recompute reliability inside each bootstrap resample, keeping duplicate
copies of a mouse in the same split-half (id-aware splits). Point estimates
are unaffected. Both modalities need re-running.

Reference implementation: `doc/context/reference/disattenuation_reference.py`
(runnable from the repo root; seed 20260921; 200 split-halves for the point
estimate, 400 bootstrap resamples with 40 split-halves each; reliability
clipped at 0 and the ratio set to NaN when the ceiling is 0, as in the
pipeline). Output: `doc/context/reference/disattenuation_reference.csv`. The
pipeline fix should reproduce these intervals to within Monte Carlo error.

## Figures (drafts, not in the pipeline)

Four draft figures were made 2026-09-21 (disattenuated concordance,
attenuation ceiling, profile concordance scatter, significance-counting
trap). Figure 1 used the biased pipeline intervals and must be regenerated
after the fix. Colours: lipidomics `#2a78d6`, metabolomics `#eb6834`. To be
folded into the pipeline via `plot_config.save_figure`.
