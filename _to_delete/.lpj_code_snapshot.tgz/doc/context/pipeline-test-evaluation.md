# Pipeline test evaluation: the MIA result is null

Evaluated 2026-09-07 on `results/pipeline_test/{prevalence20_noexclusion,
prevalence20_t2_95, prevalence20_t2_99}` (stamped commit `e16efa7`). Written
into `doc/methodology.md` §§2.1, 3.1, 4.1, 6, 7.2, 10, 11 the same day.

## Every hit is exclusion-dependent

Only three feature-level results reach q<0.10 anywhere, and none is stable:

| Result | noexclusion | t2_95 | t2_99 |
|---|---|---|---|
| ChE(22:4) cortex MIA | q = 0.045 | 0.482 | 0.482 |
| Cer(m22:0) cortex Sex | 0.289 | 0.011 | 0.011 |
| Cer(m22:0) cortex interaction | 0.263 | 0.007 | 0.007 |

**Mechanism — the estimate does not move, only σ̂ does.** Cer(m22:0) cortex
Sex is 1.171 log2 in all three variants to 3 dp; SE falls 0.255 → 0.176. In
the saturated `BioGroup * Sex` model, the Sex contrast at the reference
BioGroup cannot depend on the MIA-male cell, so removing two MIA-male cortex
samples can only shrink the pooled residual SD. The q change is entirely
selection-induced. General lesson: **exclusion manufactures significance.**

Recommendation adopted: report the study as null with a power statement;
`prevalence20_noexclusion` (all 60) is the reporting basis. Under it,
ChE(22:4) cortex MIA reaches q = 0.045 — one feature out of 964 × 9 tests,
and it goes to q = 0.48 when the two flagged MIA-male cortex samples are
removed. Report it as a single fragile result, not a finding; no mechanism
for it has been examined.

## Power is the honest framing

Median minimum detectable effect: 0.82–1.17 log2 (1.8–2.3×) at sample level;
1.3–1.8 log2 (2.5–3.5×) at the cage/litter scale (n ≈ 8). Plausible MIA brain
lipid effects are far smaller. Say "underpowered for plausible effects", not
"no differences".

## The volcanoes only look better after exclusion

Cortex MIA, noexclusion → t2_95: p<0.05 count 23 → 16; best −log10 p 4.33 →
3.80; median |estimate| 0.281 → 0.149. The impression comes from per-panel
axis autoscaling, a tighter central mass, and sparse wing points that are
the least precisely estimated. Judge by the q table and SE, never the picture.

## The outlier screen is the whole story

- All five T²-95 exclusions are male; cortex MIA-male drops 5 → 3, 15
  features fail `MIN_PER_CELL = 3`.
- T²-95 flags 1, 2, 2 of 20 per region — its nominal false-positive rate.
- Robust Mahalanobis flags 17 samples at 95% (6/6/5 by region); overlap with T² is minimal. Which
  samples are "outliers" is a function of detector choice.

## Multivariate and aggregate agree

PERMANOVA R² 3–11%; the two nominal p<0.05 appear only in t2_95 and revert
at t2_99 (2 of 9 unadjusted tests; E1 multiplicity still unreported).
PLS-DA best p = 0.052 (full panel). Class/structural aggregation: 0 at
q<0.10 in all variants.

The earlier specification curve (16 preprocessing specifications × 9
Region × Effect = 144 results; `doc/methodology.md` §7.1) found 0 hits, min
q 0.130 — but it ran on the dismissed **57-sample** primary, before the
filtered pipeline existed. It shows that preprocessing choices move the best
q by <2×; it is not an all-60 result and should be re-run before being
quoted as one.

## Metabolomics is also null

246 features, sibling worktree, T²-95: 0 at q<0.10, min q 0.111 (cortex
MIA), despite a ~4× lighter multiple-testing burden.

## Pipeline defects found (register G6–G9)

- `permutation_null_feature_statistics.csv` lacks a `Region` column; regions
  stacked unlabelled; cannot be joined.
- Two FDR columns disagree ~100×; `p_value_empirical_fdr` is floored by 999
  permutations and cannot reach q<0.10 on ~950 features by construction.
- `results/pipeline_test/` predates the package refactor by six commits;
  re-run one variant under the current layout and diff.
