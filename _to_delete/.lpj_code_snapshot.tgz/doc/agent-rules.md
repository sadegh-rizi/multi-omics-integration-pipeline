# Shared agent rules: LPJ lipidomics analysis

These rules apply to every coding agent. They are safeguards for reproducible exploratory research, not a substitute for the supervisor's statistical or biological decisions.

## Scope and data integrity

- `data/` contains source research artifacts. Never modify them in place.
- Inspect workbook sheets, headers, sample identifiers, and missing-value encodings before writing preprocessing code.
- Do not assume rows are samples or columns are features without checking the actual input table.
- Maintain a traceable link from each derived table or figure to its source workbook, sheet, filtering rules, transformations, and code version.
- Use project-relative paths and ignore Excel temporary lock files beginning with `~$`.
- Do not expose raw data or confidential metadata to external services without explicit authorization.

## Study-design safeguards

The current analysis plan includes MIA/control comparisons, sex-aware analyses, multiple brain regions, and repeated measurements per mouse across modalities/regions. Before inferential analysis, establish and state:

1. the biological unit of observation and experimental unit;
2. sample-to-mouse mapping, region, modality, MIA/bio-group, sex, batch, and any technical replicate fields;
3. whether observations are independent, paired, nested, or repeated;
4. the intended contrast, covariates, exclusion rules, and missing-data handling.

Do not treat measurements from the same mouse as independent replicates. Do not split, cross-validate, or permute grouped/repeated data in a way that leaks mouse-level information across training and validation folds.

## Lipidomics preprocessing and annotation

Before altering preprocessing, inspect the report's methods/metadata and record what is known versus unknown for:

- acquisition platform, ion mode(s), peak integration/identification confidence, internal standards, blanks, QC samples, and batch/run order;
- intensity scale and whether values are raw, normalized, log-transformed, or already imputed;
- zero, missing, below-detection, and censored-value encoding;
- lipid identifiers, class/species resolution, adducts, isotope/isobar ambiguity, and annotation confidence.

Never silently replace missing or zero values. State the meaning and rationale for each filtering, normalization, transformation, and imputation step. Keep a sample/feature exclusion table with reasons. Do not overinterpret lipid species when identification is only class-level or ambiguous.

## Statistical analysis

- Write the question, outcome, predictor/contrast, covariates, unit of analysis, and model/test before running it.
- Distinguish exploratory work from confirmatory claims.
- Report effect size and uncertainty (for example confidence intervals) alongside p-values where applicable.
- Define the multiple-testing family before testing and use an explicit correction method, normally FDR for high-dimensional feature testing. Report raw and adjusted p-values and the correction universe.
- Do not try multiple tests, transformations, subgroups, or cutoffs until a significant result appears.
- Check model assumptions and diagnostics. If assumptions are uncertain, report that uncertainty and offer sensitivity analyses rather than declaring a result robust.
- For PCA, PLS-DA, NMF, MOFA, DIABLO, or network inference: prevent leakage, document tuning/selection, assess stability or out-of-sample performance where feasible, and do not infer causality from separation, loadings, correlations, or networks.
- For enrichment/pathway analysis, record the identifier mapping, universe/background, enrichment method, database/version/date, and how ambiguous/unmapped lipids were handled.

## Figures and tables

- Use a colorblind-safe palette and do not encode groups by color alone when a second cue is practical.
- Label axes with biological units and transformations, state sample size where relevant, and include a clear legend.
- Show distributions and individual observations when sample sizes permit; do not default to bar charts of mean ± SEM.
- Keep axis limits honest; justify any truncation or transformation.
- Save publication figures in a vector format (PDF/SVG) when appropriate and record the code/data that generated them.
- Separate exploratory figures from final inferential figures. Titles and captions must not make a stronger biological claim than the data support.
- Save every figure as vector PDF plus a presentation-resolution PNG and a manuscript-resolution PNG, via `plot_config.save_figure` (`src/plot_config.py`) — not just PDF. Exact DPI/size per venue are deliberately adjustable placeholders (`PRESENTATION_DPI`, `MANUSCRIPT_DPI`), not fixed specs. See `.claude/skills/publication-plot/SKILL.md`.

## Results directory organisation

- Never write results into one flat directory. Group `results/<analysis>/` into numbered pipeline-stage subfolders (`00_inputs/`, `01_preprocessing/`, `02_qc/`, `03_differential/`, `04_multivariate/`, ...) so the ordering of the analysis is readable from the directory listing. Tables sit at the stage level; that stage's figures go in its `figures/` subfolder.
- When outputs vary along an experimental axis (exclusion condition, model variant, parameter setting), put that axis in the **directory path and keep filenames identical across the variants**. Comparing one figure across four conditions should mean opening the same filename in four sibling folders, not parsing four long suffixed filenames in one listing. Region, plot type, and other within-variant distinctions stay in the filename.
- Each of the three `save_figure` outputs (PDF, `_presentation.png`, `_manuscript.png`) belongs in the same folder as its siblings. Do not split a figure across format-specific directories.
- When a restructure coincides with a regeneration, do both in one pass and `git rm` the superseded files. Regenerating into new subfolders while leaving the old flat copies in place produces two full sets of results with no marker of which is current — avoid this above all.
- See `doc/decisions/2026-08-05-outlier-policy-pca-and-figure-reproduction-plan.md` for the worked example of this layout.

## Python and notebook quality

- Use `pathlib.Path`, explicit function inputs/outputs, meaningful names, and type hints on reusable public functions.
- Use deterministic seeds for stochastic methods and record them in code/configuration.
- Prefer small modules for reusable parsing, preprocessing, statistics, and plotting logic; keep notebook cells focused on orchestration and inspection.
- Avoid mutable default arguments, bare `except`, hidden global state, duplicate code, hard-coded local paths, and silent coercion of data types.
- Preserve notebook outputs unless the user explicitly asks to clear or regenerate them.
- Default to the simplest correct implementation for early-stage exploratory code: plain functions over classes, inline logic over deep wrapper chains, few parameters over speculative flexibility. Add classes, config layers, or abstraction only once there is a demonstrated reuse need, not preemptively — a domain scientist without a software background should be able to read the code top-to-bottom and see the analysis, not a framework. See `.claude/skills/research-code-style/SKILL.md` for the full checklist.

## Completion standard

Before handoff, report modified files, real verification commands/results, whether data/notebooks were executed, the analytical assumptions, and residual risks. A passing script is not evidence that a biological or statistical conclusion is valid.
