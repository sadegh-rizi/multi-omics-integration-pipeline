# Methodology and results: MIA versus control brain lipidomics

Last updated: 2026-09-07
Status: analysis complete for the primary research question, and extended by a
filtered-pipeline sensitivity run (Sections 4.1 and 7.2). All findings below
are exploratory in the sense defined in `doc/agent-rules.md` — none is
presented as a confirmatory claim.

**Two analyses are described.** The **primary** analysis
(`results/mia_vs_control/`) excludes one whole animal and applies no prevalence
filter. The **filtered pipeline** (`results/pipeline_test/`) adds a 20%
prevalence filter and replaces whole-animal exclusion with sample-level
Hotelling's T² exclusion, run at three thresholds as sibling variants. The
filtered pipeline is a sensitivity analysis and does not replace the primary
result. Section 7.2 reports it in full, including why its one apparent gain in
significance does not survive inspection.

This document is self-contained. It states what was measured, what was done to
the data, what was found, and what the findings do and do not support.

---

## 1. Study design and source data

The question: does maternal immune activation (MIA) during pregnancy change
the brain lipid composition of the offspring?

Source: `data/1 MB2_088_Lalowski_Report_Final.xlsx`, produced by the CU
Anschutz metabolomics core for the Lalowski lab (study MB2_088).

- **20 mice**: 10 saline control, 10 MIA.
- **3 brain regions per mouse** — cerebellum, cortex, hippocampus — giving
  **60 samples**. Each mouse contributes three *correlated* samples, not three
  independent ones; this constrains how the data may be analysed.
- **Sex-balanced**: 5 male and 5 female in every region × treatment-group cell.
- **992 lipid species**, reported as raw peak areas (verified by inspection of
  the workbook; no normalisation had been applied before delivery).
- Quality-control material included in the same run: **6 injections of a
  pooled "Tech-Mix" QC sample**, **5 pre-run blanks** and **1 post-run blank**.

Peak detection, retention-time alignment and lipid identification were
performed by the core before delivery. The processing software, its version,
and its parameters are not documented in the workbook and were not available
to this analysis. This is recorded as a limitation in Section 10.

### Analysis population

One animal — mouse `C00431239 - 3`, contributing samples 25 (cortex), 26
(cerebellum) and 27 (hippocampus) — was excluded from all analyses, reducing
the dataset to **57 samples from 19 mice**. The justification is in Section 4.

The exclusion leaves per-region cell sizes of 4 MIA-male, 5 MIA-female,
5 control-male and 5 control-female. The design is therefore mildly unbalanced
in one cell, which weakens the treatment × sex interaction more than it
weakens the main effects.

**The filtered pipeline uses a different population.** It starts from all
**60 samples** and excludes at the level of the individual sample rather than
the animal, so a mouse flagged in one region is retained in the other two. The
three variants are:

| variant | rule | samples retained |
|---|---|---|
| `prevalence20_noexclusion` | no sample exclusion | 60 |
| `prevalence20_t2_95` | Hotelling's T² at the 95% limit | 55 |
| `prevalence20_t2_99` | Hotelling's T² at the 99% limit | 58 |

The two exclusion variants are **less independent than they appear**.
`t2_99` removes only cortex samples 25 and 37 — the same two `t2_95` removes
in that region — so cortex results are identical between the two variants,
and cerebellum and hippocampus results are identical between `t2_99` and
`prevalence20_noexclusion`. The three-way sensitivity is effectively two-way.

---

## 2. Preprocessing

**No missing value is ever imputed in the primary analysis.** Values that
cannot be trusted are set to missing and excluded, and every exclusion is
logged with its reason. This follows the project rule against silently
replacing missing or zero values.

Applied in order:

1. **Non-positive values removed.** Zero and negative peak areas cannot be
   log-transformed and do not represent measurements.
2. **Blank-dominated lipids removed** (feature level). A lipid is dropped
   entirely if it has non-zero signal in the blanks and its median across
   biological samples is less than 3× its mean blank signal — i.e. the
   measurement is mostly background. **11 lipids removed**, including four
   free fatty acids (`FA(16:0)`, `FA(19:1)`, `FA(20:0)`, `FA(24:0)`), which
   are well-known laboratory contaminants, and two lipids whose signal was
   *below* their own blank.
3. **Below-detection values masked** (value level, distinct from step 2). An
   individual measurement is set to missing if it falls below
   `max(3 × that lipid's mean blank, 1.0)` raw peak-area units. **880 values
   masked** — 738 by the blank-derived limit, 142 by the absolute floor —
   affecting 96 lipids, of which 5 lose all values.

   The absolute floor is required because for many affected lipids the blank
   is exactly zero, leaving no blank-derived threshold. It is justified by a
   gap in the data rather than chosen arbitrarily: across all measurements the
   5th percentile is ≈1.5 × 10³ and the median ≈4.4 × 10⁴, while only 1.1% of
   values fall below 1.0. The rule targets a specific artifact — 13 lipids in
   which a subset of samples reported peak areas around 10⁻⁷ while the
   remaining samples of the *same lipid* sat in the hundreds. The clearest
   case, `Hex1Cer(d18:1_14:0)` in cortex, had 8 of 20 samples at ≈10⁻⁷ against
   200–900 for the other 12: a 5.8-billion-fold gap uncorrelated with
   treatment, sex, run order or tissue mass. These are almost certainly
   *gap-filled non-detects* — values the processing software inserted where no
   peak was found — rather than measurements. **This interpretation is an
   inference; it has not been confirmed with the core.**
4. **log₂ transformation**, which makes the right-skewed intensity
   distribution approximately symmetric and converts multiplicative variation
   into additive variation.
5. **Median normalisation**: each sample's median log-intensity is subtracted,
   correcting for differences in loading and injection volume while preserving
   each lipid's fold-change.
6. **Auto-scaling** (mean-centre, unit variance per lipid) — applied *only* for
   distance-based multivariate methods, which require comparable feature
   scales. It is deliberately **not** applied before differential testing,
   where fold-change magnitude must be preserved.

After preprocessing, **972 lipids** are testable. Missingness is low: 2.71% of
cells, with 85% of lipids fully complete.

### 2.1 Prevalence filter (filtered pipeline only)

The filtered pipeline inserts one further feature-level step, disabled in the
primary analysis: a lipid is dropped if it is missing in **more than 20% of
samples**. Three ordering choices were fixed before the run and matter for
reproducibility:

- missingness is computed on **raw positive-only values**, before
  detection-limit masking;
- it is **pooled across all 60 samples**, not computed per region, so one
  feature panel is shared by every region;
- it is computed **before sample exclusion**, so all three variants test the
  same panel and differ only in samples.

Resulting attrition, identical in all three variants: **992** lipids in → 17
removed by prevalence → 11 blank-dominated removed → **964 tested**, with 394
individual cells masked below detection and none of the 964 lipids fully lost.
Per region, 938–957 of the 964 are actually fitted; the remainder fail the
minimum-cell rule in Section 3.

Normalisation is median-based rather than internal-standard-based, because it
is not documented whether internal standards were spiked into these samples.
Internal-standard normalisation would be preferable if they exist.

---

## 3. Statistical model

Per lipid, per brain region:

```
log2(intensity) ~ treatment group × sex
```

fitted by ordinary least squares. Three effects are extracted from each fit:
the MIA main effect (the primary question), the sex main effect, and the
treatment × sex interaction.

**Why per region rather than pooled.** Each mouse contributes one sample per
region, so within a single region the 10-versus-10 comparison is independent
across animals. Pooling regions would introduce repeated measures — three
correlated samples per mouse — requiring a mixed model. That was attempted
(see Section 9) and proved unusable at this sample size.

A lipid is fitted in a region only if all four treatment × sex cells contain
at least 3 usable observations. Excluded lipid–region combinations are logged
rather than dropped silently.

**Multiple-testing correction**: Benjamini–Hochberg FDR, applied separately
within each region × effect family (9 families), across the lipids actually
fitted in that family.

**Sensitivity analysis**: the same models were refitted using `limma`
(R/Bioconductor) with empirical-Bayes variance moderation, which stabilises
per-lipid variance estimates by borrowing information across lipids. The
moderation had almost no effect — the estimated prior degrees of freedom were
only 1.8–2.4 against 16 residual degrees of freedom, meaning the method found
little shared variance structure to borrow from. No conclusion changed. The
filtered pipeline repeats the `limma` fit and reaches the same conclusion
there: it changes no variant's set of FDR-significant lipids.

### 3.1 Additional inference in the filtered pipeline

The filtered pipeline adds four components to the model above. All were
specified in `doc/decisions/2026-09-03-filtered-pipeline-and-litter-aware-differential-plan.md`
and confirmed before execution.

**Permutation calibration.** 999 deterministic permutations (seed 20260903)
give an empirical null for every lipid. The scheme respects the design:
BioGroup is permuted *within* Sex for the MIA and interaction effects, Sex
*within* BioGroup for the sex effect. Exchangeability is at the **sample**
level. If the `Mouse number` prefix identifies the dam (open question A1),
sample-level permutation is anti-conservative and every empirical p-value
below is a lower bound.

**Effective number of tests.** For each Region × Effect family,
`m_eff = M² p(1−p) / Var(K)`, where `K` is the count of nominally significant
lipids across null permutations. This is descriptive — it is *not* a
substitute for Benjamini–Hochberg — and is recorded in
`05_diagnostics/multiple_testing_caveat.csv`.

**Aggregation.** Two further multiple-testing families sit alongside the
per-lipid one: 39 lipid-class summaries (unweighted mean and median of
normalised log₂ species profiles) and 160 unweighted structural indices. Each
is corrected within its own Region × Effect family. Lipids whose sum
composition is structurally ambiguous for a multi-chain class are excluded
from the structural indices and logged in
`06_aggregation/aggregate_exclusions.csv`.

**Detectable effect size.** Per region, the minimum detectable effect at
nominal two-sided α = 0.05 and 80% power, reported at the observed sample
scale and at an illustrative litter scale of n ≈ 8. The litter figure is an
illustration only; litter-aware modelling is deferred (open question B1) and
litter identity is unresolved.

**Litter structure is not modelled.** Every model in both analyses treats pups
as independent. If the `Mouse number` prefix is the dam, the 10 saline
controls come from only 2 litters, and all results are optimistic rather than
conservative. This is stated in each run's `analysis_model_contract.csv` and
is the highest-impact open question in the project.

---

## 4. Outlier assessment

Four independent methods were applied to the full 60-sample dataset, before
any exclusion, so that no screen was conditional on another's result.

| method | what it detects |
|---|---|
| MAD-based leverage screen | per lipid, samples whose removal collapses that lipid's variance |
| Hotelling's T² | samples far from the centre *within* the principal-component model |
| DModX | samples poorly reconstructed *by* the model (residual distance) |
| Robust Mahalanobis (MCD) | as T², but resistant to outliers distorting the covariance estimate |

**One animal was identified.** Sample 25 (cortex) was ranked first by the
leverage screen (the most extreme point in 22 of ~990 cortex lipids, against a
mean of 2.7 per sample, spread across 8 different lipid classes rather than
one correlated block), first by Hotelling's T², and first by robust
Mahalanobis distance. It was the only sample flagged at *every* model
dimensionality tested (2, 3, 5 and 10 components). It also inflates the first
principal component of cortex from 27% to 37% of variance single-handedly —
the signature of a point bending the axis toward itself.

The measuring core had independently excluded a different sample from the same
animal — sample 26 (cerebellum) — from their own figures, though their
criterion is not documented and none of the four screens above flags sample 26
as unusual (T² rank 9 of 20, robust Mahalanobis rank 12 of 20).

The whole animal was therefore removed, on the grounds that two of its three
samples were independently questioned. Sample 27 (hippocampus) was never
flagged and is removed only for consistency of the experimental unit — this is
a design choice, not a QC finding.

**No further samples were excluded.** Threshold crossings beyond this point
were shown to be the expected false-positive rate rather than real outliers:
at n≈20 per region a 95% boundary flags ~1 sample per region by construction,
and the flagged set changed completely between model dimensionalities
(cortex flagged samples 10 and 25 at 2 components, 25 and 37 at 3, 25 and 31
at 5, and 25, 31 and 37 at 10). A genuine outlier persists across
dimensionalities; a false positive does not.

A robust-Mahalanobis screen using the conventional χ² cutoff initially flagged
6–7 samples per region. Simulation of the identical configuration on clean
data containing *no* outliers produced a median of 6 flags per region, showing
those flags to be an artifact of the method at this sample size rather than a
finding.

### 4.1 Sample-level exclusion in the filtered pipeline

The filtered pipeline sets the Section 4 conclusion aside and applies a
mechanical rule instead: drop any sample above the Hotelling's T² limit for
its region. This is deliberately exploratory — it asks what the result would
be under a conventional automatic screen, not what the QC evidence supports.
Three properties of the resulting exclusions must be reported with any number
derived from them.

**All five samples excluded at the 95% limit are Male.**

| sample | region | group | sex |
|---|---|---|---|
| 35 | Cerebellum | Saline Control | Male |
| 25 | Cortex | MIA | Male |
| 37 | Cortex | MIA | Male |
| 9 | Hippocampus | Saline Control | Male |
| 6 | Hippocampus | MIA | Male |

Whether this is a real sex-linked variance difference or coincidence is
unresolved (open question D3). Its consequence is not: the design enters
perfectly balanced at 5/5/5/5 per region and leaves with **3 MIA-male cortex
samples**. Fifteen lipids then fail the minimum-cell rule and drop out of
cortex entirely, and the cortex treatment × sex interaction rests on a
three-sample cell.

**The screen flags at its own nominal false-positive rate.** At the 95% limit
it removes 1, 2 and 2 samples from regions of 20 — five in total, against the
three expected by construction from 60 samples at a 5% boundary. This is the
same argument already made in Section 4 against excluding further samples, and
it applies unchanged here: the rule is removing points consistent with ordinary
membership of the distribution.

**The two detectors disagree.** On the same matrices, robust Mahalanobis flags
**17** samples at the 95% level (6 cerebellum, 6 cortex, 5 hippocampus) where
T² flags 5, and the two sets barely overlap. In cerebellum the four highest
robust-Mahalanobis samples are all Female and none is flagged by T²; the
T²-flagged sample 35 ranks only fifth by Mahalanobis. Which samples count as
outliers is therefore a function of detector choice rather than a property of
the data. Both detectors are recorded per sample in
`02_qc/outlier_screen_<region>.csv`.

---

## 5. Analytical quality assessment

Three independent measures of measurement quality, all using QC material
already present in the run.

**Pooled-QC reproducibility.** Coefficient of variation across the six
Tech-Mix injections: **median 23.3%** after normalising the injections, or
32.4% on raw peak areas. The computed values agree with the workbook's own
`%CV` column at r = 0.986. Roughly 28% of lipids exceed a CV of 30%, a common
acceptance threshold.

**Instrument drift.** The Tech-Mix median signal declines monotonically across
the run, from 17,173 in the first injection to 9,211 in the last — a **1.86×
decline**. This does not propagate into the study samples after median
normalisation (correlation between sample number and sample median signal:
−0.03).

**QC clustering in principal-component space.** In a well-behaved run, repeat
injections of identical material cluster tightly at the centre of a PCA of the
biological samples. Here they do so on PC1 (QC spread is 0.11 of biological
spread) but **not on PC2, where QC spread is 0.76 of biological spread**. The
mean distance of a QC injection from the biological centroid, 18.5, equals the
mean distance of a genuine biological sample from that same centroid. Repeat
injections of one material are scattering as widely as different brain samples
do.

Separately, technical variance was compared with biological variance per lipid
per region. Technical noise equals or exceeds biological variation for **71%
of cortex lipids and 69% of hippocampus lipids**, versus 19% in cerebellum.

Together these indicate that a substantial share of the total variation in
this dataset is analytical rather than biological.

---

## 6. Statistical power

Given the observed biological variability, the **minimum detectable effect at
80% power, after FDR correction, is approximately a 2-fold change**
(|log₂ fold-change| ≈ 1.0) for a main effect at 10 samples per group. For the
treatment × sex interaction, which is estimated from 5 samples per cell, it is
roughly 4- to 6-fold.

The **observed** MIA effects are far smaller: median |log₂ fold-change| =
**0.207**, a 1.15× change; the 90th percentile is 0.672, a 1.59× change. Only
**5.6%** of lipids show a change of 2-fold or greater.

The study is therefore structurally unable to detect effects of the magnitude
actually present, independent of whether those effects are real.

The filtered pipeline computes this per region from the observed standard
errors rather than from a single pooled figure. Median minimum detectable
effect at 80% power, `prevalence20_t2_95`:

| region | sample scale (log₂ / fold) | illustrative litter n ≈ 8 (log₂ / fold) |
|---|---|---|
| Cerebellum | 1.17 / 2.25× | 1.80 / 3.48× |
| Cortex | 0.88 / 1.84× | 1.32 / 2.50× |
| Hippocampus | 0.89 / 1.86× | 1.34 / 2.52× |

The other two variants differ by less than 0.1 log₂ units. Two things follow.
First, the sample-scale floor of roughly **1.8–2.3×** confirms the Section 6
figure on the filtered panel. Second, if litter rather than pup is the
experimental unit, the floor rises to **2.5–3.5×** — far above the 20–80%
effects typically reported for neuroinflammatory models. **This is the single
most important number in the analysis**: it establishes that the study could
not have detected a plausible MIA effect, which is a much stronger statement
than reporting that no effect was found.

---

## 7. Results

Sections 7 and 7.1 report the **primary** analysis. Section 7.2 reports the
filtered pipeline separately, because its exclusion variants do not share this
analysis population.

**No lipid reaches FDR q < 0.05 for any effect, in any region.** The smallest
q-value observed anywhere is 0.238, for the MIA effect in cortex.

**The assay and pipeline demonstrably work.** In a PCA pooling all samples,
brain region separates strongly — the ratio of between-region to within-region
spread on PC1 is **2.83**, and region explains 33% of total variance. For
treatment group the same ratio is **0.11**, 26× weaker. A large biological
difference is detected cleanly by this pipeline; the treatment difference is
simply not of comparable size.

**Supervised classification does not survive validation.** PLS-DA, a
supervised method that finds the projection best separating known labels,
produces visually convincing separation between treatment groups. Label-
permutation testing (1,000 permutations, stratified by sex) shows this
separation is not statistically supported: p = 0.63 (cerebellum), 0.37
(cortex), 0.10 (hippocampus). PLS-DA generates apparent separation even when
no group difference exists, which is why the permutation test is necessary.

**Aggregating to lipid classes does not recover a signal.** Collapsing 972
lipids into 38 classes reduces the multiple-testing burden 25-fold and
averages away per-lipid noise. Result: 0 classes significant after correction,
and 4 nominally significant against 5.7 expected by chance.

**The p-value distributions are at or below chance.** For the MIA effect,
nominally significant lipids (p < 0.05) number 44 against 143 expected by
chance; across all three effects, 264 against 430. A hidden diffuse signal
suppressed only by correction would produce an *excess* of small p-values, not
a deficit. Section 7.2 identifies the source of this depletion — it is the
correlation structure of the panel, not an inflated-variance artifact — and it
is not by itself evidence about the presence or absence of an effect.

**One apparent pattern is a compositional artifact.** In hippocampus, 28 of 38
lipid classes decreased in MIA (sign test p = 0.005). However, the classes
that *increased* are the large, abundant ones (PC with 222 species, TG with
102), and the direction of change correlates with both class abundance
(r = +0.34) and class size (r = +0.35). Under median normalisation, if a group
of abundant lipids rises then everything else is mathematically pushed down.
The sign test assumes the 38 classes are independent, which normalisation
prevents. This is the closure effect inherent to compositional data, and the
direction cannot be interpreted without an external normalisation anchor.

### 7.1 The result does not depend on analytical choices

To test whether the null result is an artifact of preprocessing decisions, a
**pre-specified specification curve** was run: every combination of two
prevalence-filter options (20% filter applied, or not), two QC-CV filtering
options (applied at CV > 30%, or not applied) and four missing-value
strategies, giving 16 complete analyses.

The four missing-value strategies were: none (primary); half-minimum
imputation; Random Forest imputation restricted to genuinely
missing-at-random cells with half-minimum for censored cells; and Random
Forest applied to everything. The distinction matters because **85% of the
missing values in this dataset are left-censored** — known to be below
detection — and Random Forest assumes missing-at-random, so applying it to
censored cells imputes them systematically too high.

All sixteen specifications, across 3 regions and 3 effects (144 results in
total), were committed to reporting *before* any was run.

**Result: 0 FDR-significant lipids in any of the 144.** The smallest q-value
across the entire multiverse is 0.130; the best q-value per specification
ranges from 0.130 to 0.244. Analytical choice moves the result by less than a
factor of two and never approaches significance. The prevalence filter is the
mildest axis of the four: turning it on moves the best q-value from 0.238 to
0.219 under the primary no-imputation setting.

A masked-value recovery test (hiding 1% of observed values and comparing
imputed against true) found Random Forest substantially more accurate than
half-minimum imputation (RMSE ≈ 0.87 versus ≈ 2.9). This validates Random
Forest **for missing-at-random cells only** — a masking test can only hide
values that were observed, and therefore cannot assess performance on
censored cells, where the truth is unknown. It does not license applying
Random Forest to the censored majority.

Other analytical variants tested and reported: removing technically noisy
lipids (made cortex separation *worse*, permutation p 0.37 → 0.86);
empirical-Bayes variance moderation (no change); QC-CV filtering, which
removes 29% of the panel and changes nothing.

### 7.2 Filtered pipeline: three exclusion variants

The filtered pipeline (Sections 2.1, 3.1, 4.1) was run to ask whether a
prevalence filter plus automatic sample exclusion recovers a signal the
primary analysis missed. **It does not.** What it does instead is show how
completely the apparent result depends on which samples are dropped.

#### Every FDR result is exclusion-dependent

Across all three variants, all three effects and all three regions — 8,526 to
8,580 model fits per variant — exactly **three** results reach q < 0.10, and
**not one of them is stable**:

| lipid, region, effect | noexclusion | t2_95 | t2_99 |
|---|---|---|---|
| ChE(22:4), cortex, MIA | **q = 0.045** | 0.482 | 0.482 |
| Cer(m22:0), cortex, sex | 0.289 | **0.011** | **0.011** |
| Cer(m22:0), cortex, interaction | 0.263 | **0.007** | **0.007** |

Nothing reaches q < 0.05 in any variant except Cer(m22:0). No lipid is
significant in more than one variant. The single MIA-effect result exists only
when *no* sample is excluded, and the two Cer(m22:0) results exist only when
samples *are* excluded.

#### The mechanism is the standard error, not the effect

Cer(m22:0) makes the mechanism visible. Its cortex sex estimate is **1.171
log₂ in all three variants, identical to three decimal places**; only the
standard error moves, from 0.255 to 0.176. This is not a coincidence. In the
saturated `BioGroup * Sex` model the sex contrast is evaluated at the reference
BioGroup (Saline Control), so it is a function of the two control cell means
alone. Removing two MIA-male cortex samples is *arithmetically incapable* of
changing it. All it can do is shrink the pooled residual σ̂ that every
coefficient in the region shares.

The q-value therefore falls from 0.289 to 0.011 for one reason: the exclusion
rule removed the samples that were inflating the within-cell variance, and the
same variance estimate is then used to test them. That is selection-induced
significance in its clearest form, and it is why the Cer(m22:0) interaction
result must not be reported as a finding. ChE(22:4) fails in the mirror image —
its estimate barely moves (0.856 → 0.770) while its standard error inflates
(0.155 → 0.186) and its q-value collapses from 0.045 to 0.482.

#### Permutation inference finds nothing at all

Against the empirical null, **no lipid reaches q < 0.10 in any variant or
effect**; the smallest empirical BH q-value anywhere is 0.386. Two caveats
belong with that number in both directions:

- With 999 permutations the smallest attainable empirical p-value is 0.001.
  Across a ~950-lipid panel, BH on such a granular p-value **cannot reach
  q < 0.10 by construction**. `p_value_empirical_fdr` is therefore
  uninformative here rather than evidence of absence, and should not be quoted
  as though it were a null result. The finer `empirical_null_fdr` column in the
  same file reaches 0.006 for Cer(m22:0) — but that is the same
  exclusion-dependent result as above, not independent support for it.
- Sample-level permutation is anti-conservative if litters exist, so these are
  upper bounds on significance.

**No Region × Effect family shows global signal.** Measured against the
permutation null rather than against a uniform distribution, every family sits
within 1.4 standard deviations of its null mean (|z| ≤ 1.31 across all three
variants). The permutation null itself yields 23–56 nominally significant
lipids where a uniform null predicts ~47, with a standard deviation of 13–53.

This **answers open question E5**, which had been blocking interpretation. The
depletion of small p-values is not an inflated-standard-error artifact and not
a sign of suppressed signal: it is an ordinary draw from a heavily
over-dispersed correlated null. The effective number of independent tests is
**16 to 135 per family against a nominal panel of 964** — recorded per family
in `05_diagnostics/multiple_testing_caveat.csv`, closing the earlier gap where
this had been left unestimated.

#### Multivariate and aggregated results agree

- **PERMANOVA**: treatment, sex and interaction explain 3–11% of variance per
  region. Only two terms reach nominal p < 0.05 — cerebellum sex (0.033) and
  hippocampus treatment (0.045) — and both appear *only* in `t2_95` and revert
  in `t2_99`. That is 2 of 9 unadjusted tests, exactly the chance expectation,
  and the multiplicity family across regions and terms is still unresolved
  (open question E1).
- **PLS-DA**: nothing survives permutation in any variant; the best value is
  p = 0.052 in hippocampus, 1 of 3 regions, unadjusted. The earlier top-50
  feature panel has been removed from the pipeline — selecting features on
  labelled data before a supervised projection is circular — so only the full
  panel is reported. This settles open question E2.
- **Aggregation**: **0 results at q < 0.10** for class means, class medians and
  structural indices, in all three variants. Their nominal counts are unstable
  in the same way as the per-lipid results: structural indices show 60, 33 and
  70 lipids at p < 0.05 across the three variants.

#### On the volcano plots looking better after exclusion

The cortex volcano does look cleaner after `t2_95`. The improvement is not
real, and the underlying numbers run the other way:

| cortex, MIA effect | noexclusion | t2_95 |
|---|---|---|
| lipids at nominal p < 0.05 | 23 | **16** |
| strongest result, −log₁₀(p) | 4.33 | **3.80** |
| median \|estimate\| (log₂) | 0.281 | **0.149** |
| SD of estimate (log₂) | 0.570 | 0.558 |

Fewer lipids cross the significance line, the best p-value gets *worse*, and
the typical effect size is nearly halved. Three things create the visual
impression of improvement:

1. **The axes rescale.** Both axes are auto-scaled per panel. Removing the
   ChE(22:4) point at −log₁₀ p = 4.33 drops the y-axis ceiling, so the
   remaining cloud fills more of the frame at a larger apparent scale. The two
   panels cannot be compared by eye at all until the axes are fixed.
2. **The central mass tightens.** Median |estimate| falls from 0.281 to 0.149,
   so the null cloud contracts into a narrower, more canonical "V".
3. **The wings look more prominent.** The proportion of lipids beyond
   |log₂| > 1 barely changes (6.2% → 6.6%), but against a tightened centre the
   sparse high-|estimate| points read as separated. Those points are the
   *least* precisely estimated lipids in the panel — large estimates carrying
   large standard errors — and a wider spread of estimates at unchanged
   p-values is a loss of precision, not a gain in signal.

A volcano plot is a display of raw p-values against effect size. It cannot show
whether anything survives correction, and here nothing does. The figures are
correctly captioned in the pipeline ("Raw p-values shown; no point is an FDR
claim"), and that caption should be read as binding.

#### Recommendation

`prevalence20_noexclusion` is the better basis for anything reported. Its only
cost is one nominal ChE(22:4) result that no other variant reproduces; its
benefit is that the reported result no longer depends on an automatic detector,
at an arbitrary threshold, that removed only male samples and reduced one
design cell to n = 3. If an exclusion variant is shown, all three should be
shown together.

---

## 8. Interpretation

The data do not support a detectable effect of maternal immune activation on
brain lipid composition in this cohort.

This is a **statement about detectability, not about biology**. Three
independent lines of evidence establish why:

1. The observed effects (≈1.15× median) are well below the detection floor
   (≈2×) imposed by the sample size.
2. Analytical variability is substantial — median pooled-QC CV of 23%, QC
   injections scattering as widely as biological samples on PC2, and technical
   noise equalling or exceeding biological variation for the majority of
   cortex and hippocampus lipids.
3. The result is invariant across a pre-specified space of analytical choices,
   so it is not an artifact of preprocessing.

A fourth line was added by the filtered pipeline (Section 7.2): the only
results that cross an FDR threshold anywhere in the project are created or
destroyed by which two to five samples an automatic screen removes, and the
mechanism is demonstrably a shift in the pooled residual variance rather than
in any effect estimate. Permutation inference, which does not depend on the
parametric variance estimate, finds nothing in any variant. Taken together,
these say the null is not fragile — the *departures* from it are.

Crucially, the pipeline detects brain region — a large, expected biological
difference — with a between/within ratio of 2.83. The null is specific to the
treatment effect, not a general failure to see biology.

The sex effect, ordinarily among the most robustly detected contrasts in
rodent lipidomics, is *also* null here. That is informative: it indicates the
limitation is general to this dataset's sensitivity rather than specific to
the MIA contrast.

**What this does not show.** It does not show that MIA has no effect on brain
lipids. An effect of the magnitude typically reported for this kind of
neuroinflammatory model — commonly in the 20–80% range — would be invisible at
this sample size and noise level. The correct conclusion is that this
experiment cannot resolve the question, not that the question is answered.

---

## 9. Analyses attempted and not usable

**Pooled cross-region mixed model.** A random-intercept model across all 60
samples, intended to gain power by using all three regions while accounting
for within-mouse correlation, failed to fit for 87% of lipids (singular
matrix); of those that did fit, 91% carried convergence warnings. The model is
too complex for 20 mice. Retained as a documented limitation.

**Mouse-blocked omnibus PERMANOVA.** Scoped but not implemented. A pooled
cross-region PERMANOVA would require permuting whole mice rather than
individual samples, because treatment and sex are constant within an animal.

**Per-region PERMANOVA** was run (Freedman–Lane permutation, 9,999
permutations). No term reaches significance in any region; treatment, sex and
their interaction jointly explain 3–8.5% of total variance per region.

---

## 10. Limitations and open items

- **Upstream processing is undocumented.** Peak picking, alignment,
  gap-filling behaviour and identification confidence were performed by the
  measuring core; the software, version and parameters are unknown to this
  analysis. Whether gap-filling occurred — which determines whether the
  detection-limit filter in Section 2 is correcting an artifact or discarding
  real data — is an open question for the core.
- **Internal standards.** It is not known whether any were spiked in. Without
  them, the data are compositional and the *direction* of a global shift
  cannot be interpreted (see Section 7).
- **Tech-Mix composition.** Whether the pooled QC is an aliquot of the study
  samples or an external reference material is not documented. This affects
  how its displacement in PCA space (Section 5) should be read, though not the
  interpretation of its scatter.
- **Acquisition order and randomisation** are not documented. Sample numbering
  is systematic; whether injection order matched it, and whether it was
  randomised with respect to treatment group, is unknown.
- **Sample 27** is excluded for experimental-unit consistency, not because it
  failed any QC criterion.
- **Outlier detection at this sample size is low-powered.** Simulation shows
  roughly a 4-standard-deviation displacement is needed for 90% detection at
  n = 20. Subtle outliers would not be found, and "no further outliers
  detected" should be read with that limitation attached.
- **External lipid annotation** (mapping species to LIPID MAPS, KEGG and HMDB
  identifiers for pathway context) is planned but not complete.
- **Litter structure is unresolved and unmodelled.** If the `Mouse number`
  prefix identifies the dam, litter rather than pup is the experimental unit,
  the 10 saline controls come from only 2 litters, and every result in both
  analyses is optimistic rather than conservative. This is the highest-impact
  open question in the project and is answerable only by the animal-work owner.
- **All five samples excluded at the 95% T² limit are male** (Section 4.1),
  reducing the cortex MIA-male cell to n = 3. Any number derived from
  `prevalence20_t2_95` carries this.
- **Permutation resolution.** 999 permutations floor the empirical p-value at
  0.001, which prevents empirical BH from reaching q < 0.10 over a ~950-lipid
  panel regardless of the data. Raising the permutation count is required
  before the empirical FDR column can be read as evidence either way.
- **The filtered-pipeline outputs predate the source refactor.** They are
  stamped at commit `e16efa7`, and the package reorganisation that followed
  moved the runner that produced them. They have not been regenerated under
  the current layout, and should be before any figure or table derived from
  them is used.
- Thresholds used — `min_per_cell = 3`, blank multiplier 3×, absolute floor
  1.0, QC-CV 30% — are conventional defaults rather than values validated
  against this dataset specifically. The specification curve (Section 7.1)
  tests sensitivity to the two most consequential of them.

---

## 11. Software and reproducibility

- Analysis code is in `src/` as plain Python modules; notebooks orchestrate
  and inspect but contain no modelling logic. `limma` runs from a standalone
  R script (`src/differential_moderated.R`) with dependencies pinned by
  `renv`.
- Test coverage: unit tests across all analysis modules using synthetic
  fixtures; no real data in tests.
- Results are organised under `results/mia_vs_control/` in numbered
  pipeline-stage folders (`00_inputs/` through `07_specification_curve/`).
  The filtered pipeline writes the same stage layout under
  `results/pipeline_test/<variant>/`, with `05_diagnostics/` and
  `06_aggregation/` added, and a `run_manifest.json` per variant recording the
  permutation seed and scheme, the exclusion rule, the feature counts and every
  standing caveat.
- Analysis code was reorganised into the `src/lpj_lipidomics/` package
  (`io/`, `preprocessing`, `statistics/`, `multivariate/`, `qc/`, `outliers/`,
  `runners/`); the former flat `src/*.py` module paths remain as compatibility
  imports. New code should import from `lpj_lipidomics`.
- Implementation was distributed across two AI coding assistants, coordinated
  through plan documents in `doc/decisions/` written and confirmed before
  implementation, with prompt records in `prompts/`.
- Key result files: `03_differential/differential_effects.csv`,
  `07_specification_curve/specification_results.csv`,
  `02_qc/qc_injection_cv.csv`, `01_preprocessing/detection_limit_exclusions.csv`.
  For the filtered pipeline add `02_qc/sample_exclusions.csv`,
  `05_diagnostics/multiple_testing_caveat.csv`,
  `05_diagnostics/permutation_null_feature_statistics.csv` and
  `07_specification_curve/detectable_effect_size_summary.csv`.

**Known defect in `permutation_null_feature_statistics.csv`.** The file has no
`Region` column, so its three regions are stacked unlabelled and 5,643 of its
8,526 rows share a `Feature` + `Effect` key. It cannot currently be joined to
`differential_effects.csv` without inference. It also carries two FDR columns,
`p_value_empirical_fdr` and `empirical_null_fdr`, which disagree by roughly two
orders of magnitude on the same row without documentation of which is
authoritative. Both should be fixed before the empirical p-values are used.
