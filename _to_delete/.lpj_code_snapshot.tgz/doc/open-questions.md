# Open questions

Consolidated register of every unresolved question raised across
`doc/decisions/*.md`, collected 2026-09-03. Each entry names its source
document; the source remains authoritative for context and rationale.

**How to use this file.** It is an index, not a decision record. When a
question is answered, record the answer and its reasoning in the relevant
`doc/decisions/` file (or a new one), then mark the entry here `ANSWERED` with
a pointer — do not delete it, so the register stays a complete history of what
was undecided and when.

Grouped by who can answer, then by topic. **Section A cannot be answered from
the delivered data at all** and is the natural agenda for the next vendor or
wet-lab contact.

---

## A. Vendor / wet-lab questions — not answerable from the data

| # | Question | Source | Status |
|---|---|---|---|
| A1 | Does the `Mouse number` prefix (e.g. `C00429562 - 1` … `- 6`) identify the **dam/litter**, or a cage, shipment, ear-tag batch, or vendor accession? And what are `C00` and `C01` (no suffix, both MIA males)? | `2026-09-03-filtered-pipeline...` Q1 | **ANSWERED 2026-09-17: it is the cage number.** `data/Samples for metabolomics.xlsx` carries `Cage no`, identical as a set to the prefixes. All animals are **P14 (pre-weaning)**, so a cage is the dam plus her litter — cage is the clustering unit. `C00` and `C01` are two separate cages collected 2024-08-06, one MIA male each, not truncated identifiers. 2 control cages (6, 4 pups) vs 6 MIA cages (3, 3, 1, 1, 1, 1). See `2026-09-17-cage-and-collection-date-structure-plan.md`. |
| A1a | Is **one cage exactly one dam**? Six of eight cages are single-sex, improbable for whole litters (~6% for the two 3-pup cages jointly), suggesting only a sex-selected subset of each litter was sampled. | evaluation 2026-09-17 | **OPEN — the one remaining question for the animal-work owner.** MIA is administered per dam, so the experimental-unit count of 8 cannot be asserted until this is confirmed. |
| A8 | **Collection date is partly confounded with treatment.** 2024-08-06 and 2024-09-13 are MIA-only; 2024-10-23 is control-only; only 2024-06-11 contains both (4 MIA, 6 control, 3 cages). Was this deliberate cohorting, and what else differed between collection dates (operator, reagent lot, dam cohort)? | evaluation 2026-09-17 | **OPEN — newly visible.** Not adjustable away: date as a fixed effect reduces the MIA estimate to the 2024-06-11 subset. `Date processed` is a single value for all 60 samples, so processing is *not* confounded. |
| A2 | Is **Tech-Mix** a pooled study aliquot or an external reference material? Changes how its CV should be read and whether the CV filter is meaningful. | `2026-08-07-qc-feature-filters-plan.md` | **OPEN.** `analysis_config.py` still carries the note "probably pooled study-sample QC, pending vendor confirmation". |
| A3 | Is **sample number** the true acquisition order? Currently used only as a proxy in drift figures. | `2026-08-21-qc-completion-and-loadings-plan.md` | **OPEN.** Figures must state it is a proxy. |
| A4 | Were the metabolomics and lipidomics measurements made from the **same tissue extraction** (biphasic split) or separate aliquots? | `2026-08-26-cross-modality-outliers-loadings-noisyr-plan.md` A5 | **OPEN.** Until answered, cross-modality concordance is "two assays of possibly shared provenance", never "independent confirmation". |
| A5 | On what basis did the vendor exclude **sample 26**? It is not reproducible from the delivered data (ranks 9th of 20 by T², 12th by robust Mahalanobis). | `2026-08-07-full-data-policy-change.md`, `2026-08-26-cross-modality...` | **OPEN.** |
| A6 | Does the **post-run blank** systematically show more carryover than the pre-run blank? Determines whether pooling all 6 blanks inflates the detection limit versus using the 5 pre-run injections only. | `2026-07-30-trace-level-detection-limit-preprocessing-plan.md` #2 | **OPEN — checkable empirically**, flagged as "worth checking before committing". |
| A7 | The similarity-versus-abundance curve **rises at the very lowest abundance window** (Pearson 0.41–0.44, against a trough of 0.11–0.17 just above it) in all three regions. Samples agree at the bottom of the range because they share a background signal. Is that blank carryover, vendor gap-filling, or both? | `2026-09-07-noisyr-diagnosis-and-repair-plan.md` §2 | **OPEN.** Bears on A6 and on the gap-filling question in `doc/methodology.md` §10. Repairing the threshold rule does not answer it. |
| A9 | Is there any **absolute anchor** for normalisation: were internal standards spiked in, and was extraction volume scaled to tissue mass (per mg)? Without one, every reported region difference is relative (compositional). | supervisor review 2026-10-01; `2026-09-26-known-broken-fixes-plan.md` §4.9 | **OPEN — vendor question.** |
| A10 | **Lipid nomenclature:** is `ST(d..)` a sulfatide (LipidSearch convention), and can ether lipids be split into O- (alkyl) vs P- (plasmalogen)? Determines the myelin index and ether composites. | `2026-10-05-biology-in-the-data-plan.md` §8 | **OPEN — vendor question.** |
| A11 | Were **maternal responses** to poly(I:C) recorded (IL-6, weight loss, temperature), and was any **offspring behaviour** measured? A per-dam response or per-mouse behaviour score would give a continuous phenotype, and tells whether MIA took in every dam. | `2026-10-05-biology-in-the-data-plan.md` §4.5 | **OPEN — question for the animal-work owner.** Highest-value open item for MIA biology. |
| A12 | **Proteomics run structure:** were cerebellum, cortex and hippocampus acquired as separate LC-MS batches and quantified in separate FragPipe/MaxLFQ runs (the three delivered matrices are separate and separately ND-imputed)? Is the pre-imputation matrix available? Decides whether proteomic region differences are partly technical. Ask the colleague who supplied the data. | `2026-10-11-multiomics-integration-plan.md` §3.1, D1–D2 | **OPEN — blocks interpretation of every region-anchored integration result.** |
| A13 | **Hippocampal dissection and shared homogenate:** were hippocampus boundaries fixed (fimbria / adjacent white matter included or excluded), and did lipidomics and proteomics come from the same homogenate? Lipid and protein myelin scores correlate r = 0.75–0.86 within region, so dissection-driven myelin content would mimic an MIA myelin effect. | `2026-10-12-effect-size-estimation-evaluation.md` §2.5, D2 | **OPEN — question for the animal-work owner.** |

---

## B. Study design and experimental unit

| # | Question | Source | Status |
|---|---|---|---|
| B1 | If A1 confirms litters: does the differential model gain a dam random effect (`+ (1\|dam)`), or is the analysis collapsed to litter means? | `2026-09-03-filtered-pipeline...` §6.3 | **UNBLOCKED 2026-09-17 by A1; planned, not authorized.** `2026-09-17-cage-and-collection-date-structure-plan.md` §5.4 proposes **collapse to cage means as primary** rather than a random effect — with 2 control cages, 4 singleton MIA cages and a 2-vs-6 split, a mixed model has almost nothing to estimate between-cage variance from (cf. the 87% failure rate of the earlier pooled mixed model). Arm choice is §8.1 of that plan. |
| B4 | **Cage-level permutation cannot produce a discovery.** C(8,2) = 28 distinct assignments, so the smallest empirical p is 1/28 ≈ 0.036 and BH over ~950 features has a floor of ~34. Restricted to 2024-06-11 the space is C(3,1) = 3. Is a cage-level empirical p worth reporting at all given this? | evaluation 2026-09-17 | **OPEN — design fact, not a data finding.** Must be stated wherever a cage-level empirical p-value appears. Same class as the 999-permutation floor (G8). |
| B2 | Is a **pooled omnibus PERMANOVA** (in addition to the per-region ones) wanted, given the mouse-blocked permutation caveat? | `2026-07-21-mia-vs-control-lipidomics-plan.md` | **OPEN.** |
| B3 | Should the pooled **cross-region** moderated model be revisited using `limma`'s `duplicateCorrelation` for repeated measures? The earlier `fit_pooled_mixed_sensitivity` failed to converge for ~87% of features. | `2026-07-23-limma-moderated-variance-r-plan.md`, `2026-07-30-trace-level...` #4 | **OPEN**, noted as a loose end rather than a priority. |
| B5 | **Sex is identifiable only within the two control cages** (3F/3M and 2F/2M); in MIA it equals cage and largely collection date. Is a 10-mouse within-cage sex analysis worth reporting, and should the earlier "sex structure in cortex" claim be withdrawn (cortex sex discoveries at the permutation null, z ≈ +1.0)? | `2026-10-05-biology-in-the-data-plan.md` §4.3, D4 | **OPEN — planned.** Recommendation: within-cage controls as primary; withdraw the claim. |

---

## C. Preprocessing, filtering and missingness

| # | Question | Source | Status |
|---|---|---|---|
| C1 | **Prevalence filter denominator**: is ">20% missing" computed over all 60 samples pooled, or per region? | `2026-09-03-filtered-pipeline...` Q3 | **ANSWERED 2026-09-03: pooled across all regions (all 60 samples), one feature list applied to every region.** |
| C2 | Is the prevalence rule applied to raw NaN, or **after** detection-limit masking? Different feature sets result. | `2026-09-03-filtered-pipeline...` Q4 | **ANSWERED 2026-09-03: before masking** — computed on `exclude_nonpositive(raw)` only. |
| C2a | Is the prevalence filter computed **before or after** sample exclusion? Filtering first keeps one feature panel shared across the T² variants; filtering after measures missingness on the analysed samples only. | `2026-09-03-filtered-pipeline...` Q4a | **ANSWERED 2026-09-03: before sample exclusion.** |
| C3 | Does removing high-missingness lipids **delete the signal**? If missingness is confounded with Bio group, a prevalence filter preferentially removes group-discriminating features. | `2026-09-03-filtered-pipeline...` Q5, `2026-08-31-missingness-overview...` | **REVIEWED 2026-09-03: no treatment-group missingness signal detected** (`p = 0.7788` in the exploratory per-sample Wilcoxon check; not a guarantee that no biological feature is removed). |
| C4 | `blank_multiplier = 3` and `absolute_floor = 1.0` are proposed defaults; 5× and 10× are equally standard conventions. | `2026-07-30-trace-level-detection-limit-preprocessing-plan.md` #1 | **PARTIALLY SETTLED** — `FEATURE_BLANK_MULTIPLIER = 3.0` is adopted in `analysis_config.py`; the floor position within the empty band remains a judgment call. |
| C5 | Should the feature-level contamination filter (drop lipids with median signal < 3–10× blank; 11–21 lipids) be adopted, separately from the value-level rule? | `2026-07-30-trace-level...` #3 | **PARTIALLY SETTLED** — the 3× feature rule is adopted; the 5×/10× variants are not evaluated. |
| C6 | Adopt the **QC CV filter** at all, and at what threshold? 30% is convention; 20% would remove 64% of the panel. | `2026-08-07-qc-feature-filters-plan.md` #2, #3 | **OPEN.** `APPLY_QC_CV_FILTER = False`; explicitly deferred until the filtered/unfiltered comparison is reviewed. |
| C7 | Missing-value handling if per-group n drops below threshold due to exclusions — currently "exclude, do not impute". | `2026-07-21-mia-vs-control-lipidomics-plan.md` | **OPEN**, though `MIN_PER_CELL = 3` now encodes the exclusion behaviour. |
| C8 | Is **per-sample median normalisation** adequate, or should **PQN** be used (supervisor review 2026-10-01)? With three regions, which PQN reference — per region, pooled, or Tech-Mix? | `2026-09-26-known-broken-fixes-plan.md` §4.9, D10–D11 | **OPEN — planned as a sensitivity arm.** Recommendation: per-region reference, all-60 arm. Exploratory: the extra PQN shift is ~0.05–0.08 log₂ per sample, so it is not expected to change any result. |

---

## D. QC, outliers and sample exclusion

| # | Question | Source | Status |
|---|---|---|---|
| D1 | Drop the flagged **sample**, the whole **mouse**, or the whole **litter**? | `2026-09-03-filtered-pipeline...` Q2a, `2026-08-05-outlier-policy...` | **ANSWERED 2026-09-03: sample level only.** |
| D2 | T² threshold at **95%** (5 samples) or **99%** (2 samples)? | `2026-09-03-filtered-pipeline...` Q2c | **ANSWERED 2026-09-03: 95%**, with 99% and no-exclusion retained as sibling variants. |
| D3 | All five T²-95 flagged samples are **Male**. Real sex-linked variance difference, or coincidence? Exclusion shifts the sex balance and weakens the interaction term. | `2026-09-03-filtered-pipeline...` Q2b | **OPEN as to cause; consequence RESOLVED 2026-09-07** (`doc/methodology.md` §4.1, §7.2). The cortex MIA-male cell drops 5 → 3, 15 lipids fail the min-cell rule, and the only two q<0.05 results in the project are created by the σ̂ shrinkage this exclusion causes. `prevalence20_noexclusion` is recommended as the reporting basis. |
| D4 | Minimum-replicate thresholds for the technical/biological variance split (4-of-6 Tech-Mix, 15-of-20 biological) are proposed defaults, not confirmed. | `2026-07-22-technical-vs-biological-variance-qc-plan.md` | **OPEN.** |
| D5 | Is per-region biological variance (rather than the all-60-pooled estimate) wanted? It changes the numbers from what was discussed in chat. | `2026-07-22-technical-vs-biological-variance-qc-plan.md` | **OPEN.** |
| D6 | Add the T²-vs-DModX ("influence") plot? `dmodx` already exists in `outlier_screen.py`. | `2026-08-07-pca-hotelling-ellipse-plan.md` #1 | **OPEN** — deliberately deferred to keep one figure per region. |
| D7 | How many PCs to **display and describe** in the descriptive PCA (separate from the screen's p = 3)? | `2026-08-05-outlier-policy...` #4 | **OPEN.** Showing 5 is harmless since nothing is estimated from a covariance. |
| D8 | Show **case/control together with region** in the pooled PCA, and beyond PC1–PC2 (supervisor review 2026-10-01)? Group-associated variance appears only on PC4, where cage/date dominate (metabolomics R² group 0.21 vs cage 0.70). | `2026-09-26-known-broken-fixes-plan.md` §4.8, D9 | **OPEN — planned.** Recommendation: composite figure with cage/date panels and an attribution heatmap. |

---

## E. Statistical modelling and multiple testing

| # | Question | Source | Status |
|---|---|---|---|
| E1 | Multiple-testing family for the **PERMANOVA** terms/regions — separate from the per-lipid FDR already fixed for differential abundance. | `2026-07-21-mia-vs-control-lipidomics-plan.md` | **OPEN — now material.** `permanova_multiplicity_note.csv` still records "not reported" while two terms sit at nominal p<0.05 (cerebellum Sex 0.033, hippocampus BioGroup 0.045), both present only in `t2_95` and reverting in `t2_99` — 2 of 9 unadjusted tests, the chance expectation. |
| E2 | Should PLS-DA use the **top-50 feature subset** or the full lipid panel? | `2026-08-05-outlier-policy...` #3 | **ANSWERED 2026-09-07: full panel, and now enforced in code.** Feature selection before a supervised projection is circular. The filtered pipeline emits only `full filtered panel after complete-case requirement` rows; the selection-biased `top50` rows (p = 0.004–0.014) are gone. Nothing survives permutation in any variant (best p = 0.052, hippocampus). Recorded in `doc/methodology.md` §7.2. |
| E3 | If a specification does produce FDR-significant lipids, check whether those lipids are ones whose values were largely **imputed** — an imputation artifact, not a hit. | `2026-08-07-imputation-and-specification-curve-plan.md` #1 | **STANDING RULE**, not a question. Moot so far: 0 hits across 144 specifications. |
| E4 | Include **class-level aggregation** as a fifth specification-curve axis? | `2026-08-07-imputation-and-specification-curve-plan.md` #2 | **ANSWERED: no** — it changes the unit of analysis rather than the preprocessing, and belongs in its own analysis. Now scheduled as `2026-09-03-filtered-pipeline...` §6.4 with its own multiple-testing family. |
| E5 | What explains the **depletion** of small p-values (42 features at p<0.01 against 397 expected, summed across 144 specs)? Inflated SEs from imputation, residual injection drift, or a few high-leverage samples? | `2026-09-03-filtered-pipeline...` §6.1 | **ANSWERED 2026-09-07: none of the above — it is the panel's correlation structure.** Against the permutation null rather than a uniform one, every Region × Effect family lies within 1.4 SD of its null mean (\|z\| ≤ 1.31 in all three variants); the permutation null itself yields 23–56 nominal discoveries against ~47 expected, SD 13–53. `m_eff` is 16–135 per family against a nominal 964 and is now recorded in `05_diagnostics/multiple_testing_caveat.csv`. A small-p deficit or excess is not evidence on its own. See `doc/methodology.md` §7.2. |
| E6 | **MIA composite panel inference:** one primary composite (myelin index, hippocampus) with the rest as estimation, or a Holm/BH family? Cage-level permutation p ≥ 0.036 means no more than one hypothesis can pass a permutation-calibrated threshold. Panel membership (C1–C8) to be confirmed against full-text literature before freezing. | `2026-10-05-biology-in-the-data-plan.md` §4.4, D5–D7 | **OPEN — planned.** Recommendation: single primary, two-stage label-blind freeze. **Note 2026-10-12: the panel was computed unblinded in an exploratory run (`2026-10-12-effect-size-estimation-evaluation.md`); a blind run on this cohort is no longer possible.** |
| E7 | **ASCA (multivariate Region × Group × Sex) — design choices before implementation:** Python ASCA+ vs ALASCA (R, no permutation tests); complete features vs imputation; autoscale vs unscaled; keep Sex; cage-level exact permutation (28, floor 0.036) as primary for Group and Region × Group; T²-95/T²-99 as sensitivity; mouse-bootstrap loading intervals; explorer tab later; skip date-subset sensitivity. | `2026-10-08-asca-region-group-plan.md` D1–D9 | **OPEN** — recommendations: D1(c) D2(a) D3(a) D4(a) D5(a) D6(a) D7(a) D8(a) D9(a). |
| E8 | **Multi-omics integration (lipidomics + metabolomics + proteomics), three options:** MOFA+ on all samples (label-free), DIABLO supervised on region on all samples, and a control-only reference model with MIA projected (primary MIA test); packages mofapy2, mixOmics, FactoMineR. Decisions D1–D10: proteomics run structure, imputed values, feature sets, DIABLO design weight, MOFA implementation, Option 3 distance, cage-level inference, populations, R dependency fix (Deriv), order of work. | `2026-10-11-multiomics-integration-plan.md` D1–D10 | **CONFIRMED 2026-10-11:** D1 ask first (A12), D2(c), D3(a), D4(a), D5(a), D6(a), D7(a), **D8 all 60 only (no T² arms)**, D9(a), D10(a). See the plan's "Confirmed decisions". |
| E9 | **Effect-size reading of the MIA contrast (exploratory, 2026-10-12):** report estimates, ruled-out effect sizes and robustness instead of p-values. Hippocampus myelin (lipid C1 0.86×, myelin proteins −0.48 SD) matches Makinodan 2008 but is one signal measured twice and is carried by litters from dates without controls. | `2026-10-12-effect-size-estimation-evaluation.md` D1–D3 | **OPEN — D1 (declare C1–C8 unblinded) recommended.** |
| E10 | **Exploratory integration (revision 2):** within-region multi-group MOFA+ with per-region replication (WP1), cross-omics association screen on lipid summary features with modules (WP2), GO/Reactome and lipid-category enrichment (WP3), covariate map with MIA as one row (WP4), known-answer benchmark and cross-omics predictability (WP5); finding rules fixed in §4.6. Decisions D1–D10. | `2026-10-12-integration-extensions-plan.md` §7–8 | **IMPLEMENTED WITH CORRECTIONS 2026-10-13.** Bugs 1–4 and the top-5%/10% enrichment cutoff were corrected. R MFA/mixOmics, DIABLO, spike-ins, LOLO, MOFA shared-factor null, enzyme-product controls, and lipid-category enrichment remain deferred. |

---

## F. Annotation and databases

| # | Question | Source | Status |
|---|---|---|---|
| F1 | Plain-string matching vs **Goslin** normalization for lipid-name mapping? | `2026-07-30-lipid-database-annotation-plan.md` #1 | **OPEN** — decide after seeing the initial match rate, not before. |
| F2 | Rate-limiting/backoff parameters for the ~987 LIPID MAPS queries and follow-on KEGG queries. | same, #2 | **OPEN** — a reasonable default at implementation time. |
| F3 | Should `kegg_pathways` store pathway IDs, names, or both? | same, #3 | **OPEN** — leaning both. |

---

## G. Implementation and dependencies

| # | Question | Source | Status |
|---|---|---|---|
| G1 | **PERMANOVA implementation**: hand-written sequential-SS + blocked permutation on scipy/numpy, or add a dependency (e.g. `scikit-bio`)? `scikit-bio`'s `permanova` supports only one-way grouping, so the multi-term/blocked logic must be hand-written either way. Requires sign-off per `AGENTS.md` before any `requirements.txt` change. | `2026-07-21-mia-vs-control-lipidomics-plan.md` | **OPEN.** |
| G2 | PLS-DA in Python (scikit-learn + manual permutation) or R (`ropls`)? | `2026-07-30-reproduce-lipidomics-figures-plan.md` #1 | **OPEN** — leaning Python. |
| G3 | Heatmap clustering distance/linkage (proposed Euclidean/Ward) — a default, not verified against anything. | same, #2 | **OPEN.** |
| G4 | Should the candidate-annotation step retroactively flag rows in `differential_effects.csv` / `permanova_by_region.csv` in place, or stay a separate join done fresh in the notebook? | `2026-07-22-technical-vs-biological-variance-qc-plan.md` | **OPEN.** |
| G5 | Notebook placement for the figure-reproduction work (new section vs new notebook). | `2026-07-30-reproduce-lipidomics-figures-plan.md` #4 | **OPEN.** |
| G6 | `permutation_null_feature_statistics.csv` has **no `Region` column**, so its three regions are stacked unlabelled and 5,643 of 8,526 rows share a `Feature`+`Effect` key. It cannot be joined to `differential_effects.csv`. | evaluation 2026-09-07 | **OPEN — defect.** Fix before the empirical p-values are used anywhere. Plan proposed 2026-09-26: `2026-09-26-known-broken-fixes-plan.md` §4.4 (add `Region`, assert unique key). |
| G7 | The same file carries two FDR columns, `p_value_empirical_fdr` and `empirical_null_fdr`, disagreeing by ~100× on the same row (0.62 vs 0.006 for Cer(m22:0) cortex sex), with no note on which is authoritative. | evaluation 2026-09-07 | **OPEN — defect.** Document the definition of each, or drop one. Plan proposed 2026-09-26: `2026-09-26-known-broken-fixes-plan.md` §4.4, decision D6. |
| G8 | **999 permutations floors the empirical p-value at 0.001**, so empirical BH cannot reach q<0.10 over a ~950-lipid panel regardless of the data. What count is wanted — 10,000? | evaluation 2026-09-07 | **OPEN.** Until raised, `p_value_empirical_fdr` is uninformative rather than a null result. Plan proposed 2026-09-26: `2026-09-26-known-broken-fixes-plan.md` §4.4, decision D6. |
| G9 | `results/pipeline_test/` is stamped at commit `e16efa7`, six commits behind HEAD, and the package refactor moved the runner that produced it. Re-run one variant under the current layout and diff before using these outputs. | evaluation 2026-09-07 | **OPEN — reproducibility.** Plan proposed 2026-09-26: `2026-09-26-known-broken-fixes-plan.md` §4.5, decision D7. |
| G10 | The **noisyR cross-check returns unusable results** — a failure written as `0.0`, NA propagation voiding 2 of 4 curves, and a non-monotone curve that makes the 0.25 first-crossing rule return the bottom of the abundance range. Diagnosed and an ordered repair proposed. | `2026-09-07-noisyr-diagnosis-and-repair-plan.md` | **DIAGNOSED 2026-09-07; repair PROPOSED, not authorized.** |
| G11 | Does the repaired noisyR cross-check regenerate `results/mia_vs_control/02_qc/` in place (with `git rm` of superseded files) or write to a sibling variant path? | `2026-09-07-noisyr-diagnosis-and-repair-plan.md` §6 | **OPEN — blocks implementation of G10.** |
| G12 | noisyR's NA handling was inferred by simulation, not read from `calculate_expression_similarity_counts`; no R runtime was available. Confirm against the package source before implementing the pairwise-correlation fix. | `2026-09-07-noisyr-diagnosis-and-repair-plan.md` §7 | **OPEN — verification.** |
| G13 | Remove `OUTLIER_MOUSE` and the `run_abundance_similarity` 57-sample arm entirely, or keep the constant as a historical label? | `2026-09-26-known-broken-fixes-plan.md` D2 | **OPEN** - recommendation: remove. |
| G14 | Existing 57-sample result trees (`mia_vs_control/00_inputs`...`08_cage_structure`, specification curve, feature-PCA `primary`): regenerate in place with `git rm` when re-run, archive now, or leave until re-run? | `2026-09-26-known-broken-fixes-plan.md` D3 | **OPEN** - recommendation: regenerate in place when re-run. |
| G15 | Disattenuation bootstrap settings: inner split-halves per resample (40 / 100 / 200) and reliability definition (pipeline mean-of-Spearman-Brown vs reference Spearman-Brown-of-mean-r). | `2026-09-26-known-broken-fixes-plan.md` D4 | **OPEN** - recommendation: 1,000 x 100, pipeline definition. |
| G16 | Add a T2-99 arm (`prevalence20_hotelling99`) to the region-persistence runner? | `2026-09-26-known-broken-fixes-plan.md` D5 | **DONE** - arm in the runner (2026-10-01 regeneration); its outputs were completed 2026-10-07 (`prompts/2026-10-07-region-persistence-t2-99-completion-v1.md`). |
| G17 | Where does the G9 re-run write: sibling `results/pipeline_test_rerun/` then diff, or overwrite `results/pipeline_test/` in place? | `2026-09-26-known-broken-fixes-plan.md` D7 | **OPEN** - recommendation: sibling tree. |
| G18 | Commit `requirements-lock.txt` and `renv.lock` on the fixes branch or a separate branch? | `2026-09-26-known-broken-fixes-plan.md` D8 | **OPEN** - recommendation: fixes branch, own commit. |
| G19 | **DIABLO train/test centring mismatch:** `R/integration/run_diablo.R` trains on within-mouse-centred blocks (`withinVariation`) but predicts uncentred test and full-fit data; region accuracy 0.60 CV and 44/60 on training data. `loadings.csv` is written empty. Option 3 uses the same fitting code, so its MIA distances are also invalid. | `2026-10-12-integration-extensions-plan.md` §4.0 | **OPEN — known broken; fix before reading any DIABLO or Option-3 output.** |

---

## H. Presentation and thesis scope

| # | Question | Source | Status |
|---|---|---|---|
| H1 | Does the rigor-added figure tier belong in the thesis body or an appendix, next to or instead of the faithful tier? | `2026-07-30-reproduce-lipidomics-figures-plan.md` #3 | **OPEN** — presentation decision, not a methods one. |
| H2 | Does the full-data PCA/T² ellipse version belong in the thesis or only in the vendor discussion? | `2026-08-07-pca-hotelling-ellipse-plan.md` #2 | **OPEN** — presentation decision. |
| H3 | Which run is the **primary** analysis once the pipeline-test variants exist? | `2026-09-03-filtered-pipeline...` Q7 | **ANSWERED 2026-09-03: existing `results/mia_vs_control/` remains primary; filtered variants are sensitivity analyses.** |
| H4 | **Interactive explorer app (PyShiny):** which dependencies (shiny, shinywidgets, plotly), whether to run the metabolomics all-60 variant first so the default view is saved output, how to treat manual whole-mouse removal, and whether to host it next to the colleague's proteomics app. | `2026-10-07-pyshiny-explorer-app-plan.md` D1–D9 | **IMPLEMENTED 2026-10-07** as read from the code: D1 pinned deps; D3 prepared differential-only metabolomics snapshot; D6 warn-banner; D7 local. See `prompts/2026-10-07-pyshiny-explorer-implementation-v1.md`. Hosting (D7b) still open. |

---

## Resolved — kept for the record

- **Imputation (supervisor question 2026-10-01): none in the primary analysis.** Random Forest on all missing cells was one of four specification-curve arms, and it is invalid for the ~85% of missing cells that are left-censored (MNAR). No arm produced a hit. The all-60 re-run of the specification curve keeps all four arms. See `2026-09-26-known-broken-fixes-plan.md` §4.10.
- **Number of PCs for the outlier screen: 3**, for both T² and robust Mahalanobis (`2026-08-05-outlier-policy...`, now `OUTLIER_SCREEN_PCS = 3`).
- **What happens to flagged samples: report first, then a fixed explicit list** (`2026-08-05-outlier-policy...`).
- **Analysis population: all 60 samples**; mouse `C00431239 - 3` no longer excluded (`2026-08-07-full-data-policy-change.md`). Note: the pipeline-test T² exclusion supersedes this for that variant only, and the document's claim that "Hotelling's T² flagged nothing at 95%" holds for the 10-PC screen it describes but **not** for the adopted 3-PC screen. **Discrepancy found 2026-09-07:** `results/mia_vs_control/00_inputs/differential_input_metadata.csv` still holds **57 rows from 19 mice** with `C00431239 - 3` absent, so the primary differential outputs do not reflect this policy change. Either the change was scoped to the QC/PCA figures only, or the primary needs regenerating — worth settling before the two analyses are described side by side.
- **Figure conditions: generate only A and B** (12 figures), since C and D are byte-identical while `SAMPLE_OUTLIER_EXCLUSIONS` is empty (`2026-08-05-outlier-policy...` #1).
- **Cross-modality concordance rule fixed before looking**: same statistic, same region, both modalities; report expected count under independence (≈0.15) alongside observed (`2026-08-26-cross-modality...` A4).
- **Unmapped/ambiguous lipids**: every annotation row carries `mapping_status` ∈ {`matched`, `unmapped`, `ambiguous`}; never silently dropped or inferred (`2026-07-30-lipid-database-annotation-plan.md`).
