# Analysis state — read this first

**As of 2026-10-13.** One-page entry point for any new session or tool. The
reasoning behind each line is in `doc/context/`; the full method write-up is
`doc/methodology.md`; open questions are indexed in `doc/open-questions.md`.
Update this file whenever a line below stops being true.

---

## The study in five lines

- MIA vs saline control, P14 offspring brain; 20 mice (10/10, sex-balanced),
  3 regions each (cerebellum, cortex, hippocampus) → **60 samples**.
- Lipidomics: 964 features after the prevalence-20 filter. Metabolomics: 246
  features (sibling worktree `metabolomics-pipeline`).
- Experimental unit is the **cage = dam + litter**: 2 control cages (6, 4
  pups) vs 6 MIA cages (3, 3, 1, 1, 1, 1).
- Collection date is partly confounded with treatment; only 2024-06-11 has
  both groups. All samples were processed in one batch (2025-02-17).
- Framed as a **multi-omics methods thesis**, with this dataset as a
  calibration substrate (region = positive control, MIA = negative control).

Sample numbers map to mouse, region, sex, group, cage and collection date in
`results/mia_vs_control/09_region_persistence/prevalence20_noexclusion/lipidomics/00_inputs/region_input_metadata.csv`
(all 60) and, at source, `data/Samples for metabolomics.xlsx`.

## Permitted populations — binding

**All 60 samples, or sample-level removal of Hotelling T² > 95% or > 99%
flags. Never whole-mouse removal. The 57-sample population is dismissed.**
`results/mia_vs_control/00_inputs/` is still the 57-sample tree because
`src/lpj_lipidomics/io/study_design.py` filters `OUTLIER_MOUSE` — do not use
it or anything built on it. → `doc/context/population-rule.md`

## Settled

| Finding | Where |
|---|---|
| No robust MIA effect in lipidomics or metabolomics. All 60 has one fragile hit — ChE(22:4) cortex MIA, q = 0.045 — which goes to q = 0.48 when the two flagged MIA-male cortex samples are removed; report it as fragile, not as a finding | `context/pipeline-test-evaluation.md` |
| The q<0.05 results that appear only under T² exclusion (Cer(m22:0) cortex Sex/interaction) are σ̂-shrinkage artifacts; do not report | same |
| Honest framing is power: MDE 1.8–2.3× (sample), 2.5–3.5× (cage) | same |
| Effective tests m_eff 16–135 vs nominal 964; small-p depletion is ordinary against the permutation null | `context/design-constraints.md` |
| Region signature not detectably altered by MIA (all 60, corrected intervals): Cx−Cb 1.03 [0.93, 1.08], Hp−Cb 0.88 [0.71, 1.03] | `context/region-persistence.md` |
| Per-feature region × treatment interaction: 0 at q<0.05, both modalities | same |
| Cross-group significance counts (Cx−Hp 152 vs 6) are a threshold artifact | same |
| Co-abundance modules real (z ≈ +180) but not reproducible at n ≈ 20; Cx/Hp modules mostly technical | `context/feature-pca.md` |
| noisyR's assumption inverts on shared-background LC-MS; repaired threshold ≈ 16–17 log2 | `context/noisyr.md` |
| Pooled or group-stratified outlier screens are wrong for the region design; the label-blind difference-space screen with attribution is the proposed alternative (decision doc not yet written) | `context/outlier-screening.md` |

"Settled" means the conclusion is not expected to change. Several rest on
inputs with fixes pending (below): the region-persistence intervals come from
an exploratory reference implementation, and the lipidomics null rests on
`results/pipeline_test/`, which predates the refactor. Re-check the numbers
after those re-runs.

## Open

| Question | Status |
|---|---|
| Cx−Hp concordance: all 60 1.10 [0.26, 4.67] (profile reliability low: ctl 0.47, MIA 0.26) | Unresolved; interval includes 1. T² values currently come from whole-mouse drops and must be redone with contrast-specific pairing |
| A1a — is one cage exactly one dam? | Email to animal-work owner |
| A4 — shared extraction across modalities? | Email; blocks any concordance claim |
| A8 — why is collection date treatment-split? | Email |
| Is proteomics coming? | Unknown |
| Cage-aware sensitivity (`08_cage_structure/`) | Ran on 57 samples → must be re-run on 60, then evaluated |
| Second supervisor review (2026-10-01): pooled PCA with case/control, PQN normalisation, imputation | Planned in `decisions/2026-09-26-known-broken-fixes-plan.md` §4.8–4.10 (D9–D11); register A9, C8, D8 |

## Known broken — fix before relying on

1. `study_design.py` still produces the 57-sample tree (above). Downstream
   of it: `doc/methodology.md` §1 still describes 57 samples as the primary
   population; the specification curve (§7.1, 144 results, min q 0.130), the
   feature-PCA `primary` run and `08_cage_structure/` all ran on 57. Their
   conclusions are unlikely to flip, but none can be quoted as an all-60
   result until re-run.
2. `region_contrast.py::disattenuated_concordance` bootstrap is biased
   downward — reliability must be recomputed inside each resample with
   id-aware split-halves. Re-run both modalities after the fix.
3. Region-persistence pairing requires all three regions per mouse, so a
   flagged sample drops the whole mouse. Needs contrast-specific pairs.
4. `permutation_null_feature_statistics.csv` has no Region column; two FDR
   columns disagree ~100× (G6, G7). 999 permutations floor empirical p (G8).
5. `results/pipeline_test/` predates the package refactor (G9).
6. `doc/project_summary.md` is stale (describes the 57-sample exclusion);
   marked superseded.
7. **Dependencies are not pinned.** `requirements.txt` lists names without
   versions; there is no `renv.lock` (and `renv/` is gitignored). A new
   environment will not reproduce current results exactly. Fix in WSL:
   `/root/.virtualenvs/LPJ_lipidomics/bin/python -m pip freeze > requirements-lock.txt`
   and `Rscript -e 'renv::snapshot()'`, then commit both.

## Next steps, in order

1. Fix items 1–3 above; re-run `09_region_persistence` for both modalities
   on all 60, T²-99 and T²-95 with contrast-specific pairing. Write the
   decision doc for the difference-space screen; add it as a fourth arm only
   once confirmed.
   *Status 2026-10-07:* the 2026-10-01 regeneration (contrast-specific
   pairing) wrote all 60 and T²-95 and stopped during T²-99; T²-99 was
   completed for both modalities with the same code and locked environment
   (`09_region_persistence/prevalence20_hotelling99/provenance.json`), and
   `regression_checks.csv` passes 51/51. All three populations agree: every
   disattenuated-concordance interval includes 1 and no per-feature
   interaction reaches q < 0.05.
2. Regenerate figure 1 (disattenuated concordance) with corrected intervals;
   fold the four region-persistence figures into the pipeline.
3. Re-run `08_cage_structure` on 60 samples and evaluate.
4. Send the A1a / A4 / A8 emails.
5. Integration-as-negative-control study (2–3 methods, permutation-validated).
6. Power-and-design deliverable. Hold GRN work.
7. Biology in the data (PROPOSED `decisions/2026-10-05-biology-in-the-data-plan.md`): P14 regional lipid architecture; sex structure separated from cage; pre-registered MIA composite panel (two-stage, single primary). After fixes items 1 and 3.
8. Interactive explorer app — IMPLEMENTED in `app/` (`shiny run app/app.py`; see `app/README.md`). Re-run the app tests in the WSL venv and commit. All three region-persistence populations now have saved runs (T²-99 completed 2026-10-07). Includes a Sensitivity grid tab (filters × normalization × outlier rules, 504 lipidomics combinations): build once with `python -m app.build_multiverse`.
9. ASCA (PROPOSED `decisions/2026-10-08-asca-region-group-plan.md`): one multivariate test of Region × Group (× Sex) with cage-level exact permutation for group effects; region as positive control. Decisions D1–D9 (register E7) open.
10. Multi-omics integration (CONFIRMED 2026-10-11, all 60 only; `decisions/2026-10-11-multiomics-integration-plan.md`): proteomics now in `data/` (3 per-region Perseus matrices, 3,821 shared proteins, already imputed). Region-anchored integration in three forms — MOFA+ label-free, DIABLO on region, and a control-only reference with MIA projected (primary MIA test). Replaces the control-only network/GRN idea, which is not identifiable at 10 control mice from 2 litters. Region-anchored fits wait on register A12 (proteomics run structure); input building and marker checks can start.
11. Effect-size estimation (EXPLORATORY, run 2026-10-12; `decisions/2026-10-12-effect-size-estimation-evaluation.md`, `results/mia_vs_control/15_effect_sizes/`): no brain-wide MIA signature; most lipids can be ruled out above 2×. Hippocampus myelin (lipid C1 0.86×, myelin proteins −0.48 SD) fits Makinodan 2008 but lipid and protein scores are one signal (r ≈ 0.86) and it is carried by litters from dates without controls. The C1–C8 panel is now unblinded (E6, E9). Ask A13.
12. Exploratory integration (Python scope implemented with corrections 2026-10-13, `decisions/2026-10-12-integration-extensions-plan.md`, register E10): factor recovery now requires `|r| >= 0.8`, oligodendrocyte scores are region-standardized, predictability uses fold-local PCA with pooled out-of-fold R², and modules use correlation distance. R MFA/mixOmics, DIABLO, spike-ins, LOLO, the MOFA shared-factor null, enzyme-product controls, and lipid-category enrichment remain deferred.

## Uncommitted work at time of writing

Region-persistence plan, runner, `region_contrast.py`, tests and results;
feature-PCA results; meeting decks; `doc/open-questions.md` edits; this file,
`doc/context/`, and four new skills staged in `skills-to-install/` (move
them into `.claude/skills/`; instructions in its README). See `git status`.

## How to work here

`doc/context/working-conventions.md` — read order, which project skill for
which task, plans before code, provenance, and the scientific habits this
project depends on.
