


## Initial Questions: 

We have 20 samples (10 control vs 10 MIA) and /* 3 regions per sample (60). 
Are regions significantly different from each other ? 
	-Should they be looked at separately / together? 
What are sex differences? 

How much does control /MIA drive the variation between samples? 
	- What are the underlying lipids that are significantly different between control and MIE (and because of control vs MIE) ?
	- Are there any lipids significantly different between any brain regions? 

