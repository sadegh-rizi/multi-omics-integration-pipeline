# AGENTS.md

Guidance for AI coding agents working in this repository. This file applies to Codex/GPT-style agents. Claude Code should also read `CLAUDE.md` and `doc/agent-rules.md`.

## Project overview

This repository contains lipidomics analysis materials for the LPJ project. The current codebase is notebook-oriented and uses Python for data analysis and visualization.

Relevant files and directories:

- `notebooks/`: exploratory and analysis notebooks.
- `data/`: source workbooks and report files. Treat these as immutable research inputs unless the user explicitly requests a change.
- `doc/Analysis plan.docx`: exploratory analysis context; it is not permission to change methods without explaining the rationale.
- `doc/agent-rules.md`: canonical shared rules for scientific validity, data handling, statistics, plotting, and verification.
- `requirements.txt`: Python package requirements.

## Instruction priority

1. Follow the user's explicit request.
2. Follow this file and `doc/agent-rules.md`.
3. Preserve the current analysis and data unless a requested change requires otherwise.

When instructions conflict or scientific intent is unclear, stop and state the ambiguity rather than silently choosing a biological or statistical method.

## Planning before implementation

Before writing, editing, or running any code — notebook cells, modules, scripts, or dependency changes — write a short plan: the files you will touch, the approach, and the validation command(s). List every open design, statistical, or biological question implied by the task and ask the user directly; do not silently choose a default for an ambiguous decision. Wait for explicit confirmation of the plan before making any edit. Apply this regardless of how small the change looks; skip it only for the user's own direct, fully-specified one-line instructions.

## Environment setup (WSL2)

**Python interpreter — do not go looking for it.** The project environment is:

```
/root/.virtualenvs/LPJ_lipidomics/bin/python
```

Use that absolute path directly. Do not search `/root`, `/home`, `/opt`,
`~/.conda/envs`, `~/micromamba/envs`, or `~/.config/JetBrains` to rediscover it —
that search has been run and this is the answer. If the path does not exist,
say so and stop rather than hunting for an alternative.

Known state of that environment (verified 2026-08-05): `numpy`, `pandas`,
`scipy`, `matplotlib`, `openpyxl`, `pytest`, `statsmodels` are installed;
`sklearn`, `nbformat`, `nbclient` were **not**. Check before assuming, and ask
before installing.

**R** is installed system-wide in WSL2 and used only for
`src/differential_moderated.R` (limma). Dependencies are pinned with `renv`.
If `Rscript` prints `The project is out-of-sync -- use renv::status() for
details`, that warning repeats on every single call and adds up; resolve it once
with `renv::status()` / `renv::restore()` rather than tolerating it per-invocation.

Do not create, rebuild, upgrade, or change any environment or dependency unless
asked. Do not use the Windows activation command (`.venv\\Scripts\\Activate.ps1`)
from WSL.

## Development workflow

- Prefer small, reviewable changes with one stated purpose.
- Before modifying code, inspect the relevant notebook cells, metadata, and input schema. Do not infer column meanings from names alone.
- Preserve existing notebooks and data unless a requested change requires editing them.
- If adding reusable analysis code, place it in a Python module rather than duplicating logic across notebooks.
- Keep paths portable; use `pathlib.Path` and project-relative paths rather than hard-coded Windows or WSL absolute paths.
- Do not add a dependency merely because an agent prefers it. Explain the need and ask before changing `requirements.txt`.

## Context efficiency

Context is a finite, paid resource. These rules come from auditing a real
session that spent roughly a third of its budget on avoidable re-reading.

- **Never `read` a whole `.ipynb`.** Notebooks are JSON with embedded outputs
  (including base64 images), so a full read is enormous and mostly noise. Use
  `grep` to locate the cell, or extract just the sources:
  `python -c "import json,sys; [print(''.join(c['source'])) for c in json.load(open(sys.argv[1]))['cells']]" nb.ipynb`.
  In one audited session a single notebook was read 10 times for ~1,700 lines.
- **Do not read back a file you just wrote or patched.** The write already
  succeeded or errored; re-reading confirms nothing.
- **Check whether a file is already in context before reading it again.**
  Re-read only if it changed since.
- **Batch discovery.** One `glob`/`ls` per directory, not four consecutive calls
  on the same path. Prefer `grep` with a targeted pattern over reading a file to
  find one line.
- **Keep skills small and project-specific.** A skill is loaded in full every
  time it triggers. Do not put general library/API tutorials in a skill — the
  model already knows those. Project rules, conventions, and non-obvious local
  gotchas only. (The `publication-plot` skill previously carried ~810 lines of
  matplotlib/seaborn/plotly tutorial and cost ~8% of a session's context per
  trigger.)
- Prefer `head`/`tail`/`sed -n 'A,Bp'` over reading large files whole when only a
  region is needed.

## Working with notebooks

- Minimize noisy notebook diffs.
- Do not clear, regenerate, or bulk-edit notebook outputs unless asked.
- If changing notebook logic, make the smallest targeted edit and report whether the notebook was executed.
- Before execution, confirm that the required source files exist and that execution will not overwrite data or prior results.
- Move repeated or testable logic into modules once it is used more than once; notebooks should orchestrate, inspect, and visualize.

## Data handling and scientific integrity

- Never delete, rename, overwrite, normalize in place, or resave files in `data/` without explicit approval.
- Keep source, interim, and derived results distinct. Write new derived outputs to a clearly named results/output location only when requested.
- Do not send raw research data, participant identifiers, credentials, or confidential workbook contents to external services unless the user explicitly authorizes it and institutional policy permits it.
- Read `doc/agent-rules.md` before changing preprocessing, normalization, imputation, statistical testing, multivariate modelling, pathway analysis, or figures.

## Verification

Before handing off changes, run the narrowest useful check available and report the real result:

- For Python modules/scripts: run a relevant import, targeted script, or test.
- For notebooks: execute only when necessary and feasible; otherwise inspect the changed cells and say execution was not run.
- For dependency changes: confirm `python -m pip install -r requirements.txt` remains valid if practical.
- For statistical or biological changes: state assumptions, the unit of observation, and residual risks; do not claim scientific validity merely because code runs.

If verification cannot be run, explain why and name the residual risk.

## Git workflow

- Start every task on a new branch: `task/<short-name>`. Never work on main.
- Verify the tree is clean before starting; stop and report if it isn't.
- Check `git status --short` before and after edits.
- Do not discard, stage, commit, push, or reformat the user's unrelated changes unless explicitly asked.
- Never modify files in `.idea/`, `data/`, `doc/`, `notebooks/`, or `.skills/` outside the requested scope.
- Commit each generation event separately, with trailers:
  ```
  Prompt: prompts/<file>.md
  Model: <model-version>
  ```
  See `prompts/README.md` for the prompt file naming convention and `.claude/skills/ai-provenance/SKILL.md` for the full provenance scheme. A prompt alone cannot reconstruct generated code later, since regenerating from the same prompt is not deterministic.
- Results and data files may be committed, but ask the user for explicit confirmation before each such commit.
- Never `git add .` — stage named files only. No secrets.
- Never: push, force-push, rebase shared branches, `reset --hard`, `clean -fd`, squash.
- Merging and pushing are done by the human. Stop after committing.

<!-- CODEGRAPH_START -->
## CodeGraph

In repositories indexed by CodeGraph (a `.codegraph/` directory exists at the repo root), reach for it BEFORE grep/find or reading files when you need to understand or locate code:

- **MCP tool** (when available): `codegraph_explore` answers most code questions in one call — the relevant symbols' verbatim source plus the call paths between them, including dynamic-dispatch hops grep can't follow. Name a file or symbol in the query to read its current line-numbered source. If it's listed but deferred, load it by name via tool search.
- **Shell** (always works): `codegraph explore "<symbol names or question>"` prints the same output.

If there is no `.codegraph/` directory, skip CodeGraph entirely — indexing is the user's decision.
<!-- CODEGRAPH_END -->
