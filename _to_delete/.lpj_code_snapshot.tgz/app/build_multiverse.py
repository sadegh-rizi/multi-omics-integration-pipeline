"""Precompute the filter × normalization × outlier-rule grid BEFORE launching the app.

Run from the repository root:  python -m app.build_multiverse [--modality lipidomics|metabolomics]

Writes results/explorer_prepared/multiverse/<modality>/:
  combinations.csv   one row per combination (settings, samples removed, n features, min cell)
  summary.csv        per combination × region × effect: n tested, n q≤0.05/0.10, n p≤0.05, min q
  effects.npz        float32 values[combination, feature, region, effect, stat] for estimate, SE, p, q
  outlier_rules.csv  the samples each rule removed at build time
  run_manifest.json, provenance.json

Refuses to overwrite an existing grid (move it aside to rebuild). The npz is
regenerable and is listed in .gitignore; the CSVs and JSON are small.
"""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

import numpy as np
import pandas as pd

from app import ROOT, multiverse, registry


def build(modality: str) -> Path:
    output = multiverse.GRID_ROOT / modality
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Refusing to overwrite {output}; move it aside to rebuild.")
    output.mkdir(parents=True, exist_ok=True)
    started = time.time()
    combos = multiverse.combinations(modality)
    names = multiverse.build_annotations(modality)
    universe = names["Feature"].astype(str).tolist()
    index = {feature: i for i, feature in enumerate(universe)}
    regions, effects = list(registry.REGIONS), list(registry.EFFECTS)
    values = np.full((len(combos), len(universe), len(regions), len(effects), len(multiverse.STATS)), np.nan, dtype=np.float32)
    rows, summaries = [], []
    for c, combination in enumerate(combos):
        fitted, info = multiverse.fit(combination)
        rows.append({**info, "label": combination.label(), "is_primary": combination.is_primary,
                     **{axis: getattr(combination, axis) for axis in multiverse.AXES}})
        summaries.append(multiverse.summarize(fitted, combination.key))
        if fitted.empty:
            continue
        f = fitted["Feature"].astype(str).map(index).to_numpy()
        r = fitted["Region"].map({name: i for i, name in enumerate(regions)}).to_numpy()
        e = fitted["Effect"].map({name: i for i, name in enumerate(effects)}).to_numpy()
        for s, stat in enumerate(multiverse.STATS):
            values[c, f, r, e, s] = fitted[stat].to_numpy(dtype=np.float32)
        print(f"[{c + 1}/{len(combos)}] {combination.key}: {info['n_samples']} samples, {info['n_features']} features")
    pd.DataFrame(rows).to_csv(output / "combinations.csv", index=False)
    pd.concat(summaries, ignore_index=True).to_csv(output / "summary.csv", index=False)
    multiverse.rule_table(modality).to_csv(output / "outlier_rules.csv", index=False)
    np.savez_compressed(output / "effects.npz", values=values, features=np.array(universe), regions=np.array(regions),
                        effects=np.array(effects), stats=np.array(multiverse.STATS),
                        names=np.array(names["Name"].fillna(names["Feature"]).astype(str).tolist(), dtype=str),
                        classes=np.array(names["Class / method"].fillna("").astype(str).tolist(), dtype=str))
    manifest = {
        "analysis": "explorer sensitivity grid (multiverse); descriptive robustness display, not a new primary analysis",
        "modality": modality, "n_combinations": len(combos), "primary": multiverse.PRIMARY if modality == "lipidomics" else {"outliers": "none"},
        "axes": {axis: {key: label for key, (label, _) in options.items()} if axis != "outliers" else options
                 for axis, options in multiverse.AXES.items()} if modality == "lipidomics" else {"outliers": multiverse.OUTLIERS},
        "model": "OLS BioGroup × Sex per region (vectorized path tested equal to fit_regionwise_differential); BH over retained panel within Region × Effect; min 3 per cell",
        "preprocessing_order": multiverse.__doc__.split("\n\n")[1].strip() if modality == "lipidomics" else "saved all-60 metabolomics matrix; samples removed only",
        "imputation": "none", "outlier_rules": "sample-level, label-blind; never whole-mouse by design (flagged if it occurs)",
        "seconds": round(time.time() - started, 1),
    }
    sources = [multiverse.ENSEMBLE, *(ROOT / "results/mia_vs_control/02_qc" / f"outlier_screen_{r.lower()}.csv" for r in registry.REGIONS)]
    sources += [multiverse.RAW_WORKBOOK, multiverse.CAGE_WORKBOOK] if modality == "lipidomics" else [
        registry.source("metabolomics", "all60", kind) for kind in ("matrix", "metadata")]
    code = [Path(multiverse.__file__), Path(__file__), ROOT / "src/lpj_lipidomics/preprocessing.py",
            ROOT / "src/lpj_lipidomics/statistics/permutation.py"]
    try:
        commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, stderr=subprocess.DEVNULL).strip()
        dirty = bool(subprocess.check_output(["git", "status", "--porcelain", "--", "src", "app"], cwd=ROOT, text=True, stderr=subprocess.DEVNULL).strip())
    except (OSError, subprocess.CalledProcessError):
        commit, dirty = "unrecorded", "unrecorded"
    provenance = {
        "git_commit": commit, "working_tree_source_diff": dirty,
        "sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [*sources, *code]},
        "prompt": "prompts/2026-10-07-explorer-multiverse-implementation-v1.md",
        "model": "claude-opus-5-5",
    }
    (output / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=str) + "\n")
    (output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--modality", choices=registry.MODALITIES, action="append")
    for modality in parser.parse_args().modality or list(registry.MODALITIES):
        print(build(modality))
