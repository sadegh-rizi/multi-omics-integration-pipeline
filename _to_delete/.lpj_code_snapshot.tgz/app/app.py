"""Run locally from the repository root: shiny run app/app.py."""

import os
from pathlib import Path
import sys
import tempfile

# Shiny executes this entry point as a file; make the adjacent app package and
# canonical src package importable without modifying the user's environment.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
# The Shiny CLI imports this file as `app`, while tests import `app.app`.
# In the CLI case expose its directory as the package search path as well.
if __name__ == "app":
    __path__ = [str(ROOT / "app")]
# Service accounts (Shiny Server's `shiny` user) often have no writable home;
# give matplotlib a private cache instead of a warning on every start.
if "MPLCONFIGDIR" not in os.environ and not os.access(Path.home(), os.W_OK):
    os.environ["MPLCONFIGDIR"] = tempfile.mkdtemp(prefix="lpj-explorer-mpl-")

from shiny import App, reactive, render, ui
from app import data, registry
from app.modules.overview import overview_ui, overview_server
from app.modules.select_samples import samples_ui, samples_server
from app.modules.sample_overview import sample_overview_ui, sample_overview_server
from app.modules.feature_explorer import feature_ui, feature_server
from app.modules.differential import differential_ui, differential_server
from app.modules.volcano import volcano_ui, volcano_server
from app.modules.cross_plots import cross_ui, cross_server
from app.modules.multiverse import multiverse_ui, multiverse_server
from app.modules.regional_de import regional_ui, regional_server
from app.modules.persistence import persistence_ui, persistence_server
from app.modules.outlier_review import outlier_ui, outlier_server
from app.modules.qc import qc_ui, qc_server
from app.modules.classes_structure import classes_ui, classes_server
from app.modules.provenance import provenance_ui, provenance_server

app_ui = ui.page_navbar(
    ui.nav_panel("Overview", overview_ui("overview")),
    ui.nav_panel("Select samples", samples_ui("samples")),
    ui.nav_menu("Explore", ui.nav_panel("Sample overview", sample_overview_ui("sample_overview")),
                ui.nav_panel("Lipid / metabolite explorer", feature_ui("feature"))),
    ui.nav_menu("Effects", ui.nav_panel("Differential", differential_ui("differential")),
                ui.nav_panel("Volcano & MA", volcano_ui("volcano")), ui.nav_panel("Cross plots", cross_ui("cross")),
                ui.nav_panel("Sensitivity grid", multiverse_ui("multiverse"))),
    ui.nav_menu("Regions", ui.nav_panel("Regional DE", regional_ui("regional")),
                ui.nav_panel("Regional persistence", persistence_ui("persistence"))),
    ui.nav_menu("Diagnostics", ui.nav_panel("Outlier review", outlier_ui("outlier")),
                ui.nav_panel("QC", qc_ui("qc")), ui.nav_panel("Classes & structure", classes_ui("classes"))),
    ui.nav_panel("Data & provenance", provenance_ui("provenance")),
    title="LPJ Explorer", id="tab", selected="Overview", window_title="LPJ · Regional omics explorer",
    sidebar=ui.sidebar(
        ui.h5("Shared study selection"),
        ui.input_radio_buttons("modality", "Modality", {"lipidomics": "Lipidomics", "metabolomics": "Metabolomics"}),
        ui.output_text("selection_summary"),
        ui.p("Change samples in Select samples. Cross-plot axes can use independent presets."),
        ui.input_action_button("reload", "Reload sources (resets All 60)"), width=255),
    header=ui.TagList(ui.tags.style("""
        body {background:#f5f7fa; color:#233448;}
        .navbar {border-bottom:3px solid #2a78d6;}
        .design-banner {border-left:4px solid #d28d21; background:#fff5df; padding:12px 16px; margin:12px 0; border-radius:4px;}
        .card {border:1px solid #dce3eb; border-radius:8px;}
        .shiny-text-output {white-space:pre-wrap; overflow-wrap:anywhere; font-size:.85rem; background:#eef3f8; padding:10px;}
        .btn {margin:4px 5px 4px 0;}
        .tab-content {padding:18px;}
        """), ui.output_ui("population_warning")),
    footer=ui.p("Local research explorer · normalized relative abundances · exploratory inference", class_="text-muted p-3"),
)


def server(input, output, session):
    used = set()  # Per-session audit, not a process-global list of other users' reads.

    @reactive.calc
    def modality():
        input.reload()
        return input.modality()

    samples = samples_server("samples", modality, used)

    @render.text
    def selection_summary():
        _, metadata = data.selected_inputs(modality(), samples(), used)
        population = data.matching_population(modality(), samples(), used)
        return f"{modality().title()} · {registry.POPULATIONS.get(population, 'Custom — exploratory')}\n{len(samples())} samples · {metadata['Mouse number'].nunique()} mice"

    @render.ui
    def population_warning():
        _, metadata = data.inputs(modality(), used=used)
        mice = data.removed_mice(metadata, samples())
        if mice:
            return ui.div("Not a permitted population — exploratory. Whole mice removed: " + ", ".join(mice), class_="design-banner", role="alert")
        return None

    overview_server("overview", modality, samples, used)
    sample_overview_server("sample_overview", modality, samples, used)
    feature_server("feature", modality, samples, used)
    differential_server("differential", modality, samples, used)
    volcano_server("volcano", modality, samples, used)
    cross_server("cross", modality, samples, used)
    multiverse_server("multiverse", modality, samples, used)
    regional_server("regional", modality, samples, used)
    persistence_server("persistence", modality, samples, used)
    outlier_server("outlier", modality, samples, used)
    qc_server("qc", modality, samples, used)
    classes_server("classes", modality, samples, used)
    provenance_server("provenance", modality, samples, used)


app = App(app_ui, server, static_assets={"/analysis-state.md": ROOT / "doc/analysis-state.md"})
