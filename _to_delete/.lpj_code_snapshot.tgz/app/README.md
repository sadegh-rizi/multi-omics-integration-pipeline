# LPJ Explorer — interactive lipidomics and metabolomics results

A local, read-only PyShiny app for exploring the MIA-vs-control brain
lipidomics and metabolomics results. Plan:
`doc/decisions/2026-10-07-pyshiny-explorer-app-plan.md`.

It shows pipeline outputs; it is not a second pipeline. Every number either
comes from a saved result file or from the same package function the pipeline
uses (`src/lpj_lipidomics`). It never writes to `results/` or `data/`.

## Run

From the repository root, in the project WSL venv:

```bash
/root/.virtualenvs/LPJ_lipidomics/bin/python -m shiny run app/app.py
```

Then open http://127.0.0.1:8000. Dependencies (`shiny`, `shinywidgets`,
`plotly`) are pinned in `requirements.txt`.

The metabolomics all-60 differential snapshot is prepared once, before the
app is launched (it refuses to overwrite an existing snapshot):

```bash
/root/.virtualenvs/LPJ_lipidomics/bin/python -m app.prepare_metabolomics
```

It writes `results/explorer_prepared/metabolomics/prevalence20_noexclusion/`
with its own `run_manifest.json` and `provenance.json`. It is a
differential-only snapshot made with the pipeline's OLS function; it is not a
full metabolomics pipeline run.

## Deploy to a server

`python -m app.export_bundle` writes a self-contained bundle
(`dist/lpj-explorer-<date>.zip`): app, analysis package, the allow-listed
result files only (no raw data), `deploy/`, and a manifest with sha256 hashes.
`deploy/environment.yml` (conda) and `deploy/requirements.txt` (venv) pin
Python 3.12 and every package. Full instructions for the lab's Shiny Server:
`deploy/DEPLOY.md`.

## Sensitivity grid (build once)

The **Effects → Sensitivity grid** tab shows how differential results move
across lipid-filtering thresholds, normalization and outlier-removal rules.
Build the grid once, before launching the app. It takes about a minute:

```bash
/root/.virtualenvs/LPJ_lipidomics/bin/python -m app.build_multiverse
```

It writes `results/explorer_prepared/multiverse/{lipidomics,metabolomics}/`
and refuses to overwrite an existing grid: move the old one aside to rebuild.
Rebuild whenever the outlier screens or the pipeline code change; the tab
warns if the saved rules no longer match. `effects.npz` (~33 MB) can be
regenerated and is git-ignored; the CSV and JSON files are small.

**Lipidomics axes** (504 combinations). The first value of each is the
pipeline's primary setting:

| Axis | Values |
|---|---|
| Prevalence filter | ≤20% missing · none · ≤10% · ≤30% |
| Blank multiplier (feature and value level) | 3× · 5× · 10× |
| QC-CV feature filter | off · Tech-Mix CV ≤30% · ≤20% |
| Normalization | median · PQN (per-region reference) |
| Outlier rule | none · T²-95 · T²-99 · detector-ensemble candidates · T²-95 AND ensemble · T²-95 OR ensemble · difference-space T²-95 (proposed) |

**Metabolomics:** only the outlier rule varies (7 combinations). Its filters
and acquisition-mode normalization are fixed by the sibling pipeline.

**How it is built and served:**
- The builder refits every combination with the pipeline's own
  preprocessing and model functions, in the pipeline's order.
- With the pipeline settings, it reproduces the saved pipeline outputs
  (all 60, T²-95 and T²-99) to 1e-8.
- In the app, the primary combination shows the saved pipeline file; every
  other combination comes from the saved grid.
- The running app never opens `data/`; only the offline builder reads the
  raw workbook.

**Outlier rules.** Every rule removes samples, never whole mice, and is
blind to group labels. The per-region T² and ensemble flags come from the
lipidomics screens and are applied to metabolomics by sample number, as in
the persistence pipeline. Rules that leave a group × sex cell below 3 cannot
be fitted in that region. The views report this rather than hiding it.

**Views:**
- **Selected combination:** volcano and table.
- **Across combinations:** a specification curve of q ≤ 0.05 counts or the
  smallest q, with the primary analysis starred.
- **One feature across combinations:** estimate ± SE in every combination.
- **Stability:** per-feature counts and a descriptive "SE-driven /
  estimate-driven" label.
- **Outlier rules:** which samples each rule removes, and how much the rules
  agree.

Report the distribution ("q ≤ 0.05 in k of N combinations"), never a single
chosen cell.

## MIA effect by sex

The model is `BioGroup × Sex` with males and controls as reference, so the
saved "MIA vs Saline Control" effect is the **male** MIA effect. Two further
contrasts of the same fit are offered wherever an effect is chosen
(Differential, Volcano & MA, Cross plots):

| Choice | Contrast of (intercept, MIA, Female, MIA×Female) |
|---|---|
| MIA vs Control — males (model reference) | (0, 1, 0, 0): saved pipeline effect |
| MIA vs Control — females | (0, 1, 0, 1) |
| MIA vs Control — average of females and males | (0, 1, 0, ½) |

- The derived contrasts are not in the saved pipeline files. They are always
  recomputed from the selected samples with the same OLS fit (estimate c·β,
  SE from c′(X′X)⁻¹c·σ²), the same ≥3-per-cell rule and residual df.
- They are BH-adjusted within Region × Effect over the full retained panel,
  like the saved effects. The badge says "Derived contrast".
- Tests:
  - (0, 1, 0, 0) reproduces the saved effect to 1e-10;
  - the female contrast equals a refit with females as reference;
  - the average equals statsmodels with ±½ sex coding.
- These are post-hoc additions. Each adds a BH family per region, and
  MIA-female cells share cages, so the female contrast is also partly a cage
  contrast. Treat hits as exploratory.

## Saved vs recomputed

| Choice | What the app shows |
|---|---|
| All 60, T²-95 or T²-99 preset, with a saved result for that analysis | **Saved** — the pipeline file, its commit and whether the source tree was dirty |
| Any other sample selection, or a population whose saved run is incomplete | **Recomputed — exploratory**, with the removed samples listed |
| Moving an evidence or effect-size threshold | Nothing is refitted; only colours and filters change |

The badge above each table and plot says which applies. Recomputing a saved
preset reproduces the saved table to 1e-8 (tested).

Sources come only from the allow-list in `app/registry.py`. The dismissed
57-sample trees (`results/mia_vs_control/00_inputs/`, `08_cage_structure/`,
the specification curve, feature-PCA `primary`) are not sources. Removing every
sample of a mouse by hand is allowed for exploration, but a banner then says
the selection is not a permitted population.

## Tabs

| Tab | What it shows |
|---|---|
| Overview | Counts, cage and collection-date structure, the population rule |
| Select samples | Presets (All 60 / remove T²-95 / remove T²-99), filters by region, group, sex, cage, date, T² flag, individual samples |
| Sample overview | PCA per region or pooled; colour by any metadata, marker = group; PC pair; ellipses; marginal R² heatmap (region, group, sex, cage, date, tissue mass); ordered per-sample boxplots, missingness and a downloadable per-sample QC table |
| Lipid / metabolite explorer | One feature, lines joining each mouse's three regions; optional rings and sample numbers on T²-95 / T²-99 / ensemble-candidate samples |
| Differential | OLS `BioGroup × Sex` per region: MIA in males / females / sex-averaged, sex, interaction; class filter; highlighted-only download |
| Volcano & MA | Side by side; FDR or raw p; colour by evidence or class; auto labels (top 10 up + top 10 down); separate volcano / MA PDFs; highlighted-only download |
| Cross plots | log₂ effect vs log₂ effect; axis = group/sex effect or paired regional contrast, any population; presets below |
| Sensitivity grid | Differential results across filter thresholds × normalization × outlier rules (see above) |
| Regional DE | Paired within-mouse region contrasts within Control, MIA or all mice |
| Regional persistence | Control vs MIA regional differences; concordance, reliability, disattenuated intervals, interaction q (raw and ICC-adjusted) |
| Outlier review | Ensemble verdict; one sub-tab per detector with its full parameter sweep; per-region T², robust Mahalanobis, DModX and the difference-space screen (see below) |
| QC | Missingness, technical vs biological variance, Tech-Mix CV/drift, noisyR curves |
| Classes & structure | Class aggregates and structural indices |
| Data & provenance | Downloads, and every source file read in this session with its commit |

**Cross-plot presets:**
- MIA effect, region A vs region B.
- Same effect, all 60 vs T²-95. This is the exclusion-dependence view:
  points on the diagonal that change colour moved only their SE.
- MIA effect vs sex effect.
- Regional contrast, Control vs MIA.

The plot shows Pearson and Spearman r, the count of points in each octant,
and 1:1 axes. Points can be coloured by evidence category, lipid class or SE
ratio. It shows concordance, not an interaction test.

## Outlier review

All views read the saved detector-ensemble outputs in
`results/mia_vs_control/02_qc/ensemble/`. Nothing is refitted. The screens are
lipidomics, all 60 samples and label-blind. Metabolomics analyses apply them by
sample number.

- **Ensemble**
  - Candidates in every scope, with the calibration-sensitive samples.
  - Views: a sample × detector stability heatmap; corroboration counts
    (stable detectors vs non-covariance detectors); and the trinity-mean
    ensemble percentile at stage 1 vs stage 2.
  - Also shows the ensemble null limits and the distance-concentration
    diagnostic.
- **Detector sweeps** has one sub-tab per detector: Mahalanobis, kNN isotropic,
  kNN soft, LOF, LOF small-k (supporting, not counted), isolation forest and
  kernel PCA.
  - Pick a scope, calibration stage, representation, and the value to show:
    null percentile, flag at 95% or 99%, or raw score.
  - Heatmap view: samples × every parameter setting. ★ marks ensemble
    candidates. ◆ marks the representative setting that feeds the ensemble
    percentiles.
  - Sweep-curve view: one line per sample across the parameter.
  - The table gives per-sample flag fractions; its `fraction_flag_95` equals
    the saved stability fraction (tested).
  - Each detector also shows its null-calibration limits. Isolation forest
    also shows seed-to-seed rank ranges.
- **Per-region screens (T² / DModX)**: the previous view, unchanged.

The pooled scope is shown but labelled invalid for the region design. Ensemble
candidates are a review list, not an exclusion rule. The permitted
populations remain all 60, T²-95 and T²-99.

## Tests

```bash
/root/.virtualenvs/LPJ_lipidomics/bin/python -m pytest tests/test_app_registry.py tests/test_app_compute.py tests/test_app_views.py tests/test_app_multiverse.py tests/test_app_outliers.py tests/test_app_features.py tests/test_app_deploy.py
LPJ_BROWSER_SMOKE=1 /root/.virtualenvs/LPJ_lipidomics/bin/python -m pytest tests/test_app_browser.py
```

The browser smoke test needs `chromium` (or `google-chrome`) on `PATH`. It
opens every tab in both modalities and runs the cross-plot presets and
downloads. It also checks the empty and single-sex selections.

All three region-persistence populations (all 60, T²-95, T²-99) have saved runs. The compute tests check that the app's recompute matches each one.

## Manual checklist (if no Chromium)

1. The app starts, and the sidebar reads "Lipidomics · All 60 · 60 samples ·
   20 mice".
2. Every tab renders for both modalities with no red error text.
3. The Differential badge says *Saved* for All 60. Deselect one sample and
   it says *Recomputed* and names the sample.
4. Moving a threshold slider changes colours immediately, with no spinner.
5. Each cross-plot preset applies, and both downloads produce a CSV and a ZIP.
6. Removing all three samples of one mouse shows the "Not a permitted
   population" banner.

## Limits

Interactive inference inherits every design limit of the study:
- 20 mice from 8 cages, 2 of them control;
- collection date partly confounded with treatment;
- abundances are relative (median-normalised), not absolute.

The banners say so; they do not fix it.
