import pandas as pd
import plotly.express as px
from shiny import module, reactive, ui

from app import data, plots, registry
from app.modules.common import MODEL, banner, view_ui, view_server


@module.ui
def classes_ui():
    return ui.TagList(banner(), ui.p(MODEL),
        ui.p("Saved class aggregates and structural indices have their own BH families. Structural estimates use the units of the named index, even where historical column names say log2. These indices are unweighted observed-feature summaries, not enzyme activities."),
        ui.layout_columns(ui.input_select("kind", "Summary", {"class_aggregate": "Lipid class aggregates", "structural_index": "Structural indices", "pathway": "Saved metabolomics pathway aggregates"}),
                          ui.input_select("region", "Region", registry.REGIONS), ui.input_select("effect", "Effect", registry.EFFECTS)),
        view_ui("view"),
        banner("Composite biological panel: awaiting the biology-plan Part C output."))


@module.server
def classes_server(input, output, session, modality, samples, used):
    @reactive.calc
    def result():
        population = data.matching_population(modality(), samples(), used)
        if population is None:
            return pd.DataFrame(), "No saved aggregate result for this custom selection. Select a matching preset to inspect saved aggregates."
        for base in registry.differential_roots(modality(), population):
            path = base / "06_aggregation" / f"{input.kind()}_differential_effects.csv"
            if not path.exists():
                continue
            metadata = data.read_csv(base / "00_inputs/differential_input_metadata.csv", used)
            if set(metadata["Sample"]) != set(samples()):
                continue
            frame = data.read_csv(path, used)
            frame = frame.loc[frame["Region"].eq(input.region()) & frame["Effect"].eq(input.effect())].copy()
            return frame, data.badge(modality(), samples(), path, used)
        return pd.DataFrame(), "No matching saved aggregate source for this modality / population."

    @reactive.calc
    def figure():
        table = result()[0]
        if table.empty:
            return plots.empty(result()[1])
        table = table.copy()
        table["Upper CI distance"] = table["ci_upper_log2"] - table["estimate_log2"]
        table["Lower CI distance"] = table["estimate_log2"] - table["ci_lower_log2"]
        figure = px.scatter(table, x="estimate_log2", y="Feature", error_x="Upper CI distance", error_x_minus="Lower CI distance",
                            hover_data=["p_value", "p_value_fdr", "standard_error"])
        figure.update_xaxes(title="Effect in index units" if input.kind() == "structural_index" else "Effect (normalized log₂)")
        return plots.finish(figure, "Saved aggregate effects with 95% CIs")

    view_server("view", lambda: result()[0], lambda: result()[1], figure)
