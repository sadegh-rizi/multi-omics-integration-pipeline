"""Shared scientific labels and result/table download panel."""

import pandas as pd
from shiny import module, reactive, render, ui
from shinywidgets import output_widget, render_widget

from app import data, plots

DESIGN = (
    "Exploratory study: 20 mice; treatment administered to dams/cages (2 control vs 6 MIA cages). "
    "Collection date partly confounds treatment; MIA sex also confounds cage. "
    "Repeated regions from one mouse are paired, not independent treatment replicates."
)
MODEL = (
    "OLS BioGroup × Sex per region. MIA effect is MIA−Control in males; sex effect is Female−Male in controls; "
    "interaction is the difference of these effects. ≥3 usable samples in each of four cells. "
    "BH includes the full retained feature panel within Region × Effect. No imputation. "
    "Single-sex/group selections cannot fit this model; the model is not silently changed. "
    "MIA effects for females and for the average of both sexes are further contrasts of the same fit."
)
COMPOSITION = (
    "Within-mouse differences use feature-wise complete pairs. Positive = higher in the first-named region. "
    "Regions were separately median-normalized (metabolomics by acquisition mode): effects are relative "
    "to the panel, not absolute tissue concentrations. Tissue mass may contribute."
)
COUNTING = (
    "Do not compare within-group significance counts: significant in Control but not MIA is not an interaction. "
    "Use the direct difference-of-differences and its raw / ICC-adjusted q values. "
    "A concordance interval including 1 is unresolved; low reliability can explain low observed r."
)


def banner(text: str = DESIGN):
    return ui.div(text, class_="design-banner")


def thresholds():
    return ui.TagList(
        ui.input_select("evidence", "Evidence rule", {"p_value_fdr": "BH FDR q", "p_value": "Raw p (exploratory)"}),
        ui.input_slider("threshold", "Evidence threshold — highlighting only", min=.001, max=.20, value=.05, step=.001),
        ui.input_slider("lfc", "Minimum |log₂ effect| — highlighting only", min=0, max=3, value=0, step=.05),
        ui.input_select("color", "Colour", {"Evidence": "Evidence category", "Class / method": "Lipid class / metabolite method"}),
        ui.input_text("highlight", "Label features (comma-separated names or IDs)"),
        ui.input_selectize("classes", "Class / method filter (empty = all)", choices=[], multiple=True),
    )


def class_choices(input, modality, used):
    @reactive.effect
    def update():
        choices = sorted(data.annotations(modality(), used)["Class / method"].dropna().unique())
        ui.update_selectize("classes", choices=choices, selected=[])


def filter_classes(table, classes):
    if classes and not table.empty and "Class / method" in table:
        return table.loc[table["Class / method"].isin(classes)].copy()
    return table


def display_frame(frame):
    """Readable on-screen copy: identifiers first, floats to 4 significant digits.

    Downloads use the unrounded table; this only affects the grid display.
    """
    if frame is None or frame.empty:
        return frame
    frame = frame.copy()
    first = [column for column in ("Feature", "Name", "Class / method") if column in frame]
    frame = frame[first + [column for column in frame.columns if column not in first]]
    for column in frame.select_dtypes("float").columns:
        frame[column] = frame[column].map(lambda value: float(f"{value:.4g}") if pd.notna(value) else value)
    return frame


@module.ui
def view_ui(plot: bool = True, export: bool = False, highlighted: bool = False):
    return ui.TagList(
        ui.output_text("badge"),
        output_widget("figure") if plot else None,
        ui.download_button("table_csv", "Download displayed table"),
        ui.download_button("highlighted_csv", "Download highlighted features only") if highlighted else None,
        ui.download_button("figure_zip", "Download PDF + PNGs + table") if export else None,
        ui.output_data_frame("table"),
    )


@module.server
def view_server(input, output, session, table, badge, figure=None, export=False):
    table_data, badge_text, figure_data = table, badge, figure
    @render.text
    def badge():
        return badge_text()

    # Preserve the passed reactive callable before the output name is rebound.
    @render.data_frame
    def table():
        return render.DataGrid(display_frame(table_data()), filters=True, height="430px")

    if figure_data is not None:
        @render_widget
        def figure():
            return figure_data()

    @render.download_button(filename="explorer_table.csv")
    def table_csv():
        yield table_data().to_csv(index=False)

    @render.download_button(filename="explorer_highlighted_features.csv")
    def highlighted_csv():
        from app.compute import highlighted_only
        yield highlighted_only(table_data()).to_csv(index=False)

    if export:
        @render.download_button(filename="exploratory_figure.zip")
        def figure_zip():
            current = figure_data()
            context = "\n".join([badge_text(), DESIGN, str(current.layout.title.text),
                                  str(current.layout.xaxis.title.text), str(current.layout.yaxis.title.text)])
            yield plots.scatter_bundle(current, table_data(), context)
