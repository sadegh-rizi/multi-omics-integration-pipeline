"""Regional concordance, reliability and direct interaction, with async refits."""

import asyncio
import pandas as pd
from shiny import module, reactive, render, ui
from shinywidgets import output_widget, render_widget

from app import compute, data, plots, registry
from app.modules.common import COMPOSITION, COUNTING, banner, view_ui, view_server
from lpj_lipidomics.statistics.region_contrast import REGION_CONTRASTS


@module.ui
def persistence_ui():
    return ui.TagList(banner(), ui.p(COMPOSITION), banner(COUNTING),
        ui.p("Interactions: Welch comparison of MIA−Control paired differences; BH across all three contrasts × full feature panel. ICC-adjusted q at point and interval endpoints is a sensitivity, not a fix for 2 control cages. Reliability: 1,000 split halves; 1,000 mouse bootstraps with 100 ID-aware inner splits, fixed pipeline seeds."),
        ui.input_select("contrast", "Region contrast", [name for name, _, _ in REGION_CONTRASTS]),
        ui.output_text("scatter_badge"), output_widget("scatter"),
        ui.h4("Saved population sensitivities, side by side"), output_widget("population_intervals"),
        ui.output_text("population_sources"), ui.output_data_frame("population_table"),
        ui.h4("Current selection"),
        ui.p("Saved presets load immediately. Missing snapshots and custom selections require Run persistence; the full bootstrap/ICC computation may take several minutes. Changing samples hides any previous result until the matching run finishes."),
        ui.input_task_button("run", "Run persistence for current selection"),
        ui.output_text("status"),
        ui.input_select("kind", "Current result table", {"disattenuation": "Concordance, reliability, ceiling and interval", "interactions": "Region × treatment interactions: raw and ICC-adjusted", "concordance": "Observed concordance", "reliability": "Split-half reliability", "icc": "Cage ICC intervals", "pairing": "Contrast-specific pairing"}),
        view_ui("view", plot=False))


@module.server
def persistence_server(input, output, session, modality, samples, used):
    @reactive.calc
    def scatter_data():
        left, left_badge = compute.regional(modality(), samples(), "Saline Control", used)
        right, right_badge = compute.regional(modality(), samples(), "MIA", used)
        if left.empty or right.empty:
            return pd.DataFrame(), "X (Control): " + left_badge + "\nY (MIA): " + right_badge
        return (compute.highlight(compute.cross_join(left.loc[left["Contrast"].eq(input.contrast())],
                                                    right.loc[right["Contrast"].eq(input.contrast())]), .05, 0),
                "X (Control): " + left_badge + "\nY (MIA): " + right_badge)

    @render.text
    def scatter_badge():
        return scatter_data()[1]

    @render_widget
    def scatter():
        return plots.cross(scatter_data()[0], "Control regional difference", "MIA regional difference")

    @reactive.calc
    def populations():
        tables, badges = [], []
        for population, ids in data.sample_sets(modality(), used).items():
            if compute.persistence_available(modality(), ids, used):
                result, badge = compute.persistence(modality(), ids, used)
                tables.append(result["disattenuation"].assign(Population=registry.POPULATIONS[population], Modality=modality()))
                badges.append(registry.POPULATIONS[population] + ": " + badge)
            else:
                badges.append(registry.POPULATIONS[population] + ": no complete saved run; select this population and Run persistence.")
        return pd.concat(tables, ignore_index=True) if tables else pd.DataFrame(), "\n".join(badges)

    @render_widget
    def population_intervals():
        table = populations()[0]
        return plots.persistence_intervals(table) if not table.empty else plots.empty("No complete saved persistence run.")

    @render.text
    def population_sources():
        return populations()[1]

    @render.data_frame
    def population_table():
        return render.DataGrid(populations()[0], filters=True)

    @ui.bind_task_button(button_id="run")
    @reactive.extended_task
    async def worker(modality_name, sample_ids, version):
        sources = set()
        try:
            result = await asyncio.to_thread(compute.persistence, modality_name, sample_ids, sources)
        except ValueError as error:
            return (modality_name, sample_ids, version), str(error), sources
        return (modality_name, sample_ids, version), result, sources

    @reactive.effect
    @reactive.event(input.run)
    def run():
        worker.invoke(modality(), samples(), data.input_version(modality(), used))

    @reactive.calc
    def current():
        ids = samples()
        if compute.persistence_available(modality(), ids, used):
            return compute.persistence(modality(), ids, used)
        if worker.status() != "success":
            return {}, "Recomputed — exploratory: click Run persistence; " + worker.status()
        key, result, sources = worker.result()
        if key != (modality(), ids, data.input_version(modality(), used)):
            return {}, "Selection changed — click Run persistence. Previous results are hidden."
        used.update(sources)
        return ({}, result) if isinstance(result, str) else result

    @render.text
    def status():
        return current()[1]

    @reactive.calc
    def table():
        result = current()[0].get(input.kind(), pd.DataFrame())
        if "Contrast" in result:
            result = result.loc[result["Contrast"].eq(input.contrast())]
        return data.annotate(result, modality(), used) if "Feature" in result else result

    view_server("view", table, lambda: current()[1])
