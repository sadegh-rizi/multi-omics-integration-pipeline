"""Sensitivity grid: lipid filtering × normalization × outlier rule → differential results."""

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from shiny import module, reactive, render, ui
from shinywidgets import output_widget, render_widget

from app import ROOT, compute, data, multiverse as mv, plots, registry
from app.modules.common import MODEL, banner, class_choices, display_frame, filter_classes, thresholds, view_ui, view_server

FORKING = ("This grid shows how results move across reasonable analysis choices. The primary analysis is fixed in "
           "advance (≤20% missing, 3× blank, no QC-CV filter, median normalization, all 60 samples). Report the "
           "whole distribution — e.g. 'q ≤ 0.05 in k of N combinations; estimate stable / SE-driven' — never a single "
           "chosen cell. Every outlier rule removes samples, not mice, and is blind to group labels.")
RULE_COLORS = dict(zip(mv.OUTLIERS.values(), [*plots.COLORBLIND_COLORS, "#444444"]))


def _choices(options):
    return {key: label if isinstance(label, str) else label[0] for key, label in options.items()}


@module.ui
def multiverse_ui():
    return ui.TagList(
        banner(FORKING), ui.p(MODEL),
        ui.output_ui("grid_status"),
        ui.layout_columns(
            ui.input_select("prevalence", "Prevalence filter", _choices(mv.PREVALENCE)),
            ui.input_select("blank", "Blank multiplier (feature + value level)", _choices(mv.BLANK)),
            ui.input_select("qc_cv", "QC-CV feature filter", _choices(mv.QC_CV)),
            ui.input_select("normalization", "Normalization", _choices(mv.NORMALIZATION)),
            ui.input_select("outliers", "Outlier rule (sample-level)", mv.OUTLIERS),
            col_widths=[2, 3, 2, 2, 3]),
        ui.layout_columns(ui.input_select("region", "Region", registry.REGIONS, selected="Cortex"),
                          ui.input_select("effect", "Effect", registry.EFFECTS),
                          ui.input_action_button("reset", "Reset to primary"), col_widths=[3, 4, 3]),
        ui.output_text("combination_info"),
        ui.navset_card_tab(
            ui.nav_panel("Selected combination", ui.layout_sidebar(ui.sidebar(thresholds()), view_ui("view", export=True))),
            ui.nav_panel("Across combinations",
                         ui.input_radio_buttons("metric", "Per combination", {"n_q05": "Features with q ≤ 0.05", "min_q": "Smallest q"}, inline=True),
                         output_widget("curve"), ui.output_data_frame("summary")),
            ui.nav_panel("One feature across combinations",
                         ui.input_selectize("feature", "Feature", choices=[]), output_widget("feature_plot"),
                         ui.output_data_frame("feature_table")),
            ui.nav_panel("Stability", ui.p(mv.stability.__doc__.split("\n\n")[1].replace("\n", " ")),
                         ui.input_checkbox("ever_only", "Only features significant in at least one combination", True),
                         ui.output_data_frame("stability")),
            ui.nav_panel("Outlier rules", output_widget("overlap"), ui.output_data_frame("rules")),
        ),
    )


@module.server
def multiverse_server(input, output, session, modality, samples, used):
    class_choices(input, modality, used)

    @reactive.effect
    @reactive.event(input.reset)
    def _reset():
        for axis, value in mv.PRIMARY.items():
            ui.update_select(axis, selected=value)

    @reactive.calc
    def combination():
        if modality() == "metabolomics":
            return mv.Combination("metabolomics", *mv.FIXED_METABOLOMICS.values(), input.outliers())
        return mv.Combination("lipidomics", input.prevalence(), input.blank(), input.qc_cv(), input.normalization(), input.outliers())

    @reactive.calc
    def fitted():
        """Primary → the saved pipeline file; any other combination → the saved grid."""
        current = combination()
        table, info = mv.grid_table(current, used)
        if current.is_primary:
            ids = data.sample_sets(modality(), used)["all60"]
            table, badge = compute.differential(modality(), ids, used)
            return table, badge, info
        if table.empty:
            return table, "No saved grid for this combination. Build it: python -m app.build_multiverse", info
        path = mv.grid_path(modality(), "effects.npz")
        record = data.provenance(path, used)
        badge = (f"Saved sensitivity grid — {path.relative_to(ROOT)}; commit {record['commit']} "
                 f"(pipeline preprocessing + OLS, fidelity-tested; exploratory). Removed: {info.get('removed') or 'none'}")
        return table, badge, info

    @render.ui
    def grid_status():
        notes = []
        if modality() == "metabolomics":
            notes.append("Metabolomics: only the outlier rule varies. Its feature filters and acquisition-mode "
                         "normalization are fixed by the sibling pipeline; the filter and normalization controls are ignored.")
        if not mv.grid_available(modality()):
            notes.append("The saved grid is absent, so 'Across combinations', 'One feature' and 'Stability' are empty. "
                         "Build it once before launching: python -m app.build_multiverse")
        elif not mv.saved_rules_current(modality(), used):
            notes.append("The outlier screens changed since the grid was built: the saved grid no longer matches the "
                         "current rules. Rebuild it (move the old grid aside first).")
        return ui.div(*(ui.p(note) for note in notes), class_="design-banner") if notes else None

    @render.text
    def combination_info():
        _, _, info = fitted()
        if not info:
            return combination().label() + "\n(not in the saved grid)"
        text = (f"{combination().label()}\n{int(info['n_samples'])} samples · {int(info['n_features'])} features · "
                f"smallest Region × Group × Sex cell: {int(info['min_cell'])}")
        if int(info["min_cell"]) < 3:
            text += "\nA cell is below 3: features in that region cannot be fitted under the pipeline rule."
        if str(info["whole_mouse_removed"]).lower() == "true":
            text += "\nThis rule removed every sample of a mouse — not a permitted population."
        return text

    @reactive.calc
    def table():
        frame = fitted()[0]
        if frame.empty:
            return frame
        frame = frame.loc[frame["Region"].eq(input.region()) & frame["Effect"].eq(input.effect())].copy()
        return compute.highlight(filter_classes(frame, input.classes()), input.threshold(), input.lfc(), input.evidence())

    @reactive.calc
    def volcano():
        figure = plots.volcano(table(), input.evidence(), input.color(), input.highlight())
        return figure.update_layout(title=f"{input.region()} · {input.effect()} · {combination().label()}")

    view_server("view", table, lambda: fitted()[1], volcano, export=True)

    # ---------------------------------------------------------- saved grid
    @reactive.calc
    def grid():
        return mv.grid(modality(), used)

    @reactive.calc
    def summary_data():
        saved = grid()
        if saved is None:
            return pd.DataFrame()
        frame = saved["summary"].loc[lambda d: d["Region"].eq(input.region()) & d["Effect"].eq(input.effect())]
        frame = frame.merge(saved["combinations"], on="key", how="left")
        frame["Outlier rule"] = frame["outliers"].map(mv.OUTLIERS)
        return frame

    @render_widget
    def curve():
        frame = summary_data()
        if frame.empty:
            return plots.empty("No saved grid. Run: python -m app.build_multiverse")
        metric = input.metric()
        frame = frame.sort_values([metric, "key"], ascending=metric == "min_q", kind="stable").reset_index(drop=True)
        frame["Rank"] = np.arange(1, len(frame) + 1)
        unfitted = int(frame["n_tested"].eq(0).sum())
        figure = px.scatter(frame.loc[frame["n_tested"].gt(0)], x="Rank", y=metric, color="Outlier rule",
                            color_discrete_map=RULE_COLORS,
                            hover_data=["label", "n_samples", "n_features", "n_tested", "n_q05", "min_q", "min_cell"])
        primary = frame.loc[frame["is_primary"].astype(str).str.lower().eq("true")]
        figure.add_trace(go.Scatter(x=primary["Rank"], y=primary[metric], mode="markers", name="Primary analysis",
                                    marker=dict(symbol="star", size=16, color="black")))
        if metric == "min_q":
            figure.add_hline(y=.05, line_dash="dash", line_color="#aaaaaa")
            figure.update_yaxes(type="log", title="Smallest BH q in the panel")
        else:
            figure.update_yaxes(title="Features with q ≤ 0.05")
        fitted_rows = frame.loc[frame["n_tested"].gt(0)]
        hits = int(fitted_rows["n_q05"].gt(0).sum())
        note = f" · {unfitted} not fittable (a group × sex cell < 3)" if unfitted else ""
        return plots.finish(figure.update_xaxes(title="Combination (sorted)"),
                            f"{input.region()} · {input.effect()} · any q ≤ 0.05 in {hits} of {len(fitted_rows)} fitted combinations{note}")

    @render.data_frame
    def summary():
        frame = summary_data()
        if not frame.empty:
            frame = frame[["prevalence", "blank", "qc_cv", "normalization", "Outlier rule", "n_samples", "n_features",
                           "min_cell", "n_tested", "n_q05", "n_q10", "n_p05", "min_q"]]
        return render.DataGrid(display_frame(frame), filters=True, height="380px")

    @reactive.effect
    def _features():
        names = mv.annotations(modality(), used)
        choices = dict(zip(names["Feature"].astype(str), names["Name"].fillna(names["Feature"]).astype(str)))
        ui.update_selectize("feature", choices=choices, selected=next(iter(choices), None), server=True)

    @reactive.calc
    def across():
        if not input.feature():
            return pd.DataFrame()
        frame = mv.feature_across(modality(), input.feature(), input.region(), input.effect(), used)
        if frame.empty:
            return frame
        frame["Outlier rule"] = frame["outliers"].map(mv.OUTLIERS)
        frame["Tested"] = frame["p_value_fdr"].notna()
        frame["q ≤ 0.05"] = np.where(frame["p_value_fdr"].le(.05), "q ≤ 0.05", np.where(frame["Tested"], "q > 0.05", "not tested"))
        return frame

    @render_widget
    def feature_plot():
        frame = across()
        if frame.empty:
            return plots.empty("No saved grid, or the feature is not in it.")
        frame = frame.loc[frame["Tested"]].sort_values("estimate_log2", kind="stable").reset_index(drop=True)
        if frame.empty:
            return plots.empty("This feature was filtered out or unfittable in every combination.")
        frame["Rank"] = np.arange(1, len(frame) + 1)
        figure = px.scatter(frame, x="Rank", y="estimate_log2", color="Outlier rule", symbol="q ≤ 0.05",
                            color_discrete_map=RULE_COLORS, error_y="standard_error",
                            hover_data=["label", "standard_error", "p_value", "p_value_fdr", "n_samples"])
        primary = frame.loc[frame["is_primary"].astype(str).str.lower().eq("true")]
        figure.add_trace(go.Scatter(x=primary["Rank"], y=primary["estimate_log2"], mode="markers", name="Primary analysis",
                                    marker=dict(symbol="star", size=16, color="black")))
        figure.add_hline(y=0, line_color="#aaaaaa")
        figure.update_yaxes(title="Effect (normalized log₂) ± 1 SE")
        name = mv.annotations(modality(), used).set_index("Feature")["Name"].get(input.feature(), input.feature())
        n_sig = int(frame["p_value_fdr"].le(.05).sum())
        return plots.finish(figure.update_xaxes(title="Combination (sorted by estimate)"),
                            f"{name} · {input.region()} · {input.effect()} · q ≤ 0.05 in {n_sig} of {len(frame)} tested combinations")

    @render.data_frame
    def feature_table():
        frame = across()
        if frame.empty:
            return render.DataGrid(frame)
        columns = ["prevalence", "blank", "qc_cv", "normalization", "Outlier rule", "n_samples",
                   "estimate_log2", "standard_error", "p_value", "p_value_fdr"]
        return render.DataGrid(display_frame(frame[columns]), filters=True, height="380px")

    @render.data_frame
    def stability():
        frame = mv.stability(modality(), input.region(), input.effect(), used)
        if not frame.empty and input.ever_only():
            frame = frame.loc[frame["n_q05"].gt(0)]
        return render.DataGrid(display_frame(frame), filters=True, height="430px")

    @render_widget
    def overlap():
        matrix = mv.rule_overlap(modality())
        figure = px.imshow(matrix, zmin=0, zmax=1, color_continuous_scale="Cividis", text_auto=".2f", aspect="auto")
        return plots.finish(figure, "Agreement between outlier rules (Jaccard of removed samples)")

    @render.data_frame
    def rules():
        table = mv.rule_table(modality()).drop(columns=["Rule"])
        return render.DataGrid(table, filters=True, height="380px")
