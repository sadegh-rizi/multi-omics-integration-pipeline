"""Shared sample state and explicit population choices."""

from shiny import module, reactive, render, ui

from app import data, registry
from app.modules.common import banner

FILTERS = {"region": "Sample type", "group": "Bio group", "sex": "Sex", "cage": "Cage", "date": "Date collected"}


@module.ui
def samples_ui():
    return ui.TagList(
        banner("All 60 is primary. T² presets remove samples, never whole mice, using the reviewed lipidomics flags mapped by sample number to both modalities, as in the persistence pipeline."),
        ui.layout_columns(*(ui.input_action_button(key, label) for key, label in registry.POPULATIONS.items())),
        ui.layout_columns(*(ui.input_selectize(key, label, [], multiple=True) for key, label in FILTERS.items()), col_widths=[4, 4, 4, 6, 6]),
        ui.input_select("flag", "Reviewed T² status", {"all": "All", "flag95": "Flagged at 95%", "flag99": "Flagged at 99%", "unflagged95": "Not flagged at 95%"}),
        ui.input_selectize("individual", "Individual samples (selection can be empty)", [], multiple=True),
        ui.output_text("summary"),
        ui.output_data_frame("cells"), ui.output_data_frame("cages"), ui.output_data_frame("metadata"),
    )


@module.server
def samples_server(input, output, session, modality, used):
    @reactive.calc
    def all_metadata():
        return data.inputs(modality(), used=used)[1]

    @reactive.effect
    def initialize():
        metadata = all_metadata()
        for key, column in FILTERS.items():
            choices = sorted(metadata[column].dropna().astype(str).unique())
            ui.update_selectize(key, choices=choices, selected=choices)
        ui.update_selectize("individual", choices=metadata["Sample"].tolist(), selected=metadata["Sample"].tolist())
        ui.update_select("flag", selected="all")

    def apply_preset(population):
        metadata = all_metadata()
        for key, column in FILTERS.items():
            ui.update_selectize(key, selected=sorted(metadata[column].dropna().astype(str).unique()))
        ui.update_select("flag", selected="all")
        ui.update_selectize("individual", selected=list(data.sample_sets(modality(), used)[population]))

    @reactive.effect
    @reactive.event(input.all60)
    def all60():
        apply_preset("all60")

    @reactive.effect
    @reactive.event(input.t2_95)
    def t2_95():
        apply_preset("t2_95")

    @reactive.effect
    @reactive.event(input.t2_99)
    def t2_99():
        apply_preset("t2_99")

    @reactive.calc
    def selected():
        metadata = all_metadata()
        for key, column in FILTERS.items():
            metadata = metadata.loc[metadata[column].astype(str).isin(input[key]() or ())]
        metadata = metadata.loc[metadata["Sample"].isin(input.individual() or ())]
        sets = data.sample_sets(modality(), used)
        flag = input.flag()
        if flag == "flag95":
            metadata = metadata.loc[~metadata["Sample"].isin(sets["t2_95"])]
        elif flag == "flag99":
            metadata = metadata.loc[~metadata["Sample"].isin(sets["t2_99"])]
        elif flag == "unflagged95":
            metadata = metadata.loc[metadata["Sample"].isin(sets["t2_95"])]
        return tuple(sorted(metadata["Sample"]))

    @render.text
    def summary():
        metadata = all_metadata()
        current = metadata.loc[metadata["Sample"].isin(selected())]
        removed = data.removed_mice(metadata, selected())
        return (f"{len(current)} samples · {current['Mouse number'].nunique()} mice · {current['Cage'].nunique()} cages\n"
                + ("Whole mice removed — not a permitted population; exploratory: " + ", ".join(removed) if removed else "No whole mouse removed."))

    @render.data_frame
    def cells():
        frame = all_metadata().loc[lambda x: x["Sample"].isin(selected())]
        return render.DataGrid(frame.groupby(["Sample type", "Bio group", "Sex"]).size().rename("n samples").reset_index())

    @render.data_frame
    def cages():
        frame = all_metadata().loc[lambda x: x["Sample"].isin(selected())]
        return render.DataGrid(frame.groupby(["Cage", "Bio group", "Sex", "Date collected"]).agg(
            samples=("Sample", "size"), mice=("Mouse number", "nunique")).reset_index())

    @render.data_frame
    def metadata():
        return render.DataGrid(all_metadata().loc[lambda x: x["Sample"].isin(selected())], filters=True)

    return selected
