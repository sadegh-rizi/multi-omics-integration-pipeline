"""PyShiny core modules, one per explorer tab."""
