import pandas as pd
import plotly.express as px
from shiny import module, reactive, ui

from app import ROOT, data, plots
from app.modules.common import banner, view_ui, view_server

TABLES = {"missingness": "Selected-sample missingness", "technical_vs_biological_variance.csv": "Technical vs biological variance",
          "qc_injection_cv.csv": "Tech-Mix CV", "qc_injection_drift.csv": "Tech-Mix drift", "noisyr": "noisyR curve", "thresholds": "noisyR thresholds"}


@module.ui
def qc_ui():
    return ui.TagList(banner("Missingness uses the current selected, preprocessed feature panel. Saved Tech-Mix/noisyR diagnostics describe their fixed source population. The noisyR cross-check compares two in-house implementations, not independent validation."),
        ui.layout_columns(ui.input_select("kind", "QC view", TABLES),
                          ui.input_select("scope", "noisyR scope", ["cortex", "hippocampus", "cerebellum", "techmix"])),
        view_ui("view"))


@module.server
def qc_server(input, output, session, modality, samples, used):
    @reactive.calc
    def result():
        if input.kind() == "missingness":
            values, metadata = data.selected_inputs(modality(), samples(), used)
            frame = metadata.copy()
            frame["Missing fraction"] = frame["Sample"].map(values.isna().mean())
            frame["Observed features"] = frame["Sample"].map(values.notna().sum())
            return frame, "Descriptive selected-sample missingness · " + data.badge(modality(), samples(), used=used)
        if modality() != "lipidomics":
            return pd.DataFrame(), "This saved QC diagnostic is not available for metabolomics. No lipidomics numbers are substituted."
        root = ROOT / "results/mia_vs_control/02_qc"
        if input.kind() in ("noisyr", "thresholds"):
            kind = "curve" if input.kind() == "noisyr" else "thresholds"
            path = root / "noisyr_work" / f"noisyr_{kind}_{input.scope()}_window99_step20.csv"
        else:
            path = root / input.kind()
        frame = data.read_csv(path, used)
        return frame, data.badge(modality(), data.sample_sets(modality(), used)["all60"], path, used) + "; fixed source, not refitted by sample filters"

    @reactive.calc
    def figure():
        frame = result()[0]
        if frame.empty:
            return plots.empty(result()[1])
        kind = input.kind()
        if kind == "missingness":
            figure = px.scatter(frame, x="Sample", y="Missing fraction", color="Sample type", symbol="Bio group",
                                color_discrete_map=plots.COLORS, range_y=[0, 1], hover_data=["Bio group", "Sex", "Mouse number"])
        elif kind == "technical_vs_biological_variance.csv":
            figure = px.scatter(frame, x="biological_sd_log2", y="technical_sd_log2", color="Region", hover_data=["Lipid Name"], color_discrete_map=plots.COLORS)
        elif kind == "qc_injection_cv.csv":
            figure = px.scatter(frame, x="raw_cv_percent", y="normalized_cv_percent", hover_data=["Lipid Name"])
        elif kind == "qc_injection_drift.csv":
            figure = px.line(frame, x="injection_index", y="median_positive_signal", markers=True)
        elif kind == "noisyr":
            figure = px.line(frame, x="median_log2_abundance", y="median_pearson", markers=True)
        else:
            figure = px.scatter(frame, x="sample", y="threshold_log2_abundance")
        return plots.finish(figure, TABLES[kind])

    view_server("view", lambda: result()[0], lambda: result()[1], figure)
