from shiny import module, reactive, ui

from app import compute, data, plots, registry
from app.modules.common import MODEL, banner, class_choices, filter_classes, thresholds, view_ui, view_server
from lpj_lipidomics.statistics.region_contrast import REGION_CONTRASTS


def axis_ui(prefix, title):
    return ui.card(ui.card_header(title),
        ui.input_select(prefix + "kind", "Comparison", {"differential": "Group / sex effect", "regional": "Paired regional contrast"}),
        ui.input_select(prefix + "population", "Population", {"current": "Current sample selection", **registry.POPULATIONS}),
        # Show only the inputs that the chosen comparison kind uses.
        ui.panel_conditional(f"input.{prefix}kind === 'differential'",
            ui.input_select(prefix + "region", "Region", registry.REGIONS, selected="Cortex" if prefix == "x" else "Cerebellum"),
            ui.input_select(prefix + "effect", "Effect", registry.EFFECT_CHOICES)),
        ui.panel_conditional(f"input.{prefix}kind === 'regional'",
            ui.input_select(prefix + "contrast", "Region contrast", [name for name, _, _ in REGION_CONTRASTS]),
            ui.input_select(prefix + "group", "Group", ["Saline Control", "MIA", "All mice"],
                            selected="Saline Control" if prefix == "x" else "MIA")))


@module.ui
def cross_ui():
    return ui.TagList(banner(), ui.p(MODEL),
        banner("Concordance is not an interaction test. Exclusion dependence: compare BOTH estimate and SE. On-diagonal points changing evidence category can reflect SE shrinkage rather than changed effect."),
        ui.layout_columns(ui.input_select("preset", "Preset", {"regions": "MIA: region A vs region B", "exclusion": "Same effect: All 60 vs T²-95", "sex": "MIA vs sex, same region", "persistence": "Region contrast: Control vs MIA"}),
                          ui.input_action_button("apply", "Apply preset")),
        ui.layout_columns(axis_ui("x", "X axis"), axis_ui("y", "Y axis")),
        ui.layout_sidebar(ui.sidebar(thresholds(), ui.input_checkbox("se_color", "Colour by SE ratio (y/x)", False),
                                     ui.input_checkbox("auto_labels", "Auto labels: 5 most extreme features per direction (octant)", True),
                                     ui.input_checkbox("labels", "Label nearest-origin feature in each octant", False)),
                          view_ui("view", export=True, highlighted=True)))


@module.server
def cross_server(input, output, session, modality, samples, used):
    class_choices(input, modality, used)

    @reactive.effect
    @reactive.event(input.apply)
    def apply():
        preset = input.preset()
        for axis in ("x", "y"):
            ui.update_select(axis + "kind", selected="regional" if preset == "persistence" else "differential")
            ui.update_select(axis + "population", selected="t2_95" if preset == "exclusion" and axis == "y" else "all60")
            ui.update_select(axis + "region", selected="Cerebellum" if preset == "regions" and axis == "y" else "Cortex")
            ui.update_select(axis + "effect", selected=registry.EFFECTS[1] if preset == "sex" and axis == "y" else registry.EFFECTS[0])
            ui.update_select(axis + "contrast", selected=REGION_CONTRASTS[0][0])
            ui.update_select(axis + "group", selected="Saline Control" if axis == "x" else "MIA")

    def get_axis(axis):
        population = input[axis + "population"]()
        ids = samples() if population == "current" else data.sample_sets(modality(), used)[population]
        kind = input[axis + "kind"]()
        table, badge = compute.effect_vector(modality(), ids, kind, input[axis + "region"](), input[axis + "effect"](),
                                             input[axis + "contrast"](), input[axis + "group"](), used)
        label = (input[axis + "contrast"]() + ", " + input[axis + "group"]() if kind == "regional"
                 else input[axis + "region"]() + ", " + input[axis + "effect"]())
        if kind != "regional":
            badge = compute.effect_badge(badge, input[axis + "effect"]())
        return table, badge, label + " · " + population

    @reactive.calc
    def vectors():
        return get_axis("x"), get_axis("y")

    @reactive.calc
    def joined():
        left, right = vectors()
        return compute.cross_join(left[0], right[0])

    @reactive.calc
    def table():
        return compute.highlight(filter_classes(joined(), input.classes()), input.threshold(), input.lfc(), input.evidence())

    @reactive.calc
    def figure():
        left, right = vectors()
        auto = compute.sector_extremes(table(), 5) if input.auto_labels() else []
        figure = plots.cross(table(), left[2], right[2], "SE ratio (y/x)" if input.se_color() else input.color(), input.labels(),
                             input.highlight(), auto)
        return figure.update_layout(title=figure.layout.title.text + f"<br>{input.evidence()} ≤ {input.threshold():.3f}; |effect| ≥ {input.lfc():.2f}")

    view_server("view", table, lambda: "X: " + vectors()[0][1] + "\nY: " + vectors()[1][1], figure, export=True)
