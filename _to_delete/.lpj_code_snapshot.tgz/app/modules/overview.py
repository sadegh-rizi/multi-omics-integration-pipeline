from shiny import module, render, ui

from app import data
from app.modules.common import DESIGN, banner


@module.ui
def overview_ui():
    return ui.TagList(
        ui.h2("LPJ lipidomics & metabolomics explorer"), banner(),
        ui.p("Explore the saved pipeline, paired regional comparisons and regional-signature persistence. Start with All 60, then compare sample-level exclusion sensitivities."),
        ui.output_text("counts"), ui.output_data_frame("cage_table"),
        ui.h4("How to read the views"),
        ui.markdown("""- **Saved** badges name the source and recorded commit; unrecorded commits are shown honestly.
- **Recomputed** means exploratory, with the exact sample removals disclosed. Thresholds only highlight.
- Differential effects use the pipeline's **OLS group × sex** model. Region contrasts use **paired mouse differences**.
- The persistence tab shows observed concordance, split-half reliability, attenuation ceiling, bootstrap intervals and direct interactions.
- A T² flag prioritizes review; it does not establish that a sample failed.
- Matrices are normalized log₂ values, with missing values retained. No app imputation or re-normalization.
- Metabolomics acquisition method is not a biological class.
"""),
        ui.a("Current analysis state", href="/analysis-state.md", target="_blank"),
        banner("Cage-structure sensitivity, historical specification curves and feature-PCA primary: awaiting an approved all-60 rerun. Excluded result trees are hidden."),
    )


@module.server
def overview_server(input, output, session, modality, samples, used):
    @render.text
    def counts():
        matrix, metadata = data.inputs(modality(), used=used)
        return f"{modality().title()} · {len(matrix)} retained features · {len(metadata)} source samples · {len(samples())} selected"

    @render.data_frame
    def cage_table():
        _, metadata = data.inputs(modality(), used=used)
        mice = metadata.drop_duplicates("Mouse number")
        return render.DataGrid(mice.groupby(["Cage", "Bio group", "Sex", "Date collected"]).size().rename("Mice").reset_index())
