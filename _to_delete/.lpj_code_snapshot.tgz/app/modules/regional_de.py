from shiny import module, reactive, ui

from app import compute, data, plots
from app.modules.common import COMPOSITION, banner, class_choices, filter_classes, thresholds, view_ui, view_server
from lpj_lipidomics.statistics.region_contrast import REGION_CONTRASTS


@module.ui
def regional_ui():
    return ui.TagList(banner(), ui.p(COMPOSITION),
        ui.p("One-sample t on each mouse's regional difference; BH over all retained features separately within contrast × group. Descriptive. Missing regional samples remove only pairs involving that region."),
        ui.layout_sidebar(ui.sidebar(
            ui.input_select("contrast", "Region contrast", [name for name, _, _ in REGION_CONTRASTS]),
            ui.input_select("group", "Paired mice", ["Saline Control", "MIA", "All mice"]),
            ui.input_select("kind", "Plot", ["Volcano", "MA"]), thresholds()), view_ui("view", export=True)))


@module.server
def regional_server(input, output, session, modality, samples, used):
    class_choices(input, modality, used)

    @reactive.calc
    def fitted():
        return compute.regional(modality(), samples(), input.group(), used)

    @reactive.calc
    def table():
        frame = fitted()[0]
        if frame.empty:
            return frame
        frame = frame.loc[frame["Contrast"].eq(input.contrast())].copy()
        values, metadata = data.selected_inputs(modality(), samples(), used)
        contrast = compute.contrasts_for(values, metadata).get(input.contrast())
        if contrast is None:
            return frame.iloc[:0]
        pairs = contrast.metadata
        if input.group() != "All mice":
            pairs = pairs.loc[pairs["Bio group"].eq(input.group())]
        left = values.loc[:, pairs["Sample A"]].set_axis(pairs["Sample"], axis=1)
        right = values.loc[:, pairs["Sample B"]].set_axis(pairs["Sample"], axis=1)
        frame["Mean normalized log₂ abundance"] = frame["Feature"].map(((left + right) / 2).mean(axis=1))
        return compute.highlight(filter_classes(frame, input.classes()), input.threshold(), input.lfc(), input.evidence())

    @reactive.calc
    def figure():
        figure = plots.volcano(table(), input.evidence(), input.color(), input.highlight(), input.kind() == "MA")
        return figure.update_layout(title=f"{input.contrast()} · {input.group()}<br>{input.evidence()} ≤ {input.threshold():.3f}; |effect| ≥ {input.lfc():.2f}")

    view_server("view", table, lambda: fitted()[1], figure, export=True)
