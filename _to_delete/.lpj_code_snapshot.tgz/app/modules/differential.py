from shiny import module, reactive, ui

from app import compute, registry
from app.modules.common import MODEL, banner, class_choices, filter_classes, thresholds, view_ui, view_server


@module.ui
def differential_ui():
    return ui.TagList(banner(), ui.p(MODEL),
        ui.layout_sidebar(ui.sidebar(
            ui.input_select("region", "Region", registry.REGIONS),
            ui.input_select("effect", "Effect", registry.EFFECT_CHOICES), thresholds()),
            ui.p("Population is controlled by Select samples. Thresholds only highlight; filtering never changes BH."), view_ui("view", plot=False, highlighted=True)))


@module.server
def differential_server(input, output, session, modality, samples, used):
    class_choices(input, modality, used)

    @reactive.calc
    def fitted():
        return compute.differential(modality(), samples(), used)

    @reactive.calc
    def table():
        frame = fitted()[0]
        if frame.empty:
            return frame
        frame = frame.loc[frame["Region"].eq(input.region()) & frame["Effect"].eq(input.effect())]
        return compute.highlight(filter_classes(frame, input.classes()), input.threshold(), input.lfc(), input.evidence())

    view_server("view", table, lambda: compute.effect_badge(fitted()[1], input.effect()))
