import numpy as np
import pandas as pd
import plotly.express as px
from shiny import module, reactive, render, ui
from shinywidgets import output_widget, render_widget

from app import compute, data, outliers, plots, registry
from app.modules.common import banner, display_frame


@module.ui
def sample_overview_ui():
    return ui.TagList(
        banner("PCA is recomputed descriptively on complete, varying features, autoscaled across selected samples. No imputation. Top-variable ranking precedes scaling; ellipses describe data dispersion, not group tests."),
        ui.layout_columns(
            ui.input_select("scope", "PCA scope", ["pooled", *registry.REGIONS]),
            ui.input_select("color", "Colour by", ["Sample type", "Bio group", "Sex", "Cage", "Date collected", "T²-95 flag", "T²-99 flag"]),
            ui.input_select("x", "X PC", [f"PC {n}" for n in range(1, 6)]),
            ui.input_select("y", "Y PC", [f"PC {n}" for n in range(1, 6)], selected="PC 2"),
            col_widths=[3, 3, 3, 3]),
        ui.input_slider("top", "Maximum top-variable complete features", min=10, max=1500, value=1500, step=10),
        ui.input_checkbox("ellipses", "95% normal-theory data ellipses", False), ui.input_checkbox("labels", "Sample labels", False),
        ui.output_text("badge"),
        ui.layout_columns(output_widget("scores"), output_widget("attribution")),
        ui.h4("Per-sample distributions and QC"),
        ui.p("Uses the PCA scope above (pooled = all selected samples). Values are median-normalized log₂ "
             "abundances of the retained panel, so sample medians are aligned by construction; spread (IQR), "
             "missingness and the region-wise robust z-scores are the informative columns. Pre-normalization "
             "signal is not shown: the app does not read the raw workbook.", class_="help-note"),
        ui.input_radio_buttons("dist_color", "Colour boxes by", ["Bio group", "Sex", "Sample type", "Cage", "Any flag"], inline=True),
        output_widget("distributions"), output_widget("missingness"),
        ui.download_button("qc_csv", "Download per-sample QC table"),
        ui.output_data_frame("qc_table"),
    )


def sample_qc(values: pd.DataFrame, metadata: pd.DataFrame, flags: dict) -> pd.DataFrame:
    """Per-sample summary of the normalized retained panel, with region-wise robust z-scores."""
    stats = pd.DataFrame({
        "Sample": values.columns,
        "Features observed": values.notna().sum().to_numpy(),
        "Missing %": (100 * values.isna().mean()).to_numpy(),
        "Median log₂": values.median().to_numpy(),
        "IQR log₂": (values.quantile(.75) - values.quantile(.25)).to_numpy(),
        "Mean log₂": values.mean().to_numpy(),
    })
    columns = ["Sample", "Sample number", "Sample type", "Mouse number", "Bio group", "Sex", "Cage", "Date collected"]
    frame = metadata[[c for c in columns if c in metadata]].merge(stats, on="Sample", validate="one_to_one")
    for column in ("IQR log₂", "Missing %"):
        grouped = frame.groupby("Sample type")[column]
        mad = grouped.transform(lambda x: 1.4826 * (x - x.median()).abs().median()).replace(0, np.nan)
        frame[f"{column} robust z (region)"] = (frame[column] - grouped.transform("median")) / mad
    for name, flagged in flags.items():
        frame[name] = flagged(frame)
    frame["Any flag"] = frame[list(flags)].any(axis=1)
    order = {"Cerebellum": 0, "Cortex": 1, "Hippocampus": 2}
    return frame.assign(_r=frame["Sample type"].map(order)).sort_values(
        ["_r", "Bio group", "Sex", "Sample number"], ascending=[True, False, True, True]).drop(columns="_r").reset_index(drop=True)


@module.server
def sample_overview_server(input, output, session, modality, samples, used):
    @reactive.calc
    def result():
        try:
            return compute.pca(modality(), samples(), input.scope(), input.top(), used)
        except ValueError as error:
            return str(error)

    @render.text
    def badge():
        current = result()
        return data.badge(modality(), samples(), used=used) + (f"; PCA: {current[3]} complete features" if not isinstance(current, str) else "; " + current)

    @render_widget
    def scores():
        current = result()
        if isinstance(current, str):
            return plots.empty(current)
        frame, variance, _, _ = current
        frame = frame.copy()
        sets = data.sample_sets(modality(), used)
        for level in (95, 99):
            frame[f"T²-{level} flag"] = (~frame.index.isin(sets[f"t2_{level}"])).astype(str)
        return plots.pca(frame, variance, input.x(), input.y(), input.color(), input.ellipses(), input.labels())

    @render_widget
    def attribution():
        current = result()
        return plots.empty(current) if isinstance(current, str) else plots.attribution(current[2])

    @reactive.calc
    def qc():
        values, metadata = data.selected_inputs(modality(), samples(), used)
        if values.empty:
            return pd.DataFrame()
        if input.scope() != "pooled":
            metadata = metadata.loc[metadata["Sample type"].eq(input.scope())]
            values = values.loc[:, metadata["Sample"]]
        sets = data.sample_sets(modality(), used)
        candidates = outliers.region_candidate_numbers(used)
        flags = {"T²-95 flag": lambda f: ~f["Sample"].isin(sets["t2_95"]),
                 "T²-99 flag": lambda f: ~f["Sample"].isin(sets["t2_99"]),
                 "Ensemble candidate": lambda f: f["Sample number"].isin(candidates)}
        return sample_qc(values, metadata, flags)

    @render_widget
    def distributions():
        table = qc()
        if table.empty:
            return plots.empty("No samples selected.")
        values, _ = data.selected_inputs(modality(), samples(), used)
        order = list(table["Sample"])
        frame = values.loc[:, order].melt(var_name="Sample", value_name="Normalized log₂ abundance").dropna()
        color = input.dist_color()
        frame = frame.merge(table[["Sample", color]].astype({color: str}), on="Sample")
        figure = px.box(frame, x="Sample", y="Normalized log₂ abundance", color=color, points=False,
                        category_orders={"Sample": order}, color_discrete_map=plots.COLORS,
                        color_discrete_sequence=plots.COLORBLIND_COLORS)
        figure.update_xaxes(tickangle=-60, tickfont=dict(size=9))
        return plots.finish(figure, "Per-sample distributions (observed values) · ordered by region, group, sex")

    @render_widget
    def missingness():
        table = qc()
        if table.empty:
            return plots.empty("No samples selected.")
        figure = px.bar(table, x="Sample", y="Missing %", color=table[input.dist_color()].astype(str),
                        category_orders={"Sample": list(table["Sample"])}, range_y=[0, 100],
                        color_discrete_map=plots.COLORS, color_discrete_sequence=plots.COLORBLIND_COLORS)
        figure.update_xaxes(tickangle=-60, tickfont=dict(size=9))
        return plots.finish(figure, "Post-preprocessing missingness · retained panel")

    @render.data_frame
    def qc_table():
        return render.DataGrid(display_frame(qc()), filters=True, height="430px")

    @render.download_button(filename=lambda: f"sample_qc_{modality()}_{input.scope()}.csv")
    def qc_csv():
        yield qc().to_csv(index=False)
