from io import BytesIO
from zipfile import ZipFile

from shiny import module, render, ui

from app import compute, data
from app.modules.common import DESIGN, MODEL


@module.ui
def provenance_ui():
    return ui.TagList(ui.h3("Data & provenance"),
        ui.p("Downloads are generated in memory. The running app never writes data/ or results/. Files below are those actually read by this session, with modification times and the nearest registered provenance record. Missing commits stay unrecorded; the current Git HEAD is never substituted for an old source."),
        ui.download_button("matrix", "Selected matrix CSV"), ui.download_button("metadata", "Selected metadata CSV"),
        ui.download_button("results", "Current differential + paired comparisons ZIP"),
        ui.p("The result download uses full statsmodels fitting for a custom selection (may take ~36 s); saved results are downloaded directly."),
        ui.input_action_button("refresh", "Refresh source audit"), ui.download_button("audit", "Source audit CSV"),
        ui.output_data_frame("sources"))


@module.server
def provenance_server(input, output, session, modality, samples, used):
    @render.download_button(filename="selected_matrix.csv")
    def matrix():
        values, _ = data.selected_inputs(modality(), samples(), used)
        yield values.to_csv(index_label="Feature")

    @render.download_button(filename="selected_metadata.csv")
    def metadata():
        _, frame = data.selected_inputs(modality(), samples(), used)
        yield frame.to_csv(index=False)

    @render.download_button(filename="explorer_results.zip")
    def results():
        memory = BytesIO()
        badges = []
        with ZipFile(memory, "w") as archive:
            differential, badge = compute.differential(modality(), samples(), used, full=True)
            archive.writestr("differential.csv", differential.to_csv(index=False))
            badges.append(badge)
            for group in ("Saline Control", "MIA", "All mice"):
                table, badge = compute.regional(modality(), samples(), group, used)
                archive.writestr(f"regional_{group.replace(' ', '_')}.csv", table.to_csv(index=False))
                badges.append(badge)
            if compute.persistence_available(modality(), samples(), used):
                tables, badge = compute.persistence(modality(), samples(), used)
                for name, table in tables.items():
                    archive.writestr(f"persistence_{name}.csv", table.to_csv(index=False))
                badges.append(badge)
            archive.writestr("context.txt", "\n".join([modality(), DESIGN, MODEL, *badges]))
            archive.writestr("source_audit.csv", data.source_table(used).to_csv(index=False))
        yield memory.getvalue()

    @render.data_frame
    def sources():
        input.refresh()
        return render.DataGrid(data.source_table(used), filters=True)

    @render.download_button(filename="source_audit.csv")
    def audit():
        yield data.source_table(used).to_csv(index=False)
