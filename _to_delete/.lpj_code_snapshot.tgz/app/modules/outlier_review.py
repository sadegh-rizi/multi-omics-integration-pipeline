"""Outlier review: detector ensemble, per-detector parameter sweeps, and the per-region T²/DModX screens."""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from shiny import module, reactive, render, ui

from app import ROOT, compute, data, outliers as ens, plots, registry
from app.modules.common import banner, display_frame, view_ui, view_server
from lpj_lipidomics.multivariate.pca import fit_pca
from lpj_lipidomics.outliers.screen import sample_outlier_table
from lpj_lipidomics.preprocessing import autoscale

REVIEW = ("Flags prioritize review, not sample failure. Every screen here is label-blind and uses all 60 samples. "
          "About 5% of samples are flagged at a 95% limit by construction. Nothing on this tab changes the sample "
          "selection. The permitted exclusions remain none, T²-95 or T²-99.")
RULE = ("Ensemble rule (pre-declared): a detector is stable for a sample when it flags it at the 95% null limit in "
        "≥60% of its counted settings (all parameters × representations in that scope and calibration stage). "
        "A candidate needs, under stage-2 (trimmed) calibration, ≥2 stable counted detectors, ≥1 of them "
        "non-covariance (kNN isotropic, LOF, isolation forest, kernel PCA). The trinity-mean ensemble flag must "
        "also be the same at stage 1 and stage 2; otherwise the sample is calibration-sensitive. "
        "lof_supporting is shown but not counted. Pooled scope mixes regions and is invalid for the region design.")
PERCENTILE_SCALE = [[0, "#f7f7f7"], [0.80, "#fee8c8"], [0.95, "#fc8d59"], [0.99, "#d7301f"], [1, "#7f0000"]]
FLAG_SCALE = [[0, "#f0f0f0"], [0.5, "#f0f0f0"], [0.5, "#D55E00"], [1, "#D55E00"]]
STABILITY_SCALE = [[0, "#f7f7f7"], [0.599, "#c6dbef"], [0.6, "#fd8d3c"], [1, "#a63603"]]


def _scope_select(id_, scopes, selected="cortex"):
    choices = {scope: ens.SCOPES[scope] for scope in scopes}
    return ui.input_select(id_, "Scope", choices, selected=selected if selected in choices else scopes[0])


def _height(rows: int) -> int:
    return max(420, 140 + 22 * rows)


# ---------------------------------------------------------------- per-detector sweep

@module.ui
def detector_ui(detector: str):
    label, description = ens.DETECTORS[detector]
    if not ens.available():
        return ui.p("Detector-ensemble outputs are missing; run the ensemble runner first.")
    options = ens.options(detector)
    representations = {"all": "All (the pool behind the stability fraction)", **{r: r for r in options["representation"]}}
    return ui.TagList(
        ui.p(ui.strong(label + ". "), description),
        ui.layout_columns(
            _scope_select("scope", options["scope"]),
            ui.input_select("stage", "Calibration", ens.STAGES),
            ui.input_select("representation", "Representation", representations),
            ui.input_select("value", "Show", ens.VALUES),
            ui.input_radio_buttons("kind", "View", {"heatmap": "Sample × setting heatmap", "curves": "Sweep curves"}),
            col_widths=[3, 3, 2, 2, 2]),
        ui.p("Rows are sorted by the fraction of counted settings flagged at 95%. ★ marks the final ensemble "
             "candidates in this scope; ◆ marks the representative setting that feeds the ensemble percentiles. "
             "The table's fraction_flag_95 reproduces the saved stability fraction.", class_="help-note"),
        view_ui("view"),
        ui.h5("Null calibration for these settings"),
        ui.p("Limits come from label-free null replicates. The false-positive rate is the share of null samples "
             "beyond the 95% limit, so it should be near 0.05.", class_="help-note"),
        ui.output_data_frame("limits"),
        ui.TagList(ui.h5("Seed-to-seed rank ranges (50 seeds)"), ui.output_data_frame("ranks"))
        if detector == "isolation_forest" else None,
    )


@module.server
def detector_server(input, output, session, detector: str, used):
    @reactive.calc
    def sweep():
        return ens.detector_sweep(detector, input.scope(), input.stage(), input.representation(), used)

    @reactive.calc
    def summary():
        return ens.sweep_summary(sweep(), detector, input.scope(), input.stage(), used)

    @reactive.calc
    def badge():
        path = ens.ENSEMBLE / "detector_scores_long.csv"
        text = data.badge("lipidomics", (), path, used)
        note = " · pooled scope is invalid for the region design" if input.scope() == "pooled" else ""
        return text + f" · {ens.STAGES[input.stage()]}{note}"

    @reactive.calc
    def figure():
        current, table = sweep(), summary()
        if current.empty:
            return plots.empty("No saved settings for this detector, scope and representation.")
        candidates = set(table.loc[table["ensemble candidate"].fillna(False), "Label"])
        order = list(table["Label"])
        value = input.value()
        title = f"{ens.DETECTORS[detector][0]} · {ens.SCOPES[input.scope()].split(' —')[0]} · {ens.VALUES[value]}"
        representative = ens.setting_label(detector, input.scope(), used)
        if input.kind() == "heatmap":
            matrix = ens.sweep_matrix(current, value).reindex(order)
            ylabels = [f"{label} ★" if label in candidates else label for label in matrix.index]
            xlabels = [f"{column} ◆" if column == representative else column for column in matrix.columns]
            scale = {"null_percentile": PERCENTILE_SCALE, "score": "Viridis"}.get(value, FLAG_SCALE)
            bounds = {"zmin": 0, "zmax": 1} if value != "score" else {}
            figure = go.Figure(go.Heatmap(
                z=matrix.to_numpy(), x=xlabels, y=ylabels, colorscale=scale, **bounds,
                hovertemplate="%{y}<br>%{x}<br>" + ens.VALUES[value] + ": %{z:.4g}<extra></extra>"))
            figure.update_yaxes(autorange="reversed", tickfont=dict(size=10))
            figure.update_xaxes(tickangle=-60, tickfont=dict(size=9))
            figure = plots.finish(figure, title)
            figure.update_layout(height=_height(len(matrix)), margin=dict(l=130, b=150))
            return figure
        frame = current.copy()
        frame["Candidate"] = frame["Label"].isin(candidates).map({True: "Ensemble candidate", False: "Other"})
        y = value if value != "score" else "score"
        frame[y] = frame[y].astype(float)
        figure = px.line(frame, x="Parameter", y=y, color="Label", line_dash="Candidate",
                         facet_col="representation" if frame["representation"].nunique() > 1 else None,
                         markers=True, hover_data=["Sample", "Setting", "null_percentile"],
                         category_orders={"Label": order})
        for trace in figure.data:
            if trace.name.split(",")[0] not in candidates:
                trace.update(line=dict(color="#bdbdbd", width=1), marker=dict(color="#bdbdbd", size=4), opacity=0.7)
        if value == "null_percentile":
            figure.add_hline(y=0.95, line_dash="dash", annotation_text="95%")
            figure.add_hline(y=0.99, line_dash="dot", annotation_text="99%")
        figure.update_xaxes(type="category")
        figure = plots.finish(figure, title + " · candidates coloured, others grey")
        figure.update_layout(height=620)
        return figure

    @render.data_frame
    def limits():
        frame = ens.null_limits(detector, input.scope(), input.stage(), used)
        if input.representation() != "all":
            frame = frame.loc[frame["representation"].eq(input.representation())]
        return render.DataGrid(display_frame(frame), filters=True, height="300px")

    if detector == "isolation_forest":
        @render.data_frame
        def ranks():
            return render.DataGrid(display_frame(ens.rank_ranges(input.scope(), used)), filters=True, height="300px")

    view_server("view", summary, badge, figure)


# ---------------------------------------------------------------- ensemble verdict

@module.ui
def ensemble_ui():
    if not ens.available():
        return ui.p("Detector-ensemble outputs are missing; run the ensemble runner first.")
    return ui.TagList(
        ui.p(RULE, class_="help-note"),
        ui.h5("Candidates in every scope"),
        ui.output_data_frame("by_scope"),
        ui.layout_columns(
            _scope_select("scope", list(ens.SCOPES)),
            ui.input_select("stage", "Calibration (heatmap)", ens.STAGES),
            ui.input_radio_buttons("kind", "View", {
                "stability": "Stability: sample × detector",
                "corroboration": "Corroboration counts",
                "trinity": "Ensemble percentile, stage 1 vs 2"}),
            col_widths=[3, 4, 5]),
        view_ui("view"),
        ui.h5("Ensemble null limits"),
        ui.output_data_frame("ensemble_limits"),
        ui.h5("Distance concentration (relative contrast, k = 2)"),
        ui.p("Values near 1 mean nearest and farthest neighbours are almost equally far, so distance-based "
             "detectors lose resolution. Raw space is concentrated, which is why the kNN, LOF and kernel "
             "detectors run in 3–10 PCs.", class_="help-note"),
        ui.output_data_frame("concentration"),
    )


@module.server
def ensemble_server(input, output, session, used):
    @render.data_frame
    def by_scope():
        frame = ens.candidates_by_scope(used).rename(columns={"Stage-2 rule only": "Stage-2 rule met, calibration-sensitive"})
        return render.DataGrid(frame, height=None)

    @reactive.calc
    def verdict():
        return ens.verdict(input.scope(), used)

    @reactive.calc
    def badge():
        text = data.badge("lipidomics", (), ens.ENSEMBLE / "ensemble_verdict.csv", used)
        return text + (" · pooled scope is invalid for the region design" if input.scope() == "pooled" else "")

    @reactive.calc
    def figure():
        table = verdict()
        candidates = set(table.loc[table["candidate_outlier"], "Sample"])
        labels = table.set_index("Sample")["Label"]
        scope_name = ens.SCOPES[input.scope()].split(" —")[0]
        if input.kind() == "stability":
            matrix = ens.stability_matrix(input.scope(), input.stage(), used)
            matrix = matrix.reindex(table["Sample"])
            ylabels = [f"{labels[s]} ★" if s in candidates else labels[s] for s in matrix.index]
            xlabels = [f"{c} (not counted)" if c in ens.NOT_COUNTED else (f"{c} ·nc" if c in ens.NON_COVARIANCE else c)
                       for c in matrix.columns]
            figure = go.Figure(go.Heatmap(
                z=matrix.to_numpy(), x=xlabels, y=ylabels, zmin=0, zmax=1, colorscale=STABILITY_SCALE,
                text=matrix.round(2).to_numpy(), texttemplate="%{text}", textfont=dict(size=9),
                hovertemplate="%{y}<br>%{x}<br>stability fraction %{z:.3f}<extra></extra>"))
            figure.update_yaxes(autorange="reversed", tickfont=dict(size=10))
            figure = plots.finish(figure, f"Stability fraction · {scope_name} · {ens.STAGES[input.stage()].split(' —')[0]}"
                                  " · orange = stable (≥0.60) · ·nc = non-covariance · ★ candidate")
            figure.update_layout(height=_height(len(matrix)), margin=dict(l=130))
            return figure
        if input.kind() == "corroboration":
            frame = table.assign(Verdict=table["candidate_outlier"].map({True: "Candidate", False: "Not a candidate"}))
            frame.loc[frame["calibration_sensitive"], "Verdict"] = "Calibration-sensitive"
            figure = px.strip(frame, x="stable_detector_count", y="stable_non_covariance_count", color="Verdict",
                              hover_data=["Label", "Sample", "trinity_mean_stage2", "hotelling_t2"],
                              color_discrete_map={"Candidate": "#D55E00", "Not a candidate": "#999999",
                                                  "Calibration-sensitive": "#0072B2"})
            figure.add_vrect(x0=1.5, x1=max(2.5, frame["stable_detector_count"].max() + 0.5), y0=0, y1=1,
                             fillcolor="#D55E00", opacity=0.06, line_width=0)
            figure.update_xaxes(title="Stable counted detectors (stage 2)", dtick=1)
            figure.update_yaxes(title="…of which non-covariance", dtick=1)
            return plots.finish(figure, f"Corroboration · {scope_name} · shaded = ≥2 detectors")
        frame = table.copy()
        frame["Verdict"] = frame["candidate_outlier"].map({True: "Candidate", False: "Not a candidate"})
        frame.loc[frame["calibration_sensitive"], "Verdict"] = "Calibration-sensitive"
        figure = px.scatter(frame, x="trinity_mean_stage1", y="trinity_mean_stage2", color="Verdict", text="Label",
                            hover_data=["Sample", "stable_detector_count", "hotelling_t2"],
                            color_discrete_map={"Candidate": "#D55E00", "Not a candidate": "#999999",
                                                "Calibration-sensitive": "#0072B2"})
        figure.update_traces(textposition="top center", textfont=dict(size=9))
        limits = ens.read("ensemble_null_limits.csv", used)
        limits = limits.loc[limits["scope"].eq(input.scope()) & limits["combination"].eq("trinity_mean")]
        for stage, axis in (("contaminated", "x"), ("trimmed", "y")):
            value = limits.loc[limits["calibration_stage"].eq(stage), "limit_95"]
            if not value.empty:
                (figure.add_vline if axis == "x" else figure.add_hline)(value.iloc[0], line_dash="dash",
                                                                         annotation_text=f"95% limit, {stage}")
        figure.update_xaxes(title="Trinity mean percentile, stage 1 (contaminated)")
        figure.update_yaxes(title="Trinity mean percentile, stage 2 (trimmed)")
        return plots.finish(figure, f"Ensemble percentile · {scope_name} · off-diagonal flag change = calibration-sensitive")

    @render.data_frame
    def ensemble_limits():
        frame = ens.read("ensemble_null_limits.csv", used)
        return render.DataGrid(display_frame(frame.loc[frame["scope"].eq(input.scope())]), height="230px")

    @render.data_frame
    def concentration():
        return render.DataGrid(display_frame(ens.read("distance_concentration_diagnostic.csv", used)), height="230px")

    view_server("view", verdict, badge, figure)


# ---------------------------------------------------------------- per-region screens (unchanged behaviour)

@module.ui
def screens_ui():
    return ui.TagList(
        ui.input_checkbox("difference", "Difference-space screen + two-contrast attribution (proposed, not a permitted exclusion)", False),
        ui.input_checkbox("live", "Recompute per-region diagnostics with the current package (includes robust distance and 99% limits)", False),
        ui.layout_columns(ui.input_select("region", "Region", registry.REGIONS),
            ui.input_select("metric", "Diagnostic", {"hotelling_t2": "Hotelling T²", "robust_mahalanobis": "Robust Mahalanobis", "dmodx": "DModX"})),
        view_ui("view"), ui.h4("Difference-space attribution (diagnosis only)"), ui.output_data_frame("attribution"))


@module.server
def screens_server(input, output, session, modality, used):
    @reactive.calc
    def result():
        if input.difference():
            table, attribution = compute.difference_screen(modality(), used)
            return table, "Recomputed — exploratory; all 60; difference-space screen is proposed, not a permitted exclusion", attribution
        if input.live():
            values, metadata = data.inputs(modality(), used=used)
            metadata = metadata.loc[metadata["Sample type"].eq(input.region())]
            complete = values.loc[:, metadata["Sample"]].dropna()
            scaled = autoscale(complete.loc[complete.var(axis=1).gt(0)])
            model, scores, _ = fit_pca(scaled, n_components=3)
            frame = sample_outlier_table(scaled, model, scores).rename_axis("Sample").reset_index()
            frame = frame.merge(metadata, on="Sample", validate="one_to_one")
            return frame, "Recomputed — exploratory; label-blind all-60 input, 3 PCs per region; presets still use the reviewed saved flags", pd.DataFrame()
        tree = "mia_vs_control" if modality() == "lipidomics" else "metabolomics"
        path = ROOT / "results" / tree / "02_qc" / f"outlier_screen_{input.region().lower()}.csv"
        if not path.exists():
            return pd.DataFrame(), "No saved screen; enable recompute.", pd.DataFrame()
        frame = data.read_csv(path, used)
        if "Sample" not in frame:
            frame = frame.rename(columns={frame.columns[0]: "Sample"})
        return frame, data.badge(modality(), data.sample_sets(modality(), used)["all60"], path, used), pd.DataFrame()

    @reactive.calc
    def figure():
        frame = result()[0]
        metric = "hotelling_t2" if input.difference() else input.metric()
        if metric not in frame:
            return plots.empty("Metric absent from this historical screen; enable recompute for full current diagnostics.")
        x = "Mouse number" if input.difference() else "Sample"
        figure = px.scatter(frame, x=x, y=metric, color="Contrast" if input.difference() else None,
                            hover_data=[column for column in ("Mouse number", "Bio group", "Sex") if column in frame])
        for level in (95, 99):
            column = f"{metric}_{level}_limit"
            if column in frame and frame[column].nunique() == 1:
                figure.add_hline(y=frame[column].iloc[0], line_dash="dash", annotation_text=f"{level}% limit")
        return plots.finish(figure, "Fixed-population outlier diagnostics · review flags, not failures")

    @render.data_frame
    def attribution():
        return render.DataGrid(result()[2], filters=True)

    view_server("view", lambda: result()[0], lambda: result()[1], figure)


# ---------------------------------------------------------------- tab

@module.ui
def outlier_ui():
    return ui.TagList(
        banner(REVIEW),
        ui.output_text("modality_note"),
        ui.navset_card_tab(
            ui.nav_panel("Ensemble", ensemble_ui("ensemble")),
            ui.nav_panel("Detector sweeps", ui.navset_card_tab(
                *[ui.nav_panel(ens.DETECTORS[name][0], detector_ui(name, detector=name)) for name in ens.DETECTORS],
                id="detector_tabs")),
            ui.nav_panel("Per-region screens (T² / DModX)", screens_ui("screens")),
            id="outlier_tabs"),
    )


@module.server
def outlier_server(input, output, session, modality, samples, used):
    @render.text
    def modality_note():
        if modality() == "metabolomics":
            return ("Ensemble and detector sweeps are the lipidomics screens. Metabolomics analyses apply them by "
                    "sample number, as the persistence pipeline does. The per-region screens follow the modality.")
        return "Ensemble and detector sweeps: lipidomics, all 60 samples, label-blind."

    if ens.available():
        ensemble_server("ensemble", used=used)
        for name in ens.DETECTORS:
            detector_server(name, detector=name, used=used)
    screens_server("screens", modality=modality, used=used)
