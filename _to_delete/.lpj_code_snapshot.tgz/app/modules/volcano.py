"""Volcano and MA plots side by side, with automatic directional labels and per-plot PDF export."""

from shiny import module, reactive, render, ui
from shinywidgets import output_widget, render_widget

from app import compute, data, plots, registry
from app.modules.common import DESIGN, MODEL, banner, class_choices, display_frame, filter_classes, thresholds


@module.ui
def volcano_ui():
    return ui.TagList(banner(), ui.p(MODEL),
        ui.layout_sidebar(ui.sidebar(
            ui.input_select("region", "Region", registry.REGIONS),
            ui.input_select("effect", "Effect", registry.EFFECT_CHOICES),
            thresholds(),
            ui.input_checkbox("auto_labels", "Auto labels: top 10 up + top 10 down", True),
            ui.p("Auto labels rank positive and negative effects separately by the displayed evidence (q or raw p), "
                 "then raw p and |effect| to break ties. They are the best-ranked features in each direction, not necessarily "
                 "features passing the threshold.", class_="help-note")),
            ui.output_text("badge"),
            ui.layout_columns(output_widget("volcano_plot"), output_widget("ma_plot"), col_widths=[6, 6]),
            ui.layout_columns(
                ui.download_button("volcano_pdf", "Volcano PDF"), ui.download_button("ma_pdf", "MA PDF"),
                ui.download_button("table_csv", "Download complete table"),
                ui.download_button("highlighted_csv", "Download highlighted features only"),
                col_widths=[2, 2, 4, 4]),
            ui.output_data_frame("table")))


@module.server
def volcano_server(input, output, session, modality, samples, used):
    class_choices(input, modality, used)

    @reactive.calc
    def fitted():
        return compute.differential(modality(), samples(), used)

    @reactive.calc
    def rows():
        frame = fitted()[0]
        if frame.empty:
            return frame
        frame = frame.loc[frame["Region"].eq(input.region()) & frame["Effect"].eq(input.effect())].copy()
        values, metadata = data.selected_inputs(modality(), samples(), used)
        ids = metadata.loc[metadata["Sample type"].eq(input.region()), "Sample"]
        frame["Mean normalized log₂ abundance"] = frame["Feature"].map(values.loc[:, ids].mean(axis=1))
        return compute.highlight(filter_classes(frame, input.classes()), input.threshold(), input.lfc(), input.evidence())

    @reactive.calc
    def badge_text():
        return compute.effect_badge(fitted()[1], input.effect())

    @reactive.calc
    def auto():
        return compute.directional_top(rows(), input.evidence(), 10) if input.auto_labels() else []

    def title():
        return (f"{input.region()} · {registry.EFFECT_CHOICES[input.effect()]}<br>"
                f"{input.evidence()} ≤ {input.threshold():.3f}; |effect| ≥ {input.lfc():.2f}")

    @reactive.calc
    def volcano_figure():
        figure = plots.volcano(rows(), input.evidence(), input.color(), input.highlight(), False, auto())
        return figure.update_layout(title=title())

    @reactive.calc
    def ma_figure():
        figure = plots.volcano(rows(), input.evidence(), input.color(), input.highlight(), True, auto())
        return figure.update_layout(title=title())

    @render.text
    def badge():
        return badge_text()

    @render_widget
    def volcano_plot():
        return volcano_figure()

    @render_widget
    def ma_plot():
        return ma_figure()

    @render.data_frame
    def table():
        return render.DataGrid(display_frame(rows()), filters=True, height="430px")

    def context():
        return "\n".join([badge_text(), DESIGN])

    @render.download_button(filename=lambda: f"volcano_{input.region()}_{input.effect()}.pdf".replace(" ", "_"))
    def volcano_pdf():
        yield plots.figure_pdf(volcano_figure(), context())

    @render.download_button(filename=lambda: f"ma_{input.region()}_{input.effect()}.pdf".replace(" ", "_"))
    def ma_pdf():
        yield plots.figure_pdf(ma_figure(), context())

    @render.download_button(filename="volcano_table.csv")
    def table_csv():
        yield rows().to_csv(index=False)

    @render.download_button(filename="volcano_highlighted_features.csv")
    def highlighted_csv():
        yield compute.highlighted_only(rows()).to_csv(index=False)
