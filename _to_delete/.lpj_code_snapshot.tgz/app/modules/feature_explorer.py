import pandas as pd
from shiny import module, reactive, ui

from app import data, outliers, plots, registry
from app.modules.common import view_ui, view_server


MARKS = {"none": "None", "T²-95 flag": "T²-95 flag (reviewed screen)", "T²-99 flag": "T²-99 flag (reviewed screen)",
         "Ensemble candidate": "Detector-ensemble candidate (own region)", "Any flag": "Any of these"}


@module.ui
def feature_ui():
    return ui.TagList(ui.h3("Lipid / metabolite explorer"),
        ui.layout_columns(ui.input_selectize("category", "Class / acquisition method", []),
                          ui.input_selectize("feature", "Search feature name", []),
                          ui.input_checkbox("class_mean", "Show class / method mean instead", False)),
        ui.layout_columns(ui.input_select("mark", "Mark flagged samples", MARKS),
                          ui.input_checkbox("mark_labels", "Label marked samples with their sample number", True)),
        ui.p("Class view = unweighted mean of observed normalized log₂ features per sample. For metabolomics this groups acquisition methods, not biological classes. The value table preserves missing samples."),
        view_ui("view"))


@module.server
def feature_server(input, output, session, modality, samples, used):
    @reactive.effect
    def categories():
        classes = sorted(data.annotations(modality(), used)["Class / method"].dropna().unique())
        ui.update_selectize("category", choices=classes, selected=classes[0] if classes else None)

    @reactive.effect
    def features():
        annotations = data.annotations(modality(), used)
        annotations = annotations.loc[annotations["Class / method"].eq(input.category())]
        choices = dict(zip(annotations["Feature"], annotations["Name"] + " [" + annotations["Feature"] + "]"))
        ui.update_selectize("feature", choices=choices, selected=next(iter(choices), None))

    @reactive.calc
    def table():
        values, metadata = data.selected_inputs(modality(), samples(), used)
        annotations = data.annotations(modality(), used).set_index("Feature")
        if input.class_mean():
            ids = annotations.index[annotations["Class / method"].eq(input.category())].intersection(values.index)
            profile = values.loc[ids].mean(axis=0)
        elif input.feature() in values.index:
            profile = values.loc[input.feature()]
        else:
            return pd.DataFrame()
        frame = metadata.copy()
        frame["Value"] = frame["Sample"].map(profile)
        sets = data.sample_sets(modality(), used)
        frame["T²-95 flag"] = ~frame["Sample"].isin(sets["t2_95"])
        frame["T²-99 flag"] = ~frame["Sample"].isin(sets["t2_99"])
        frame["Ensemble candidate"] = frame["Sample number"].isin(outliers.region_candidate_numbers(used))
        frame["Any flag"] = frame[["T²-95 flag", "T²-99 flag", "Ensemble candidate"]].any(axis=1)
        frame["Sample type"] = pd.Categorical(frame["Sample type"], ["Cerebellum", "Hippocampus", "Cortex"], ordered=True)
        return frame.sort_values(["Mouse number", "Sample type"])

    @reactive.calc
    def figure():
        annotations = data.annotations(modality(), used).set_index("Feature")
        title = str(input.category()) + " mean" if input.class_mean() else str(annotations.loc[input.feature(), "Name"]) if input.feature() in annotations.index else "Feature"
        return plots.feature(table(), title, None if input.mark() == "none" else input.mark(), input.mark_labels())

    def badge():
        if input.class_mean():
            return "Descriptive class / method mean · " + data.badge(modality(), samples(), used=used)
        return data.badge(modality(), samples(), registry.source(modality(), "all60", "matrix"), used) + f"; displaying {len(samples())} selected samples"

    view_server("view", table, badge, figure)
