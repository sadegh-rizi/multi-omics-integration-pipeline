"""Read-only local explorer; use the repository package without installation."""

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

# Service accounts (e.g. Shiny Server's `shiny` user) often have no writable
# home; give matplotlib a private cache instead of a warning on every start.
if "MPLCONFIGDIR" not in os.environ and not os.access(Path.home(), os.W_OK):
    os.environ["MPLCONFIGDIR"] = tempfile.mkdtemp(prefix="lpj-explorer-mpl-")
