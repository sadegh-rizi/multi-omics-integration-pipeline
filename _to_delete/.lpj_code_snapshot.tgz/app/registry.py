"""Explicit allow-list of reviewed populations and result sources.

No directory supplied by a browser is opened. Even resolved symlinks must
remain within a permitted source. Historical 57-sample trees are not sources.
"""

from pathlib import Path

from app import ROOT

MODALITIES = ("lipidomics", "metabolomics")
POPULATIONS = {"all60": "All 60", "t2_95": "Remove T²-95 samples", "t2_99": "Remove T²-99 samples"}
VARIANTS = {"all60": "prevalence20_noexclusion", "t2_95": "prevalence20_t2_95", "t2_99": "prevalence20_t2_99"}
REGIONAL_VARIANTS = {"all60": "prevalence20_noexclusion", "t2_95": "prevalence20_hotelling95", "t2_99": "prevalence20_hotelling99"}
REGIONS = ("Cerebellum", "Cortex", "Hippocampus")
EFFECTS = ("MIA vs Saline Control", "Female vs Male", "MIA x Female interaction")
# Further contrasts of the same fitted model (coefficients: intercept, MIA,
# Female, MIA × Female). The saved pipeline files hold only EFFECTS; these are
# always computed from the same samples with the same OLS fit (c·β, SE from
# c'(X'X)⁻¹c·σ²) and BH-adjusted within Region × Effect like the others.
DERIVED_EFFECTS = {
    "MIA vs Saline Control (female)": (0.0, 1.0, 0.0, 1.0),
    "MIA vs Saline Control (sex-averaged)": (0.0, 1.0, 0.0, 0.5),
}
EFFECT_CHOICES = {
    "MIA vs Saline Control": "MIA vs Control — males (model reference)",
    "MIA vs Saline Control (female)": "MIA vs Control — females",
    "MIA vs Saline Control (sex-averaged)": "MIA vs Control — average of females and males",
    "Female vs Male": "Female vs Male — controls",
    "MIA x Female interaction": "MIA × Female interaction (female − male MIA effect)",
}
PERSISTENCE_FILES = {
    "matrix": "00_inputs/region_input_matrix.csv",
    "metadata": "00_inputs/region_input_metadata.csv",
    "annotations": "01_preprocessing/prevalence_filter_features.csv",
    "regional": "03_differential/within_group_region_tests.csv",
    "interactions": "03_differential/region_interactions.csv",
    "concordance": "02_qc/concordance.csv",
    "reliability": "02_qc/split_half_reliability.csv",
    "disattenuation": "02_qc/disattenuated_concordance.csv",
    "icc": "02_qc/cage_icc.csv",
    "pairing": "02_qc/contrast_pairing.csv",
    "selection": "02_qc/sample_selection.csv",
    "manifest": "manifest.json",
}


def persistence_root(modality: str, population: str, root: Path = ROOT) -> Path:
    if modality not in MODALITIES or population not in POPULATIONS:
        raise ValueError("Population rule: choose a registered modality and all60/T²-95/T²-99 population.")
    return root / "results/mia_vs_control/09_region_persistence" / REGIONAL_VARIANTS[population] / modality


def differential_roots(modality: str, population: str, root: Path = ROOT) -> tuple[Path, ...]:
    persistence_root(modality, population, root)  # validate identifiers
    if modality == "lipidomics":
        return tuple(root / "results" / tree / VARIANTS[population]
                     for tree in ("pipeline_test_rerun", "pipeline_test"))
    return (
        root / "results/explorer_prepared/metabolomics" / VARIANTS[population],
        root.parent / "metabolomics-pipeline/results/metabolomics_pipeline" / VARIANTS[population],
    )


def allowed_paths(root: Path = ROOT) -> set[Path]:
    """Enumerate the complete allow-list, including currently absent files."""
    paths = set()
    for modality in MODALITIES:
        for population in POPULATIONS:
            base = persistence_root(modality, population, root)
            paths.update(base / name for name in PERSISTENCE_FILES.values())
            for base in differential_roots(modality, population, root):
                paths.update(base / name for name in (
                    "00_inputs/differential_input_matrix.csv", "00_inputs/differential_input_metadata.csv",
                    "03_differential/differential_effects.csv", "03_differential/differential_feature_qc.csv",
                    "provenance.json", "run_manifest.json",
                    "06_aggregation/class_aggregate_differential_effects.csv",
                    "06_aggregation/structural_index_differential_effects.csv",
                    "06_aggregation/pathway_differential_effects.csv",
                ))
    paths.add(root / "results/mia_vs_control/09_region_persistence/provenance.json")
    # QC files are explicit exceptions: the per-region screens use all 60.
    for tree in ("mia_vs_control", "metabolomics"):
        paths.update(root / "results" / tree / "02_qc" / f"outlier_screen_{region.lower()}.csv" for region in REGIONS)
    for name in ("technical_vs_biological_variance.csv", "qc_injection_cv.csv", "qc_injection_drift.csv"):
        paths.add(root / "results/mia_vs_control/02_qc" / name)
    for scope in ("techmix", "cerebellum", "cortex", "hippocampus"):
        for kind in ("curve", "thresholds"):
            paths.add(root / "results/mia_vs_control/02_qc/noisyr_work" / f"noisyr_{kind}_{scope}_window99_step20.csv")
    # Sensitivity grid: ensemble verdicts and the prepared outputs written by
    # app/build_multiverse.py. Raw workbooks stay outside the app's reach; only
    # the offline builder reads them.
    # Detector ensemble (Outlier review): saved sweeps, stability, calibration.
    for name in ("ensemble_verdict.csv", "detector_scores_long.csv", "stability_fractions.csv", "null_limits.csv",
                 "ensemble_null_limits.csv", "isolation_forest_rank_ranges.csv",
                 "distance_concentration_diagnostic.csv", "run_metadata.csv", "provenance.json"):
        paths.add(root / "results/mia_vs_control/02_qc/ensemble" / name)
    for modality in MODALITIES:
        for name in ("combinations.csv", "summary.csv", "effects.npz", "outlier_rules.csv",
                     "run_manifest.json", "provenance.json"):
            paths.add(root / "results/explorer_prepared/multiverse" / modality / name)
    return paths


def permitted(path: Path, root: Path = ROOT) -> Path:
    """Reject unknown paths, traversal and redirected files, even if they exist."""
    path = Path(path)
    if not path.is_absolute():
        path = root / path
    lexical = path.absolute()
    if lexical not in allowed_paths(root) or lexical.resolve() != lexical:
        raise ValueError(f"Population rule: source is not permitted: {path}")
    return lexical


def source(modality: str, population: str, kind: str, root: Path = ROOT) -> Path:
    return permitted(persistence_root(modality, population, root) / PERSISTENCE_FILES[kind], root)


def differential_source(modality: str, population: str, root: Path = ROOT) -> Path | None:
    for base in differential_roots(modality, population, root):
        path = permitted(base / "03_differential/differential_effects.csv", root)
        if path.exists():
            return path
    return None
