"""Thin in-memory wrappers around the pipeline's statistical functions.

Thresholds and annotation filters are deliberately absent from cache keys:
they change display, never the fitted panel or the multiple-testing family.
"""

from dataclasses import replace
from functools import lru_cache

import numpy as np
import pandas as pd
from scipy.stats import t

from app import data, registry
from lpj_lipidomics.config import CAGE_ICC_BOOTSTRAPS, CAGE_ICC_RANDOM_SEED
from lpj_lipidomics.preprocessing import autoscale
from lpj_lipidomics.multivariate.pca import fit_pca
from lpj_lipidomics.multivariate.pca_metadata import score_attribution
from lpj_lipidomics.outliers.screen import hotelling_t2
from lpj_lipidomics.statistics.differential import fit_regionwise_differential, _bh_adjust
from lpj_lipidomics.statistics.permutation import ols_t_statistics, _design_matrix
from lpj_lipidomics.statistics.clustered import intraclass_correlation
from lpj_lipidomics.statistics.region_contrast import (
    REGION_CONTRASTS, build_region_contrasts, one_sample_region_tests,
    interaction_tests, apply_interaction_fdr, concordance_summary,
    estimate_split_half_reliability, disattenuated_concordance,
)


def fit_differential(values: pd.DataFrame, metadata: pd.DataFrame, full: bool = False) -> pd.DataFrame:
    """Same saturated model, minimum cell size and all-feature BH as the pipeline.

    Full statsmodels fitting takes ~36 s here. The package's vectorized OLS
    path is used for display; full fitting remains available for downloads.
    CIs use the same residual df and t distribution, never normal intervals.
    """
    if full:
        return fit_regionwise_differential(values, metadata, fdr_denominator="all_features").effects
    result = ols_t_statistics(values, metadata)
    if result.empty:
        return result
    critical = t.ppf(0.975, result["residual_df"])
    result["ci_lower_log2"] = result["estimate_log2"] - critical * result["standard_error"]
    result["ci_upper_log2"] = result["estimate_log2"] + critical * result["standard_error"]
    result["effect_scale"] = "normalized_log2"
    result["fold_change"] = 2 ** result["estimate_log2"]
    result["fdr_denominator"] = len(values)
    result["p_value_fdr"] = np.nan
    for _, indices in result.groupby(["Region", "Effect"], observed=True).groups.items():
        result.loc[indices, "p_value_fdr"] = _bh_adjust(result.loc[indices, "p_value"], len(values))
    return result.merge(_cell_counts(values, metadata), on=["Feature", "Region"], validate="many_to_one")


def _cell_counts(values: pd.DataFrame, metadata: pd.DataFrame) -> pd.DataFrame:
    counts = []
    for region, rows in metadata.groupby("Sample type", sort=False):
        frame = pd.DataFrame({"Feature": values.index, "Region": region})
        for group in ("Saline Control", "MIA"):
            for sex in ("Male", "Female"):
                samples = rows.loc[rows["Bio group"].eq(group) & rows["Sex"].eq(sex), "Sample"]
                frame[f"n_{group.replace(' ', '_').lower()}_{sex.lower()}"] = values.loc[:, samples].notna().sum(axis=1).to_numpy()
        counts.append(frame)
    return pd.concat(counts)


def fit_contrasts(values: pd.DataFrame, metadata: pd.DataFrame, contrasts: dict | None = None,
                  min_per_cell: int = 3) -> pd.DataFrame:
    """Linear contrasts c·β of the pipeline's saturated OLS model, per region and feature.

    Same design (`_design_matrix`), feature-wise missingness, ≥3-per-cell
    eligibility, residual df and t distribution as `ols_t_statistics`; the
    contrast (0, 1, 0, 0) reproduces its "MIA vs Saline Control" row exactly.
    BH uses the full retained panel within Region × Effect, as the pipeline.
    """
    contrasts = registry.DERIVED_EFFECTS if contrasts is None else contrasts
    ordered = metadata.set_index("Sample", drop=False).loc[values.columns]
    frames = []
    for region, rows in ordered.groupby("Sample type", sort=False):
        samples = rows["Sample"].tolist()
        design = _design_matrix(rows.rename(columns={"Bio group": "BioGroup"})[["BioGroup", "Sex"]])
        numeric = values.loc[:, samples].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
        observed = np.isfinite(numeric)
        groups, sexes = rows["Bio group"].to_numpy(), rows["Sex"].to_numpy()
        cells = np.column_stack([(groups == g) & (sexes == x) for g in ("Saline Control", "MIA") for x in ("Male", "Female")])
        eligible = (observed.astype(int) @ cells.astype(int)).min(axis=1) >= min_per_cell
        if not eligible.any():
            continue
        weights = observed[eligible].astype(float)
        response = np.nan_to_num(numeric[eligible], nan=0.0)
        inverse = np.linalg.pinv(np.einsum("fi,ij,ik->fjk", weights, design, design))
        coefficients = np.einsum("fij,fj->fi", inverse, np.einsum("fi,ij->fj", weights * response, design))
        residuals = (response - coefficients @ design.T) * weights
        n_usable = observed[eligible].sum(axis=1).astype(int)
        residual_df = n_usable - design.shape[1]
        residual_variance = np.sum(residuals * residuals, axis=1) / residual_df
        for name, vector in contrasts.items():
            c = np.asarray(vector, dtype=float)
            estimate = coefficients @ c
            error = np.sqrt(np.maximum(np.einsum("j,fjk,k->f", c, inverse, c) * residual_variance, 0))
            statistic = np.divide(estimate, error, out=np.full_like(estimate, np.nan), where=error > 0)
            frames.append(pd.DataFrame({
                "Feature": values.index[eligible].to_numpy(), "Region": region, "Effect": name,
                "estimate_log2": estimate, "standard_error": error, "t_statistic": statistic,
                "p_value": 2 * t.sf(np.abs(statistic), residual_df), "residual_df": residual_df, "n_usable": n_usable}))
    if not frames:
        return pd.DataFrame()
    result = pd.concat(frames, ignore_index=True)
    critical = t.ppf(0.975, result["residual_df"])
    result["ci_lower_log2"] = result["estimate_log2"] - critical * result["standard_error"]
    result["ci_upper_log2"] = result["estimate_log2"] + critical * result["standard_error"]
    result["effect_scale"] = "normalized_log2"
    result["fold_change"] = 2 ** result["estimate_log2"]
    result["fdr_denominator"] = len(values)
    result["p_value_fdr"] = np.nan
    for _, indices in result.groupby(["Region", "Effect"], observed=True).groups.items():
        result.loc[indices, "p_value_fdr"] = _bh_adjust(result.loc[indices, "p_value"], len(values))
    result["contrast_source"] = "derived contrast of the same OLS fit (recomputed)"
    return result.merge(_cell_counts(values, metadata), on=["Feature", "Region"], validate="many_to_one")


@lru_cache(maxsize=32)
def _derived(modality: str, samples: tuple[str, ...], version: tuple) -> pd.DataFrame:
    values, metadata = data.selected_inputs(modality, samples)
    return fit_contrasts(values, metadata)


DERIVED_NOTE = ("Derived contrast — recomputed from the same samples with the pipeline OLS model "
                "(c·β; not in the saved pipeline files). ")


def effect_badge(badge: str, effect: str) -> str:
    """Badge for one effect: derived contrasts are always recomputed, even for a saved population."""
    return DERIVED_NOTE + badge if effect in registry.DERIVED_EFFECTS else badge


@lru_cache(maxsize=32)
def _differential(modality: str, samples: tuple[str, ...], version: tuple, full: bool) -> pd.DataFrame:
    values, metadata = data.selected_inputs(modality, samples)
    return fit_differential(values, metadata, full)


def differential(modality: str, samples: tuple[str, ...], used: set | None = None,
                 force: bool = False, full: bool = False) -> tuple[pd.DataFrame, str]:
    samples = tuple(sorted(samples))
    population = data.matching_population(modality, samples, used)
    if population and not force:
        path = registry.differential_source(modality, population)
        if path:
            metadata_path = path.parent.parent / "00_inputs/differential_input_metadata.csv"
            saved_metadata = data.read_csv(metadata_path, used)
            # Metabolomics historical T² flags differ from regional persistence.
            if set(saved_metadata["Sample"]) == set(samples):
                frame = _with_derived(data.read_csv(path, used), modality, samples, used)
                return data.annotate(frame, modality, used), data.badge(modality, samples, path, used)
    frame = _differential(modality, samples, data.input_version(modality, used), full).copy()
    frame = _with_derived(frame, modality, samples, used)
    return data.annotate(frame, modality, used), data.badge(modality, samples, used=used)


def _with_derived(frame: pd.DataFrame, modality: str, samples: tuple[str, ...], used: set | None) -> pd.DataFrame:
    if frame.empty:
        return frame
    extra = _derived(modality, samples, data.input_version(modality, used))
    if extra.empty:
        return frame
    return pd.concat([frame, extra.loc[:, [c for c in extra.columns if c in frame.columns or c == "contrast_source"]]],
                     ignore_index=True)


def contrasts_for(values: pd.DataFrame, metadata: pd.DataFrame) -> dict:
    # The package accepts an explicit region set; absent regions have no pairs.
    present = tuple(region for region in registry.REGIONS if region in set(metadata["Sample type"]))
    definitions = tuple(item for item in REGION_CONTRASTS if item[1] in present and item[2] in present)
    if not definitions:
        return {}
    return build_region_contrasts(values, metadata, regions=present, contrast_definitions=definitions)


@lru_cache(maxsize=32)
def _regional(modality: str, samples: tuple[str, ...], version: tuple, pooled: bool) -> pd.DataFrame:
    values, metadata = data.selected_inputs(modality, samples)
    tables = []
    for contrast in contrasts_for(values, metadata).values():
        if pooled:
            # A one-sample paired test over all mice, using the SAME helper.
            contrast = replace(contrast, metadata=contrast.metadata.assign(**{"Bio group": "Saline Control"}))
        table = one_sample_region_tests(contrast)
        if pooled:
            table = table.loc[table["Group"].eq("Saline Control")].assign(Group="All mice")
        tables.append(table)
    return pd.concat(tables, ignore_index=True) if tables else pd.DataFrame()


def regional(modality: str, samples: tuple[str, ...], group: str = "Saline Control",
             used: set | None = None, force: bool = False) -> tuple[pd.DataFrame, str]:
    samples = tuple(sorted(samples))
    population = data.matching_population(modality, samples, used)
    if population and group != "All mice" and not force:
        path = registry.source(modality, population, "regional")
        metadata_path = registry.source(modality, population, "metadata")
        if path.exists() and metadata_path.exists() and set(data.read_csv(metadata_path, used)["Sample"]) == set(samples):
            frame = data.read_csv(path, used)
            return data.annotate(frame.loc[frame["Group"].eq(group)], modality, used), data.badge(modality, samples, path, used)
    frame = _regional(modality, samples, data.input_version(modality, used), group == "All mice").copy()
    if not frame.empty:
        frame = frame.loc[frame["Group"].eq(group)]
    return data.annotate(frame, modality, used), data.badge(modality, samples, used=used)


@lru_cache(maxsize=8)
def _persistence(modality: str, samples: tuple[str, ...], version: tuple) -> dict[str, pd.DataFrame]:
    values, metadata = data.selected_inputs(modality, samples)
    contrasts = contrasts_for(values, metadata)
    if len(contrasts) != 3:
        raise ValueError("Persistence requires all three regional contrasts; retain samples in each region.")
    result = {key: [] for key in ("concordance", "reliability", "disattenuation", "interactions", "icc", "pairing")}
    population = data.matching_population(modality, samples)
    offset = list(registry.POPULATIONS).index(population) * 100 if population else 0
    for number, contrast in enumerate(contrasts.values()):
        counts = contrast.metadata["Bio group"].value_counts()
        if min(counts.get("Saline Control", 0), counts.get("MIA", 0)) < 4:
            raise ValueError(f"{contrast.name}: at least four paired mice per group are required for split halves.")
        icc = intraclass_correlation(contrast.values, contrast.metadata,
                                    n_bootstraps=CAGE_ICC_BOOTSTRAPS, random_state=CAGE_ICC_RANDOM_SEED + offset + number)
        reliability, draws = estimate_split_half_reliability(contrast, n_splits=1000, random_state=20260919 + offset + number)
        result["icc"].append(icc.assign(Contrast=contrast.name))
        result["interactions"].append(interaction_tests(contrast, icc))
        result["concordance"].append(concordance_summary(contrast))
        result["reliability"].append(reliability)
        result["disattenuation"].append(disattenuated_concordance(
            contrast, reliability, draws, n_bootstraps=1000, n_inner_splits=100, random_state=20260920 + offset + number))
        result["pairing"].append(contrast.metadata.assign(Contrast=contrast.name))
    tables = {key: pd.concat(frames, ignore_index=True) for key, frames in result.items()}
    tables["interactions"] = apply_interaction_fdr(tables["interactions"], n_features=len(values), n_contrasts=3)
    return tables


def persistence_available(modality: str, samples: tuple[str, ...], used: set | None = None) -> bool:
    population = data.matching_population(modality, samples, used)
    if not population:
        return False
    kinds = ("metadata", "manifest", "concordance", "reliability", "disattenuation", "interactions", "icc", "pairing")
    if not all(registry.source(modality, population, kind).exists() for kind in kinds):
        return False
    return set(data.read_csv(registry.source(modality, population, "metadata"), used)["Sample"]) == set(samples)


def persistence(modality: str, samples: tuple[str, ...], used: set | None = None) -> tuple[dict, str]:
    samples = tuple(sorted(samples))
    population = data.matching_population(modality, samples, used)
    if persistence_available(modality, samples, used):
        kinds = ("concordance", "reliability", "disattenuation", "interactions", "icc", "pairing")
        manifest = data.read_json(registry.source(modality, population, "manifest"), used)
        if not str(manifest.get("pairing", "")).startswith("contrast-specific"):
            raise ValueError("Population rule: persistence source predates contrast-specific pairing.")
        tables = {kind: data.read_csv(registry.source(modality, population, kind), used) for kind in kinds}
        if "bootstrap_method" not in tables["disattenuation"]:
            raise ValueError("Persistence source predates the corrected reliability bootstrap; rerun required.")
        path = registry.source(modality, population, "disattenuation")
        return tables, data.badge(modality, samples, path, used)
    tables = _persistence(modality, samples, data.input_version(modality, used))
    return {key: frame.copy() for key, frame in tables.items()}, data.badge(modality, samples, used=used)


def effect_vector(modality: str, samples: tuple[str, ...], kind: str, region: str,
                  effect: str, contrast: str, group: str, used: set | None = None) -> tuple[pd.DataFrame, str]:
    if kind == "regional":
        table, badge = regional(modality, samples, group, used)
        return (table.loc[table["Contrast"].eq(contrast)].copy() if not table.empty else table), badge
    table, badge = differential(modality, samples, used)
    return (table.loc[table["Region"].eq(region) & table["Effect"].eq(effect)].copy() if not table.empty else table), badge


def cross_join(left: pd.DataFrame, right: pd.DataFrame) -> pd.DataFrame:
    """Join by Feature, never by row position; retain both estimates AND SEs."""
    if left.empty or right.empty:
        return pd.DataFrame()
    columns = ["Feature", "estimate_log2", "standard_error", "p_value", "p_value_fdr"]
    joined = left[columns].merge(right[columns], on="Feature", suffixes=("_x", "_y"), validate="one_to_one")
    for column in ("Name", "Class / method"):
        if column in left:
            joined = joined.merge(left[["Feature", column]], on="Feature", validate="one_to_one")
    joined["SE ratio (y/x)"] = joined["standard_error_y"].div(joined["standard_error_x"].replace(0, np.nan))
    return joined.sort_values("Feature", kind="stable").reset_index(drop=True)


def highlight(table: pd.DataFrame, threshold: float, lfc: float, evidence: str = "p_value_fdr") -> pd.DataFrame:
    result = table.copy()
    if result.empty:
        return result
    if "estimate_log2_x" in result:
        x = result[f"{evidence}_x"].le(threshold) & result["estimate_log2_x"].abs().ge(lfc)
        y = result[f"{evidence}_y"].le(threshold) & result["estimate_log2_y"].abs().ge(lfc)
        result["Evidence"] = np.select([x & y, x, y], ["Both", "X only", "Y only"], default="Neither")
        angle = np.mod(np.arctan2(result["estimate_log2_y"], result["estimate_log2_x"]), 2 * np.pi)
        result["Octant"] = np.floor(angle / (np.pi / 4)).astype("Int64") + 1
    else:
        result["Evidence"] = np.where(result[evidence].le(threshold) & result["estimate_log2"].abs().ge(lfc), "Highlighted", "Other")
    return result


@lru_cache(maxsize=24)
def _pca(modality: str, samples: tuple[str, ...], version: tuple, scope: str, top: int) -> tuple:
    values, metadata = data.selected_inputs(modality, samples)
    if scope != "pooled":
        metadata = metadata.loc[metadata["Sample type"].eq(scope)]
        values = values.loc[:, metadata["Sample"]]
    complete = values.dropna()
    complete = complete.loc[complete.var(axis=1).gt(0)]
    complete = complete.loc[complete.var(axis=1).sort_values(ascending=False, kind="stable").index[:top]]
    if min(complete.shape) < 2:
        raise ValueError("PCA requires at least two samples and two complete, varying features.")
    model, scores, _ = fit_pca(autoscale(complete), n_components=min(5, complete.shape[0], complete.shape[1] - 1))
    attribution = score_attribution(scores, model.explained_variance_ratio_, metadata, scope)
    return scores.join(metadata.set_index("Sample")), model.explained_variance_ratio_, attribution, len(complete)


def pca(modality: str, samples: tuple[str, ...], scope: str, top: int, used: set | None = None) -> tuple:
    return _pca(modality, tuple(sorted(samples)), data.input_version(modality, used), scope, top)


@lru_cache(maxsize=4)
def _difference_screen(modality: str, version: tuple) -> tuple[pd.DataFrame, pd.DataFrame]:
    # Fixed all-60 source; never condition the diagnostic on a selected label.
    values, metadata = data.inputs(modality)
    tables = []
    for contrast in build_region_contrasts(values, metadata).values():
        complete = contrast.values.dropna()
        complete = complete.loc[complete.var(axis=1).gt(0)]
        _, scores, _ = fit_pca(autoscale(complete), n_components=3)
        table = hotelling_t2(scores).rename_axis("Mouse number").reset_index()
        table["Contrast"] = contrast.name
        for level in (95, 99):
            table[f"flag_{level}"] = table["hotelling_t2"].gt(table[f"hotelling_t2_{level}_limit"])
        tables.append(table)
    screen = pd.concat(tables, ignore_index=True)
    attribution = []
    for level in (95, 99):
        for mouse, rows in screen.groupby("Mouse number"):
            flagged = set(rows.loc[rows[f"flag_{level}"], "Contrast"])
            attributed = None
            for region in registry.REGIONS:
                expected = {name for name, a, b in REGION_CONTRASTS if region in (a, b)}
                if flagged == expected:
                    attributed = region
            sample = metadata.loc[metadata["Mouse number"].eq(mouse) & metadata["Sample type"].eq(attributed), "Sample"]
            attribution.append({"Mouse number": mouse, "Limit": level, "Flagged contrasts": "; ".join(sorted(flagged)),
                                "Attributed region": attributed or "No attributable sample",
                                "Sample": sample.iloc[0] if len(sample) else "", "Permitted exclusion": False})
    return screen, pd.DataFrame(attribution)


def difference_screen(modality: str, used: set | None = None) -> tuple:
    return _difference_screen(modality, data.input_version(modality, used))


def directional_top(table: pd.DataFrame, evidence: str = "p_value_fdr", n: int = 10,
                    x: str = "estimate_log2") -> list[str]:
    """Top-n positive and top-n negative effects by displayed evidence, |effect| breaking ties.

    These are the best-ranked features in each direction, not necessarily
    features that pass the threshold.
    """
    if table.empty or evidence not in table:
        return []
    valid = table.loc[np.isfinite(table[x]) & np.isfinite(table[evidence]) & table[x].ne(0)]
    # BH q values tie in blocks; raw p breaks those ties before |effect| does.
    keys = [evidence] + (["p_value"] if evidence != "p_value" and "p_value" in valid else []) + ["_abs"]
    picks = []
    for side in (valid.loc[valid[x].gt(0)], valid.loc[valid[x].lt(0)]):
        ranked = side.assign(_abs=side[x].abs()).sort_values(keys, ascending=[True] * (len(keys) - 1) + [False], kind="stable")
        picks.extend(ranked["Feature"].head(n).tolist())
    return picks


def sector_extremes(table: pd.DataFrame, n: int = 5, x: str = "estimate_log2_x", y: str = "estimate_log2_y") -> list[str]:
    """The n features farthest from the origin in each of the 8 directional sectors of a cross plot."""
    if table.empty:
        return []
    valid = table.loc[np.isfinite(table[x]) & np.isfinite(table[y]) & (table[x].ne(0) | table[y].ne(0))].copy()
    angle = np.mod(np.arctan2(valid[y], valid[x]), 2 * np.pi)
    valid["_sector"] = np.floor(angle / (np.pi / 4)).astype(int)
    valid["_distance"] = np.hypot(valid[x], valid[y])
    ranked = valid.sort_values("_distance", ascending=False, kind="stable").groupby("_sector").head(n)
    return ranked["Feature"].tolist()


def highlighted_only(table: pd.DataFrame) -> pd.DataFrame:
    """Rows that pass the current highlighting rule (single effect or either cross-plot axis)."""
    if table.empty or "Evidence" not in table:
        return table
    return table.loc[table["Evidence"].isin(["Highlighted", "Both", "X only", "Y only"])]
