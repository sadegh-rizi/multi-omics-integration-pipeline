"""Cached, validated result readers and source provenance; no result writes."""

from datetime import datetime, timezone
from functools import lru_cache
import json
from pathlib import Path

import pandas as pd

from app import ROOT
from app import registry


def stamp(path: Path) -> tuple[str, int, int]:
    path = registry.permitted(path)
    info = path.stat()
    return str(path), info.st_mtime_ns, info.st_size


@lru_cache(maxsize=128)
def _csv(version: tuple[str, int, int]) -> pd.DataFrame:
    path = registry.permitted(Path(version[0]))
    frame = pd.read_csv(path, dtype={"Feature": str})
    if "Feature" in frame and frame["Feature"].isna().any():
        raise ValueError(f"Missing feature identifier in {path}")
    return frame


def read_csv(path: Path, used: set[Path] | None = None) -> pd.DataFrame:
    path = registry.permitted(path)
    if used is not None:
        used.add(path)
    return _csv(stamp(path)).copy(deep=True)


def read_json(path: Path, used: set[Path] | None = None) -> dict:
    path = registry.permitted(path)
    if used is not None:
        used.add(path)
    return json.loads(path.read_text(encoding="utf-8"))


def inputs(modality: str, population: str = "all60", used: set[Path] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    matrix = read_csv(registry.source(modality, population, "matrix"), used).set_index("Feature")
    metadata = read_csv(registry.source(modality, population, "metadata"), used)
    if matrix.index.has_duplicates or metadata["Sample"].duplicated().any():
        raise ValueError("Feature and sample identifiers must be unique.")
    if set(matrix.columns) != set(metadata["Sample"]):
        raise ValueError("Matrix and metadata sample IDs disagree.")
    if population == "all60" and (len(metadata) != 60 or metadata["Mouse number"].nunique() != 20):
        raise ValueError("Population rule: the primary source must contain all 60 samples from 20 mice.")
    metadata = metadata.rename(columns={"selected": "Source selected", "population": "Source population",
                                        "exclusion_reason": "Source exclusion reason"})
    return matrix, metadata.set_index("Sample", drop=False).loc[matrix.columns].reset_index(drop=True)


def annotations(modality: str, used: set[Path] | None = None) -> pd.DataFrame:
    frame = read_csv(registry.source(modality, "all60", "annotations"), used)
    name = "Lipid Name" if modality == "lipidomics" else "Metabolite"
    category = "Lipid Class" if modality == "lipidomics" else "Method"
    # Acquisition method is deliberately NOT called a metabolite class.
    return frame[["Feature", name, category]].rename(columns={name: "Name", category: "Class / method"})


def annotate(frame: pd.DataFrame, modality: str, used: set[Path] | None = None) -> pd.DataFrame:
    if "Feature" not in frame:
        return frame
    return frame.merge(annotations(modality, used), on="Feature", how="left", validate="many_to_one")


def sample_sets(modality: str, used: set[Path] | None = None) -> dict[str, tuple[str, ...]]:
    metadata = read_csv(registry.source(modality, "all60", "metadata"), used)
    screens = pd.concat([read_csv(ROOT / "results/mia_vs_control/02_qc" / f"outlier_screen_{region.lower()}.csv", used)
                         for region in registry.REGIONS], ignore_index=True)
    result = {"all60": tuple(sorted(metadata["Sample"]))}
    for population, level in (("t2_95", 95), ("t2_99", 99)):
        flagged = screens[f"hotelling_t2_{level}_flag"].astype(str).str.lower().eq("true")
        numbers = screens.loc[flagged, "Sample number"]
        result[population] = tuple(sorted(metadata.loc[~metadata["Sample number"].isin(numbers), "Sample"]))
    return result


def matching_population(modality: str, samples: tuple[str, ...], used: set[Path] | None = None) -> str | None:
    return next((name for name, ids in sample_sets(modality, used).items() if set(samples) == set(ids)), None)


def selected_inputs(modality: str, samples: tuple[str, ...], used: set[Path] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    values, metadata = inputs(modality, used=used)
    unknown = set(samples).difference(values.columns)
    if unknown:
        raise ValueError(f"Unknown sample IDs: {sorted(unknown)}")
    # Preserve pipeline order for reproducible bootstrap and least-squares fits.
    metadata = metadata.loc[metadata["Sample"].isin(samples)].copy()
    return values.loc[:, metadata["Sample"]], metadata


def removed_mice(metadata: pd.DataFrame, samples: tuple[str, ...]) -> tuple[str, ...]:
    kept = metadata.loc[metadata["Sample"].isin(samples), "Mouse number"]
    return tuple(sorted(set(metadata["Mouse number"]).difference(kept)))


def provenance(path: Path, used: set[Path] | None = None) -> dict:
    path = registry.permitted(path)
    allowed = registry.allowed_paths()
    for parent in path.parents:
        candidate = parent / "provenance.json"
        if candidate in allowed and candidate.exists():
            record = read_json(candidate, used)
            return {"commit": record.get("git_commit", record.get("producing_commit", "unrecorded")),
                    "source_dirty": record.get("working_tree_source_diff", "unrecorded"),
                    "provenance_file": str(candidate.relative_to(ROOT)) if candidate.is_relative_to(ROOT) else str(candidate)}
    return {"commit": "unrecorded", "source_dirty": "unrecorded", "provenance_file": "not supplied"}


def badge(modality: str, samples: tuple[str, ...], path: Path | None = None, used: set[Path] | None = None) -> str:
    if path is not None:
        record = provenance(path, used)
        label = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
        return f"Saved — pipeline output {label}; commit {record['commit']}; source working-tree changes: {record['source_dirty']}"
    _, metadata = inputs(modality, used=used)
    removed = sorted(set(metadata["Sample"]).difference(samples))
    return f"Recomputed — exploratory (n = {len(samples)}, removed: {', '.join(removed) or 'none'})"


def source_table(used: set[Path]) -> pd.DataFrame:
    rows = []
    for path in sorted(used):
        info = path.stat()
        rows.append({"Source": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
                     "Modified (UTC)": datetime.fromtimestamp(info.st_mtime, timezone.utc).isoformat(),
                     "Bytes": info.st_size, **provenance(path)})
    return pd.DataFrame(rows)


def input_version(modality: str, used: set[Path] | None = None) -> tuple:
    paths = [registry.source(modality, "all60", kind) for kind in ("matrix", "metadata")]
    if used is not None:
        used.update(paths)
    return tuple(stamp(path) for path in paths)
