"""Interactive, descriptive views using the thesis palettes."""

from io import BytesIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.utils import PlotlyJSONEncoder

from lpj_lipidomics.plotting import (
    BIO_GROUP_COLORS, BRAIN_REGION_COLORS, SEX_COLORS, COLORBLIND_COLORS, save_figure,
)
from lpj_lipidomics.multivariate.pca import confidence_ellipse

MODALITY_COLORS = {"lipidomics": "#2a78d6", "metabolomics": "#eb6834"}
EVIDENCE_COLORS = {"Neither": "#999999", "Both": "#009E73", "X only": "#0072B2", "Y only": "#D55E00",
                   "Highlighted": "#009E73", "Other": "#999999"}
COLORS = {**BIO_GROUP_COLORS, **BRAIN_REGION_COLORS, **SEX_COLORS, **EVIDENCE_COLORS}


def empty(message: str) -> go.Figure:
    figure = go.Figure()
    figure.add_annotation(text=message, x=0.5, y=0.5, xref="paper", yref="paper", showarrow=False)
    return figure.update_layout(template="plotly_white", height=450)


def finish(figure: go.Figure, title: str) -> go.Figure:
    figure.update_layout(template="plotly_white", title=title, height=570,
                         margin=dict(l=65, r=30, t=90, b=70), legend_title_text="")
    # Plotly accepts NaNs in hover/customdata; the widget comm requires strict
    # JSON. Its own encoder turns non-finite values into null without imputation.
    for trace in figure.data:
        for name in ("customdata", "x", "y", "z", "text"):
            value = getattr(trace, name, None)
            if value is not None:
                setattr(trace, name, json.loads(json.dumps(value, cls=PlotlyJSONEncoder)))
    return figure


def add_highlights(figure: go.Figure, table: pd.DataFrame, x: str, y: str, query: str) -> None:
    if not query.strip():
        return
    terms = [term.strip().casefold() for term in query.split(",") if term.strip()]
    names = table.get("Name", table["Feature"]).fillna(table["Feature"]).astype(str)
    selected = names.map(lambda name: any(term in name.casefold() for term in terms)) | table["Feature"].astype(str).isin(terms)
    subset = table.loc[selected]
    figure.add_trace(go.Scatter(x=subset[x], y=subset[y], mode="markers+text", text=names[selected],
                               textposition="top center", name="Selected labels", marker=dict(color="black", symbol="circle-open", size=12)))


def add_auto_labels(figure: go.Figure, table: pd.DataFrame, x: str, y: str, features: list[str],
                    name: str = "Auto labels") -> None:
    """Text labels for the given features, alternating positions to reduce overlap."""
    if not features or table.empty:
        return
    subset = table.loc[table["Feature"].isin(features)]
    subset = subset.loc[np.isfinite(subset[x]) & np.isfinite(subset[y])]
    if subset.empty:
        return
    names = subset.get("Name", subset["Feature"]).fillna(subset["Feature"]).astype(str)
    positions = ["top left", "top right", "bottom left", "bottom right"] * (len(subset) // 4 + 1)
    figure.add_trace(go.Scatter(x=subset[x], y=subset[y], mode="text", text=names, name=name,
                                textposition=positions[:len(subset)], textfont=dict(size=10, color="#202020"),
                                hoverinfo="skip", showlegend=False, cliponaxis=False))


def cross(table: pd.DataFrame, x_label: str, y_label: str, color: str = "Evidence",
          labels: bool = False, query: str = "", auto: list[str] | None = None) -> go.Figure:
    if table.empty:
        return empty("No common fitted features for these axes.")
    x, y = "estimate_log2_x", "estimate_log2_y"
    finite = table.loc[np.isfinite(table[x]) & np.isfinite(table[y])].copy()
    if finite.empty:
        return empty("No finite paired effects.")
    hover = [column for column in ("Feature", "Name", "Class / method", "standard_error_x", "standard_error_y",
                                   "p_value_x", "p_value_y", "p_value_fdr_x", "p_value_fdr_y") if column in finite]
    figure = px.scatter(finite, x=x, y=y, color=color, symbol="Evidence", hover_data=hover,
                        color_discrete_map=COLORS, color_discrete_sequence=COLORBLIND_COLORS,
                        color_continuous_scale="Cividis")
    limit = max(float(finite[[x, y]].abs().max().max()) * 1.1, 0.1)
    for slope in (1, -1):
        figure.add_shape(type="line", x0=-limit, y0=-slope * limit, x1=limit, y1=slope * limit,
                         line=dict(color="#aaaaaa", dash="dash"))
    figure.add_hline(y=0, line_color="#aaaaaa")
    figure.add_vline(x=0, line_color="#aaaaaa")
    figure.update_xaxes(title=x_label + " (log₂ effect)", range=[-limit, limit])
    figure.update_yaxes(title=y_label + " (log₂ effect)", range=[-limit, limit], scaleanchor="x", scaleratio=1)
    if labels:
        near = finite.assign(distance=finite[x] ** 2 + finite[y] ** 2).sort_values("distance").groupby("Octant").head(1)
        figure.add_trace(go.Scatter(x=near[x], y=near[y], text=near.get("Name", near["Feature"]),
                                   mode="text", textposition="top center", showlegend=False))
    for octant in range(1, 9):
        angle = (octant - 0.5) * np.pi / 4
        figure.add_annotation(x=limit * .84 * np.cos(angle), y=limit * .84 * np.sin(angle),
                              text=f"n={int(finite['Octant'].eq(octant).sum())}", showarrow=False, font=dict(color="#666666", size=11))
    pearson = finite[x].corr(finite[y]) if min(finite[x].nunique(), finite[y].nunique()) > 1 else np.nan
    spearman = finite[x].corr(finite[y], method="spearman") if min(finite[x].nunique(), finite[y].nunique()) > 1 else np.nan
    add_highlights(figure, finite, x, y, query)
    add_auto_labels(figure, finite, x, y, auto or [])
    return finish(figure, f"Effect concordance · {len(finite)} features · Pearson r={pearson:.3f}, Spearman ρ={spearman:.3f}")


def volcano(table: pd.DataFrame, evidence: str, color: str, query: str, ma: bool = False,
            auto: list[str] | None = None) -> go.Figure:
    if table.empty:
        return empty("No eligible model fits. OLS requires ≥3 usable observations in every group × sex cell.")
    table = table.copy()
    table["−log₁₀ evidence"] = -np.log10(table[evidence].clip(lower=np.finfo(float).tiny))
    x, y = ("Mean normalized log₂ abundance", "estimate_log2") if ma else ("estimate_log2", "−log₁₀ evidence")
    hover = [column for column in ("Feature", "Name", "Class / method", "standard_error", "ci_lower_log2", "ci_upper_log2",
                                   "p_value", "p_value_fdr", "n_usable", "n_mice") if column in table]
    figure = px.scatter(table, x=x, y=y, color=color, symbol="Evidence", hover_data=hover,
                        color_discrete_map=COLORS, color_discrete_sequence=COLORBLIND_COLORS)
    figure.add_hline(y=0, line_color="#aaaaaa")
    if not ma:
        figure.add_vline(x=0, line_color="#aaaaaa")
        figure.update_xaxes(title="Effect (normalized log₂; relative to panel)")
        figure.update_yaxes(title="−log₁₀ BH q" if evidence == "p_value_fdr" else "−log₁₀ raw p")
    else:
        figure.update_yaxes(title="Effect (normalized log₂; relative to panel)")
    add_highlights(figure, table, x, y, query)
    add_auto_labels(figure, table, x, y, auto or [])
    return finish(figure, ("MA" if ma else "Volcano") + f" · {len(table)} fitted features")


def pca(scores: pd.DataFrame, variance: np.ndarray, x: str, y: str, color: str,
        ellipses: bool, labels: bool) -> go.Figure:
    if x not in scores or y not in scores or x == y:
        return empty("Choose two distinct PCs available for this sample set.")
    frame = scores.rename_axis("Sample").reset_index()
    figure = px.scatter(frame, x=x, y=y, color=color, symbol="Bio group", color_discrete_map=COLORS,
                        color_discrete_sequence=COLORBLIND_COLORS,
                        symbol_map={"Saline Control": "circle-open", "MIA": "triangle-up"},
                        hover_data=["Sample", "Mouse number", "Cage", "Date collected", "Sex", "Sample type"],
                        text="Sample" if labels else None)
    if ellipses:
        for group, rows in frame.groupby(color, observed=True):
            if len(rows) >= 3 and np.linalg.det(np.cov(rows[[x, y]].T)) > 0:
                boundary = confidence_ellipse(rows[x], rows[y])
                figure.add_trace(go.Scatter(x=boundary[:, 0], y=boundary[:, 1], mode="lines", name=f"{group}: 95% data ellipse",
                                           line=dict(color=COLORS.get(group, "#777777"), dash="dot")))
    figure.update_xaxes(title=f"{x} ({variance[int(x.split()[1])-1]:.1%})")
    figure.update_yaxes(title=f"{y} ({variance[int(y.split()[1])-1]:.1%})")
    return finish(figure, f"Descriptive PCA · n={len(frame)} samples; regions repeat within mouse")


def attribution(table: pd.DataFrame) -> go.Figure:
    table = table.loc[table["Factor"].ne("Total")].pivot(index="Component", columns="Factor", values="factor_score_r2")
    figure = px.imshow(table, zmin=0, zmax=1, color_continuous_scale="Cividis", text_auto=".2f", aspect="auto")
    return finish(figure, "Marginal PC-score R² · factors overlap; not an additive partition")


def feature(frame: pd.DataFrame, title: str, mark: str | None = None, labels: bool = True) -> go.Figure:
    if frame.empty:
        return empty("No samples selected.")
    groups = [group for group in ("Saline Control", "MIA") if group in set(frame["Bio group"])]
    hover = [column for column in ("Sample", "Mouse number", "Cage", "Date collected", "Sex",
                                   "T²-95 flag", "T²-99 flag", "Ensemble candidate") if column in frame]
    figure = px.line(frame, x="Sample type", y="Value", color="Bio group", line_group="Mouse number", markers=True,
                     symbol="Sex", facet_col="Bio group", color_discrete_map=COLORS,
                     category_orders={"Sample type": ["Cerebellum", "Hippocampus", "Cortex"], "Bio group": groups},
                     hover_data=hover)
    figure.update_yaxes(title="Median-normalized log₂ abundance")
    suffix = ""
    if mark and mark in frame:
        flagged = frame.loc[frame[mark].astype(bool) & frame["Value"].notna()]
        for column, group in enumerate(groups, start=1):
            rows = flagged.loc[flagged["Bio group"].eq(group)]
            if rows.empty:
                continue
            figure.add_trace(go.Scatter(
                x=rows["Sample type"].astype(str), y=rows["Value"], mode="markers+text" if labels else "markers",
                text=rows["Sample number"].astype(str) if labels else None, textposition="middle right",
                marker=dict(symbol="circle-open", size=16, color="#D55E00", line=dict(width=2.5)),
                name=mark, legendgroup="flag", showlegend=column == 1,
                hovertext=rows["Sample"], hoverinfo="text+y"), row=1, col=column)
        suffix = f" · ringed: {mark} ({len(flagged)} samples)"
    return finish(figure, title + " · lines join the same mouse; missing values remain missing" + suffix)


def persistence_intervals(table: pd.DataFrame) -> go.Figure:
    figure = go.Figure()
    for _, row in table.iterrows():
        label = f"{row['Population']} · {row['Contrast']}"
        color = MODALITY_COLORS.get(row.get("Modality"), "#2a78d6")
        # Draw endpoints directly: the estimate can lie outside a bootstrap CI.
        figure.add_trace(go.Scatter(x=[row["bootstrap_q025"], row["bootstrap_q975"]], y=[label, label],
                                   mode="lines", line=dict(color=color), showlegend=False))
        figure.add_trace(go.Scatter(x=[row["disattenuated_concordance"]], y=[label], mode="markers", showlegend=False,
                                   marker=dict(color=color, size=9), hovertext=f"r observed={row['r_observed']:.3f}; ceiling={row['attenuation_ceiling']:.3f}"))
    figure.add_vline(x=1, line_dash="dash", line_color="#777777")
    figure.update_xaxes(title="Disattenuated concordance and mouse-bootstrap 95% interval (unclipped)")
    return finish(figure, "Regional-signature persistence · intervals including 1 are unresolved")


def scatter_bundle(figure: go.Figure, table: pd.DataFrame, context: str) -> bytes:
    """Static companions for single-panel scatter views, without Kaleido.

    Export exactly the displayed traces, guides, labels and axes via the shared
    three-format writer. Temporary files never enter data/ or results/.
    """
    fig = _static(figure)
    memory = BytesIO()
    with TemporaryDirectory(prefix="lpj-explorer-") as directory:
        paths = save_figure(fig, Path(directory) / "exploratory_figure")
        with ZipFile(memory, "w") as archive:
            for path in paths.values():
                archive.write(path, path.name)
            archive.writestr("table.csv", table.to_csv(index=False))
            archive.writestr("context.txt", context)
    plt.close(fig)
    return memory.getvalue()


def figure_pdf(figure: go.Figure, context: str = "") -> bytes:
    """One-page vector PDF of a single-panel scatter view (same renderer as the ZIP export)."""
    fig = _static(figure)
    if context:
        fig.text(0.01, 0.005, context, fontsize=6, color="#555555", va="bottom", wrap=True)
    memory = BytesIO()
    fig.savefig(memory, format="pdf", bbox_inches="tight")
    plt.close(fig)
    return memory.getvalue()


def _static(figure: go.Figure):
    """Matplotlib rendering of the displayed traces, guides, labels and axes (no Kaleido)."""
    fig, ax = plt.subplots(figsize=(9, 7))
    for trace in figure.data:
        if trace.type not in ("scatter", "scattergl"):
            continue
        x, y = np.asarray(trace.x), np.asarray(trace.y)
        color = trace.marker.color if "markers" in (trace.mode or "markers") else trace.line.color
        if color is None:
            color = "#2a78d6"
        if "lines" in (trace.mode or ""):
            ax.plot(x, y, color=color, label=trace.name if trace.showlegend is not False else None)
        elif "markers" in (trace.mode or "markers"):
            symbol = trace.marker.symbol if isinstance(trace.marker.symbol, str) else "circle"
            marker = {"circle": "o", "diamond": "D", "square": "s", "cross": "+", "x": "x", "circle-open": "o"}.get(symbol, "o")
            artist = ax.scatter(x, y, c=color, s=18, marker=marker,
                                label=trace.name if trace.showlegend is not False else None, cmap="cividis" if not isinstance(color, str) else None)
            if not isinstance(color, str):
                fig.colorbar(artist, ax=ax, label="SE ratio (y/x)")
        if "text" in (trace.mode or "") and trace.text is not None:
            for a, b, text in zip(x, y, trace.text):
                ax.annotate(str(text), (a, b), fontsize=7)
    for shape in figure.layout.shapes or ():
        if shape.type == "line":
            if shape.xref in ("paper", "x domain"):
                ax.axhline(shape.y0, color="#aaaaaa", linewidth=.7)
            elif shape.yref in ("paper", "y domain"):
                ax.axvline(shape.x0, color="#aaaaaa", linewidth=.7)
            else:
                ax.plot([shape.x0, shape.x1], [shape.y0, shape.y1], color="#aaaaaa", linestyle="--", linewidth=.7)
    for note in figure.layout.annotations or ():
        if note.xref != "paper":
            ax.annotate(note.text, (note.x, note.y), fontsize=8)
    ax.set(xlabel=figure.layout.xaxis.title.text, ylabel=figure.layout.yaxis.title.text,
           title=figure.layout.title.text.replace("<br>", "\n"))
    if figure.layout.xaxis.range:
        ax.set_xlim(figure.layout.xaxis.range)
    if figure.layout.yaxis.range:
        ax.set_ylim(figure.layout.yaxis.range)
    if figure.layout.yaxis.scaleanchor == "x":
        ax.set_aspect("equal")
    if ax.get_legend_handles_labels()[0]:
        ax.legend(fontsize=7, loc="best")
    return fig
