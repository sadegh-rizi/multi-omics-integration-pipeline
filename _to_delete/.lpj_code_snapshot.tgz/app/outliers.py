"""Saved detector-ensemble results for the Outlier review tab; reads only, never refits.

Source: ``results/mia_vs_control/02_qc/ensemble/`` (``run_outlier_ensemble``,
corrected Mahalanobis calibration). The screens are label-blind, use all 60
lipidomics samples, and are applied to metabolomics by sample number.

Rule, as in ``lpj_lipidomics.outliers.ensemble`` and the runner:

* a detector is *stable* for a sample when it flags it at the 95% null limit in
  at least 60% of its counted settings (every parameter × representation,
  pooled within one scope and calibration stage);
* *candidate* = under stage-2 (trimmed) calibration, ≥2 stable counted
  detectors (lof_supporting is not counted) of which ≥1 is non-covariance
  (kNN isotropic, LOF, isolation forest, kernel PCA), AND the trinity-mean
  ensemble flag does not change between stage-1 and stage-2 calibration.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from app import ROOT, data

ENSEMBLE = ROOT / "results/mia_vs_control/02_qc/ensemble"
FILES = ("detector_scores_long.csv", "stability_fractions.csv", "null_limits.csv", "ensemble_null_limits.csv",
         "isolation_forest_rank_ranges.csv", "distance_concentration_diagnostic.csv", "run_metadata.csv",
         "ensemble_verdict.csv", "provenance.json")
MINIMUM_FRACTION = 0.60
SCOPES = {"cerebellum": "Cerebellum", "cortex": "Cortex", "hippocampus": "Hippocampus",
          "pooled": "Pooled (all 60) — invalid for the region design"}
STAGES = {"trimmed": "Stage 2 — trimmed calibration (used by the verdict)",
          "contaminated": "Stage 1 — contaminated calibration"}
STAGE_SUFFIX = {"contaminated": "stage1", "trimmed": "stage2"}
NON_COVARIANCE = ("knn_isotropic", "lof", "isolation_forest", "kernel_pca")
NOT_COUNTED = ("lof_supporting",)
# Representative settings that feed the trinity / five-detector ensemble
# percentiles (run_outlier_ensemble.representative_for_stage). kNN uses
# k = round(sqrt(n)), so it depends on the scope size.
REPRESENTATIVE = {"mahalanobis": ("auto", "raw"), "isolation_forest": ("50", "pc3"),
                  "lof": ("10", "pc3"), "lof_supporting": ("8", "pc3"), "kernel_pca": ("0.1", "pc3")}

DETECTORS = {
    "mahalanobis": ("Mahalanobis (Ledoit–Wolf)",
                    "Covariance distance on all retained lipids with Ledoit–Wolf shrinkage. Swept over shrinkage "
                    "0.875 and 1.0; 'auto' is the data-chosen intensity, shown but not counted (its stage-2 "
                    "calibration fell back to stage 1). Covariance family."),
    "knn_isotropic": ("kNN distance (isotropic)",
                      "Mean distance to the k nearest neighbours in PC space, PCs unscaled. Swept over k and over "
                      "3 / 5 / 10 PCs. Non-covariance family."),
    "knn_soft": ("kNN distance (soft-whitened)",
                 "As kNN isotropic but with PCs partly whitened, so small-variance PCs count more. Counted, "
                 "covariance-type family (not a non-covariance corroborator)."),
    "lof": ("Local outlier factor",
            "Density of a sample relative to its neighbours' density, k ≥ 10. Run on the pooled scope only; "
            "region scopes (n = 20) use the small-k version below. Non-covariance family."),
    "lof_supporting": ("LOF, small k (supporting)",
                       "LOF with k = 2–15 for the n = 20 region scopes. Shown for support only: it is not counted "
                       "in the stability rule."),
    "isolation_forest": ("Isolation forest",
                         "Mean path length to isolate a sample across 50 seeds × 100 trees, in 3 / 5 / 10 PCs. "
                         "The sweep is over representations; seed-to-seed rank ranges are shown below. "
                         "Non-covariance family."),
    "kernel_pca": ("Kernel PCA reconstruction",
                   "RBF kernel-PCA reconstruction error, swept over 9 kernel widths γ (0.01–1) and 3 / 5 / 10 PCs. "
                   "Non-covariance family."),
}
VALUES = {"null_percentile": "Null percentile", "flag_95": "Flagged at 95% null limit",
          "flag_99": "Flagged at 99% null limit", "score": "Raw detector score"}


def read(name: str, used: set[Path] | None = None) -> pd.DataFrame:
    return data.read_csv(ENSEMBLE / name, used)


def available() -> bool:
    return all((ENSEMBLE / name).exists() for name in FILES if name.endswith(".csv"))


def _bool(series: pd.Series) -> pd.Series:
    if series.dtype == bool:
        return series
    return series.astype(str).str.lower().eq("true")


def sample_labels(used: set[Path] | None = None) -> pd.DataFrame:
    """Lipidomics all-60 metadata with a short display label, e.g. 'Cx 25 · MIA M'."""
    _, metadata = data.inputs("lipidomics", used=used)
    frame = metadata[["Sample", "Sample number", "Sample type", "Mouse number", "Bio group", "Sex"]].copy()
    group = frame["Bio group"].str.contains("MIA|Poly", case=False).map({True: "MIA", False: "Ctrl"})
    region = frame["Sample type"].str[:2].replace({"Ce": "Cb", "Co": "Cx", "Hi": "Hp"})
    frame["Label"] = (region + " " + frame["Sample number"].astype(str).str.zfill(2) + " · " + group + " "
                      + frame["Sex"].str[0])
    return frame


def t2_flags(used: set[Path] | None = None) -> pd.DataFrame:
    sets = data.sample_sets("lipidomics", used)
    everyone = pd.Index(sets["all60"])
    return pd.DataFrame({"Sample": everyone, "T²-95 flag": ~everyone.isin(sets["t2_95"]),
                         "T²-99 flag": ~everyone.isin(sets["t2_99"])})


def verdict(scope: str, used: set[Path] | None = None) -> pd.DataFrame:
    frame = read("ensemble_verdict.csv", used)
    frame = frame.loc[frame["scope"].eq(scope)].copy()
    for column in frame.columns:
        if column.startswith(("candidate_outlier", "flag_", "calibration_sensitive")) or "_flag_95_" in column:
            frame[column] = _bool(frame[column])
    frame = frame.merge(sample_labels(used), on="Sample", how="left", validate="one_to_one")
    frame = frame.merge(t2_flags(used), on="Sample", how="left", validate="one_to_one")
    first = ["Label", "Sample", "Mouse number", "Bio group", "Sex", "candidate_outlier", "candidate_outlier_stage2",
             "calibration_sensitive", "stable_detector_count", "stable_non_covariance_count",
             "stable_detector_count_stage1", "stable_non_covariance_count_stage1", "candidate_outlier_stage1",
             "flag_stage1", "flag_stage2", "trinity_mean_stage1", "trinity_mean_stage2", "trinity_max_stage2",
             "five_detector_mean_stage2", "hotelling_t2", "T²-95 flag", "T²-99 flag"]
    frame = frame[[c for c in first if c in frame] + [c for c in frame.columns if c not in first]]
    return frame.sort_values(["candidate_outlier", "stable_detector_count", "trinity_mean_stage2"],
                             ascending=False).reset_index(drop=True)


def rederive(scope: str, used: set[Path] | None = None) -> pd.DataFrame:
    """Re-apply the stability rule to the saved stability fractions (consistency check)."""
    stability = read("stability_fractions.csv", used)
    stability = stability.loc[stability["scope"].eq(scope) & stability["calibration_stage"].eq("trimmed")]
    stable = stability.assign(stable=stability["stability_fraction"].ge(MINIMUM_FRACTION)).pivot(
        index="Sample", columns="detector", values="stable").fillna(False)
    counted = [name for name in stable.columns if name not in NOT_COUNTED]
    non_covariance = [name for name in NON_COVARIANCE if name in stable]
    result = pd.DataFrame(index=stable.index)
    result["stable_detector_count"] = stable[counted].sum(axis=1).astype(int)
    result["stable_non_covariance_count"] = stable[non_covariance].sum(axis=1).astype(int)
    result["candidate_outlier_stage2"] = result["stable_detector_count"].ge(2) & result["stable_non_covariance_count"].ge(1)
    return result


def stability_matrix(scope: str, stage: str, used: set[Path] | None = None) -> pd.DataFrame:
    """Sample (label) × detector stability fraction for one scope and calibration stage."""
    stability = read("stability_fractions.csv", used)
    stability = stability.loc[stability["scope"].eq(scope) & stability["calibration_stage"].eq(stage)]
    matrix = stability.pivot(index="Sample", columns="detector", values="stability_fraction")
    order = [name for name in DETECTORS if name in matrix]
    return matrix[order]


def candidates_by_scope(used: set[Path] | None = None) -> pd.DataFrame:
    frame = read("ensemble_verdict.csv", used)
    frame = frame.merge(sample_labels(used), on="Sample", how="left")
    rows = []
    for scope, label in SCOPES.items():
        current = frame.loc[frame["scope"].eq(scope)]
        rows.append({"Scope": label,
                     "Candidates (final)": ", ".join(current.loc[_bool(current["candidate_outlier"]), "Label"]) or "none",
                     "Stage-2 rule only": ", ".join(current.loc[_bool(current["candidate_outlier_stage2"])
                                                                & ~_bool(current["candidate_outlier"]), "Label"]) or "none",
                     "Calibration-sensitive": ", ".join(current.loc[_bool(current["calibration_sensitive"]), "Label"]) or "none"})
    return pd.DataFrame(rows)


def _short(value: str) -> str:
    """Display form of a parameter value: 0.01778279410038923 → 0.0178; integers and words unchanged."""
    try:
        number = float(value)
    except ValueError:
        return value
    return value if "." not in value else f"{number:.3g}"


def setting_label(detector: str, scope: str, used: set[Path] | None = None) -> str | None:
    """'Setting' label of the representative setting used in the ensemble percentiles."""
    representative = representative_value(detector, scope, used)
    if representative is None:
        return None
    parameter, representation = representative
    frame = sweep_scores(used)
    rows = frame.loc[frame["detector"].eq(detector) & frame["scope"].eq(scope)
                     & frame["parameter_value"].eq(parameter) & frame["representation"].eq(representation)]
    if rows.empty:
        return None
    name = rows["parameter_name"].iloc[0]
    counted = bool(rows["counts_for_stability"].all())
    return f"{representation} · {name}={_short(parameter)}" + ("" if counted else " (not counted)")


def _parameter_sort_key(value: str) -> tuple[int, float, str]:
    try:
        return (0, float(value), value)
    except ValueError:
        return (1, 0.0, value)


def options(detector: str, used: set[Path] | None = None) -> dict[str, list[str]]:
    scores = sweep_scores(used)
    current = scores.loc[scores["detector"].eq(detector)]
    representations = [r for r in ("pc3", "pc5", "pc10", "raw") if r in set(current["representation"])]
    scopes = [s for s in SCOPES if s in set(current["scope"])]
    return {"scope": scopes, "representation": representations}


def sweep_scores(used: set[Path] | None = None) -> pd.DataFrame:
    frame = read("detector_scores_long.csv", used)
    frame["parameter_value"] = frame["parameter_value"].astype(str)
    for column in ("flag_95", "flag_99", "counts_for_stability"):
        frame[column] = _bool(frame[column])
    return frame


def representative_value(detector: str, scope: str, used: set[Path] | None = None) -> tuple[str, str] | None:
    if detector == "knn_isotropic":
        n = sweep_scores(used).loc[lambda f: f["scope"].eq(scope), "Sample"].nunique()
        return str(int(round(np.sqrt(n)))), "pc3"
    return REPRESENTATIVE.get(detector)


def detector_sweep(detector: str, scope: str, stage: str, representation: str = "all",
                   used: set[Path] | None = None) -> pd.DataFrame:
    """Long table for one detector, scope and stage, with a sortable 'Setting' label."""
    frame = sweep_scores(used)
    frame = frame.loc[frame["detector"].eq(detector) & frame["scope"].eq(scope) & frame["calibration_stage"].eq(stage)]
    if representation != "all":
        frame = frame.loc[frame["representation"].eq(representation)]
    frame = frame.merge(sample_labels(used)[["Sample", "Label"]], on="Sample", how="left", validate="many_to_one")
    name = frame["parameter_name"].iloc[0] if not frame.empty else "parameter"
    frame["Parameter"] = frame["parameter_value"].map(_short)
    frame["Setting"] = (frame["representation"] + " · " + name + "=" + frame["Parameter"]
                        + np.where(frame["counts_for_stability"], "", " (not counted)"))
    reps = {"pc3": 0, "pc5": 1, "pc10": 2, "raw": 3}
    keys = frame.apply(lambda row: (reps.get(row["representation"], 9),) + _parameter_sort_key(row["parameter_value"]), axis=1)
    frame["_order"] = keys
    return frame.sort_values("_order").drop(columns="_order").reset_index(drop=True)


def sweep_matrix(sweep: pd.DataFrame, value: str) -> pd.DataFrame:
    """Sample label × setting matrix of the chosen value, settings in sweep order."""
    if sweep.empty:
        return pd.DataFrame()
    settings = list(dict.fromkeys(sweep["Setting"]))
    matrix = sweep.pivot(index="Label", columns="Setting", values=value).astype(float)
    return matrix[settings]


def sweep_summary(sweep: pd.DataFrame, detector: str, scope: str, stage: str,
                  used: set[Path] | None = None) -> pd.DataFrame:
    """Per-sample summary over the counted settings; stability fraction matches the saved file."""
    if sweep.empty:
        return pd.DataFrame()
    counted = sweep.loc[sweep["counts_for_stability"]]
    if counted.empty:  # lof_supporting: shown for support, never counted; summarise every setting
        counted = sweep
    summary = counted.groupby(["Label", "Sample"], observed=True).agg(
        settings=("flag_95", "size"), fraction_flag_95=("flag_95", "mean"), fraction_flag_99=("flag_99", "mean"),
        median_percentile=("null_percentile", "median"), max_percentile=("null_percentile", "max")).reset_index()
    summary["stable (≥60% at 95)"] = summary["fraction_flag_95"].ge(MINIMUM_FRACTION)
    representative = representative_value(detector, scope, used)
    if representative is not None:
        parameter, representation = representative
        rep = sweep.loc[sweep["parameter_value"].eq(parameter) & sweep["representation"].eq(representation),
                        ["Sample", "null_percentile"]].rename(columns={"null_percentile": "representative_percentile"})
        summary = summary.merge(rep, on="Sample", how="left")
    saved = read("stability_fractions.csv", used)
    saved = saved.loc[saved["scope"].eq(scope) & saved["calibration_stage"].eq(stage) & saved["detector"].eq(detector),
                      ["Sample", "stability_fraction"]].rename(columns={"stability_fraction": "saved_stability_fraction"})
    summary = summary.merge(saved, on="Sample", how="left")
    verdict_frame = read("ensemble_verdict.csv", used)
    verdict_frame = verdict_frame.loc[verdict_frame["scope"].eq(scope), ["Sample", "candidate_outlier"]]
    verdict_frame["ensemble candidate"] = _bool(verdict_frame.pop("candidate_outlier"))
    summary = summary.merge(verdict_frame, on="Sample", how="left").merge(t2_flags(used), on="Sample", how="left")
    return summary.sort_values(["fraction_flag_95", "median_percentile"], ascending=False).reset_index(drop=True)


def null_limits(detector: str, scope: str, stage: str, used: set[Path] | None = None) -> pd.DataFrame:
    frame = read("null_limits.csv", used)
    frame["parameter_value"] = frame["parameter_value"].astype(str)
    frame = frame.loc[frame["detector"].eq(detector) & frame["scope"].eq(scope) & frame["calibration_stage"].eq(stage)]
    return frame.dropna(axis=1, how="all").reset_index(drop=True)


def rank_ranges(scope: str, used: set[Path] | None = None) -> pd.DataFrame:
    frame = read("isolation_forest_rank_ranges.csv", used)
    frame = frame.loc[frame["scope"].eq(scope)].merge(sample_labels(used)[["Sample", "Label"]], on="Sample", how="left")
    frame["rank_span"] = frame["isolation_forest_rank_worst"] - frame["isolation_forest_rank_best"]
    return frame[["Label", "Sample", "representation", "isolation_forest_rank_best", "isolation_forest_rank_worst",
                  "rank_span"]].sort_values(["representation", "isolation_forest_rank_best"]).reset_index(drop=True)


def region_candidate_numbers(used: set[Path] | None = None) -> set[int]:
    """Sample numbers that are final ensemble candidates in their own region scope (not pooled)."""
    if not available():
        return set()
    frame = read("ensemble_verdict.csv", used)
    frame = frame.loc[frame["scope"].isin(["cerebellum", "cortex", "hippocampus"]) & _bool(frame["candidate_outlier"])]
    labels = sample_labels(used).set_index("Sample")["Sample number"]
    return set(frame["Sample"].map(labels).dropna().astype(int))
