"""Prepare the missing all-60 OLS snapshot BEFORE launching the read-only app.

Run: python -m app.prepare_metabolomics
Uses the current pipeline's saved, mode-normalized all-60 matrix and full
statsmodels function. This is a differential-only preparation, not a claim
that the sibling T²-95-only pipeline has run an unsupported full variant.
"""

import hashlib
import json
from pathlib import Path
import subprocess

from app import ROOT, compute, data, registry


def prepare() -> Path:
    output = registry.differential_roots("metabolomics", "all60")[0]
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    used = set()
    values, metadata = data.inputs("metabolomics", used=used)
    fitted = compute.fit_regionwise_differential(values, metadata, fdr_denominator="all_features")
    effects = data.annotate(fitted.effects, "metabolomics", used)
    output.mkdir(parents=True)
    for stage in ("00_inputs", "03_differential"):
        (output / stage).mkdir()
    values.to_csv(output / "00_inputs/differential_input_matrix.csv", index_label="Feature")
    metadata.to_csv(output / "00_inputs/differential_input_metadata.csv", index=False)
    # Keep the standard annotation names in the snapshot; display joins separately.
    effects.rename(columns={"Name": "Metabolite", "Class / method": "Method"}).to_csv(
        output / "03_differential/differential_effects.csv", index=False)
    fitted.feature_qc.to_csv(output / "03_differential/differential_feature_qc.csv", index=False)
    code = ROOT / "src/lpj_lipidomics/statistics/differential.py"
    manifest = {
        "analysis": "all-60 metabolomics differential-only pipeline-function snapshot",
        "n_input_samples": len(metadata), "n_tested_features": len(values),
        "model": "BioGroup * Sex; Saline Control and Male reference levels",
        "fdr": "BH, all panel features within Region x Effect", "min_per_cell": 3,
        "normalization": "inherited from saved region-persistence matrix; mode-specific median-normalized log2",
        "missing_values": "retained; no imputation", "full_sibling_pipeline_run": False,
        "sources": [str(path.relative_to(ROOT)) for path in sorted(used)],
    }
    provenance = {
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "working_tree_source_diff": True,
        "sha256": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [*sorted(used), code, Path(__file__).resolve()]},
        "prompt": "prompts/2026-10-07-pyshiny-explorer-implementation-v1.md",
        "model": "openai/gpt-6-astra",
    }
    (output / "run_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    return output


if __name__ == "__main__":
    print(prepare())
