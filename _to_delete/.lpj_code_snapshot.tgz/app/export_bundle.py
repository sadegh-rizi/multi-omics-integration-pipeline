"""Export a self-contained, read-only deployment bundle of the LPJ Explorer.

    python -m app.export_bundle                      # → dist/lpj-explorer-<date>/ and .zip
    python -m app.export_bundle --out /some/dir --name lpj-explorer-test --no-zip

Standard library only, so any Python ≥ 3.10 can run it (the server environment
is described separately in deploy/environment.yml).

What goes in, and nothing else:

* the app code (``app/``) and the analysis package it imports (``src/lpj_lipidomics``);
* every result file on the app's allow-list (``app.registry.allowed_paths``) that
  exists — the same files the running app is permitted to open;
* ``doc/analysis-state.md`` (linked from the app) and ``deploy/`` (environment,
  server config, smoke check, instructions);
* ``BUNDLE_MANIFEST.json``: source commit, sha256 and size of every file, and
  the allow-listed sources that were absent.

Raw workbooks (``data/``) are never copied; the allow-list excludes them and the
exporter refuses them explicitly. The bundle mirrors the parent folder of this
repository, so files of the sibling ``metabolomics-pipeline`` tree that the
allow-list names keep their relative location and stay "Saved" in the app.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

from app import ROOT, registry

BASE = ROOT.parent
CODE_DIRS = ("app", "src/lpj_lipidomics")
EXTRA_FILES = ("doc/analysis-state.md",)
DEPLOY_DIR = "deploy"
SKIP_PARTS = {"__pycache__", ".pytest_cache", ".ipynb_checkpoints"}
SKIP_SUFFIXES = {".pyc", ".pyo"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _git(*args: str) -> str | None:
    try:
        return subprocess.check_output(["git", "--no-optional-locks", *args], cwd=ROOT, text=True,
                                       stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def _code_files() -> list[Path]:
    files = []
    for directory in CODE_DIRS:
        for path in sorted((ROOT / directory).rglob("*")):
            if path.is_file() and not SKIP_PARTS.intersection(path.parts) and path.suffix not in SKIP_SUFFIXES:
                files.append(path)
    files += [ROOT / name for name in EXTRA_FILES if (ROOT / name).exists()]
    files += sorted(path for path in (ROOT / DEPLOY_DIR).rglob("*") if path.is_file() and not SKIP_PARTS.intersection(path.parts))
    return files


def _result_files() -> tuple[list[Path], list[str]]:
    present, absent = [], []
    for path in sorted(registry.allowed_paths()):
        if not path.is_relative_to(BASE):
            raise ValueError(f"Allow-listed source outside the project folder: {path}")
        if path.exists():
            present.append(path)
        else:
            absent.append(str(path.relative_to(BASE)))
    return present, absent


def plan() -> tuple[list[Path], list[str]]:
    """Files to copy (absolute paths) and allow-listed sources that are absent."""
    results, absent = _result_files()
    files = list(dict.fromkeys([*_code_files(), *results]))
    raw = ROOT / "data"
    for path in files:
        if path.is_relative_to(raw) or path.suffix.lower() in {".xlsx", ".xls"}:
            raise ValueError(f"Refusing to bundle raw data: {path}")
        if path.resolve() != path.absolute():
            raise ValueError(f"Refusing a redirected (symlinked) file: {path}")
    return files, absent


def export(out: Path, name: str, make_zip: bool = True) -> Path:
    target = out / name
    if target.exists() or (make_zip and (out / f"{name}.zip").exists()):
        raise FileExistsError(f"Refusing to overwrite an existing bundle: {target}")
    if target.resolve().is_relative_to((ROOT / "results").resolve()) or target.resolve().is_relative_to((ROOT / "data").resolve()):
        raise ValueError("Write the bundle outside results/ and data/.")
    files, absent = plan()
    entries = []
    for source in files:
        relative = source.relative_to(BASE)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        entries.append({"path": relative.as_posix(), "bytes": destination.stat().st_size, "sha256": _sha256(destination)})
    status = _git("status", "--porcelain", "--", "app", "src", "deploy")
    manifest = {
        "bundle": name,
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "app_dir": f"{ROOT.name}/app",
        "git_commit": _git("rev-parse", "HEAD") or "unrecorded",
        "git_branch": _git("branch", "--show-current") or "unrecorded",
        "code_has_uncommitted_changes": None if status is None else bool(status),
        "exported_with_python": sys.version.split()[0],
        "environment": f"{ROOT.name}/deploy/environment.yml",
        "raw_data_included": False,
        "allow_listed_sources_absent": absent,
        "n_files": len(entries),
        "total_bytes": sum(entry["bytes"] for entry in entries),
        "files": entries,
    }
    (target / "BUNDLE_MANIFEST.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    if make_zip:
        with zipfile.ZipFile(out / f"{name}.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(target.rglob("*")):
                if path.is_file():
                    archive.write(path, (Path(name) / path.relative_to(target)).as_posix())
    return target


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--out", type=Path, default=ROOT / "dist", help="output folder (default: dist/ in the repo)")
    parser.add_argument("--name", default=f"lpj-explorer-{datetime.now():%Y%m%d}", help="bundle folder name")
    parser.add_argument("--no-zip", action="store_true", help="write the folder only")
    parser.add_argument("--dry-run", action="store_true", help="list what would be bundled and stop")
    args = parser.parse_args(argv)
    files, absent = plan()
    size = sum(path.stat().st_size for path in files)
    print(f"{len(files)} files, {size / 1e6:.1f} MB; {len(absent)} allow-listed sources absent")
    if args.dry_run:
        for path in files:
            print("  ", path.relative_to(BASE))
        for path in absent:
            print("   absent:", path)
        return
    target = export(args.out, args.name, not args.no_zip)
    print(f"Bundle written to {target}" + ("" if args.no_zip else f" and {target}.zip"))
    print(f"On the server, serve app_dir = <install dir>/{ROOT.name}/app (see {ROOT.name}/deploy/DEPLOY.md)")


if __name__ == "__main__":
    main()
