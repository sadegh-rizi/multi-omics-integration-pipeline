"""Filter × normalization × outlier-rule sensitivity grid ("multiverse").

Every combination reuses the pipeline's own preprocessing and model functions,
in the order of ``runners/run_pipeline_variant.py``:

    raw → non-positive masked → prevalence filter (all 60, raw positives)
        → blank-dominated features removed → below-detection values masked
        → fully-masked features dropped → optional QC-CV feature filter
        → sample-level outlier removal → log2 → median or PQN normalization
        → OLS BioGroup × Sex per region, BH over the retained panel.

Outlier rules remove SAMPLES, never whole mice. They are all label-blind.
Metabolomics has only the outlier axis: its filters and mode-wise
normalization are fixed by the sibling pipeline, whose all-60 matrix is used.

Two roles, kept apart:
- BUILD side (``matrix``, ``fit``; used only by ``app/build_multiverse.py``)
  reads the raw workbook and refits every combination.
- APP side (``grid``, ``grid_table``, ``feature_across``, ``stability``, rule
  views) reads only the saved grid and allow-listed QC files; the running app
  never opens ``data/``.
Nothing here writes files; ``app/build_multiverse.py`` saves the grid.
"""

from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd

from app import ROOT, compute, data, registry
from lpj_lipidomics.config import MIN_PER_CELL, QC_CV_MIN_INJECTIONS
from lpj_lipidomics.io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from lpj_lipidomics.io.study_design import full_lipidomics_metadata
from lpj_lipidomics.preprocessing import (
    exclude_below_detection, exclude_blank_dominated_features, exclude_low_prevalence_features,
    exclude_nonpositive, log2_transform, median_normalize, pqn_normalize,
)
from lpj_lipidomics.qc.variance import qc_injection_cv

RAW_WORKBOOK = ROOT / "data/1 MB2_088_Lalowski_Report_Final.xlsx"
CAGE_WORKBOOK = ROOT / "data/Samples for metabolomics.xlsx"
ENSEMBLE = ROOT / "results/mia_vs_control/02_qc/ensemble/ensemble_verdict.csv"
GRID_ROOT = ROOT / "results/explorer_prepared/multiverse"
GRID_FILES = ("combinations.csv", "summary.csv", "effects.npz", "outlier_rules.csv", "run_manifest.json", "provenance.json")

# Axis values: (display label, parameter). The first entry is the reference.
PREVALENCE = {"20": ("≤20% missing (pipeline)", 0.20), "none": ("No prevalence filter", None),
              "10": ("≤10% missing", 0.10), "30": ("≤30% missing", 0.30)}
BLANK = {"3": ("3× blank (pipeline)", 3.0), "5": ("5× blank", 5.0), "10": ("10× blank", 10.0)}
QC_CV = {"off": ("No QC-CV filter (pipeline)", None), "30": ("Tech-Mix CV ≤30%", 30.0), "20": ("Tech-Mix CV ≤20%", 20.0)}
NORMALIZATION = {"median": ("Median (pipeline)", "median"), "pqn": ("PQN, per-region reference", "pqn")}
OUTLIERS = {
    "none": "No exclusion",
    "t2_95": "Hotelling T² 95% (per region)",
    "t2_99": "Hotelling T² 99% (per region)",
    "ensemble": "Detector-ensemble candidates (per region)",
    "t2_95_and_ensemble": "T²-95 AND ensemble (agreement)",
    "t2_95_or_ensemble": "T²-95 OR ensemble (union)",
    "difference_95": "Difference-space T²-95, attributed (proposed)",
}
AXES = {"prevalence": PREVALENCE, "blank": BLANK, "qc_cv": QC_CV, "normalization": NORMALIZATION, "outliers": OUTLIERS}
PRIMARY = {"prevalence": "20", "blank": "3", "qc_cv": "off", "normalization": "median", "outliers": "none"}
FIXED_METABOLOMICS = {"prevalence": "pipeline", "blank": "pipeline", "qc_cv": "pipeline", "normalization": "pipeline"}
STATS = ("estimate_log2", "standard_error", "p_value", "p_value_fdr")


@dataclass(frozen=True)
class Combination:
    modality: str
    prevalence: str
    blank: str
    qc_cv: str
    normalization: str
    outliers: str

    @property
    def key(self) -> str:
        return "|".join((self.modality, self.prevalence, self.blank, self.qc_cv, self.normalization, self.outliers))

    @property
    def is_primary(self) -> bool:
        if self.modality == "metabolomics":
            return self.outliers == "none"
        return all(getattr(self, axis) == value for axis, value in PRIMARY.items())

    def label(self) -> str:
        if self.modality == "metabolomics":
            return OUTLIERS[self.outliers] + " · pipeline filters"
        return " · ".join((PREVALENCE[self.prevalence][0], BLANK[self.blank][0], QC_CV[self.qc_cv][0],
                           NORMALIZATION[self.normalization][0], OUTLIERS[self.outliers]))


def combinations(modality: str) -> list[Combination]:
    if modality == "metabolomics":
        return [Combination(modality, *FIXED_METABOLOMICS.values(), rule) for rule in OUTLIERS]
    return [Combination(modality, *values) for values in product(*(list(axis) for axis in AXES.values()))]


def validate(combination: Combination) -> Combination:
    if combination.modality not in registry.MODALITIES:
        raise ValueError("Unknown modality.")
    if combination.outliers not in OUTLIERS:
        raise ValueError("Unknown outlier rule.")
    if combination.modality == "metabolomics":
        if any(getattr(combination, axis) != value for axis, value in FIXED_METABOLOMICS.items()):
            raise ValueError("Metabolomics filters and normalization are fixed by its pipeline.")
        return combination
    for axis in ("prevalence", "blank", "qc_cv", "normalization"):
        if getattr(combination, axis) not in AXES[axis]:
            raise ValueError(f"Unknown {axis} setting.")
    return combination


# ---------------------------------------------------------------- outlier rules
@lru_cache(maxsize=2)
def _rule_numbers(modality: str, version: tuple) -> dict[str, frozenset[int]]:
    """Sample numbers removed by each rule. Region screens are lipidomics-based
    and mapped by sample number, as in the persistence pipeline; the
    difference-space screen is computed on the modality's own data."""
    screens = pd.concat([data.read_csv(ROOT / "results/mia_vs_control/02_qc" / f"outlier_screen_{region.lower()}.csv")
                         for region in registry.REGIONS], ignore_index=True)
    flag = lambda column: frozenset(screens.loc[screens[column].astype(str).str.lower().eq("true"), "Sample number"].astype(int))
    ensemble = data.read_csv(ENSEMBLE)
    regional = ensemble.loc[ensemble["scope"].isin([region.lower() for region in registry.REGIONS])]
    candidates = regional.loc[regional["candidate_outlier"].astype(str).str.lower().eq("true"), "Sample"]
    ensemble_numbers = frozenset(int(sample.split("-")[-1]) for sample in candidates)
    _, assignments = compute.difference_screen(modality)
    _, metadata = data.inputs(modality)
    attributed = assignments.loc[assignments["Limit"].eq(95) & assignments["Sample"].ne(""), "Sample"]
    difference = frozenset(metadata.loc[metadata["Sample"].isin(attributed), "Sample number"].astype(int))
    t2_95, t2_99 = flag("hotelling_t2_95_flag"), flag("hotelling_t2_99_flag")
    return {"none": frozenset(), "t2_95": t2_95, "t2_99": t2_99, "ensemble": ensemble_numbers,
            "t2_95_and_ensemble": t2_95 & ensemble_numbers, "t2_95_or_ensemble": t2_95 | ensemble_numbers,
            "difference_95": difference}


def rule_numbers(modality: str) -> dict[str, frozenset[int]]:
    return _rule_numbers(modality, data.input_version(modality))


def rule_table(modality: str) -> pd.DataFrame:
    """Which samples each rule removes, with region/group/sex/mouse/cage."""
    _, metadata = data.inputs(modality)
    rows = []
    for rule, numbers in rule_numbers(modality).items():
        removed = metadata.loc[metadata["Sample number"].astype(int).isin(numbers)]
        for _, sample in removed.iterrows():
            rows.append({"Rule": rule, "Rule label": OUTLIERS[rule], "Sample": sample["Sample"],
                         "Sample number": int(sample["Sample number"]), "Region": sample["Sample type"],
                         "Group": sample["Bio group"], "Sex": sample["Sex"], "Mouse": sample["Mouse number"],
                         "Cage": sample["Cage"], "Date collected": sample["Date collected"]})
    return pd.DataFrame(rows, columns=["Rule", "Rule label", "Sample", "Sample number", "Region", "Group", "Sex",
                                       "Mouse", "Cage", "Date collected"])


def rule_overlap(modality: str) -> pd.DataFrame:
    """Jaccard agreement between the sample sets removed by each rule."""
    sets = rule_numbers(modality)
    names = list(sets)
    matrix = pd.DataFrame(index=[OUTLIERS[n] for n in names], columns=[OUTLIERS[n] for n in names], dtype=float)
    for left in names:
        for right in names:
            union = sets[left] | sets[right]
            matrix.loc[OUTLIERS[left], OUTLIERS[right]] = 1.0 if not union else len(sets[left] & sets[right]) / len(union)
    return matrix


# ------------------------------------------------------------- preprocessing
@lru_cache(maxsize=1)
def _raw_lipidomics() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    # Build side only: explicit constant inputs, never a browser-supplied path.
    sample_sheet, lipidomics = read_lipidomics_tables(RAW_WORKBOOK)
    samples, blank_columns, techmix_columns = lipidomics_measurement_columns(lipidomics)
    metadata = full_lipidomics_metadata(sample_sheet, samples, cage_workbook=CAGE_WORKBOOK)
    if len(metadata) != 60:
        raise ValueError("Population rule: the raw workbook must yield all 60 samples.")
    raw = lipidomics.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    cv = qc_injection_cv(lipidomics.loc[:, techmix_columns], min_injections=QC_CV_MIN_INJECTIONS)
    for frame in (raw, blanks, cv):
        frame.index = frame.index.astype(str)
    annotations = pd.DataFrame({"Feature": lipidomics.index.astype(str), "Name": lipidomics["Lipid Name"].to_numpy(),
                                "Class / method": lipidomics["Lipid Class"].to_numpy()})
    return raw, blanks, cv, metadata, annotations


@lru_cache(maxsize=48)
def _filtered_lipidomics(prevalence: str, blank: str, qc_cv: str) -> pd.DataFrame:
    """Raw-scale matrix (all 60 samples) after feature filters and masking."""
    raw, blanks, cv, _, _ = _raw_lipidomics()
    positive = exclude_nonpositive(raw)
    fraction = PREVALENCE[prevalence][1]
    filtered = positive if fraction is None else exclude_low_prevalence_features(positive, max_missing_fraction=fraction)
    multiplier = BLANK[blank][1]
    filtered = exclude_blank_dominated_features(filtered, blanks.loc[filtered.index], blank_multiplier=multiplier)
    detectable = exclude_below_detection(filtered, blanks.loc[filtered.index], blank_multiplier=multiplier)
    detectable = detectable.loc[~detectable.isna().all(axis=1)]
    threshold = QC_CV[qc_cv][1]
    if threshold is not None:
        # Not-assessable CVs are excluded, as in the specification curve.
        keep = cv.index[cv["normalized_cv_percent"].le(threshold)]
        detectable = detectable.loc[detectable.index.intersection(keep, sort=False)]
    return detectable


def matrix(combination: Combination) -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    """Normalized log2 matrix and metadata for one combination, plus removed samples."""
    combination = validate(combination)
    removed_numbers = rule_numbers(combination.modality)[combination.outliers]
    if combination.modality == "metabolomics":
        values, metadata = data.inputs("metabolomics")
        # Median/mode normalization is per sample, so subsetting is exact.
    else:
        detectable = _filtered_lipidomics(combination.prevalence, combination.blank, combination.qc_cv)
        _, _, _, metadata, _ = _raw_lipidomics()
        values = detectable
    keep = ~metadata["Sample number"].astype(int).isin(removed_numbers)
    removed = metadata.loc[~keep, "Sample"].tolist()
    metadata = metadata.loc[keep].reset_index(drop=True)
    values = values.loc[:, metadata["Sample"]]
    if combination.modality == "lipidomics":
        logged = log2_transform(values)
        if NORMALIZATION[combination.normalization][1] == "pqn":
            values = pqn_normalize(logged, metadata.set_index("Sample")["Sample type"])
        else:
            values = median_normalize(logged)
    return values, metadata, removed


def build_annotations(modality: str) -> pd.DataFrame:
    """Build side: full feature universe with names (raw workbook for lipidomics)."""
    return _raw_lipidomics()[4] if modality == "lipidomics" else data.annotations(modality)


def annotations(modality: str, used: set | None = None) -> pd.DataFrame:
    """App side: the saved grid's feature universe, falling back to the app's annotations."""
    saved = grid(modality, used)
    if saved is None:
        return data.annotations(modality, used)
    arrays = saved["arrays"]
    return pd.DataFrame({"Feature": arrays["features"].astype(str), "Name": arrays["names"].astype(str),
                         "Class / method": arrays["classes"].astype(str)})


def cell_minimum(metadata: pd.DataFrame) -> int:
    counts = metadata.groupby(["Sample type", "Bio group", "Sex"]).size()
    full = pd.MultiIndex.from_product([registry.REGIONS, ("Saline Control", "MIA"), ("Male", "Female")])
    return int(counts.reindex(full, fill_value=0).min())


@lru_cache(maxsize=64)
def _fit(key: str) -> tuple[pd.DataFrame, dict]:
    combination = Combination(*key.split("|"))
    values, metadata, removed = matrix(combination)
    effects = compute.fit_differential(values, metadata)
    info = {"key": key, "n_samples": len(metadata), "n_features": len(values), "removed": "; ".join(sorted(removed)),
            "n_removed": len(removed), "min_cell": cell_minimum(metadata),
            "whole_mouse_removed": bool(metadata["Mouse number"].nunique() < 20)}
    return effects, info


def fit(combination: Combination) -> tuple[pd.DataFrame, dict]:
    effects, info = _fit(validate(combination).key)
    return effects.copy(), dict(info)


def summarize(effects: pd.DataFrame, key: str) -> pd.DataFrame:
    """One row per Region × Effect, including regions that could not be fitted
    (n_tested = 0), so every combination appears in every summary view."""
    rows = []
    for region in registry.REGIONS:
        for effect in registry.EFFECTS:
            rows_ = effects.loc[effects["Region"].eq(region) & effects["Effect"].eq(effect)] if not effects.empty else effects
            q = rows_["p_value_fdr"] if not rows_.empty else pd.Series(dtype=float)
            p = rows_["p_value"] if not rows_.empty else pd.Series(dtype=float)
            rows.append({"key": key, "Region": region, "Effect": effect, "n_tested": int(p.notna().sum()),
                         "n_q05": int(q.le(.05).sum()), "n_q10": int(q.le(.10).sum()), "n_p05": int(p.le(.05).sum()),
                         "min_q": float(q.min()) if q.notna().any() else np.nan})
    return pd.DataFrame(rows)


# --------------------------------------------------------------- saved grid
def grid_path(modality: str, name: str) -> Path:
    return registry.permitted(GRID_ROOT / modality / name)


def grid_available(modality: str) -> bool:
    return all(grid_path(modality, name).exists() for name in GRID_FILES)


@lru_cache(maxsize=2)
def _grid(modality: str, version: tuple) -> dict:
    with np.load(grid_path(modality, "effects.npz"), allow_pickle=False) as archive:
        arrays = {name: archive[name] for name in archive.files}
    return {"arrays": arrays, "combinations": data.read_csv(grid_path(modality, "combinations.csv")),
            "summary": data.read_csv(grid_path(modality, "summary.csv")),
            "rules": data.read_csv(grid_path(modality, "outlier_rules.csv"))}


def grid(modality: str, used: set | None = None) -> dict | None:
    if not grid_available(modality):
        return None
    paths = [grid_path(modality, name) for name in GRID_FILES]
    if used is not None:
        used.update(paths)
    return _grid(modality, tuple(data.stamp(path) for path in paths))


def saved_rules_current(modality: str, used: set | None = None) -> bool:
    """The saved grid is only valid if the outlier rules still remove the same samples."""
    saved = grid(modality, used)
    if saved is None:
        return False
    current = rule_table(modality)[["Rule", "Sample number"]].sort_values(["Rule", "Sample number"]).reset_index(drop=True)
    stored = saved["rules"][["Rule", "Sample number"]].sort_values(["Rule", "Sample number"]).reset_index(drop=True)
    return current.astype(str).equals(stored.astype(str))


def grid_table(combination: Combination, used: set | None = None) -> tuple[pd.DataFrame, dict]:
    """One combination's effects (all regions × effects) from the saved grid."""
    saved = grid(combination.modality, used)
    if saved is None:
        return pd.DataFrame(), {}
    combos = saved["combinations"]
    match = np.flatnonzero(combos["key"].astype(str).eq(validate(combination).key).to_numpy())
    if len(match) != 1:
        return pd.DataFrame(), {}
    arrays, c = saved["arrays"], int(match[0])
    features = arrays["features"].astype(str)
    frames = []
    for r, region in enumerate(arrays["regions"].astype(str)):
        for e, effect in enumerate(arrays["effects"].astype(str)):
            block = arrays["values"][c, :, r, e, :].astype(float)
            tested = np.isfinite(block[:, 2])
            frame = pd.DataFrame(block[tested], columns=list(STATS))
            frame.insert(0, "Feature", features[tested])
            frame.insert(1, "Region", region)
            frame.insert(2, "Effect", effect)
            frames.append(frame)
    table = pd.concat(frames, ignore_index=True)
    table = table.merge(annotations(combination.modality, used), on="Feature", how="left", validate="many_to_one")
    return table, combos.iloc[c].to_dict()


def feature_across(modality: str, feature: str, region: str, effect: str, used: set | None = None) -> pd.DataFrame:
    """One feature's estimate, SE and q in every saved combination."""
    saved = grid(modality, used)
    if saved is None:
        return pd.DataFrame()
    arrays = saved["arrays"]
    features, regions, effects = (list(arrays[name].astype(str)) for name in ("features", "regions", "effects"))
    if feature not in features:
        return pd.DataFrame()
    i, r, e = features.index(feature), regions.index(region), effects.index(effect)
    frame = saved["combinations"].copy()
    for s, stat in enumerate(STATS):
        frame[stat] = arrays["values"][:, i, r, e, s].astype(float)
    return frame


def stability(modality: str, region: str, effect: str, used: set | None = None) -> pd.DataFrame:
    """Per feature across all saved combinations where it was tested.

    'Driver' is a pre-declared descriptive heuristic, not a test: comparing
    combinations where the feature reaches q≤0.05 with those where it does
    not, 'SE-driven' means the median |estimate| changes by <20% while the
    median SE shrinks by >15%; 'estimate-driven' means |estimate| grows ≥20%. Both labels describe how the
    numbers move, not why: check which samples the significant combinations remove (removing samples from one
    group × sex cell moves that cell's mean, and the MIA effect is the male contrast).
    """
    saved = grid(modality, used)
    if saved is None:
        return pd.DataFrame()
    arrays = saved["arrays"]
    regions, effects = list(arrays["regions"].astype(str)), list(arrays["effects"].astype(str))
    block = arrays["values"][:, :, regions.index(region), effects.index(effect), :].astype(float)
    estimate, se, q = block[..., 0], block[..., 1], block[..., 3]
    tested = np.isfinite(q)
    significant = tested & (q <= .05)
    primary = np.flatnonzero(saved["combinations"]["is_primary"].astype(str).str.lower().eq("true").to_numpy())
    rows = []
    for i, feature in enumerate(arrays["features"].astype(str)):
        n_tested, n_sig = int(tested[:, i].sum()), int(significant[:, i].sum())
        if n_tested == 0:
            continue
        driver = "never significant" if n_sig == 0 else "always significant" if n_sig == n_tested else "mixed"
        if driver == "mixed":
            sig, non = significant[:, i], tested[:, i] & ~significant[:, i]
            est_ratio = np.nanmedian(np.abs(estimate[sig, i])) / np.nanmedian(np.abs(estimate[non, i]))
            se_ratio = np.nanmedian(se[sig, i]) / np.nanmedian(se[non, i])
            driver = ("estimate-driven" if est_ratio >= 1.2 else
                      "SE-driven" if est_ratio < 1.2 and se_ratio < .85 else "unclear")
        rows.append({"Feature": feature, "n_tested": n_tested, "n_q05": n_sig, "fraction_q05": n_sig / n_tested,
                     "primary_q": float(q[primary[0], i]) if len(primary) else np.nan,
                     "estimate_min": float(np.nanmin(estimate[tested[:, i], i])),
                     "estimate_max": float(np.nanmax(estimate[tested[:, i], i])),
                     "se_min": float(np.nanmin(se[tested[:, i], i])), "se_max": float(np.nanmax(se[tested[:, i], i])),
                     "Driver": driver})
    table = pd.DataFrame(rows)
    return table.merge(annotations(modality, used), on="Feature", how="left").sort_values(
        ["n_q05", "fraction_q05"], ascending=False, kind="stable").reset_index(drop=True)
