# LPJ Lipidomics

This repository contains exploratory lipidomics analysis materials for the LPJ
project. It includes source research files, Jupyter notebooks, reusable Python
analysis functions, tests, and generated analysis results.

## Repository contents

- `data/`: source workbooks and other research inputs. These files are treated
  as immutable.
- `notebooks/`: exploratory analyses, including the MIA versus control
  workflow.
- `src/lpj_lipidomics/`: canonical package organized by analysis domain:
  `io/`, `preprocessing`, `statistics/`, `multivariate/`, `qc/`, `outliers/`,
  and `runners/`.
- `src/*.py`: compatibility imports for the former flat module paths. New code
  should import from `lpj_lipidomics`.
- `tests/`: automated tests for the reusable analysis functions.
- `results/`: derived analysis outputs.
- `doc/`: analysis plans, decisions, and project documentation.

## Setup

Use Python 3 and create a virtual environment from the repository root:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

The required packages include NumPy, pandas, Matplotlib, SciPy, openpyxl,
statsmodels, and pytest.

## Usage

With the virtual environment activated, open the notebooks in `notebooks/` in
your preferred Jupyter environment. The notebooks use the functions in
`src/lpj_lipidomics/` for reusable analysis steps.

Run a package runner from the repository root with:

```bash
PYTHONPATH=src python -m lpj_lipidomics.runners.run_mia_vs_control
```

The standalone detector sweeps write only evidence under
`results/mia_vs_control/02_qc/ensemble/detector_sweeps/`; they do not create or
overwrite the multi-detector ensemble verdict.

Run the automated tests from the repository root with:

```bash
pytest
```

## Interactive explorer

A local PyShiny app for browsing the results lives in `app/`:

```bash
python -m shiny run app/app.py
```

See `app/README.md` for which views show saved pipeline outputs and which recompute.

## Data handling

Do not overwrite or modify files in `data/`. Write new derived outputs to
`results/` and keep the notebook or code used to generate them traceable to
their source inputs.
