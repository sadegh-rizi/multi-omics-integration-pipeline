---
name: lipidomics-analysis
description: Use before modifying lipidomics preprocessing, feature annotation, quality control, differential analysis, or biological interpretation in the LPJ project.
---

# Lipidomics analysis

Read `AGENTS.md`, `doc/agent-rules.md`, and the relevant source-workbook metadata before acting.

## Preprocessing and QC

1. Inspect the actual workbook sheets and determine sample/feature orientation, identifiers, metadata fields, intensity scale, and values used for missing/below-detection measurements.
2. Identify what is known about acquisition, ion mode, internal standards, blanks, pooled QC, batch/run order, feature identification confidence, adducts, and normalization already applied. Clearly label unknowns.
3. Propose filtering, normalization, transformation, and imputation separately. For each, give the rationale, the affected samples/features, and how it will be recorded. Never overwrite source values.
4. Use QC and exploratory diagnostics before differential or multivariate analysis: missingness, distributions, total signal/normalization diagnostics, outliers, batch structure, and PCA where appropriate.

## Interpretation and integration

- Preserve the lipid annotation exactly as supplied and distinguish class-level from species-level and ambiguous identifications.
- Do not overclaim lipid identity, pathway membership, enzyme activity, or causality from abundance changes alone.
- For enrichment, networks, or multi-omics integration, document identifier mapping, database/source version, background set, and model validation.
- Respect the repeated mouse/region/modality study structure in every comparison and validation strategy.

## Completion criteria

Before implementing a change, summarize the available metadata, unknowns that affect validity, proposed processing steps, and validation/diagnostic outputs. At handoff, list actual changes and execution results separately from biological interpretation.
