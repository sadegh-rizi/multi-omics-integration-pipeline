---
name: python-analysis
description: Use when adding or refactoring reusable Python analysis logic, parsing research files, or moving repeated notebook code into modules for this LPJ lipidomics project.
---

# Python analysis

Read `AGENTS.md` and `doc/agent-rules.md` first. This project is notebook-oriented, runs in WSL2, and has no established test suite yet.

## Workflow

1. Inspect the relevant notebook cells, input schema, and existing path handling before editing. Do not infer column semantics from names alone.
2. Keep changes narrow. Extract repeated parsing, transformation, statistical, or plotting logic into small modules only when it improves reuse or testability.
3. Use `pathlib.Path`, explicit function parameters and return values, meaningful names, and type hints on reusable public functions.
4. Preserve missing values deliberately. Do not silently coerce types, fill missing data, mutate input frames unexpectedly, or hide exceptions.
5. Use the existing WSL virtual environment and existing dependencies. Do not add packages without user approval.
6. Run the narrowest meaningful verification available: a targeted import, a small synthetic-data check, or the relevant script/notebook section only if data access and side effects are safe.

## Completion criteria

Report the files changed, real commands/results, whether a notebook was executed, and any unresolved assumptions about the source schema or data semantics.

## Pitfalls

- Do not hard-code Windows or WSL absolute paths.
- Do not convert notebook exploration into a large framework prematurely.
- Do not claim a function is correct solely because it runs on one workbook.
