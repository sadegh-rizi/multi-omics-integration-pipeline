---
name: decision-doc
description: Use when writing a plan, evaluation, or decision record for the LPJ project — produces the doc/decisions/ document, its prompts/ provenance file, and the open-questions register updates in the repository's established format.
---

# Decision document

Read `AGENTS.md`, `doc/agent-rules.md`, `doc/analysis-state.md` and the
`careful-planning` skill first. A decision document is the plan that
`careful-planning` requires; writing one does not authorize implementing it.

## Three files, always together

1. `doc/decisions/YYYY-MM-DD-<topic>-plan.md` — the plan or evaluation.
   (Other suffixes in use: `-task.md`, `-spec.md`, `-brief.md`,
   `-policy-change.md`.)
2. `prompts/YYYY-MM-DD-<topic>-v1.md` — provenance (see `ai-provenance`).
3. `doc/open-questions.md` — add or update register rows for every open
   question the plan raises or answers. The register is an index; the plan
   holds the reasoning.

Also update `doc/analysis-state.md` if the plan changes what is settled,
open, broken, or next.

## Plan document structure

```markdown
# Plan: <question in plain words>

**Status: PROPOSED YYYY-MM-DD — implementation NOT authorized.** <Who asked,
what prompted it.> Confirm §<n> before implementation, per `/careful-planning`.

Outputs would go to `results/...`. Nothing existing is overwritten.

---

## 1. Why this design / what the new information is
## 2. What an exploratory dry run showed (if any) — and its approximations
## 3. The threat that decides whether §2 means anything
## 4. Proposed analysis (numbered subsections, primary before secondary)
## 5. Files (new / changed, with paths)
## 6. Validation (tests, sanity checks, expected positive controls)
## 7. Decisions needed before implementation (numbered, each with options
##    and a recommendation)
## 8. Assumptions and limitations
```

Status values: `PROPOSED` → `CONFIRMED <date>` (with the answers to §7
recorded in a "Confirmed decisions" section) → `IMPLEMENTED <date>, commit
<hash>` → `SUPERSEDED by <file>`.

## Content rules

- State the population for every number (all 60 / T²-95 / T²-99). Never the
  57-sample tree.
- Anything computed during planning is labelled exploratory, with its
  approximations (normal vs t, single-contrast FDR, missing packages).
- Record what the dry run got wrong so it is not repeated.
- Pre-declare thresholds, floors and decision rules in the plan, before
  results exist; say that you did.
- Name the null each claim will be compared against (`null-calibration`).
- Keep the recommendation separate from the options; Sadegh decides.

## Provenance file structure

```markdown
# <Topic>

## Task
<The user's request, quoted verbatim, and any follow-ups.>

## What the agent actually computed
<Inputs by path, methods, approximations, what was not run.>

## Model
<exact model id>; tool/session (Cowork / Claude Code / Claude Science / OpenCode)

## Outputs
<files written>

## Commit
<add after committing>
```

## Completion criteria

The plan exists with status PROPOSED, the provenance file exists and quotes
the request, every open question in §7 has a register row, and
`doc/analysis-state.md` is still accurate.
