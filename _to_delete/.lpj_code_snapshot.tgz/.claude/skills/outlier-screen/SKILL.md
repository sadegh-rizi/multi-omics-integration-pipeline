---
name: outlier-screen
description: Use before proposing, running, or changing any sample-outlier screen or exclusion in the LPJ project — per-region Hotelling T², the region-contrast (within-mouse difference) screen, or any exclusion variant used in inference.
---

# Outlier screen

Read `AGENTS.md`, `doc/agent-rules.md`, `doc/context/population-rule.md` and
`doc/context/outlier-screening.md` first. This skill encodes the exclusion
policy and the screens that are valid under it; it does not authorize a new
exclusion variant.

## Binding policy

- Permitted populations: **all 60**, or removal of **samples** flagged by
  Hotelling T² at 95% or 99%. Never whole-mouse removal. The 57-sample
  population (mouse `C00431239 - 3` removed) is dismissed — do not load
  `results/mia_vs_control/00_inputs/` or anything derived from it.
- All 60 is the primary analysis. Exclusion variants are sensitivity arms,
  reported side by side, never substituted for the primary.
- A screen is always **blind to group label**. Never define "normal"
  separately for control and MIA.

## The standard screen (per region, unpaired designs)

As in `src/lpj_lipidomics/outliers/screen.py`:

1. Samples of one region; autoscale features; complete features only.
2. PCA, **3 components** (`OUTLIER_SCREEN_PCS = 3`).
3. T² on the scores; limit for individual observations:
   `((n-1)^2 / n) * beta.ppf(alpha, p/2, (n-p-1)/2)` with p = 3.
4. Flag at alpha 0.95 and 0.99; report both.

Expect ~5% flags at 95% by construction (1 of 20 per region). A flag rate at
the nominal level is not evidence that outliers exist.

## Region-contrast (paired) designs — screen in difference space

Status: proposed (2026-09-21), not yet a permitted exclusion arm. Use it for
diagnosis now; add it as an arm only after its decision doc is confirmed.

When the test uses within-mouse region differences, screen those:

1. For each contrast (Cx−Cb, Hp−Cb, Cx−Hp), build one difference vector per
   mouse. Centre and scale across **all** mice, not by group.
2. 3 PCs, T² with the Beta limit at n = number of mice.
3. Attribute a flag to a single sample only when it appears in the two
   contrasts that share a region and not in the third:
   - Cx−Cb + Cx−Hp → cortex sample
   - Cx−Cb + Hp−Cb → cerebellum sample
   - Hp−Cb + Cx−Hp → hippocampus sample
   - single contrast → no action (≈1 per contrast expected by chance at 95%)
4. Remove only that sample's pairs (contrast-specific pairing). The mouse
   stays in the contrast that does not involve the flagged region.

## Screens that are wrong here — do not propose them

- **Pooled across regions without centring:** region is ~30% of variance; the
  covariance is the region axis.
- **Pooled, region-centred:** the noisiest region (cerebellum) dominates, and
  flags arrive in cage/date blocks — it detects collection cohort. Mouse
  samples are correlated (up to 0.38), so the Beta limit is mis-calibrated.
- **Split by group (controls only + MIA only):** shrinks each group's
  variance separately; the σ̂-shrinkage mechanism that manufactured the
  Cer(m22:0) q<0.05 hits under T² exclusion.
- **Whole-mouse exclusion**, for any reason.

## Required check after any exclusion

For every result that changes significance between variants, report the
estimate and the SE in each variant. If the estimate is stable and only the
SE moved, the change is selection-induced and the result is not a finding
(see Cer(m22:0) in `doc/context/pipeline-test-evaluation.md`).

## Completion criteria

You can state: the population, the screen used and why it matches the
design, the flagged samples with region/group/mouse/cage/date, whether flags
cluster by cage or date, and the estimate-vs-SE comparison for any result
that moved.
