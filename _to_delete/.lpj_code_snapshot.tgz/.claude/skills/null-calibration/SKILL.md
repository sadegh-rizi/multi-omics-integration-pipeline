---
name: null-calibration
description: Use when interpreting counts of significant features, comparing results across groups or exclusion variants, reporting a null, or using permutation or empirical p-values in the LPJ project — calibrates every claim against the right null before it is stated.
---

# Null calibration

Read `doc/context/design-constraints.md` and
`doc/context/pipeline-test-evaluation.md` first. Use after
`statistics-review` has fixed the model; this skill governs how results are
read.

This dataset is null for treatment and highly correlated across features.
Most wrong conclusions in its history came from reading a number against the
wrong reference. Check each item below before writing a claim.

## 1. Counts go against a permutation null, not a uniform one

Features are correlated, so the number of p<0.05 features is over-dispersed.
Compare the observed count to the **label-permutation** distribution
(respecting mouse/cage structure) and report z = (observed − perm mean) /
perm SD. Here the permutation null gave 23–56 nominal discoveries where
uniform predicts ~47, with SD 13–53; nothing was anomalous (|z| ≤ 1.31).

## 2. Report m_eff alongside the nominal panel size

`m_eff = Var(|t|) / Var(mean |t| across permutations)`. Here 16–135 against
a nominal 964. A small-p excess or deficit is not evidence on its own.

## 3. Difference of significance is not significance of difference

Never compare significance counts between groups (e.g. within-control vs
within-MIA). Near a threshold a ~30% shift in t moves counts ~25×. Test the
difference directly (interaction), and if counts are shown, calibrate the
ratio with a label-shuffle null (here ≥25× ratios arose in 36% of shuffles).

## 4. Exclusion dependence: did the estimate move or only the SE?

For any result that gains or loses significance across exclusion variants,
tabulate estimate and SE per variant. Stable estimate + shrinking SE =
selection-induced; not a finding.

## 5. State the resolution floor of every empirical p

- 999 permutations → p ≥ 0.001; BH over ~950 features cannot reach q<0.10.
- Cage-level permutation, 8 cages split 2/6 → C(8,2) = 28 assignments,
  p ≥ 0.036; 3 assignments within 2024-06-11.
An empirical q that cannot reach significance by construction is
uninformative, not a null.

## 6. Dry-run numbers are not pipeline numbers

Normal approximations, single-contrast FDR, or missing scipy make exploratory
computations anti-conservative. Label them as such and expect the pipeline
(t distribution, full contrast family) to give fewer hits.

## 7. Report a null as a power statement

Give the minimum detectable effect at sample and cage level (here 1.8–2.3×
and 2.5–3.5×) next to the plausible effect size. Separate: no detectable
effect / underpowered / no structure in the data (the last is false here).

## 8. Regression to the mean under selection

Units selected because they were extreme (e.g. mice removed by a screen, or
features picked for being top-ranked) will look less extreme on re-measure
or in a second modality. Do not read that as a treatment effect or as
confirmation.

## Completion criteria

For each quantitative claim you can name the null it was compared against,
the resolution floor if empirical, the population, and — if it depends on an
exclusion — the estimate-vs-SE table.
