---
name: region-persistence
description: Use when running, changing, or interpreting the region-signature persistence analysis (within-mouse region contrasts, split-half reliability, disattenuated concordance, region × treatment interaction) in the LPJ project, for lipidomics or metabolomics.
---

# Region persistence

Read `doc/decisions/2026-09-19-region-signature-persistence-plan.md` and
`doc/context/region-persistence.md` first, then `outlier-screen` for the
population. Code: `src/lpj_lipidomics/statistics/region_contrast.py`,
runner `src/lpj_lipidomics/runners/run_region_persistence.py`, tests
`tests/test_region_contrast.py`. Outputs:
`results/mia_vs_control/09_region_persistence/<population>/<modality>/`.

## The question

Does the regional signature (Cx−Cb, Hp−Cb, Cx−Hp) that is present in
controls persist in MIA? It uses the strongest effect in the data as the
readout, and the contrast is within-mouse, so between-animal variance drops
out.

## Procedure

1. **Population:** all 60 primary; T²-99 and T²-95 as sensitivity; the
   difference-space screen as a further arm only once its decision doc is
   confirmed. Pair per contrast — a flagged
   sample removes only its mouse's pairs that involve that region.
2. **Within-group region differential** (the supervisor's step): per group,
   one-sample test of each feature's mouse differences. Descriptive only.
3. **Reliability:** split-half reliability of each group's mean difference
   profile, many random mouse splits, Spearman–Brown corrected.
4. **Concordance:** correlation of control and MIA mean profiles; attenuation
   ceiling `sqrt(rel_C × rel_M)`; disattenuated = observed / ceiling. Values
   near 1 = signature preserved.
5. **Uncertainty:** bootstrap over mice within group. **Inside each
   resample, recompute both reliabilities**, and keep all copies of a
   resampled mouse in the same split-half (split on mouse IDs, not columns).
   Drawing reliability from the original data biases the interval downward —
   this is a known bug in the current code. Sanity check: the point estimate
   must lie inside its own interval.
6. **Per-feature interaction:** compare difference vectors between groups
   (the difference-of-differences), BH within contrast, and report the
   cage-ICC-adjusted q range alongside the raw q.
7. **Cage:** report ICC of the differences; with 4 multi-pup cages it is an
   interval, not an estimate.
8. **Metabolomics:** same pipeline, independent confirmation only within the
   limits of A4 (possible shared extraction).

## Interpretation rules

- A preserved signature is a positive result about the pipeline and the
  biology; it is not evidence of an MIA effect.
- An interval that includes 1 is "unresolved", not "altered".
- Never compare within-group significance counts (Cx−Hp 152 vs 6 was a
  threshold artifact) — see `null-calibration` §3.
- If a concordance estimate drifts across exclusion variants, check which
  mice each variant removes and where they sit in difference space before
  reading anything into the drift.

## Known state (2026-09-24)

All 60, corrected reference intervals: Cx−Cb 1.03 [0.93, 1.08], Hp−Cb 0.88
[0.71, 1.03] (not detectably altered); Cx−Hp unresolved, 1.10 [0.26, 4.67]; per-feature interaction 0 at q<0.05. Bootstrap bug and
whole-mouse pairing still to fix; re-run both modalities afterwards.

## Completion criteria

Population and pairing stated; reliabilities and ceilings reported per group
and contrast; disattenuated estimates with intervals that contain their
point estimates; interaction q (raw and ICC-adjusted); drift across variants
explained by which mice were removed.
