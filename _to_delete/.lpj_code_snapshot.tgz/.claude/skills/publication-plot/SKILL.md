---
name: publication-plot
description: Use when creating, revising, or reviewing exploratory or publication-oriented plots and tables for the LPJ lipidomics project.
---

# Publication plot

Read `AGENTS.md` and `doc/agent-rules.md` first.

## Plotting workflow

1. Establish the analysis purpose: QC, exploration, model diagnostic, effect estimate, or final communication. Do not use a final-looking plot to conceal an unvalidated exploratory result.
2. Check the plotted unit, group definitions, sample count, transformation, and missing-data handling.
3. Use the Matplotlib object-oriented API for reusable figure code. Prefer a colorblind-safe palette and encode group differences with labels/markers as well as color when practical.
4. Show distributions and observations where sample size permits. Do not default to bars of mean ± SEM.
5. Label axes with units and transformations, name groups unambiguously, make legends readable, and avoid deceptive truncated axes.
6. Save or propose a clear output path outside `data/`; use PDF/SVG for final vector figures where appropriate. Do not overwrite existing figures without permission.
7. Save every figure via `plot_config.save_figure`: a vector PDF plus a presentation-resolution PNG and a manuscript-resolution PNG (`_presentation.png` / `_manuscript.png` suffixes). Exact DPI/sizing per venue are placeholders (`PRESENTATION_DPI`, `MANUSCRIPT_DPI` in `src/plot_config.py`) meant to be tuned later, not fixed now — see `doc/agent-rules.md`'s "Figures and tables" section.

## Project conventions

- Shared style, palettes, and category ordering live in `src/plot_config.py`
  (`apply_plot_style`, `validate_categories`, `SEX_COLORS`, `BIO_GROUP_COLORS`,
  `BRAIN_REGION_COLORS`). Use them rather than hard-coding colors per figure.
- Figures belong in `results/<analysis>/`, never in `data/`.

## Completion criteria

State the data source, transformation, grouping, number of observations, output path, and whether the figure was actually generated. Do not claim statistical significance from visual separation alone.

## Pitfalls

- PCA score plots require explained-variance labels and clear handling of grouping/metadata.
- Loading plots require feature/annotation provenance and should not be treated as causal evidence.
- Heatmaps need documented scaling, clustering, distance/linkage choices, and feature selection rules.

<!--
Deliberately omitted: a general matplotlib/seaborn/plotly tutorial (~810 lines)
that previously lived in this file. Modern coding models already know those APIs;
loading the tutorial cost roughly 8% of a full agent session's context every time
this skill triggered, with no benefit. Keep this file limited to project-specific
rules and conventions. If a genuinely non-obvious plotting technique is needed
repeatedly, add that specific snippet — not a library overview.
-->
