---
name: careful-planning
description: Use before starting any implementation in the LPJ project — including notebook cells, modules, scripts, or dependency changes — to resolve open design questions and get an explicit plan confirmed before code is written.
---

# Careful planning

This is the first gate for any non-trivial implementation task in this repository. Read `AGENTS.md` and `doc/agent-rules.md` first; this skill governs how you approach them, not what they say.

## Before writing any code

1. Restate the task and the intended outcome in your own words.
2. Identify every design, scientific, or technical decision the task implies that the user has not already specified. Check in particular:
   - biological unit of observation, experimental unit, and dependency structure (mouse/region/modality repeats);
   - which method, test, or model — and why, versus the alternatives;
   - preprocessing, normalization, imputation, and missing-value handling;
   - covariates, contrasts, exclusions, and multiple-testing correction;
   - whether the change belongs in a notebook cell or a module, and why;
   - output location and naming for any derived file, table, or figure;
   - whether any new dependency is required;
   - scope: what files will be touched, and what is explicitly out of scope.
3. Ask the user every open question from step 2 directly. Do not silently pick a default for an ambiguous biological, statistical, or scope decision — `AGENTS.md`'s instruction priority already requires stopping and stating the ambiguity instead of choosing silently; this skill makes that step mandatory rather than optional judgment.
4. Once questions are answered, write a short plan: files to change, the approach, and the validation command(s) you will run.
5. Wait for explicit confirmation of the plan before making any edit or running any code. A plan you posted is not confirmation — the user has to say go.

## After confirmation

Proceed to implementation and invoke the relevant domain skill for the work itself (`python-analysis`, `lipidomics-analysis`, `statistics-review`, `publication-plot`). This skill only covers the gate before that point.

## Pitfalls

- Do not treat a plausible-sounding default as equivalent to a resolved question — plausible is not the same as confirmed.
- Do not bundle multiple open questions into one broad "let me know if this looks wrong" — ask them as a specific list.
- Do not skip this gate for "quick" changes that touch statistical methods, preprocessing, or data handling; size is not the same as risk.

## Completion criteria

Before implementing, you should be able to point to: the open questions you surfaced, the user's answers, and the confirmed plan. If any of those three is missing, the gate has not been satisfied.
