---
name: statistics-review
description: Use before proposing, implementing, interpreting, or reviewing statistical tests, differential-abundance analyses, multivariate models, or pathway enrichment in the LPJ lipidomics project.
---

# Statistics review

Read `AGENTS.md` and `doc/agent-rules.md` first. This skill checks analytical framing; it does not authorize a scientific conclusion.

## Required analysis brief

Before selecting a test/model, write:

- outcome/features and measurement scale;
- biological question and contrast;
- sample size and the biological/experimental unit;
- MIA/bio-group, sex, brain region, mouse identity, batch, and other covariates available;
- dependency structure (technical replicate, repeated measure, nesting, pairing);
- preprocessing, missing-value strategy, and exclusions;
- multiple-testing family and correction;
- effect size, uncertainty measure, diagnostics, and sensitivity analysis.

If any item is unknown, state it and do not invent a design.

## Method safeguards

- Do not treat multiple region/modality measurements from a mouse as independent.
- Use grouped splitting/cross-validation and permutation schemes that respect mouse identity when fitting supervised models such as PLS-DA.
- Do not choose methods or subgrouping by significance. Keep exploratory and confirmatory results distinct.
- Report adjusted and raw p-values for high-dimensional feature testing and state the FDR procedure and tested-feature universe.
- Treat PCA separation, PLS-DA loadings, correlation, NMF factors, and inferred networks as descriptive unless a validated inferential design supports a stronger claim.
- Document identifier mapping and background/universe choices for pathway enrichment.

## Completion criteria

Return a concise review containing: recommended model/test with rationale, assumptions/diagnostics, multiplicity plan, effect-size reporting, and blocking unknowns. Cite the exact metadata or code inspected.
