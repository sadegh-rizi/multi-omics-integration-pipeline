# Deploying the LPJ Explorer to a server

The explorer is a Shiny for Python app. The recommended host is the lab's
**Shiny Server** (open source, version 1.5.22 or later), the same kind of
server that runs the colleague's proteomics explorer. Each step below says
whether it runs on **your computer** or on the **server**.

| File | Purpose |
|---|---|
| `deploy/environment.yml` | Conda environment: Python 3.12 plus every package pinned to the exact version tested |
| `deploy/requirements.txt` | The same pins, for a plain `venv` instead of conda |
| `deploy/shiny-server.conf.example` | The `location` block to add to the server's config |
| `deploy/smoke_check.py` | Checks an installed bundle (versions, file integrity, app start-up, permissions) |
| `app/export_bundle.py` | Builds the bundle |

## Before you start: access and data

- **Open-source Shiny Server has no login.** Anyone who knows the URL can
  use the app. The usual lab practice is an unguessable path, as in the
  proteomics app's URL. That is obscurity, not access control.
- **The bundle contains sample-level processed data.** It holds normalised
  matrices, per-sample QC and outlier scores; raw workbooks are excluded.
  Agree with your supervisor and the data owner before it goes on a
  network-reachable server.
- If the lab needs real access control, ask the server admin to put the
  location behind the web server's authentication (for example nginx basic
  auth or SSO in front of Shiny Server).

## 1. Build the bundle (your computer, WSL, repository root)

```bash
cd /mnt/d/#University/#MS-SystemsBio/Master_Thesis/repos/LPJ/lipidomics/LPJ_lipidomics
/root/.virtualenvs/LPJ_lipidomics/bin/python -m app.build_multiverse   # only if the grid is missing or stale
/root/.virtualenvs/LPJ_lipidomics/bin/python -m app.export_bundle --dry-run   # what will be included
/root/.virtualenvs/LPJ_lipidomics/bin/python -m app.export_bundle            # → dist/lpj-explorer-YYYYMMDD.zip
```

**Contents:**
- the app;
- the `lpj_lipidomics` package;
- exactly the result files on the app's allow-list (`app/registry.py`);
- `doc/analysis-state.md`;
- `deploy/`;
- `BUNDLE_MANIFEST.json`: commit, an uncommitted-changes flag, and the
  sha256 of every file.

It mirrors the parent folder, so files from the sibling
`metabolomics-pipeline` tree keep their place. `dist/` is git-ignored.
Commit first, so the manifest records a clean commit.

## 2. Copy and unpack (server)

```bash
scp dist/lpj-explorer-YYYYMMDD.zip you@server:/tmp/
ssh you@server
sudo mkdir -p /opt/lpj-explorer
sudo unzip /tmp/lpj-explorer-YYYYMMDD.zip -d /tmp/
sudo rsync -a --delete /tmp/lpj-explorer-YYYYMMDD/ /opt/lpj-explorer/
# Readable by the user Shiny Server runs apps as (usually `shiny`), not by others:
sudo chown -R root:shiny /opt/lpj-explorer
sudo chmod -R u=rwX,g=rX,o= /opt/lpj-explorer
```

**Install outside Shiny Server's `site_dir`** (by default
`/srv/shiny-server`). Shiny Server serves static files from `site_dir`, so
anything placed there could be downloaded directly. The app itself only
serves its own routes.

## 3. Create the Python environment (server, once per version change)

With conda, mamba or micromamba. Put the environment in a system location
the `shiny` user can read; home directories are often private.

```bash
sudo conda env create -p /opt/conda/envs/lpj-explorer -f /opt/lpj-explorer/LPJ_lipidomics/deploy/environment.yml
```

Without conda:

```bash
sudo python3.12 -m venv /opt/lpj-explorer-venv
sudo /opt/lpj-explorer-venv/bin/pip install -r /opt/lpj-explorer/LPJ_lipidomics/deploy/requirements.txt
```

Conda provides only Python 3.12 and pip. All packages come from PyPI at the
exact versions in `requirements.txt`, which are the versions the tests
passed with. They match the pipeline's `requirements-lock.txt`, plus shiny,
shinywidgets and plotly. Linux x86_64 wheels exist for all of them, so no
compiler is needed.

## 4. Smoke-check as the Shiny user (server)

```bash
sudo -u shiny /opt/conda/envs/lpj-explorer/bin/python /opt/lpj-explorer/LPJ_lipidomics/deploy/smoke_check.py
```

It must end with `RESULT: OK`. It prints, for each modality and population,
whether results are *Saved* or *Recomputed*, and whether the sensitivity
grid and the detector ensemble are present.

## 5. Configure Shiny Server (server admin)

Add the `location` block from `deploy/shiny-server.conf.example` inside
`server { … }` in `/etc/shiny-server/shiny-server.conf`:
- Replace `CHANGE-ME-random-token` (for example with `openssl rand -hex 8`).
- Point `python` at the environment from step 3. Setting it inside the
  location affects only this app.

Then:

```bash
sudo systemctl restart shiny-server
```

Open `http(s)://<server>/lpj-explorer-<token>/`. The first start takes 10–30 s.

**Logs:** the newest `*.log` file in `/var/log/shiny-server/`. If the app fails to
start, check them in this order:
1. the `python` path;
2. permissions (re-run step 4 as `shiny`);
3. `app_init_timeout`.

A matplotlib warning about a non-writable cache directory is harmless.

## Updating

1. Export a new bundle.
2. Repeat step 2. `rsync --delete` replaces the old files.
3. Run step 4.
4. `sudo systemctl restart shiny-server`.

Recreate the environment (step 3) only when `deploy/requirements.txt`
changed. Compare the old and new file.

## Other hosting options

- **Plain Linux server without Shiny Server.** Run
  `shiny run --host 127.0.0.1 --port 8000 app/app.py` from `LPJ_lipidomics/`
  under systemd, behind nginx. The proxy must pass WebSockets. Use exactly
  one worker process, or sticky sessions if there are several: Shiny keeps
  each session's state in memory.
- **Posit Connect.** Possible, but the bundle layout (results outside the
  app folder) needs a manifest built with `rsconnect`. Ask if the lab has
  Connect.
- **shinyapps.io or Shinylive.** Not recommended. Both publish the data:
  Shinylive runs in the browser, so every file is downloadable.
