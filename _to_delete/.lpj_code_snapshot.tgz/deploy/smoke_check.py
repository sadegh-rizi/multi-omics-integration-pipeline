"""Check an installed LPJ Explorer bundle before (re)starting the server.

Run with the SAME Python that Shiny Server uses for the app, e.g.

    /opt/conda/envs/lpj-explorer/bin/python /opt/lpj-explorer/LPJ_lipidomics/deploy/smoke_check.py

It checks, without starting a web server:

1. installed package versions equal deploy/requirements.txt;
2. every bundled file still has the sha256 recorded in BUNDLE_MANIFEST.json;
3. the app imports and builds its UI;
4. each modality × population loads and reports Saved or Recomputed;
5. the files the app reads are readable by this user (run it as the
   Shiny Server user, e.g. ``sudo -u shiny ...``, to check permissions).

Exit status is non-zero if anything fails. ``--allow-version-drift`` turns
version mismatches into warnings (recomputed views may then differ slightly
from the pipeline's locked environment).
"""

from __future__ import annotations

import argparse
import hashlib
from importlib import metadata
import json
from pathlib import Path
import sys

REPO = Path(__file__).resolve().parents[1]
BUNDLE = REPO.parent


def _canonical(name: str) -> str:
    return name.lower().replace("_", "-").replace(".", "-")


def check_versions() -> list[str]:
    problems = []
    for line in (REPO / "deploy/requirements.txt").read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name, wanted = line.split("==")
        try:
            found = metadata.version(name)
        except metadata.PackageNotFoundError:
            problems.append(f"{name}: not installed (want {wanted})")
            continue
        if found != wanted:
            problems.append(f"{name}: {found} installed, {wanted} pinned")
    return problems


def check_manifest() -> list[str]:
    path = BUNDLE / "BUNDLE_MANIFEST.json"
    if not path.exists():
        return ["BUNDLE_MANIFEST.json missing (running from a repository checkout, not a bundle?)"]
    problems = []
    for entry in json.loads(path.read_text(encoding="utf-8"))["files"]:
        file = BUNDLE / entry["path"]
        if not file.exists():
            problems.append(f"missing: {entry['path']}")
        elif hashlib.sha256(file.read_bytes()).hexdigest() != entry["sha256"]:
            problems.append(f"changed since export: {entry['path']}")
    return problems


def check_app() -> list[str]:
    sys.path[:0] = [str(REPO), str(REPO / "src")]
    problems = []
    import app.app as entry  # noqa: F401 — builds the full UI
    from app import compute, data, outliers, registry
    from app import multiverse
    print("  UI built:", type(entry.app).__name__)
    for modality in registry.MODALITIES:
        sets = data.sample_sets(modality)
        for population in registry.POPULATIONS:
            samples = sets[population]
            table, badge = compute.differential(modality, samples)
            persisted = compute.persistence_available(modality, samples)
            print(f"  {modality:12s} {population:6s} n={len(samples):2d}  differential: {badge.split(' —')[0]:10s}"
                  f"  persistence saved: {persisted}")
            if table.empty:
                problems.append(f"{modality} {population}: empty differential table")
    print("  detector ensemble available:", outliers.available())
    for modality in registry.MODALITIES:
        present = (multiverse.GRID_ROOT / modality / "effects.npz").exists()
        print(f"  sensitivity grid ({modality}):", "present" if present else "ABSENT - tab will say so")
    for path in sorted(registry.allowed_paths()):
        if path.exists():
            try:
                with path.open("rb") as handle:
                    handle.read(1)
            except OSError as error:
                problems.append(f"unreadable: {path} ({error})")
    return problems


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-version-drift", action="store_true")
    args = parser.parse_args()
    print("Python", sys.version.split()[0], "at", sys.executable)
    failures = []
    versions = check_versions()
    print(f"1. package versions: {'OK' if not versions else f'{len(versions)} mismatches'}")
    for line in versions:
        print("   ", line)
    if versions and not args.allow_version_drift:
        failures += versions
    integrity = check_manifest()
    print(f"2. file integrity: {'OK' if not integrity else f'{len(integrity)} problems'}")
    for line in integrity[:20]:
        print("   ", line)
    failures += integrity
    print("3-5. app checks:")
    app_problems = check_app()
    for line in app_problems:
        print("   ", line)
    failures += app_problems
    print("RESULT:", "OK" if not failures else f"FAILED ({len(failures)} problems)")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
