# LPJ Explorer: deployment instructions for the server admin

**Request:** host a read-only Shiny for Python app (an interactive viewer of
lipidomics and metabolomics results) on the lab's Shiny Server, under its
own URL, with its own Python environment. Other apps on the server are not
affected.

## What it needs

| Item | Requirement |
|---|---|
| Shiny Server | Open source **1.5.22 or later** (`shiny-server --version`); first version that runs Python apps |
| Python | 3.12, via conda/mamba (`environment.yml`) or `python3.12 -m venv` (`requirements.txt`) |
| Disk | about 80 MB app bundle + about 0.7 GB Python environment |
| Memory | about 0.5 GB per running app process |
| Network | PyPI and conda-forge **only while creating the environment**; none at run time |
| Not needed | R, a database, root at run time, outbound internet, write access to the app folder, secrets |

**Behaviour:**
- The app is read-only: it never writes files, accepts no uploads, and
  opens only a fixed list of result files inside its own folder.
- The first start takes about 10–30 s.

## Steps

Sadegh sends a zip, `lpj-explorer-YYYYMMDD.zip`, made with
`python -m app.export_bundle`. The zip contains `LPJ_lipidomics/` (with
`app/`, `src/`, `results/` and `deploy/`), possibly `metabolomics-pipeline/`,
and `BUNDLE_MANIFEST.json`.

### 1. Unpack outside `site_dir`

Do not use `/srv/shiny-server`: Shiny Server serves plain files from
`site_dir`, so the data would be downloadable.

```bash
sudo mkdir -p /opt/lpj-explorer
unzip lpj-explorer-YYYYMMDD.zip -d /tmp/
sudo rsync -a --delete /tmp/lpj-explorer-YYYYMMDD/ /opt/lpj-explorer/
sudo chown -R root:shiny /opt/lpj-explorer          # group = the user Shiny Server runs apps as
sudo chmod -R u=rwX,g=rX,o= /opt/lpj-explorer
```

### 2. Create the Python environment (once; again only if `deploy/requirements.txt` changes)

```bash
sudo conda env create -p /opt/conda/envs/lpj-explorer \
     -f /opt/lpj-explorer/LPJ_lipidomics/deploy/environment.yml
# or, without conda:
# sudo python3.12 -m venv /opt/lpj-explorer-venv
# sudo /opt/lpj-explorer-venv/bin/pip install -r /opt/lpj-explorer/LPJ_lipidomics/deploy/requirements.txt
```

The `shiny` user must be able to read and execute the environment, so do
not place it in a private home directory. All packages are pinned to exact
versions, and Linux x86_64 wheels exist for all of them.

### 3. Check, as the user Shiny Server runs apps as

```bash
sudo -u shiny /opt/conda/envs/lpj-explorer/bin/python \
     /opt/lpj-explorer/LPJ_lipidomics/deploy/smoke_check.py
```

It must end with `RESULT: OK`. It checks package versions, file checksums
against the manifest, read permissions, and that the app builds.

### 4. Add a location to `/etc/shiny-server/shiny-server.conf`, inside the existing `server { }`

```nginx
location /lpj-explorer-<random-token> {               # e.g. token from: openssl rand -hex 8
  python /opt/conda/envs/lpj-explorer/bin/python;      # allowed per location: only this app uses it
  app_dir /opt/lpj-explorer/LPJ_lipidomics/app;
  log_dir /var/log/shiny-server;
  app_init_timeout 120;
  app_idle_timeout 600;
}
```

Then run `sudo systemctl restart shiny-server`, open
`https://<server>/lpj-explorer-<token>/`, and send the URL to Sadegh.

## Access

The app shows unpublished, sample-level processed data, and open-source
Shiny Server has no login:
- **Minimum:** the unguessable path above.
- **Preferred, if the lab's setup allows:** HTTP authentication or SSO for
  this location at the reverse proxy (nginx/Apache) in front of Shiny Server.

## Updates

Sadegh sends a new zip:
1. Repeat step 1. `rsync --delete` replaces the old files.
2. Run step 3.
3. `sudo systemctl restart shiny-server`.

Repeat step 2 only if `deploy/requirements.txt` differs from the installed
copy.

## Troubleshooting

**Logs:** the newest `*.log` file in `/var/log/shiny-server/`.

| Symptom | Usual cause |
|---|---|
| "An error has occurred / app failed to start" | `python` path wrong, or environment not readable by `shiny` (re-run step 3 as `shiny`) |
| Times out on first load | Slow disk on first import; raise `app_init_timeout` |
| `RESULT: FAILED`, "changed since export" | Files edited or copied incompletely; unpack the zip again |
| Python app shown as a directory listing | Shiny Server older than 1.5.22 |

**Contact:** Sadegh. Full background is in `deploy/DEPLOY.md` in the bundle.
