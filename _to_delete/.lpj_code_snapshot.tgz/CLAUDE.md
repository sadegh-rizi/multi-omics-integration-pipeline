# Claude Code instructions: LPJ lipidomics

## Start here

Before anything else, read `doc/analysis-state.md` — the one-page state of
the analysis: permitted sample populations, what is settled, what is open,
what is known broken, and the next steps. The reasoning behind each line is
in `doc/context/` (one file per topic). Keep `doc/analysis-state.md` current
when a change makes any line in it untrue.

**Binding:** analyse all 60 samples, or remove only the samples flagged by
Hotelling T² > 95% or > 99%. Never remove a whole mouse. The 57-sample
population is dismissed — `results/mia_vs_control/00_inputs/` is still that
tree; do not use it.

Read these files before proposing or making changes:

1. `AGENTS.md`
2. `doc/agent-rules.md`
3. `doc/Analysis plan.docx` when the task changes analysis scope or methods

## Working mode

- Treat this as a WSL2/PyCharm notebook-oriented Python project.
- Use the project's existing WSL virtual environment; do not alter dependencies or environments without approval.
- Make only the requested change. Do not modify raw input data, commit, push, or clean unrelated files unless explicitly asked.
- Prefer a plan and a small, inspectable diff before a broad refactor.
- For a non-trivial change, first summarize the proposed files, assumptions, and validation command(s). Ask when the analysis question is genuinely ambiguous.

## Required finish report

State:

1. files changed;
2. commands actually run and their real results;
3. whether notebooks were executed;
4. assumptions and remaining data, biological, or statistical risks.

Invoke project skills when relevant:

- `/careful-planning` before starting any implementation, to surface open design questions and get a plan confirmed first;
- `/python-analysis` for reusable Python logic or notebook refactoring;
- `/publication-plot` for any figure;
- `/statistics-review` before statistical inference or multivariate modelling;
- `/lipidomics-analysis` before changing lipidomics preprocessing, annotation, or interpretation;
- `/ai-provenance` before committing AI-generated code, analysis, or figures, to save the prompt and stamp the output with its commit;
- `/research-code-style` whenever writing or reviewing any code, to keep it at research-appropriate complexity instead of production-software patterns.
- `/decision-doc` when writing a plan or evaluation, so the plan, its `prompts/` record and the `doc/open-questions.md` rows are produced together;
- `/outlier-screen` before any sample-outlier screen or exclusion variant;
- `/null-calibration` before reading significance counts, comparing variants or groups, using empirical p-values, or reporting a null;
- `/region-persistence` for the within-mouse region-contrast analysis.
