import numpy as np
import pandas as pd

from metabolomics_preprocessing import median_normalize_by_mode, preprocess_metabolomics


def test_preprocessing_uses_global_minimum_positive_floor_and_mode_medians():
    intensity = pd.DataFrame({"S1": [10.0, 2.0, 0.0, 100.0], "S2": [20.0, 3.0, 4.0, 110.0]}, index=list("ABCD"))
    blanks = pd.DataFrame({"B1": [1.0, 0.0, 0.0, 50.0], "B2": [1.0, 0.0, 0.0, 50.0]}, index=list("ABCD"))
    methods = pd.Series(["pos", "pos", "neg", "neg"], index=list("ABCD"))

    values, diagnostics, blank_dominated, medians = preprocess_metabolomics(intensity, blanks, methods)

    assert diagnostics.loc[0, "absolute_floor"] == 2.0
    assert diagnostics.loc[0, "absolute_floor_derivation"] == "global minimum positive metabolomics biological value"
    assert diagnostics.loc[0, "n_features_blank_limit"] == 2
    assert blank_dominated["Metabolite"].tolist() == ["D"]
    assert set(medians.index) == {"neg", "pos"}
    assert values.index.tolist() == ["A", "B"]
    assert np.isclose(values.loc["A", "S1"], -values.loc["B", "S1"])


def test_mode_normalization_does_not_mix_acquisition_modes():
    values = pd.DataFrame({"S1": [1.0, 3.0, 10.0, 14.0]}, index=list("ABCD"))
    normalized, medians = median_normalize_by_mode(values, pd.Series(["pos", "pos", "neg", "neg"], index=list("ABCD")))

    assert medians.loc["pos", "S1"] == 2.0
    assert medians.loc["neg", "S1"] == 12.0
    assert normalized["S1"].tolist() == [-1.0, 1.0, -2.0, 2.0]
