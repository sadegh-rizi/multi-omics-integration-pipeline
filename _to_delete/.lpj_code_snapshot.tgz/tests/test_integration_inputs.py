from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from lpj_lipidomics.io.proteomics import read_perseus_proteomics
from lpj_lipidomics.runners.run_integration_inputs import (
    _check_metadata_agreement,
    _marker_checks,
    _validate_metadata,
)
from lpj_lipidomics.runners.run_integration_tests import (
    mouse_group_assignments,
    mouse_grouped_folds,
    treatment_score_test,
)


def test_perseus_reader_skips_metadata_rows_and_aligns_sample_numbers(tmp_path: Path):
    source = tmp_path / "proteomics_Cerebellum.txt"
    source.write_text(
        "MLalowski_Cerebellum_MIA_05 MaxLFQ Unique Intensity\t"
        "MLalowski_Cerebellum_control_02 MaxLFQ Unique Intensity\tProtein ID\tGene\n"
        "#!{Type}\tE\tT\tT\n"
        "16.0\t17.0\tsp|P1|X\tGabra6\n"
        "18.0\t19.0\tsp|P2|Y\tCalb1\n",
        encoding="utf-8",
    )
    values, annotations = read_perseus_proteomics(source, expected_region="Cerebellum")
    assert list(values.columns) == ["MB2_088-05", "MB2_088-02"]
    assert list(values.index) == ["sp|P1|X", "sp|P2|Y"]
    assert annotations.loc["sp|P1|X", "Gene"] == "Gabra6"
    assert values.loc["sp|P2|Y", "MB2_088-02"] == 19.0


def _metadata() -> pd.DataFrame:
    rows = []
    for mouse in range(20):
        for region in ("Cerebellum", "Cortex", "Hippocampus"):
            sample_number = mouse * 3 + {"Cerebellum": 1, "Cortex": 2, "Hippocampus": 3}[region]
            rows.append({
                "Sample": f"MB2_088-{sample_number:02d}",
                "Sample number": sample_number,
                "Sample type": region,
                "Mouse number": f"M{mouse}",
                "Bio group": "MIA" if mouse >= 10 else "Saline Control",
                "Sex": "Female" if mouse % 2 else "Male",
                "Cage": f"C{mouse // 2}",
                "Date collected": "2024-06-11",
                "Tissue mass (mg)": 1.0,
            })
    return pd.DataFrame(rows)


def test_integration_metadata_requires_three_regions_per_mouse():
    metadata = _metadata()
    _validate_metadata(metadata)
    broken = metadata.drop(index=0)
    with pytest.raises(ValueError, match="all 60 samples"):
        _validate_metadata(broken)


def test_marker_checks_use_within_mouse_region_contrasts():
    metadata = _metadata()
    values = pd.DataFrame(
        0.0,
        index=["P1"],
        columns=metadata["Sample"],
    )
    values.loc["P1", metadata.loc[metadata["Sample type"].eq("Cerebellum"), "Sample"]] = 2.0
    annotations = pd.DataFrame({"Gene": ["Gabra6"]}, index=pd.Index(["P1"], name="Protein ID"))
    checks = _marker_checks(values, annotations, metadata)
    assert checks.loc[0, "direction_matches"]
    assert checks.loc[0, "n_mouse_pairs"] == 20
    assert np.isclose(checks.loc[0, "mean_target_minus_other_log2"], 2.0)


def test_metadata_agreement_rejects_changed_mouse_label():
    metadata = _metadata()
    changed = metadata.copy()
    changed.loc[0, "Mouse number"] = "wrong"
    with pytest.raises(ValueError, match="disagree"):
        _check_metadata_agreement(metadata, changed, "metabolomics")


def test_grouped_folds_and_mouse_permutations_preserve_mouse_boundaries():
    metadata = _metadata()
    folds = mouse_grouped_folds(metadata, n_splits=5, n_repeats=2, random_state=4)
    assert len(folds) == 10
    for train, test in folds:
        assert not set(metadata.iloc[train]["Mouse number"]) & set(metadata.iloc[test]["Mouse number"])

    original = metadata.drop_duplicates("Mouse number").groupby("Sex")["Bio group"].value_counts().to_dict()
    for assignment in mouse_group_assignments(metadata, n_permutations=5, random_state=4):
        current = metadata.assign(**{"Bio group": assignment.to_numpy()})
        permuted = current.drop_duplicates("Mouse number").groupby("Sex")["Bio group"].value_counts().to_dict()
        assert permuted == original


def test_treatment_test_uses_cage_assignments_and_mouse_means():
    metadata = _metadata()
    scores = pd.Series(
        np.repeat(np.where(metadata["Bio group"].eq("MIA"), 1.0, 0.0), 1)
        + np.linspace(-0.1, 0.1, len(metadata))
    )
    result = treatment_score_test(
        metadata,
        scores,
        score_name="synthetic",
        n_mouse_permutations=10,
    )
    assert result["n_cage_assignments"] == 252
    assert 0 <= result["cage_permutation_p"] <= 1
    assert 0 <= result["mouse_permutation_p"] <= 1
