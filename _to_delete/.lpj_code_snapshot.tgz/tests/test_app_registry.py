"""Population and source-boundary tests for the explorer."""

from pathlib import Path

import pandas as pd
import pytest

from app import ROOT, data, registry


@pytest.mark.parametrize("name", [
    "results/mia_vs_control/00_inputs/differential_input_matrix.csv",
    "results/mia_vs_control/08_cage_structure/manifest.json",
    "results/mia_vs_control/07_specification_curve/specification_results.csv",
    "data/1 MB2_088_Lalowski_Report_Final.xlsx",
    "results/pipeline_test/../mia_vs_control/00_inputs/differential_input_matrix.csv",
])
def test_excluded_sources(name):
    with pytest.raises(ValueError, match="Population rule"):
        registry.permitted(ROOT / name)


def test_entire_allowlist():
    paths = registry.allowed_paths()
    assert paths
    for path in paths:
        assert registry.permitted(path) == path
        assert "08_cage_structure" not in path.parts
        assert "07_specification_curve" not in path.parts
        assert not path.is_relative_to(ROOT / "results/mia_vs_control/00_inputs")
        assert "primary" not in path.parts


def test_symlink_cannot_redirect_source(tmp_path):
    path = registry.source("lipidomics", "all60", "matrix", tmp_path)
    path.parent.mkdir(parents=True)
    forbidden = tmp_path / "dismissed.csv"
    forbidden.write_text("forbidden")
    path.symlink_to(forbidden)
    with pytest.raises(ValueError, match="Population rule"):
        registry.permitted(path, tmp_path)


@pytest.mark.parametrize("modality", registry.MODALITIES)
def test_primary_population_and_presets(modality):
    values, metadata = data.inputs(modality)
    assert values.shape[1] == 60
    assert metadata["Mouse number"].nunique() == 20
    populations = data.sample_sets(modality)
    assert [len(populations[key]) for key in registry.POPULATIONS] == [60, 55, 58]
    assert not data.removed_mice(metadata, populations["t2_95"])
    assert data.matching_population(modality, populations["all60"][:-1]) is None


def test_whole_mouse_removal():
    metadata = pd.DataFrame({"Sample": ["a", "b", "c"], "Mouse number": ["m1", "m1", "m2"]})
    assert data.removed_mice(metadata, ("a", "c")) == ()
    assert data.removed_mice(metadata, ("c",)) == ("m1",)


def test_cache_returns_copies():
    path = registry.source("lipidomics", "all60", "metadata")
    first = data.read_csv(path)
    first.loc[0, "Sample"] = "mutated"
    assert data.read_csv(path).loc[0, "Sample"] != "mutated"
