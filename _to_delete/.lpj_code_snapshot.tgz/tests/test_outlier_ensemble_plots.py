import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

matplotlib.use("Agg")

from outlier_ensemble_plots import (
    _representative_percentiles,
    _draw_heatmap,
    _stability_matrix,
    plot_stability_heatmap,
    plot_stability_heatmap_without_mahalanobis,
    sample_label_mapping,
)


def _representative_score_table() -> pd.DataFrame:
    rows = []
    for scope in ("pooled", "cerebellum", "cortex", "hippocampus"):
        samples = [f"{scope}-A", f"{scope}-B"]
        lof_detector = "lof" if scope == "pooled" else "lof_supporting"
        specifications = (
            ("knn_isotropic", "1", "pc3", True),
            ("knn_soft", "1", "pc3", True),
            (lof_detector, "10" if scope == "pooled" else "8", "pc3", True),
            ("mahalanobis", "auto", "raw", True),
            ("isolation_forest", "50", "pc3", True),
            ("kernel_pca", "0.1", "pc3", True),
        )
        for detector, parameter, representation, counts in specifications:
            for index, sample in enumerate(samples):
                rows.append({
                    "Sample": sample,
                    "score": float(index + 1),
                    "null_percentile": 0.7 + index * 0.1,
                    "flag_95": index == 1,
                    "detector": detector,
                    "parameter_name": "parameter",
                    "parameter_value": parameter,
                    "representation": representation,
                    "scope": scope,
                    "calibration_stage": "trimmed",
                    "counts_for_stability": counts,
                })
    return pd.DataFrame(rows)


def _representative_verdict_table() -> pd.DataFrame:
    rows = []
    for scope in ("pooled", "cerebellum", "cortex", "hippocampus"):
        for index in range(5):
            rows.append({
                "Sample": f"{scope}-{chr(65 + index)}",
                "scope": scope,
                "hotelling_t2": 0.0,
            })
    return pd.DataFrame(rows)


def test_representative_percentiles_use_regional_supporting_lof():
    representatives = _representative_percentiles(_representative_score_table())
    assert set(representatives["detector"]) == {
        "knn_isotropic",
        "knn_soft",
        "lof",
        "mahalanobis",
        "isolation_forest",
        "kernel_pca",
    }
    assert len(representatives) == 4 * 2 * 6
    assert set(representatives.loc[representatives["scope"].ne("pooled"), "detector"]) == {
        "knn_isotropic",
        "knn_soft",
        "lof",
        "mahalanobis",
        "isolation_forest",
        "kernel_pca",
    }


def test_sample_label_mapping_uses_sex_group_codes_and_sample_number():
    metadata = pd.DataFrame({
        "Sample": ["MB2_088-01", "MB2_088-02"],
        "Sample number": [1, 2],
        "Bio group": ["MIA", "Saline Control"],
        "Sex": ["Male", "Female"],
    })
    assert sample_label_mapping(metadata) == {
        "MB2_088-01": "M_T_01",
        "MB2_088-02": "F_C_02",
    }


def test_continuous_stability_heatmap_exports_all_formats(tmp_path):
    plot_stability_heatmap(_representative_score_table(), tmp_path)
    plot_stability_heatmap_without_mahalanobis(
        _representative_score_table(), _representative_verdict_table(), tmp_path
    )
    assert (tmp_path / "stability_heatmap_all_scopes.pdf").exists()
    assert (tmp_path / "stability_heatmap_all_scopes_presentation.png").exists()
    assert (tmp_path / "stability_heatmap_all_scopes_manuscript.png").exists()
    assert (tmp_path / "stability_heatmap_without_mahalanobis_all_scopes.pdf").exists()
    assert (tmp_path / "stability_heatmap_without_mahalanobis_all_scopes_presentation.png").exists()
    assert (tmp_path / "stability_heatmap_without_mahalanobis_all_scopes_manuscript.png").exists()
    for scope in ("cerebellum", "cortex", "hippocampus"):
        assert (tmp_path / f"stability_heatmap_without_mahalanobis_{scope}.pdf").exists()
        assert (tmp_path / f"stability_heatmap_without_mahalanobis_{scope}_presentation.png").exists()
        assert (tmp_path / f"stability_heatmap_without_mahalanobis_{scope}_manuscript.png").exists()


def test_heatmap_without_mahalanobis_drops_that_column():
    scores = pd.DataFrame({
        "Sample": ["A", "A", "A", "A", "B", "B", "B", "B"],
        "flag_95": [True, False, True, True, False, False, False, False],
        "detector": ["mahalanobis", "mahalanobis", "mahalanobis", "knn_isotropic"] * 2,
        "parameter_value": ["auto", "0.875", "1.0", "1"] * 2,
        "scope": ["pooled"] * 8,
        "calibration_stage": ["trimmed"] * 8,
        "counts_for_stability": [True] * 8,
    })
    general_matrix = _stability_matrix(scores, "pooled")
    without_mahalanobis = general_matrix.drop(columns=["mahalanobis"], errors="ignore")
    assert general_matrix.loc["A", "mahalanobis"] == 2 / 3
    assert set(general_matrix.index) == {"A", "B"}
    assert "mahalanobis" not in without_mahalanobis.columns

    figure, axis = plt.subplots()
    _draw_heatmap(
        axis,
        without_mahalanobis,
        "pooled",
        n_total=2,
        sample_labels={"A": "M_T_01", "B": "F_C_02"},
    )
    assert [label.get_text() for label in axis.get_xticklabels()] == [
        "k-NN\nisotropic",
        "k-NN\nsoft",
        "LOF",
        "Isolation\nForest",
        "Kernel\nPCA",
    ]
    assert [label.get_text() for label in axis.get_yticklabels()] == ["M_T_01", "F_C_02"]
    plt.close(figure)
