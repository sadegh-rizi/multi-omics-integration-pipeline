"""Outlier review: the app's ensemble and detector-sweep views reproduce the saved ensemble outputs."""

import numpy as np
import pandas as pd
import pytest

from app import outliers as ens, registry

pytestmark = pytest.mark.skipif(not ens.available(), reason="Detector-ensemble outputs absent")
REGION_SCOPES = ("cerebellum", "cortex", "hippocampus")


def test_ensemble_sources_are_allow_listed():
    for name in ens.FILES:
        assert registry.permitted(ens.ENSEMBLE / name)


@pytest.mark.parametrize("scope", list(ens.SCOPES))
def test_verdict_rule_rederived_from_saved_stability(scope):
    verdict = ens.verdict(scope).set_index("Sample")
    rule = ens.rederive(scope)
    assert set(rule.index) == set(verdict.index)
    for column in ("stable_detector_count", "stable_non_covariance_count", "candidate_outlier_stage2"):
        assert (verdict.loc[rule.index, column] == rule[column]).all(), column
    expected = verdict["candidate_outlier_stage2"] & ~verdict["calibration_sensitive"]
    assert (verdict["candidate_outlier"] == expected).all()


def test_region_candidates_match_the_recorded_verdict():
    found = {scope: set(ens.verdict(scope).query("candidate_outlier")["Sample number"]) for scope in REGION_SCOPES}
    assert found == {"cerebellum": {35, 56}, "cortex": {22, 25, 31, 37}, "hippocampus": {9, 33}}


@pytest.mark.parametrize("detector", list(ens.DETECTORS))
@pytest.mark.parametrize("stage", list(ens.STAGES))
def test_sweep_summary_reproduces_saved_stability_fraction(detector, stage):
    for scope in ens.options(detector)["scope"]:
        sweep = ens.detector_sweep(detector, scope, stage)
        summary = ens.sweep_summary(sweep, detector, scope, stage)
        n = 60 if scope == "pooled" else 20
        assert len(summary) == n and summary["Label"].is_unique
        if detector in ens.NOT_COUNTED:
            assert summary["saved_stability_fraction"].isna().all()
        else:
            np.testing.assert_allclose(summary["fraction_flag_95"], summary["saved_stability_fraction"], atol=1e-12)
        matrix = ens.sweep_matrix(sweep, "null_percentile")
        assert matrix.shape[0] == n and not matrix.isna().any().any()
        assert matrix.shape[1] == sweep["Setting"].nunique()


@pytest.mark.parametrize("detector", list(ens.DETECTORS))
def test_representative_setting_is_in_every_sweep(detector):
    for scope in ens.options(detector)["scope"]:
        label = ens.setting_label(detector, scope)
        if detector == "knn_soft":
            assert label is None  # not part of the ensemble percentiles
            continue
        assert label in set(ens.detector_sweep(detector, scope, "trimmed")["Setting"]), (detector, scope, label)


@pytest.mark.parametrize("scope", list(ens.SCOPES))
@pytest.mark.parametrize("stage", list(ens.STAGES))
def test_trinity_mean_rebuilt_from_representative_settings(scope, stage):
    """The ◆ settings are the ones the runner used: their percentiles rebuild trinity_mean."""
    parts = []
    for detector in ("mahalanobis", "knn_isotropic", "isolation_forest"):
        sweep = ens.detector_sweep(detector, scope, stage)
        label = ens.setting_label(detector, scope)
        parts.append(sweep.loc[sweep["Setting"].eq(label)].set_index("Sample")["null_percentile"])
    rebuilt = pd.concat(parts, axis=1).mean(axis=1)
    verdict = ens.verdict(scope).set_index("Sample")
    column = f"trinity_mean_{ens.STAGE_SUFFIX[stage]}"
    np.testing.assert_allclose(rebuilt.loc[verdict.index], verdict[column], atol=1e-12)


def test_detector_scopes_match_design():
    assert ens.options("lof")["scope"] == ["pooled"]
    assert "pooled" not in ens.options("lof_supporting")["scope"]
    assert ens.options("mahalanobis")["representation"] == ["raw"]


def test_outlier_tab_builds():
    from app.modules.outlier_review import outlier_ui
    html = str(outlier_ui("outlier"))
    for detector in ens.DETECTORS:
        assert f"outlier-{detector}-view-figure" in html
    assert "outlier-ensemble-view-figure" in html and "outlier-screens-view-figure" in html
