"""Numerical fidelity, source attribution and threshold independence."""

import numpy as np
import pandas as pd
import pytest

from app import compute, data, registry

NUMERIC = ["estimate_log2", "standard_error", "p_value", "p_value_fdr"]


def assert_same(left, right, keys):
    left = left.set_index(keys).sort_index()
    right = right.set_index(keys).sort_index()
    pd.testing.assert_index_equal(left.index, right.index)
    np.testing.assert_allclose(left[NUMERIC], right[NUMERIC], rtol=0, atol=1e-8, equal_nan=True)


@pytest.mark.parametrize("population", registry.POPULATIONS)
def test_lipidomics_differential_fidelity(population):
    samples = data.sample_sets("lipidomics")[population]
    saved, badge = compute.differential("lipidomics", samples)
    recomputed, _ = compute.differential("lipidomics", samples, force=True)
    assert badge.startswith("Saved")
    assert_same(saved, recomputed, ["Feature", "Region", "Effect"])


@pytest.mark.parametrize("modality", registry.MODALITIES)
@pytest.mark.parametrize("population", registry.POPULATIONS)
def test_regional_fidelity(modality, population):
    samples = data.sample_sets(modality)[population]
    for group in ("Saline Control", "MIA"):
        saved, badge = compute.regional(modality, samples, group)
        recomputed, _ = compute.regional(modality, samples, group, force=True)
        expected = "Saved" if registry.source(modality, population, "regional").exists() else "Recomputed"
        assert badge.startswith(expected)
        assert_same(saved, recomputed, ["Feature", "Contrast", "Group"])


def test_fast_matches_full_with_missingness():
    values, metadata = data.inputs("lipidomics")
    values = values.iloc[:35].copy()
    values.iloc[0, :3] = np.nan
    assert_same(compute.fit_differential(values, metadata), compute.fit_differential(values, metadata, full=True),
                ["Feature", "Region", "Effect"])


def test_badge_and_mismatched_metabolomics_population():
    samples = data.sample_sets("metabolomics")["t2_95"]
    _, badge = compute.differential("metabolomics", samples)
    assert badge.startswith("Recomputed")
    _, metadata = data.inputs("metabolomics")
    for sample in set(metadata["Sample"]).difference(samples):
        assert sample in badge
    custom = samples[:-1]
    assert data.badge("metabolomics", custom).startswith("Recomputed")


def test_cross_join_and_thresholds_do_not_fit(monkeypatch):
    samples = data.sample_sets("lipidomics")["all60"]
    table, _ = compute.differential("lipidomics", samples)
    left = table.loc[table["Region"].eq("Cortex") & table["Effect"].eq(registry.EFFECTS[0])]
    right = table.loc[table["Region"].eq("Cerebellum") & table["Effect"].eq(registry.EFFECTS[0])]
    joined = compute.cross_join(left, right)
    shuffled = compute.cross_join(left.sample(frac=1, random_state=4), right.sample(frac=1, random_state=5))
    pd.testing.assert_frame_equal(joined, shuffled)
    calls = []
    monkeypatch.setattr(compute, "fit_differential", lambda *args: calls.append(args))
    for threshold in (0.01, 0.05, 0.5):
        highlighted = compute.highlight(joined, threshold, 0.2)
        assert set(highlighted["Evidence"]) <= {"Both", "X only", "Y only", "Neither"}
    assert not calls


@pytest.mark.parametrize("modality", registry.MODALITIES)
@pytest.mark.parametrize("population", registry.POPULATIONS)
def test_saved_persistence_is_corrected_and_paired(modality, population):
    samples = data.sample_sets(modality)[population]
    if not compute.persistence_available(modality, samples):
        pytest.skip("No complete saved persistence run; tested separately as a recompute path.")
    result, badge = compute.persistence(modality, samples)
    assert badge.startswith("Saved")
    assert set(result) == {"concordance", "reliability", "disattenuation", "interactions", "icc", "pairing"}
    assert len(result["disattenuation"]) == 3
    assert result["disattenuation"]["bootstrap_method"].str.contains("ID-aware").all()
    assert "q_value_icc_upper" in result["interactions"]


def test_missing_persistence_uses_recompute(monkeypatch):
    samples = data.sample_sets("metabolomics")["t2_99"]
    monkeypatch.setattr(compute, "persistence_available", lambda *args: False)
    called = []
    def calculate(*args):
        called.append(args)
        return {"concordance": pd.DataFrame({"value": [1]})}
    monkeypatch.setattr(compute, "_persistence", calculate)
    result, badge = compute.persistence("metabolomics", samples)
    assert called and badge.startswith("Recomputed") and "concordance" in result


def test_pairing_keeps_unaffected_contrast():
    values, metadata = data.inputs("lipidomics")
    removed = metadata.loc[metadata["Sample type"].eq("Cortex")].iloc[0]
    kept = metadata.loc[metadata["Sample"].ne(removed["Sample"])]
    contrasts = compute.contrasts_for(values.loc[:, kept["Sample"]], kept)
    assert contrasts["Hippocampus - Cerebellum"].n_mice == 20
    assert contrasts["Cortex - Cerebellum"].n_mice == 19


def test_empty_sex_scope_does_not_change_model():
    values, metadata = data.inputs("lipidomics")
    males = metadata.loc[metadata["Sex"].eq("Male")]
    assert compute.fit_differential(values.loc[:, males["Sample"]], males).empty
