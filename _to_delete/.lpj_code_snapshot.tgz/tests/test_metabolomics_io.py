import pandas as pd

from metabolomics_io import metabolomics_measurement_columns, metabolomics_sample_numbers


def test_metabolomics_columns_and_integer_join_key():
    samples = [f"MB2_088-{number}" for number in range(1, 61)]
    blanks = ["PostRunBlank-", *[f"PreRunBlank_{number}-" for number in range(1, 6)]]
    techmix = [f"Tech-Mix_{number}-" for number in range(1, 7)]
    result = metabolomics_measurement_columns(pd.DataFrame(columns=["Metabolite", *samples, *blanks, *techmix]))

    assert result == (samples, blanks, techmix)
    assert metabolomics_sample_numbers(["MB2_088-1", "MB2_088-26"]).tolist() == [1, 26]
