from pathlib import Path

import numpy as np
import pytest

from lpj_lipidomics.integration.enrichment import (
    benjamini_hochberg,
    hypergeometric_enrichment,
    parse_gmt,
)
from lpj_lipidomics.runners.run_integration_enrichment import _reference_gmt_files


def test_parse_gmt_skips_comments_and_deduplicates_members(tmp_path: Path):
    path = tmp_path / "go_mouse_v2026.1.gmt"
    path.write_text(
        "# version: 2026.1\nterm-a\tdescription\tGene1\tGene1\tGene2\n",
        encoding="utf-8",
    )

    assert parse_gmt(path) == {"term-a": frozenset({"Gene1", "Gene2"})}


def test_hypergeometric_enrichment_matches_hand_calculation():
    result = hypergeometric_enrichment(
        population=range(10),
        selected={0, 1, 5},
        gene_set={0, 1, 2, 3},
    )

    assert result.population_size == 10
    assert result.selected_size == 3
    assert result.gene_set_size == 4
    assert result.overlap_size == 2
    assert np.isclose(result.raw_p_value, (36 + 4) / 120)


def test_benjamini_hochberg_preserves_input_order():
    assert np.allclose(
        benjamini_hochberg([0.01, 0.04, 0.03, 1.0]),
        [0.04, 0.05333333333333334, 0.05333333333333334, 1.0],
    )


def test_reference_gmt_files_fail_loudly_when_absent(tmp_path: Path):
    with pytest.raises(FileNotFoundError, match="Reference GMT files are absent"):
        _reference_gmt_files(tmp_path / "reference")
