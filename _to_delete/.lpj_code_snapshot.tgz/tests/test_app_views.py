"""Plot data, exports and the prepared metabolomics baseline."""

from io import BytesIO
from zipfile import ZipFile

import numpy as np
import pandas as pd
import pytest

from app import compute, data, plots, registry


def test_prepared_metabolomics_fidelity():
    ids = data.sample_sets("metabolomics")["all60"]
    saved, badge = compute.differential("metabolomics", ids)
    if not registry.differential_source("metabolomics", "all60"):
        pytest.skip("Optional prepared baseline absent")
    actual, _ = compute.differential("metabolomics", ids, force=True)
    assert badge.startswith("Saved")
    columns = ["estimate_log2", "standard_error", "p_value", "p_value_fdr"]
    keys = ["Feature", "Region", "Effect"]
    left, right = saved.set_index(keys).sort_index(), actual.set_index(keys).sort_index()
    pd.testing.assert_index_equal(left.index, right.index)
    np.testing.assert_allclose(left[columns], right[columns], atol=1e-8, rtol=0)


@pytest.mark.parametrize("modality", registry.MODALITIES)
def test_pca_and_difference_screen(modality):
    samples = data.sample_sets(modality)["all60"]
    scores, variance, attribution, n_features = compute.pca(modality, samples, "pooled", 1500)
    assert n_features > 0 and len(scores) == 60
    figure = plots.pca(scores, variance, "PC 1", "PC 2", "Sample type", True, False)
    assert len(figure.data) >= 6
    assert set(attribution["Factor"]) >= {"Region", "Cage", "Collection date", "Tissue mass"}
    screen, assignments = compute.difference_screen(modality)
    assert len(screen) == 60 and not assignments["Permitted exclusion"].any()
    attributed = assignments.loc[assignments["Sample"].ne("")]
    assert attributed["Flagged contrasts"].str.count(";").eq(1).all()


def test_scatter_bundle_keeps_missing_hover_and_exports_three_formats():
    table = pd.DataFrame({"Feature": ["a", "b"], "Name": ["A", "B"], "Class / method": ["PC", "PE"],
                          "estimate_log2": [1., -1.], "standard_error": [.1, np.nan],
                          "p_value": [.01, .1], "p_value_fdr": [.02, .2]})
    table = compute.highlight(table, .05, 0)
    figure = plots.volcano(table, "p_value_fdr", "Evidence", "")
    # Hover missingness is JSON null, not an invented zero or a widget crash.
    assert any(None in row for trace in figure.data for row in trace.customdata)
    bundle = plots.scatter_bundle(figure, table, "OLS; no imputation")
    with ZipFile(BytesIO(bundle)) as archive:
        assert set(archive.namelist()) == {"exploratory_figure.pdf", "exploratory_figure_presentation.png", "exploratory_figure_manuscript.png", "table.csv", "context.txt"}
        assert archive.read("exploratory_figure.pdf").startswith(b"%PDF")
        assert archive.read("exploratory_figure_manuscript.png").startswith(b"\x89PNG")
        assert b"no imputation" in archive.read("context.txt")


def test_display_frame_orders_identifiers_and_rounds_only_the_copy():
    from app.modules.common import display_frame
    raw = pd.DataFrame({"estimate_log2": [0.123456789, np.nan], "Name": ["PC(16:0_18:1)", "PE(18:0_22:6)"],
                        "Feature": ["1", "2"], "p_value": [1.23456789e-7, 0.5], "Class / method": ["PC", "PE"]})
    shown = display_frame(raw)
    assert list(shown.columns[:3]) == ["Feature", "Name", "Class / method"]
    assert shown.loc[0, "estimate_log2"] == 0.1235 and shown.loc[0, "p_value"] == 1.235e-07
    assert np.isnan(shown.loc[1, "estimate_log2"])
    assert raw.loc[0, "estimate_log2"] == 0.123456789  # downloads keep full precision
