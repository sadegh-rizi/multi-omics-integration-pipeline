"""Focused tests for the exploratory integration extension helpers."""

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from lpj_lipidomics.integration.common import spearman_matrix
from lpj_lipidomics.lipid_features import build_lipid_summary_features
from lpj_lipidomics.runners.run_cross_omics_screen import _correlation_distance_labels
from lpj_lipidomics.runners.run_integration_benchmark import _pooled_oof_r2
from lpj_lipidomics.runners.run_mofa_within_region import _recovered_loading_correlations


def test_lipid_summary_features_are_complete_and_fixed_size():
    classes = [f"Class{number}" for number in range(25)]
    feature_names = [f"{classes[index % len(classes)]}({16 + index % 8}:0_{18 + index % 6}:1)" for index in range(70)]
    values = pd.DataFrame(
        np.arange(60 * len(feature_names), dtype=float).reshape(60, len(feature_names)) / 100,
        columns=[str(index) for index in range(len(feature_names))],
    )
    annotations = pd.DataFrame({
        "Lipid Name": feature_names,
        "Lipid Class": classes * 2 + classes[:20],
    }, index=values.columns)
    summaries, definitions = build_lipid_summary_features(values, annotations)
    assert 40 <= summaries.shape[1] <= 100
    assert summaries.index.equals(values.index)
    assert summaries.notna().all().all()
    assert definitions.index.is_unique


def test_spearman_matrix_matches_perfect_rank_relationship():
    left = pd.DataFrame({"a": [1, 2, 3, 4], "b": [4, 3, 2, 1]})
    right = pd.DataFrame({"x": [2, 4, 6, 8], "y": [8, 6, 4, 2]})
    correlation = spearman_matrix(left, right)
    np.testing.assert_allclose(correlation, [[1, -1], [-1, 1]])


def test_mofa_recovery_requires_absolute_loading_correlation_threshold():
    recovered = _recovered_loading_correlations(np.asarray([0.9, 0.8, 0.79, np.nan]))
    assert np.isfinite(recovered[:2]).all()
    assert np.isnan(recovered[2:]).all()


def test_module_profiles_use_correlation_distance():
    profiles = np.asarray([
        [1.0, 0.0, 1.0],
        [2.0, 0.0, 2.0],
        [0.0, 1.0, 0.0],
        [0.0, 2.0, 0.0],
    ])
    labels = _correlation_distance_labels(profiles)
    assert labels[0] == labels[1]
    assert labels[2] == labels[3]
    assert labels[0] != labels[2]


def test_predictability_uses_pooled_out_of_fold_r2():
    source = [
        (np.asarray([[0.0], [1.0], [2.0]]), np.asarray([[3.0]])),
        (np.asarray([[0.0], [1.0], [2.0]]), np.asarray([[4.0]])),
    ]
    target = [
        (np.asarray([[0.0], [1.0], [2.0]]), np.asarray([[3.0]])),
        (np.asarray([[0.0], [1.0], [2.0]]), np.asarray([[4.0]])),
    ]
    predictions = [Ridge(alpha=1.0).fit(train, target_train).predict(test) for (train, test), (target_train, _) in zip(source, target)]
    actual = np.concatenate([test for _, test in target], axis=0)
    expected = 1 - np.square(actual - np.concatenate(predictions, axis=0)).sum() / np.square(actual - actual.mean(axis=0)).sum()
    assert np.isclose(_pooled_oof_r2(source, target), expected)
