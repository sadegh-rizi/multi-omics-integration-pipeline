"""Sensitivity grid: pipeline fidelity, filter nesting, rule properties, summaries."""

import numpy as np
import pandas as pd
import pytest

from app import data, multiverse as mv, registry

KEYS = ["Feature", "Region", "Effect"]
NUMERIC = ["estimate_log2", "standard_error", "p_value", "p_value_fdr"]


def assert_same(left, right, atol=1e-8):
    left = left.set_index(KEYS).sort_index()
    right = right.set_index(KEYS).sort_index()
    pd.testing.assert_index_equal(left.index, right.index)
    np.testing.assert_allclose(left[NUMERIC], right[NUMERIC], rtol=0, atol=atol, equal_nan=True)


@pytest.mark.parametrize("rule, population", [("none", "all60"), ("t2_95", "t2_95"), ("t2_99", "t2_99")])
def test_pipeline_settings_reproduce_saved_lipidomics_output(rule, population):
    saved_path = registry.differential_source("lipidomics", population)
    if saved_path is None:
        pytest.skip("No saved pipeline output for this population")
    combination = mv.Combination("lipidomics", **{**mv.PRIMARY, "outliers": rule})
    fitted, info = mv.fit(combination)
    saved = data.read_csv(saved_path)
    assert info["n_samples"] == len(data.sample_sets("lipidomics")[population])
    assert_same(fitted, saved)


def test_rules_match_presets_and_never_remove_a_whole_mouse():
    _, metadata = data.inputs("lipidomics")
    numbers = mv.rule_numbers("lipidomics")
    for rule, population in (("t2_95", "t2_95"), ("t2_99", "t2_99")):
        kept = set(metadata.loc[~metadata["Sample number"].isin(numbers[rule]), "Sample"])
        assert kept == set(data.sample_sets("lipidomics")[population])
    for rule, removed in numbers.items():
        per_mouse = metadata.loc[metadata["Sample number"].isin(removed)].groupby("Mouse number").size()
        assert per_mouse.max() < 3 if len(per_mouse) else True, rule
    assert numbers["t2_95_and_ensemble"] <= numbers["t2_95"] <= numbers["t2_95_or_ensemble"]


def test_feature_filters_are_nested():
    def features(**changes):
        combination = mv.Combination("lipidomics", **{**mv.PRIMARY, **changes})
        return set(mv.matrix(combination)[0].index)
    assert features(qc_cv="20") <= features(qc_cv="30") <= features(qc_cv="off")
    assert features(prevalence="10") <= features(prevalence="20") <= features(prevalence="30") <= features(prevalence="none")
    assert features(blank="10") <= features(blank="5") <= features(blank="3")


def test_metabolomics_has_only_the_outlier_axis():
    with pytest.raises(ValueError, match="fixed"):
        mv.validate(mv.Combination("metabolomics", "20", "3", "off", "median", "none"))
    assert len(mv.combinations("metabolomics")) == len(mv.OUTLIERS)
    values, metadata, removed = mv.matrix(mv.Combination("metabolomics", *mv.FIXED_METABOLOMICS.values(), "t2_99"))
    assert len(metadata) == 58 and len(removed) == 2 and values.shape[1] == 58


def test_summary_has_every_region_and_effect_even_when_unfittable():
    table = mv.summarize(pd.DataFrame(columns=["Region", "Effect", "p_value", "p_value_fdr"]), "k")
    assert len(table) == len(registry.REGIONS) * len(registry.EFFECTS)
    assert table["n_tested"].eq(0).all() and table["min_q"].isna().all()


def test_pqn_combination_runs_and_differs_only_by_per_sample_shifts():
    median, _, _ = mv.matrix(mv.Combination("lipidomics", **mv.PRIMARY))
    pqn, _, _ = mv.matrix(mv.Combination("lipidomics", **{**mv.PRIMARY, "normalization": "pqn"}))
    shifts = (median - pqn)
    # Within a sample every feature moves by the same amount.
    assert np.nanmax(shifts.max() - shifts.min()) < 1e-9


def test_saved_grid_flags_the_known_se_driven_results():
    if not mv.grid_available("lipidomics"):
        pytest.skip("Grid not built: python -m app.build_multiverse")
    mia = mv.stability("lipidomics", "Cortex", "MIA vs Saline Control").set_index("Name")
    sex = mv.stability("lipidomics", "Cortex", "Female vs Male").set_index("Name")
    assert mia.loc["ChE(22:4)", "Driver"] == "SE-driven"
    assert sex.loc["Cer(m22:0)", "Driver"] == "SE-driven"
    combos = mv.grid("lipidomics")["combinations"]
    assert combos["is_primary"].astype(str).str.lower().eq("true").sum() == 1
    assert len(combos) == len(mv.combinations("lipidomics"))


def test_grid_table_matches_build_fit_to_float32_precision():
    if not mv.grid_available("lipidomics"):
        pytest.skip("Grid not built: python -m app.build_multiverse")
    combination = mv.Combination("lipidomics", "30", "5", "30", "pqn", "t2_99")
    saved, info = mv.grid_table(combination)
    fitted, built = mv.fit(combination)
    assert int(info["n_samples"]) == built["n_samples"] and int(info["n_features"]) == built["n_features"]
    left = saved.set_index(KEYS).sort_index()
    right = fitted.set_index(KEYS).sort_index().loc[left.index]
    np.testing.assert_allclose(left[NUMERIC], right[NUMERIC], rtol=1e-5, atol=1e-6, equal_nan=True)
    assert set(right.index) == set(left.index)
