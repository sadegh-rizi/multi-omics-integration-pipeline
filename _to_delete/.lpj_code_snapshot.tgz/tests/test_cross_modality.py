import pandas as pd
import pytest

from cross_modality import concordance_table, expected_under_independence


def test_concordance_reports_2x2_counts_and_independence_expectation():
    rows = []
    for number in range(1, 61):
        rows.append({"Sample number": number, "Region": "Cortex", "hotelling_t2_95_flag": number == 1})
    lipidomics = pd.DataFrame(rows)
    metabolomics = pd.DataFrame([{**row, "hotelling_t2_95_flag": row["Sample number"] == 1} for row in rows])

    result = concordance_table(lipidomics, metabolomics, "hotelling_t2")

    assert result["n_samples"].sum() == 60
    assert len(result) == 4
    assert result.loc[result["lipidomics_flag"] & result["metabolomics_flag"], "n_samples"].item() == 1
    assert expected_under_independence(60) == pytest.approx(0.15)
