import numpy as np
import pandas as pd
import pytest
from pathlib import Path

from lipidomics_io import lipidomics_measurement_columns, read_lipidomics_tables
from qc_variance import biological_variance_by_region, qc_injection_cv, technical_variance, variance_ratio_table


def test_qc_injection_cv_normalizes_injection_scale_before_calculating_cv():
    techmix = pd.DataFrame({
        "QC1": [10.0], "QC2": [20.0], "QC3": [30.0], "QC4": [40.0],
    }, index=["stable_after_normalization"])

    result = qc_injection_cv(techmix, min_injections=4)

    assert result.loc["stable_after_normalization", "raw_cv_percent"] == pytest.approx(np.std([10, 20, 30, 40], ddof=1) / 25 * 100)
    assert result.loc["stable_after_normalization", "normalized_cv_percent"] == pytest.approx(0.0)


def test_qc_injection_cv_marks_features_with_too_few_injections_not_assessable():
    techmix = pd.DataFrame({
        "QC1": [100.0, 10.0], "QC2": [200.0, 20.0], "QC3": [300.0, np.nan], "QC4": [400.0, np.nan],
    }, index=["reference", "too_few"])

    result = qc_injection_cv(techmix, min_injections=4)

    assert result.loc["too_few", "cv_status"] == "cv_not_assessable"
    assert np.isnan(result.loc["too_few", "normalized_cv_percent"])


def test_qc_raw_cv_agrees_with_vendor_workbook_metric():
    project_root = Path(__file__).resolve().parents[1]
    _, lipidomics = read_lipidomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    _, _, techmix_columns = lipidomics_measurement_columns(lipidomics)

    result = qc_injection_cv(lipidomics.loc[:, techmix_columns])
    vendor_cv_percent = pd.to_numeric(lipidomics["%CV"], errors="coerce") * 100

    assert result["raw_cv_percent"].corr(vendor_cv_percent) == pytest.approx(0.986, abs=0.005)


def test_technical_variance_requires_minimum_replicates():
    values = pd.DataFrame({
        "QC1": [1.0, 2.0], "QC2": [2.0, 2.0], "QC3": [3.0, np.nan],
        "QC4": [4.0, np.nan], "QC5": [np.nan, np.nan], "QC6": [np.nan, np.nan],
    }, index=["eligible", "excluded"])
    result = technical_variance(values, min_replicates=4)
    assert result["eligible"] == np.std([1.0, 2.0, 3.0, 4.0], ddof=1)
    assert np.isnan(result["excluded"])


def test_biological_variance_and_ratio_are_region_specific():
    columns = [f"S{number}" for number in range(8)]
    metadata = pd.DataFrame({
        "Sample": columns,
        "Sample type": ["Cortex"] * 4 + ["Hippocampus"] * 4,
    })
    values = pd.DataFrame([np.arange(8, dtype=float), [1.0, 1.0, 1.0, 1.0, np.nan, np.nan, np.nan, np.nan]], index=["variable", "missing"], columns=columns)
    biological = biological_variance_by_region(values, metadata, min_per_region=4)
    technical = pd.Series({"variable": 2.0, "missing": 1.0})
    ratio = variance_ratio_table(technical, biological, technical_counts=pd.Series({"variable": 6, "missing": 4}))
    cortex = ratio.query("Feature == 'variable' and Region == 'Cortex'").iloc[0]
    assert cortex["n_biological_used"] == 4
    assert cortex["n_techmix_used"] == 6
    assert np.isclose(cortex["variance_ratio"], 4 / np.var([0.0, 1.0, 2.0, 3.0], ddof=1))
    assert bool(cortex["technical_dominated"])
    missing_hippocampus = ratio.query("Feature == 'missing' and Region == 'Hippocampus'").iloc[0]
    assert np.isnan(missing_hippocampus["biological_sd_log2"])
    assert pd.isna(missing_hippocampus["technical_dominated"])
