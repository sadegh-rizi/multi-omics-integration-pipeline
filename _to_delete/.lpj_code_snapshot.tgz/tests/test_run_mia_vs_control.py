import pandas as pd
import pytest

from run_mia_vs_control import _between_group_r2, _linear_score_r2, analysis_metadata


def test_analysis_metadata_keeps_all_mice_and_aligns_samples():
    mice = ["C00431239 - 3", *[f"M{number}" for number in range(19)]]
    full_sheet = pd.DataFrame({
        "Sample number": range(1, 61),
        "Sample type": ["Cortex", "Cerebellum", "Hippocampus"] * 20,
        "Mouse number": [mouse for mouse in mice for _ in range(3)],
        "Bio group": ["MIA"] * 60,
        "Sex": ["Male"] * 60,
        "Tissue mass (mg)": [30.0] * 60,
    })
    columns = [f"MB2_088-{number:02d}" for number in range(1, 61)]
    metadata = analysis_metadata(full_sheet, columns)

    assert len(metadata) == 60
    assert set(metadata["Mouse number"]) == set(mice)
    assert metadata.groupby("Mouse number")["Sample type"].nunique().eq(3).all()
    assert metadata["Sample"].tolist() == columns
    with pytest.raises(ValueError, match="60 samples"):
        analysis_metadata(full_sheet, columns[3:])


def test_score_attribution_helpers_return_between_group_and_linear_r2():
    score = pd.Series([0.0, 1.0, 2.0, 3.0])
    groups = pd.Series(["A", "A", "B", "B"])
    covariate = pd.Series([0.0, 1.0, 2.0, 3.0])

    assert _between_group_r2(score, groups) == pytest.approx(0.8)
    assert _linear_score_r2(score, covariate) == pytest.approx(1.0)
