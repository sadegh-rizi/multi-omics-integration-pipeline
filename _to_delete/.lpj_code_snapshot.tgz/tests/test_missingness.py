import numpy as np
import pandas as pd
import pytest
import sys
import os
sys.path.insert(0, os.path.abspath('src'))

from missingness import (
    missingness_by_feature,
    missingness_by_sample,
    missingness_by_group,
    filtering_stage_summary,
    missingness_by_class_and_group,
    fisher_test_by_class
)
from lipidomics_io import read_lipidomics_tables, lipidomics_measurement_columns
from run_mia_vs_control import full_analysis_metadata
from preprocessing import exclude_nonpositive, exclude_blank_dominated_features, exclude_below_detection
from pathlib import Path


def test_missingness_calculations_synthetic():
    intensity = pd.DataFrame(
        [
            [1.0, 2.0, 3.0, 4.0],
            [np.nan, 2.0, 3.0, 4.0],
            [np.nan, 2.0, np.nan, np.nan],
            [np.nan, np.nan, np.nan, np.nan]
        ],
        index=[0, 1, 2, 3],
        columns=["S1", "S2", "S3", "S4"]
    )
    
    lipid_annotations = pd.DataFrame(
        {"Lipid Class": ["C1", "C1", "C2", "C2"]},
        index=[0, 1, 2, 3]
    )
    lipid_annotations.index.name = "Feature"
    
    metadata = pd.DataFrame({
        "Sample": ["S1", "S2", "S3", "S4"],
        "Group": ["A", "A", "B", "B"]
    })
    
    # 1. Feature missingness
    feat_miss = missingness_by_feature(intensity, lipid_annotations).set_index("Feature")
    assert feat_miss.loc[0, "n_missing"] == 0
    assert feat_miss.loc[1, "n_missing"] == 1
    assert feat_miss.loc[2, "n_missing"] == 3
    assert feat_miss.loc[3, "n_missing"] == 4
    
    # 2. Sample missingness
    samp_miss = missingness_by_sample(intensity, metadata).set_index("Sample")
    assert samp_miss.loc["S1", "n_missing"] == 3
    assert samp_miss.loc["S2", "n_missing"] == 1
    
    # 3. Group summary
    group_sum = missingness_by_group(samp_miss.reset_index(), "Group").set_index("Group")
    assert group_sum.loc["A", "mean_pct_missing"] == 50.0
    
    # 4. Fisher exact helper
    class_group = missingness_by_class_and_group(intensity, lipid_annotations, metadata, "Group")
    fisher = fisher_test_by_class(class_group, "Group", "A", "B").set_index("Lipid Class")
    assert "C1" in fisher.index
    assert fisher.loc["C1", "pct_missing_A"] == 25.0


def test_consistency_with_pipeline_diagnostics():
    """Check that independently recomputed masks reproduce the settled pipeline numbers exactly."""
    data_path = Path("data/1 MB2_088_Lalowski_Report_Final.xlsx")
    if not data_path.exists():
        pytest.skip("Data file not available")
        
    sample_sheet, lipidomics = read_lipidomics_tables(data_path)
    sample_columns, blank_columns, _ = lipidomics_measurement_columns(lipidomics)
    
    raw_intensity = lipidomics.loc[:, sample_columns].apply(pd.to_numeric, errors="coerce")
    raw_blank = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    
    # Base state
    intensity = exclude_nonpositive(raw_intensity)
    
    # Blank filter
    intensity_blank = exclude_blank_dominated_features(intensity, raw_blank)
    n_blank_dominated_removed = intensity.shape[0] - intensity_blank.shape[0]
    
    assert n_blank_dominated_removed == 11, f"Expected 11 blank dominated features removed, got {n_blank_dominated_removed}"
    
    # Detection limit filter
    intensity_det = exclude_below_detection(intensity_blank, raw_blank.loc[intensity_blank.index])
    
    n_below_det_cells = intensity_det.isna().sum().sum() - intensity_blank.isna().sum().sum()
    
    assert n_below_det_cells == 412, f"Expected 412 below detection cells, got {n_below_det_cells}"
