"""Sex-scoped MIA contrasts, automatic labels, PDF export, flag markers and per-sample QC."""

import numpy as np
import pandas as pd
import pytest
import statsmodels.formula.api as smf

from app import compute, data, outliers, plots, registry
from app.modules.sample_overview import sample_qc

KEYS = ["Feature", "Region"]
NUMERIC = ["estimate_log2", "standard_error", "t_statistic", "p_value", "residual_df", "p_value_fdr"]


@pytest.fixture(scope="module")
def lipidomics():
    values, metadata = data.inputs("lipidomics")
    return values, metadata


def _effect(table, effect):
    return table.loc[table["Effect"].eq(effect)].set_index(KEYS).sort_index()


def test_contrasts_reproduce_model_coefficients(lipidomics):
    values, metadata = lipidomics
    reference = compute.fit_differential(values, metadata)
    contrasts = {effect: tuple(float(i == index) for i in range(4))
                 for effect, index in (("MIA vs Saline Control", 1), ("Female vs Male", 2), ("MIA x Female interaction", 3))}
    derived = compute.fit_contrasts(values, metadata, contrasts)
    for effect in contrasts:
        left, right = _effect(reference, effect), _effect(derived, effect)
        pd.testing.assert_index_equal(left.index, right.index)
        np.testing.assert_allclose(left[NUMERIC], right[NUMERIC], rtol=0, atol=1e-10)


def test_female_contrast_equals_refit_with_female_reference(lipidomics):
    values, metadata = lipidomics
    swapped = metadata.assign(Sex=metadata["Sex"].map({"Male": "Female", "Female": "Male"}))
    reference = _effect(compute.fit_differential(values, swapped), "MIA vs Saline Control")
    derived = _effect(compute.fit_contrasts(values, metadata), "MIA vs Saline Control (female)")
    pd.testing.assert_index_equal(reference.index, derived.index)
    np.testing.assert_allclose(reference[NUMERIC], derived[NUMERIC], rtol=0, atol=1e-10)


def test_sex_averaged_contrast_matches_statsmodels_effect_coding(lipidomics):
    values, metadata = lipidomics
    values = values.iloc[:6].copy()
    values.iloc[0, :2] = np.nan  # feature-wise missingness must be handled like the pipeline
    derived = _effect(compute.fit_contrasts(values, metadata), "MIA vs Saline Control (sex-averaged)")
    for region in ("Cortex", "Cerebellum"):
        rows = metadata.loc[metadata["Sample type"].eq(region)]
        for feature in values.index[:3]:
            frame = rows.assign(y=values.loc[feature, rows["Sample"]].to_numpy(),
                                mia=rows["Bio group"].eq("MIA").astype(float),
                                sex=np.where(rows["Sex"].eq("Female"), .5, -.5)).dropna(subset=["y"])
            fit = smf.ols("y ~ mia * sex", data=frame).fit()
            row = derived.loc[(feature, region)]
            assert row["estimate_log2"] == pytest.approx(fit.params["mia"], abs=1e-10)
            assert row["standard_error"] == pytest.approx(fit.bse["mia"], abs=1e-10)
            assert row["p_value"] == pytest.approx(fit.pvalues["mia"], abs=1e-10)


def test_saved_population_gets_derived_rows_with_their_own_badge():
    samples = data.sample_sets("lipidomics")["all60"]
    table, badge = compute.differential("lipidomics", samples)
    assert badge.startswith("Saved")
    assert set(registry.EFFECT_CHOICES) == set(table["Effect"])
    counts = table.groupby("Effect").size()
    assert counts.nunique() == 1
    assert table.loc[table["Effect"].isin(registry.EFFECTS), "contrast_source"].isna().all()
    assert compute.effect_badge(badge, "MIA vs Saline Control (female)").startswith("Derived contrast")
    assert compute.effect_badge(badge, "MIA vs Saline Control") == badge
    # The male + female average equals the sex-averaged row.
    pieces = {effect: _effect(table, effect)["estimate_log2"] for effect in registry.EFFECT_CHOICES}
    np.testing.assert_allclose((pieces["MIA vs Saline Control"] + pieces["MIA vs Saline Control (female)"]) / 2,
                               pieces["MIA vs Saline Control (sex-averaged)"], atol=1e-10)


def test_directional_and_sector_labels():
    rng = np.random.default_rng(1)
    table = pd.DataFrame({"Feature": [f"f{i}" for i in range(80)], "estimate_log2": rng.normal(size=80),
                          "p_value_fdr": rng.uniform(size=80)})
    picks = compute.directional_top(table, "p_value_fdr", 10)
    chosen = table.set_index("Feature").loc[picks]
    assert len(picks) == 20 and (chosen["estimate_log2"].gt(0).sum(), chosen["estimate_log2"].lt(0).sum()) == (10, 10)
    up = table.loc[table["estimate_log2"].gt(0)].nsmallest(10, "p_value_fdr")["Feature"]
    assert set(up) == set(picks[:10])
    cross = pd.DataFrame({"Feature": table["Feature"], "estimate_log2_x": rng.normal(size=80),
                          "estimate_log2_y": rng.normal(size=80)})
    extremes = compute.sector_extremes(cross, 5)
    sectors = np.floor(np.mod(np.arctan2(cross["estimate_log2_y"], cross["estimate_log2_x"]), 2 * np.pi) / (np.pi / 4))
    assert pd.Series(sectors.to_numpy(), index=cross["Feature"]).loc[extremes].value_counts().max() <= 5


def test_volcano_auto_labels_and_pdf():
    samples = data.sample_sets("lipidomics")["all60"]
    table, _ = compute.differential("lipidomics", samples)
    table = compute.highlight(table.loc[table["Region"].eq("Cortex") & table["Effect"].eq("MIA vs Saline Control (sex-averaged)")], .05, 0)
    picks = compute.directional_top(table, "p_value_fdr", 10)
    figure = plots.volcano(table, "p_value_fdr", "Evidence", "", auto=picks)
    labels = [trace for trace in figure.data if trace.name == "Auto labels"]
    assert len(labels) == 1 and len(labels[0].text) == len(picks) == 20
    assert plots.figure_pdf(figure, "context").startswith(b"%PDF")
    assert compute.highlighted_only(table)["Evidence"].eq("Highlighted").all()


def test_feature_plot_rings_flagged_samples():
    values, metadata = data.inputs("lipidomics")
    frame = metadata.assign(Value=values.iloc[0].reindex(metadata["Sample"]).to_numpy())
    frame["Ensemble candidate"] = frame["Sample number"].isin(outliers.region_candidate_numbers())
    figure = plots.feature(frame, "test", "Ensemble candidate", True)
    rings = [trace for trace in figure.data if trace.name == "Ensemble candidate"]
    flagged = frame.loc[frame["Ensemble candidate"] & frame["Value"].notna()]
    assert sum(len(trace.x) for trace in rings) == len(flagged) > 0


def test_sample_qc_table():
    values, metadata = data.inputs("lipidomics")
    sets = data.sample_sets("lipidomics")
    table = sample_qc(values, metadata, {"T²-95 flag": lambda f: ~f["Sample"].isin(sets["t2_95"])})
    assert len(table) == 60 and table["Sample"].is_unique
    assert table["Features observed"].add(values.isna().sum().reindex(table["Sample"]).to_numpy()).eq(len(values)).all()
    assert list(dict.fromkeys(table["Sample type"])) == ["Cerebellum", "Cortex", "Hippocampus"]
    for _, rows in table.groupby("Sample type"):
        assert abs(rows["IQR log₂ robust z (region)"].median()) < 1e-9
    assert table["T²-95 flag"].sum() == 60 - len(sets["t2_95"])
