import pandas as pd

from lipidomics_io import lipidomics_measurement_columns


def test_lipidomics_measurement_columns_selects_expected_report_columns():
    sample_columns = [f"MB2_088-{number:02d}" for number in range(1, 61)]
    blank_columns = [f"PreRunBlank_{number}+.raw" for number in range(1, 6)] + ["PostRunBlank+.raw"]
    techmix_columns = [f"Tech-Mix_{number}+.raw" for number in range(1, 7)]
    lipidomics = pd.DataFrame(columns=["Lipid Name", *sample_columns, *blank_columns, *techmix_columns])

    samples, blanks, techmix = lipidomics_measurement_columns(lipidomics)

    assert samples == sample_columns
    assert blanks == blank_columns
    assert techmix == techmix_columns
