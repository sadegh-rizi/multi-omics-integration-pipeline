"""Exercise the real R CLI's optional denominator and effect-scale arguments."""

import os
from pathlib import Path
import shutil
import subprocess

import numpy as np
import pandas as pd
import pytest


@pytest.mark.parametrize("with_scale", [False, True])
def test_limma_cli_retains_declared_full_panel_denominator(tmp_path, with_scale):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript is not installed")
    root = Path(__file__).resolve().parents[1]
    metadata = pd.DataFrame({
        "Sample": [f"s{i}" for i in range(12)], "Region": "Cortex",
        "BioGroup": ["Saline Control"] * 6 + ["MIA"] * 6,
        "Sex": (["Male"] * 3 + ["Female"] * 3) * 2,
        "Mouse number": [f"m{i}" for i in range(12)],
    })
    values = pd.DataFrame(np.random.default_rng(42).normal(size=(5, 12)), columns=metadata["Sample"])
    values.iloc[-1, :3] = np.nan  # ineligible, but still in the correction universe
    matrix, meta, output = [tmp_path / name for name in ("matrix.csv", "metadata.csv", "effects.csv")]
    values.to_csv(matrix, index_label="Feature")
    metadata.to_csv(meta, index=False)
    arguments = [rscript, str(root / "src" / "differential_moderated.R"), str(matrix), str(meta), str(output), "all_features"]
    if with_scale:
        arguments.append("normalized_log2")
    subprocess.run(arguments, cwd=root, check=True, capture_output=True, text=True,
                   env={**os.environ, "RENV_CONFIG_SYNCHRONIZED_CHECK": "FALSE"})
    result = pd.read_csv(output)
    assert result["Feature"].nunique() == 4
    assert result["fdr_denominator"].eq(5).all()
