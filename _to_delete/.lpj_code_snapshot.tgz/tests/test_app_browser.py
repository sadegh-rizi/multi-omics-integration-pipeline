"""Optional real-Chromium smoke test, using its built-in DevTools protocol.

No Playwright dependency. Run explicitly with LPJ_BROWSER_SMOKE=1; all other
tests remain browser-independent. Chromium and the server are local only.
"""

import asyncio
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from urllib.request import urlopen

import pytest

from app import ROOT
from app import outliers as ens

pytestmark = pytest.mark.skipif(os.environ.get("LPJ_BROWSER_SMOKE") != "1", reason="Opt-in local Chromium smoke test")

TABS = {
    "Overview": "overview-counts", "Select samples": "samples-summary",
    "Sample overview": "sample_overview-scores", "Lipid / metabolite explorer": "feature-view-figure",
    "Differential": "differential-view-table", "Volcano & MA": "volcano-volcano_plot",
    "Cross plots": "cross-view-figure", "Sensitivity grid": "multiverse-view-figure", "Regional DE": "regional-view-figure",
    "Regional persistence": "persistence-population_intervals", "Outlier review": "outlier-ensemble-view-figure",
    "QC": "qc-view-figure", "Classes & structure": "classes-view-figure", "Data & provenance": "provenance-sources",
}


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def wait_url(url, process):
    for _ in range(150):
        if process.poll() is not None:
            raise RuntimeError(f"Process exited while waiting for {url}")
        try:
            with urlopen(url, timeout=1) as response:
                return response.read()
        except OSError:
            time.sleep(.2)
    raise TimeoutError(url)


async def browser_checks(debug_url):
    from websockets.asyncio.client import connect

    pages = json.loads(urlopen(debug_url + "/json/list").read())
    page = next(item for item in pages if item["type"] == "page")
    async with connect(page["webSocketDebuggerUrl"], max_size=20_000_000) as ws:
        sequence = 0

        async def evaluate(expression):
            nonlocal sequence
            sequence += 1
            await ws.send(json.dumps({"id": sequence, "method": "Runtime.evaluate", "params": {"expression": expression, "returnByValue": True, "awaitPromise": True}}))
            while True:
                message = json.loads(await ws.recv())
                if message.get("id") == sequence:
                    assert "error" not in message, message
                    result = message["result"]
                    assert "exceptionDetails" not in result, result
                    return result.get("result", {}).get("value")

        async def wait(expression, timeout=90):
            start = time.monotonic()
            while time.monotonic() - start < timeout:
                result = await evaluate(expression)
                if result:
                    return result
                await asyncio.sleep(.2)
            state = await evaluate("document.body.innerText")
            raise AssertionError(f"Timed out: {expression}\n{state[:8000]}")

        await wait("!!window.Shiny && !!Shiny.shinyapp && Shiny.shinyapp.isConnected()")
        for modality in ("lipidomics", "metabolomics"):
            await evaluate(f"document.querySelector('input[name=modality][value={modality}]').click()")
            await wait(f"document.getElementById('selection_summary').innerText.includes('{modality.title()}') && document.getElementById('selection_summary').innerText.includes('60 samples')")
            for tab, output in TABS.items():
                await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === " + json.dumps(tab) + ").click()")
                await asyncio.sleep(.4)
                if output.endswith(("figure", "scores", "intervals")):
                    await wait(f"!!document.querySelector('#{output} .js-plotly-plot')")
                else:
                    await wait(f"document.getElementById('{output}').innerHTML.length > 0")
                await wait("!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)")
                errors = await evaluate("Array.from(document.querySelectorAll('.tab-pane.active .shiny-output-error')).map(e => e.innerText).filter(Boolean)")
                assert not errors, (modality, tab, errors)
                print(f"Rendered {modality}: {tab}")

        # Exercise the cross-plot axis builders and actual server downloads.
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Cross plots').click()")
        for preset in ("regions", "exclusion", "sex", "persistence"):
            await evaluate(f"Shiny.setInputValue('cross-preset', '{preset}')")
            await asyncio.sleep(.2)
            await evaluate("document.getElementById('cross-apply').click()")
            await asyncio.sleep(.8)
            await wait("!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)")
            errors = await evaluate("Array.from(document.querySelectorAll('.tab-pane.active .shiny-output-error')).map(e => e.innerText).filter(Boolean)")
            assert not errors, (preset, errors)
        for element, signature in (("cross-view-table_csv", "Feature"), ("cross-view-figure_zip", "PK")):
            await wait(f"!!document.getElementById('{element}').getAttribute('href')")
            prefix = await evaluate(f"(async () => {{ const r = await fetch(document.getElementById('{element}').href); if (!r.ok) throw new Error(r.status); return (await r.text()).slice(0,20); }})()")
            assert prefix.startswith(signature), prefix

        # Sex-scoped MIA contrasts, side-by-side volcano/MA, auto labels and downloads.
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Volcano & MA').click()")
        await evaluate("Shiny.setInputValue('volcano-effect', 'MIA vs Saline Control (sex-averaged)')")
        await wait("document.getElementById('volcano-badge').innerText.startsWith('Derived contrast')")
        await wait("!!document.querySelector('#volcano-volcano_plot .js-plotly-plot') && !!document.querySelector('#volcano-ma_plot .js-plotly-plot')")
        await wait("!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)")
        assert await evaluate("document.querySelector('#volcano-volcano_plot .js-plotly-plot').data.some(t => t.name === 'Auto labels')")
        for element, signature in (("volcano-volcano_pdf", "%PDF"), ("volcano-ma_pdf", "%PDF"), ("volcano-highlighted_csv", "Feature")):
            await wait(f"!!document.getElementById('{element}').getAttribute('href')")
            prefix = await evaluate(f"(async () => {{ const r = await fetch(document.getElementById('{element}').href); if (!r.ok) throw new Error(r.status); return (await r.text()).slice(0,20); }})()")
            assert prefix.startswith(signature), (element, prefix)
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Differential').click()")
        await evaluate("Shiny.setInputValue('differential-effect', 'MIA vs Saline Control (female)')")
        await wait("document.getElementById('differential-view-badge').innerText.startsWith('Derived contrast')")

        # Flag rings in the feature explorer; per-sample QC table in Sample overview.
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Lipid / metabolite explorer').click()")
        await evaluate("Shiny.setInputValue('feature-mark', 'Any flag')")
        await wait("document.querySelector('#feature-view-figure .js-plotly-plot') && document.querySelector('#feature-view-figure .js-plotly-plot').data.some(t => (t.name || '').startsWith('Any flag'))")
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Sample overview').click()")
        await evaluate("Shiny.setInputValue('sample_overview-scope', 'Cortex')")
        await wait("document.getElementById('sample_overview-qc_table').innerText.includes('Features observed')")
        await wait("!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)")
        errors = await evaluate("Array.from(document.querySelectorAll('.tab-pane.active .shiny-output-error')).map(e => e.innerText).filter(Boolean)")
        assert not errors, errors

        # Sensitivity grid: a non-primary combination and every inner view.
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Sensitivity grid').click()")
        await evaluate("Shiny.setInputValue('multiverse-outliers', 't2_95')")
        await evaluate("Shiny.setInputValue('multiverse-qc_cv', '30')")
        await wait("document.getElementById('multiverse-view-badge').innerText.includes('Saved sensitivity grid')")
        for inner in ("Across combinations", "One feature across combinations", "Stability", "Outlier rules"):
            await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === " + json.dumps(inner) + ").click()")
            await asyncio.sleep(.6)
            await wait("!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)")
            errors = await evaluate("Array.from(document.querySelectorAll('.tab-pane.active .shiny-output-error')).map(e => e.innerText).filter(Boolean)")
            assert not errors, (inner, errors)
        await wait("!!document.querySelector('#multiverse-overlap .js-plotly-plot')")

        # Outlier review: every ensemble view, every detector sweep, then the per-region screens.
        click = "Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === {}).click()"
        settled = "!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)"
        visible_errors = "Array.from(document.querySelectorAll('.tab-pane.active .shiny-output-error')).filter(e => e.offsetParent !== null).map(e => e.innerText).filter(Boolean)"
        await evaluate(click.format(json.dumps("Outlier review")))
        await evaluate(click.format(json.dumps("Ensemble")))
        for kind in ("stability", "corroboration", "trinity"):
            await evaluate(f"Shiny.setInputValue('outlier-ensemble-kind', '{kind}')")
            await asyncio.sleep(.4)
            await wait(settled)
            await wait("!!document.querySelector('#outlier-ensemble-view-figure .js-plotly-plot')")
            assert not await evaluate(visible_errors), kind
        await evaluate("Shiny.setInputValue('outlier-ensemble-scope', 'pooled')")
        await wait("document.getElementById('outlier-ensemble-view-badge').innerText.includes('invalid for the region design')")
        await evaluate(click.format(json.dumps("Detector sweeps")))
        for name, label in ens.DETECTORS.items():
            await evaluate(click.format(json.dumps(label[0])))
            await asyncio.sleep(.5)
            await wait(f"!!document.querySelector('#outlier-{name}-view-figure .js-plotly-plot')")
            await wait(settled)
            assert not await evaluate(visible_errors), name
            await wait(f"document.getElementById('outlier-{name}-view-badge').innerText.includes('Saved')")
        await evaluate("Shiny.setInputValue('outlier-knn_isotropic-kind', 'curves')")
        await evaluate(click.format(json.dumps(ens.DETECTORS["knn_isotropic"][0])))
        await asyncio.sleep(.6)
        await wait(settled)
        assert not await evaluate(visible_errors)

        # The proposed diagnostic has no control that can apply exclusions.
        await evaluate(click.format(json.dumps("Per-region screens (T² / DModX)")))
        await evaluate("Shiny.setInputValue('outlier-screens-difference', true)")
        await wait("document.getElementById('outlier-screens-view-badge').innerText.includes('difference-space')")
        await wait("!Array.from(document.querySelectorAll('.tab-pane.active .recalculating')).some(e => e.offsetParent !== null)")
        assert await evaluate("document.getElementById('selection_summary').innerText.includes('60 samples')")

        # Empty/single-sex selection must not crash or silently switch the model.
        await evaluate("Shiny.setInputValue('samples-sex', ['Male'])")
        await wait("document.getElementById('selection_summary').innerText.includes('30 samples')")
        await evaluate("Array.from(document.querySelectorAll('a[data-value]')).find(e => e.dataset.value === 'Volcano & MA').click()")
        await wait("document.getElementById('volcano-volcano_plot').innerText.includes('No eligible')")
        await evaluate("Shiny.setInputValue('samples-individual', [])")
        await wait("document.getElementById('selection_summary').innerText.includes('0 samples')")
        await wait("document.getElementById('population_warning').innerText.includes('Whole mice removed')")


def test_all_tabs_both_modalities(tmp_path):
    browser = shutil.which("chromium") or shutil.which("google-chrome")
    if not browser:
        pytest.skip("Chromium not installed; use README manual checklist")
    app_port, browser_port = free_port(), free_port()
    server_log = tmp_path / "server.log"
    browser_log = tmp_path / "browser.log"
    with server_log.open("w") as server_output, browser_log.open("w") as browser_output:
        server = subprocess.Popen([sys.executable, "-m", "shiny", "run", "--host", "127.0.0.1", "--port", str(app_port), "app/app.py"],
                                  cwd=ROOT, stdout=server_output, stderr=subprocess.STDOUT)
        chromium = None
        try:
            wait_url(f"http://127.0.0.1:{app_port}", server)
            chromium = subprocess.Popen([browser, "--headless", "--no-sandbox", "--disable-dev-shm-usage",
                                         f"--remote-debugging-port={browser_port}", f"--user-data-dir={tmp_path / 'chromium'}",
                                         f"http://127.0.0.1:{app_port}"], stdout=browser_output, stderr=subprocess.STDOUT)
            wait_url(f"http://127.0.0.1:{browser_port}/json/version", chromium)
            asyncio.run(browser_checks(f"http://127.0.0.1:{browser_port}"))
        except Exception:
            print(server_log.read_text()[-12000:])
            print(browser_log.read_text()[-3000:])
            raise
        finally:
            for process in (chromium, server):
                if process is not None:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
