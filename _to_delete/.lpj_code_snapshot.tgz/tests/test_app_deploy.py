"""Deployment bundle: pinned environment files agree, raw data never bundled, bundle runs standalone."""

import json
from pathlib import Path
import re
import subprocess
import sys

import pytest

from app import ROOT, export_bundle, registry


def _yml_pins():
    text = (ROOT / "deploy/environment.yml").read_text()
    return sorted(re.findall(r"^\s+- ([A-Za-z0-9_.\-]+==[^\s]+)$", text, flags=re.M))


def _txt_pins():
    lines = (ROOT / "deploy/requirements.txt").read_text().splitlines()
    return sorted(line.strip() for line in lines if line.strip() and not line.startswith("#"))


def test_environment_files_agree_and_are_fully_pinned():
    assert _yml_pins() == _txt_pins()
    assert len(_txt_pins()) > 50
    text = (ROOT / "deploy/environment.yml").read_text()
    assert "- python=3.12" in text
    names = {pin.split("==")[0].lower() for pin in _txt_pins()}
    assert {"shiny", "shinywidgets", "plotly", "numpy", "pandas", "scipy", "statsmodels"} <= names


def test_environment_matches_pipeline_lock():
    """Every package of the pipeline's locked environment keeps its version in the app environment."""
    canon = lambda name: re.sub(r"[-_.]+", "-", name).lower()
    lock = {canon(n): v for n, v in (l.strip().split("==") for l in (ROOT / "requirements-lock.txt").read_text().splitlines()
                                     if "==" in l and not l.startswith("#"))}
    app = {canon(n): v for n, v in (pin.split("==") for pin in _txt_pins())}
    assert {name: app.get(name) for name in lock} == lock


def test_plan_is_allow_list_plus_code_and_never_raw_data():
    files, absent = export_bundle.plan()
    assert not any(path.is_relative_to(ROOT / "data") or path.suffix == ".xlsx" for path in files)
    results = {path for path in files if "results" in path.relative_to(export_bundle.BASE).parts}
    assert results == {path for path in registry.allowed_paths() if path.exists()}
    assert ROOT / "app/app.py" in files and ROOT / "deploy/environment.yml" in files
    assert not any("__pycache__" in path.parts for path in files)


def test_export_and_standalone_smoke_check(tmp_path):
    target = export_bundle.export(tmp_path, "bundle", make_zip=True)
    manifest = json.loads((target / "BUNDLE_MANIFEST.json").read_text())
    assert manifest["raw_data_included"] is False and manifest["n_files"] == len(manifest["files"])
    assert not (target / ROOT.name / "data").exists()
    assert (tmp_path / "bundle.zip").exists()
    with pytest.raises(FileExistsError):
        export_bundle.export(tmp_path, "bundle")
    # The bundle runs on its own: a fresh interpreter, with only the bundle on the path.
    result = subprocess.run([sys.executable, str(target / ROOT.name / "deploy/smoke_check.py"), "--allow-version-drift"],
                            capture_output=True, text=True, timeout=600, cwd=tmp_path)
    assert result.returncode == 0, result.stdout[-4000:] + result.stderr[-4000:]
    assert "RESULT: OK" in result.stdout
