"""Compatibility entry point for the package runner."""

from lpj_lipidomics.runners.run_isolation_forest import *

if __name__ == "__main__":
    import runpy
    runpy.run_module("lpj_lipidomics.runners.run_isolation_forest", run_name="__main__")
