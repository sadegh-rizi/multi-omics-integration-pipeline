"""Compatibility imports for the package configuration module."""

from lpj_lipidomics.config import *
