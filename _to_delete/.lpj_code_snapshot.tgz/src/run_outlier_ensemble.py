"""Compatibility entry point for the package runner."""

if __name__ == "__main__":
    import runpy
    runpy.run_module("lpj_lipidomics.runners.run_outlier_ensemble", run_name="__main__")
else:
    import sys
    from lpj_lipidomics.runners import run_outlier_ensemble as _implementation
    sys.modules[__name__] = _implementation
