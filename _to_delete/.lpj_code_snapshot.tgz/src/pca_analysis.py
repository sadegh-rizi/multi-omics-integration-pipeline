"""Compatibility imports for the package PCA module."""

from lpj_lipidomics.multivariate.pca import *
