"""Compatibility imports for the package diagnostics module."""

from lpj_lipidomics.statistics.diagnostics import *
