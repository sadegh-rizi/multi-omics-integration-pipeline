"""Compatibility imports for the package vendor-fidelity module."""

from lpj_lipidomics.multivariate.plsda import fit_plsda, permutation_test_plsda
from lpj_lipidomics.multivariate.vendor import *
