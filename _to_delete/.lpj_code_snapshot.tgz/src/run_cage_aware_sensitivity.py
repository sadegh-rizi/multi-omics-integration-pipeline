"""Compatibility entry point for the cage-structure sensitivity runner."""

from lpj_lipidomics.runners.run_cage_aware_sensitivity import *


if __name__ == "__main__":
    import runpy

    runpy.run_module("lpj_lipidomics.runners.run_cage_aware_sensitivity", run_name="__main__")
