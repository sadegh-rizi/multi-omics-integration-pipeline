"""Compatibility imports for the package outlier detector module."""

from lpj_lipidomics.outliers.detectors import *
