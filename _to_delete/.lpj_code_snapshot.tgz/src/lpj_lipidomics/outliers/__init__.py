"""Sample-level outlier detectors, calibration, and ensemble summaries."""
