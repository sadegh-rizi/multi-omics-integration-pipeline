"""Fixed analysis decisions for the MIA/control lipidomics regeneration."""

CAGE_METADATA_WORKBOOK = "Samples for metabolomics.xlsx"
CAGE_COLUMN = "Cage"
COLLECTION_DATE_COLUMN = "Date collected"
COLLECTION_COHORT_COLUMN = "Collection cohort"
OUTLIER_SCREEN_PCS = 3
ROBUST_MAHALANOBIS_PCS = 3
MIN_PER_CELL = 3

# These variants are sensitivity analyses.  The primary analysis settings
# below remain unchanged; the runner selects one variant at call time.
PIPELINE_VARIANTS = {
    "prevalence20_t2_95": {
        "hotelling_limit": 0.95,
        "expected_samples": 55,
        "description": "20% pooled prevalence filter and 95% T-squared sample exclusion",
    },
    "prevalence20_t2_99": {
        "hotelling_limit": 0.99,
        "expected_samples": 58,
        "description": "20% pooled prevalence filter and 99% T-squared sample exclusion",
    },
    "prevalence20_noexclusion": {
        "hotelling_limit": None,
        "expected_samples": 60,
        "description": "20% pooled prevalence filter without sample exclusion",
    },
    "prevalence20_noexclusion_pqn": {
        "hotelling_limit": None,
        "expected_samples": 60,
        "normalization": "pqn",
        "description": "All-60 per-region centred log-space PQN sensitivity",
    },
}

# Sensitivity-analysis prevalence rule. Keep disabled for the primary analysis
# until the full specification curve has been reviewed.
MAX_MISSING_FRACTION = 0.20
APPLY_PREVALENCE_FILTER = False

# Adopted feature-level signal-to-blank rule. This is distinct from the
# value-level detection-limit masking performed later in preprocessing.
FEATURE_BLANK_MULTIPLIER = 3.0

# Tech-Mix is probably pooled study-sample QC, pending vendor confirmation.
# Keep the CV filter disabled until its filtered/unfiltered comparison is reviewed.
QC_CV_THRESHOLD = 30.0
QC_CV_MIN_INJECTIONS = 4
APPLY_QC_CV_FILTER = False

# Populate only after reviewing the standalone outlier-screen evidence.
SAMPLE_OUTLIER_EXCLUSIONS: tuple[str, ...] = ()

# New exploratory diagnostics.  Seeds and counts are recorded in their output
# tables so the empirical null can be regenerated exactly.
PERMUTATION_COUNT = 999
PERMUTATION_RANDOM_SEED = 20_260_903
DIAGNOSTIC_FEATURE_COUNT = 12
POWER_ALPHA = 0.05
POWER_TARGET = 0.80
ILLUSTRATIVE_LITTER_N = 8
RF_RANDOM_STATE = 20_260_807
IQR_REMOVE_FRACTION = 0.25
TOP_FDR_HITS = 10

# Cage-structure sensitivity settings. These do not alter the primary tree.
CAGE_ICC_BOOTSTRAPS = 1_000
CAGE_ICC_RANDOM_SEED = 20_260_917
CAGE_PERMUTATION_CEILING = "exact"
CAGE_SENSITIVITY_ARMS = {
    "A": "cage-level means",
    "B": "OLS with cage random intercept",
    "C": "sample-level OLS with collection cohort fixed effect",
    "D": "2024-06-11 date-matched subset",
}

# noisyR's published default is approximately one tenth of the feature panel.
# Store the rule as a fraction so it remains comparable across panels; the
# absolute floor prevents very small panels from producing unstable windows.
NOISYR_WINDOW_FRACTION = 0.10
NOISYR_WINDOW_MIN_FEATURES = 25
NOISYR_WINDOW_FRACTIONS = (0.025, 0.05, 0.075, 0.10)
NOISYR_STEP_FEATURES = (5, 10, 20)
NOISYR_STEP_FRACTION = 0.20
NOISYR_MIN_PAIRWISE_OBSERVATIONS = 10
NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT = 10
NOISYR_MIN_COMPARATORS_PER_REFERENCE = 3
NOISYR_SUSTAINED_WINDOWS = 5

# Feature-margin PCA and co-abundance module analysis. These are descriptive
# settings; every stochastic count and threshold is written to its manifest.
FEATURE_PCA_BOOTSTRAP_COUNT = 1_000
FEATURE_MODULE_BOOTSTRAP_COUNT = 100
FEATURE_MODULE_NULL_COUNT = 100
FEATURE_PCA_RANDOM_SEED = 20_260_908
FEATURE_PCA_SPLIT_HALF_FLOOR = 0.50
FEATURE_MODULE_STABILITY_FLOOR = 0.80
FEATURE_MODULE_MIN_SIZE = 3
FEATURE_MODULE_DISTANCE_CUT = 0.30
FEATURE_HEATMAP_MAX_FEATURES = 150
