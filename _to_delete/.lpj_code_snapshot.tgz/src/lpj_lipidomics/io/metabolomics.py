"""Workbook-reading helpers for the metabolomics report sheet."""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from .lipidomics import read_table_after_header


_SAMPLE_PATTERN = re.compile(r"^MB2_088-(\d+)$")


def read_metabolomics_tables(path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return the Sample Sheet and Metabolomics report tables."""
    return (
        read_table_after_header(path, "Sample Sheet", "Sample ID"),
        read_table_after_header(path, "Metabolomics", "Metabolite"),
    )


def metabolomics_measurement_columns(metabolomics: pd.DataFrame) -> tuple[list[str], list[str], list[str]]:
    """Identify the 60 biological, six blank, and six Tech-Mix columns."""
    columns = [str(column) for column in metabolomics.columns]
    sample_columns = [column for column in columns if _SAMPLE_PATTERN.fullmatch(column)]
    blank_columns = ["PostRunBlank-", *[f"PreRunBlank_{number}-" for number in range(1, 6)]]
    techmix_columns = [f"Tech-Mix_{number}-" for number in range(1, 7)]
    if len(sample_columns) != 60:
        raise ValueError(f"Expected 60 biological metabolomics samples, found {len(sample_columns)}.")
    missing = sorted(set([*blank_columns, *techmix_columns]).difference(columns))
    if missing:
        raise ValueError(f"Expected metabolomics measurement columns are missing: {missing}.")
    return sample_columns, blank_columns, techmix_columns


def metabolomics_sample_numbers(sample_columns: list[str]) -> pd.Series:
    """Return integer join keys for the report's non-zero-padded sample IDs."""
    numbers = []
    for sample in sample_columns:
        match = _SAMPLE_PATTERN.fullmatch(sample)
        if match is None:
            raise ValueError(f"Not a metabolomics biological sample ID: {sample!r}.")
        numbers.append(int(match.group(1)))
    return pd.Series(numbers, index=sample_columns, name="Sample number")
