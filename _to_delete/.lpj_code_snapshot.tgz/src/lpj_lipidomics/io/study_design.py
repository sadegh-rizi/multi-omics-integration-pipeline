"""Shared sample, feature, and annotation alignment for report tables."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


REGIONS = ("Cerebellum", "Cortex", "Hippocampus")
LIPIDOMICS_METADATA_COLUMNS = (
    "Sample number",
    "Sample type",
    "Mouse number",
    "Bio group",
    "Sex",
    "Tissue mass (mg)",
)
CAGE_SOURCE_COLUMNS = (
    "Sample no",
    "Date collected",
    "Cage no",
    "Age",
    "Sex",
    "MIA or Control",
    "Date processed",
)
CAGE_METADATA_COLUMNS = (
    "Sample number",
    "Cage",
    "Date collected",
    "Collection cohort",
    "Age",
    "Sex",
    "Bio group",
    "Date processed",
)


def read_cage_metadata(path: Path) -> pd.DataFrame:
    """Read and forward-fill the per-mouse cage metadata workbook."""
    table = pd.read_excel(path, sheet_name="Samples to be shipped")
    missing = set(CAGE_SOURCE_COLUMNS).difference(table.columns)
    if missing:
        raise KeyError(f"Cage workbook is missing columns: {sorted(missing)}")
    if len(table) != 60:
        raise ValueError(f"Expected 60 rows in the cage workbook, found {len(table)}.")

    table = table.loc[:, CAGE_SOURCE_COLUMNS].copy()
    mouse_columns = [
        "Date collected",
        "Cage no",
        "Age",
        "Sex",
        "MIA or Control",
        "Date processed",
    ]
    table.loc[:, mouse_columns] = table.loc[:, mouse_columns].ffill()
    if table.loc[:, mouse_columns].isna().any().any():
        raise ValueError("Forward-filled cage metadata still contains missing values.")

    sample_numbers = pd.to_numeric(table["Sample no"], errors="raise").astype(int)
    if sample_numbers.duplicated().any() or set(sample_numbers) != set(range(1, 61)):
        raise ValueError("Cage workbook must contain each sample number from 1 through 60 once.")
    dates = pd.to_datetime(table["Date collected"], errors="raise")
    processed = pd.to_datetime(table["Date processed"], errors="raise")
    cohort_values = dates.dt.strftime("%Y-%m-%d")
    cohorts = sorted(cohort_values.unique())
    return pd.DataFrame({
        "Sample number": sample_numbers,
        "Cage": table["Cage no"].astype(str),
        "Date collected": dates,
        "Collection cohort": pd.Categorical(
            cohort_values,
            categories=cohorts,
            ordered=True,
        ),
        "Age": table["Age"].astype(str),
        "Sex": table["Sex"].astype(str),
        "Bio group": table["MIA or Control"].astype(str),
        "Date processed": processed,
    })


def add_cage_metadata(
    metadata: pd.DataFrame,
    cage_metadata: pd.DataFrame,
) -> pd.DataFrame:
    """Join cage/date metadata and assert the study-design nesting."""
    required = set(CAGE_METADATA_COLUMNS)
    missing = required.difference(cage_metadata.columns)
    if missing:
        raise KeyError(f"Cage metadata is missing columns: {sorted(missing)}")
    if metadata["Sample number"].duplicated().any():
        raise ValueError("Lipidomics metadata contains duplicated sample numbers.")
    if cage_metadata["Sample number"].duplicated().any():
        raise ValueError("Cage metadata contains duplicated sample numbers.")

    joined = metadata.merge(
        cage_metadata.loc[:, CAGE_METADATA_COLUMNS],
        on="Sample number",
        how="left",
        suffixes=("", "_cage"),
        validate="one_to_one",
    )
    if joined.loc[:, ["Cage", "Date collected", "Collection cohort"]].isna().any().any():
        raise ValueError("Cage metadata is missing one or more lipidomics samples.")
    for column in ("Sex", "Bio group"):
        if not joined[column].astype(str).eq(joined[f"{column}_cage"].astype(str)).all():
            raise ValueError(f"Cage workbook disagrees with the lipidomics {column} metadata.")
        joined = joined.drop(columns=f"{column}_cage")

    mouse_prefixes = joined["Mouse number"].astype(str).str.split(" - ", n=1).str[0]
    cage_values = set(joined["Cage"].astype(str))
    if set(mouse_prefixes) != cage_values:
        raise ValueError(
            "Cage set does not match the prefixes of the lipidomics Mouse number values."
        )

    nesting = joined.groupby("Cage", observed=True).agg({
        "Bio group": "nunique",
        "Date collected": "nunique",
    })
    if nesting["Bio group"].ne(1).any() or nesting["Date collected"].ne(1).any():
        raise ValueError("Each cage must map to exactly one Bio group and collection date.")
    if joined["Date processed"].nunique() != 1:
        raise ValueError("The cage workbook does not describe one processing batch.")
    return joined


def full_lipidomics_metadata(
    sample_sheet: pd.DataFrame,
    sample_columns: list[str],
    *,
    cage_workbook: Path | None = None,
) -> pd.DataFrame:
    """Align lipidomics metadata to padded report sample identifiers."""
    metadata = sample_sheet.loc[:, LIPIDOMICS_METADATA_COLUMNS].copy()
    metadata["Sample number"] = pd.to_numeric(
        metadata["Sample number"], errors="raise"
    ).astype(int)
    metadata["Sample"] = metadata["Sample number"].map(
        lambda number: f"MB2_088-{number:02d}"
    )
    if metadata["Sample"].duplicated().any():
        raise ValueError("Sample Sheet contains duplicated sample identifiers.")
    try:
        aligned = metadata.set_index("Sample").loc[sample_columns].reset_index()
    except KeyError as error:
        raise ValueError("Sample Sheet is missing one or more report samples.") from error
    if cage_workbook is not None:
        aligned = add_cage_metadata(aligned, read_cage_metadata(cage_workbook))
    return aligned


def analysis_metadata(
    sample_sheet: pd.DataFrame,
    sample_columns: list[str],
    *,
    cage_workbook: Path | None = None,
) -> pd.DataFrame:
    """Return all 60 samples; exclusion belongs in explicit variant runners.

    See doc/context/population-rule.md: never remove an entire mouse here.
    """
    metadata = full_lipidomics_metadata(
        sample_sheet,
        sample_columns,
        cage_workbook=cage_workbook,
    )
    if len(metadata) != 60 or metadata["Mouse number"].nunique() != 20:
        raise ValueError("Expected all 60 samples from 20 mice.")
    regions_by_mouse = metadata.groupby("Mouse number", observed=True)["Sample type"]
    if not regions_by_mouse.agg(lambda regions: len(regions) == 3 and set(regions) == set(REGIONS)).all():
        raise ValueError("Every mouse must contribute exactly one sample per region.")
    return metadata


def metabolomics_metadata(
    sample_sheet: pd.DataFrame,
    sample_columns: list[str],
    *,
    zero_padded: bool,
    include_tissue_mass: bool = True,
    cage_workbook: Path | None = None,
) -> pd.DataFrame:
    """Align metabolomics metadata using its report-specific sample IDs."""
    columns = [
        "Sample number",
        "Sample type",
        "Mouse number",
        "Bio group",
        "Sex",
    ]
    if include_tissue_mass:
        columns.append("Tissue mass (mg)")
    metadata = sample_sheet.loc[:, columns].copy()
    metadata["Sample number"] = pd.to_numeric(
        metadata["Sample number"], errors="raise"
    ).astype(int)
    width = 2 if zero_padded else 0
    metadata["Sample"] = metadata["Sample number"].map(
        lambda number: f"MB2_088-{number:0{width}d}" if width else f"MB2_088-{number}"
    )
    if metadata["Sample"].duplicated().any():
        raise ValueError("Sample Sheet contains duplicated sample identifiers.")
    aligned = metadata.set_index("Sample").loc[sample_columns].reset_index()
    if cage_workbook is not None:
        aligned = add_cage_metadata(aligned, read_cage_metadata(cage_workbook))
    return aligned


def lipid_feature_rows(lipidomics: pd.DataFrame) -> pd.DataFrame:
    """Remove embedded report metadata rows before using peak areas."""
    is_feature = lipidomics["Lipid Name"].notna() & lipidomics["Lipid Name"].ne(
        "Lipid Name"
    )
    features = lipidomics.loc[is_feature].copy()
    if features.empty:
        raise ValueError("Lipidomics report contains no lipid feature rows.")
    return features


def lipid_annotations(lipidomics: pd.DataFrame) -> pd.DataFrame:
    """Return feature-indexed lipid names and classes from a report table."""
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    annotations.index = lipidomics.index
    annotations.index.name = "Feature"
    return annotations
