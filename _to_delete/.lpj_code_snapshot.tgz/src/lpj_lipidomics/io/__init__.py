"""Input readers and study-design alignment helpers."""
