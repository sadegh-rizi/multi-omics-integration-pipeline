"""Reader for the delivered Perseus proteomics text exports."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

import pandas as pd


_INTENSITY_PATTERN = re.compile(
    r"^MLalowski_(?P<region>.+)_(?P<group>MIA|control)_(?P<number>\d+) "
    r"MaxLFQ Unique Intensity$",
    re.IGNORECASE,
)


def sha256_file(path: Path) -> str:
    """Return the SHA-256 digest of one source file."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_perseus_proteomics(
    path: Path,
    *,
    expected_region: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Read one imputed Perseus export as feature-by-sample values.

    The files contain four ``#!`` metadata rows after the header.  They are
    skipped as file-format metadata; the delivered expression values are not
    re-normalized or imputed here.  Sample numbers are converted to the same
    ``MB2_088-01`` identifiers used by the persistence inputs.
    """
    if not path.exists():
        raise FileNotFoundError(path)
    raw = pd.read_csv(path, sep="\t", comment="#", dtype=str)
    required = {"Protein ID", "Gene"}
    missing = required.difference(raw.columns)
    if missing:
        raise KeyError(f"Proteomics export is missing columns: {sorted(missing)}")

    intensity_columns = [
        column for column in raw.columns if _INTENSITY_PATTERN.fullmatch(str(column))
    ]
    if not intensity_columns:
        raise ValueError(f"No MaxLFQ expression columns found in {path}.")

    sample_numbers: list[int] = []
    for column in intensity_columns:
        match = _INTENSITY_PATTERN.fullmatch(str(column))
        assert match is not None
        if match.group("region").casefold() != expected_region.casefold():
            raise ValueError(
                f"Expected {expected_region} columns in {path}, found {match.group('region')}."
            )
        sample_numbers.append(int(match.group("number")))
    if len(set(sample_numbers)) != len(sample_numbers):
        raise ValueError(f"Proteomics sample numbers are duplicated in {path}.")

    protein_ids = raw["Protein ID"].astype("string").str.strip()
    if protein_ids.isna().any() or protein_ids.eq("").any():
        raise ValueError(f"Proteomics export has missing Protein ID values: {path}")
    if protein_ids.duplicated().any():
        raise ValueError(f"Proteomics Protein ID values are not unique: {path}")

    values = raw.loc[:, intensity_columns].apply(pd.to_numeric, errors="coerce")
    if values.isna().to_numpy().any():
        raise ValueError(f"Proteomics expression values are not all numeric: {path}")
    values.index = protein_ids.astype(str)
    values.columns = [f"MB2_088-{number:02d}" for number in sample_numbers]
    values.index.name = "Protein ID"

    annotations = raw.loc[:, ["Protein ID", "Gene"]].copy()
    annotations["Protein ID"] = protein_ids.astype(str)
    annotations["Gene"] = annotations["Gene"].astype("string").str.strip()
    annotations = annotations.set_index("Protein ID")
    annotations.index.name = "Protein ID"
    return values, annotations
