"""Small workbook-reading helpers shared by lipidomics notebooks."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def read_table_after_header(path: Path, sheet_name: str, header_marker: str) -> pd.DataFrame:
    """Read a report sheet whose header begins on a later row."""
    raw = pd.read_excel(path, sheet_name=sheet_name, header=None)
    matches = raw.eq(header_marker).any(axis=1)
    if not matches.any():
        raise ValueError(f"Header {header_marker!r} was not found in {sheet_name!r}.")
    header_index = int(matches[matches].index[0])
    columns = raw.iloc[header_index]
    keep = columns.notna() & columns.astype(str).str.strip().ne("")
    table = raw.iloc[header_index + 1:, keep].copy()
    table.columns = columns[keep].astype(str).str.strip()
    return table.dropna(how="all").reset_index(drop=True)


def read_lipidomics_tables(path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return the Sample Sheet and Lipidomics report tables."""
    return (
        read_table_after_header(path, "Sample Sheet", "Sample ID"),
        read_table_after_header(path, "Lipidomics", "Lipid Name"),
    )


def lipidomics_measurement_columns(lipidomics: pd.DataFrame) -> tuple[list[str], list[str], list[str]]:
    """Identify the 60 biological, six blank, and six Tech-Mix columns.

    The report's blank injections are explicitly retained for empirical
    detection-limit preprocessing; they are not biological samples.
    """
    columns = [str(column) for column in lipidomics.columns]
    sample_columns = [
        column
        for column in columns
        if column.startswith("MB2_088-") and column[-2:].isdigit()
    ]
    pre_run_blanks = [f"PreRunBlank_{number}+.raw" for number in range(1, 6)]
    post_run_blanks = ["PostRunBlank+.raw"]
    blank_columns = [*pre_run_blanks, *post_run_blanks]
    techmix_columns = [f"Tech-Mix_{number}+.raw" for number in range(1, 7)]

    missing_blanks = sorted(set(blank_columns).difference(columns))
    missing_techmix = sorted(set(techmix_columns).difference(columns))
    if len(sample_columns) != 60:
        raise ValueError(f"Expected 60 biological lipidomics samples, found {len(sample_columns)}.")
    if missing_blanks:
        raise ValueError(f"Expected six blank injections; missing {missing_blanks}.")
    if missing_techmix:
        raise ValueError(f"Expected six Tech-Mix injections; missing {missing_techmix}.")
    return sample_columns, blank_columns, techmix_columns
