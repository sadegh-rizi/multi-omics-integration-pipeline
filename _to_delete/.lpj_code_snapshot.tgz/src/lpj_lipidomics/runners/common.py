"""Shared input loading for independent analysis runners."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import full_lipidomics_metadata
from ..preprocessing import preprocess_for_multivariate


def metadata_and_values(project_root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Load the aligned full study metadata and multivariate lipid values."""
    data_file = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, lipidomics = read_lipidomics_tables(data_file)
    sample_columns, blank_columns, _ = lipidomics_measurement_columns(lipidomics)
    metadata = full_lipidomics_metadata(sample_sheet, sample_columns)
    raw = lipidomics.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    return metadata, preprocess_for_multivariate(raw, blanks)
