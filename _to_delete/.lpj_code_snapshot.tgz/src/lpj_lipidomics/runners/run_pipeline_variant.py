"""Run one filtered MIA/control sensitivity-analysis variant."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ..aggregation import (
    aggregate_class_profiles,
    annotate_lipid_structures,
    structural_index_profiles,
)
from ..config import (
    DIAGNOSTIC_FEATURE_COUNT,
    FEATURE_BLANK_MULTIPLIER,
    ILLUSTRATIVE_LITTER_N,
    IQR_REMOVE_FRACTION,
    MAX_MISSING_FRACTION,
    MIN_PER_CELL,
    PERMUTATION_COUNT,
    PERMUTATION_RANDOM_SEED,
    PIPELINE_VARIANTS,
    POWER_ALPHA,
    POWER_TARGET,
    RF_RANDOM_STATE,
    TOP_FDR_HITS,
)
from ..statistics.diagnostics import (
    cross_check_qc_tables,
    missingness_se_crosscheck,
    plot_p_value_histograms,
    plot_small_p_value_counts,
    residual_diagnostics,
    sample_influence_summary,
    summarize_p_values,
)
from ..imputation import censoring_mask
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import full_lipidomics_metadata
from ..preprocessing import (
    below_detection_reasons,
    drop_zero_variance_features,
    exclude_below_detection,
    exclude_blank_dominated_features,
    exclude_low_prevalence_features,
    exclude_nonpositive,
    filter_low_iqr_features,
    log2_transform,
    median_normalize,
    pareto_scale,
    pqn_normalize,
)
from ..statistics.differential import fit_regionwise_differential
from ..statistics.permutation import run_permutation_null
from ..statistics.power import detectable_effect_sizes, fdr_hit_table, plot_volcanoes
from .pipeline_stages import impute_regionwise, run_limma, run_multivariate


REGIONS = ("Cerebellum", "Cortex", "Hippocampus")
RF_IMPUTATION_METHODS = {"rf_mar_only", "rf_all"}
SCALING_METHODS = {"standard", "pareto"}
_EXCLUSION_COLUMNS = (
    "Feature",
    "Lipid Name",
    "Lipid Class",
    "stage",
    "reason",
    "reason_detail",
    "Region",
)
_SAMPLE_EXCLUSION_COLUMNS = (
    "Sample",
    "Sample number",
    "Sample type",
    "Mouse number",
    "Bio group",
    "Sex",
    "reason",
    "threshold",
)


def _variant_spec(variant: str) -> dict[str, object]:
    try:
        return PIPELINE_VARIANTS[variant]
    except KeyError as error:
        raise ValueError(f"Unknown pipeline variant {variant!r}. Choose from {sorted(PIPELINE_VARIANTS)}.") from error


def _feature_exclusions(
    annotations: pd.DataFrame,
    features: list[object] | pd.Index,
    *,
    stage: str,
    reason: str,
    reason_detail: str,
    region: object = "",
) -> pd.DataFrame:
    features = list(features)
    if not features:
        return pd.DataFrame(columns=_EXCLUSION_COLUMNS)
    missing_features = set(features).difference(annotations.index)
    if missing_features:
        raise ValueError(f"Excluded features are missing from the annotation table: {sorted(missing_features)}")
    selected = annotations.reindex(features)
    result = selected.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    result.insert(0, "Feature", result.index)
    result["stage"] = stage
    result["reason"] = reason
    result["reason_detail"] = reason_detail
    result["Region"] = region
    return result.reset_index(drop=True).loc[:, _EXCLUSION_COLUMNS]


def _read_outlier_evidence(
    project_root: Path,
    metadata: pd.DataFrame,
    threshold: float | None,
    output_directory: Path,
) -> tuple[list[str], pd.DataFrame]:
    """Read the fixed full-data T-squared evidence and copy selected reports."""
    selected_samples: list[str] = []
    flag_column = {0.95: "hotelling_t2_95_flag", 0.99: "hotelling_t2_99_flag"}.get(threshold)
    for region in REGIONS:
        path = project_root / "results" / "mia_vs_control" / "02_qc" / f"outlier_screen_{region.lower()}.csv"
        if not path.exists():
            raise FileNotFoundError(f"Required existing outlier evidence is missing: {path}")
        table = pd.read_csv(path)
        required = {"Sample", "hotelling_t2_95_flag", "hotelling_t2_99_flag"}
        if missing := required.difference(table.columns):
            raise KeyError(f"Outlier evidence is missing columns: {sorted(missing)}")
        table["selected_for_variant"] = False
        if flag_column is not None:
            flags = table[flag_column].astype(str).str.lower().eq("true")
            selected = table.loc[flags, "Sample"].astype(str).tolist()
            selected_samples.extend(selected)
            table.loc[flags, "selected_for_variant"] = True
        table.to_csv(output_directory / f"outlier_screen_{region.lower()}.csv", index=False)

    if len(selected_samples) != len(set(selected_samples)):
        raise ValueError("A sample was flagged in more than one regional outlier table.")
    known_samples = set(metadata["Sample"])
    unknown = set(selected_samples).difference(known_samples)
    if unknown:
        raise ValueError(f"Outlier evidence contains unknown samples: {sorted(unknown)}")
    exclusions = metadata.loc[metadata["Sample"].isin(selected_samples), list(_SAMPLE_EXCLUSION_COLUMNS[:-2])].copy()
    if threshold is None:
        exclusions = pd.DataFrame(columns=_SAMPLE_EXCLUSION_COLUMNS)
    else:
        exclusions["reason"] = f"hotelling_t2_{int(threshold * 100)}_flag"
        exclusions["threshold"] = threshold
        exclusions = exclusions.loc[:, _SAMPLE_EXCLUSION_COLUMNS]
    return selected_samples, exclusions


def _write_model_contract(
    directory: Path,
    *,
    variant: str,
    n_samples: int,
    imputation_method: str = "none",
    scaling: str = "standard",
    iqr_filter: bool = False,
) -> None:
    pd.DataFrame([
        {
            "variant": variant,
            "model": "value ~ BioGroup * Sex",
            "formula_reference": "Saline Control and Male",
            "unit_of_analysis": "biological sample within region",
            "experimental_unit_assumption": "samples treated as independent; litter structure unresolved and model deferred",
            "missing_values": "retained as missing; feature excluded from a region if any BioGroup x Sex cell has fewer than 3 usable values",
            "fdr_family": "shared feature panel within Region x Effect; ineligible features remain in the correction universe",
            "fdr_method": "Benjamini-Hochberg",
            "sample_count": n_samples,
            "sample_exclusion": "sample-level only; other regions from the same mouse retained",
            "analysis_role": "exploratory sensitivity analysis, not primary",
            "imputation_method": imputation_method,
            "scaling": scaling,
            "iqr_variance_filter": iqr_filter,
        }
    ]).to_csv(directory / "analysis_model_contract.csv", index=False)


def _assert_fdr_denominator(results: pd.DataFrame, expected: int, label: str) -> None:
    if results.empty:
        return
    if "fdr_denominator" not in results.columns:
        raise AssertionError(f"{label} is missing its FDR denominator column.")
    denominators = pd.to_numeric(results["fdr_denominator"], errors="coerce").dropna().unique()
    if len(denominators) != 1 or int(denominators[0]) != expected:
        raise AssertionError(f"{label} FDR denominator does not equal {expected}.")
    for p_column, q_column in (
        ("p_value", "p_value_fdr"),
        ("p_value_empirical", "p_value_empirical_fdr"),
    ):
        if p_column in results.columns and q_column in results.columns:
            finite_p = pd.to_numeric(results[p_column], errors="coerce").notna()
            missing_q = pd.to_numeric(results.loc[finite_p, q_column], errors="coerce").isna()
            if missing_q.any():
                raise AssertionError(f"{label} has missing FDR values for finite {p_column} values.")


def run_pipeline_variant(
    project_root: Path,
    variant: str,
    *,
    output_root_name: str = "pipeline_test",
    imputation_method: str | None = None,
    scaling: str = "standard",
    apply_iqr_filter: bool = False,
) -> Path:
    """Run the complete filtered sensitivity analysis and return its output root."""
    spec = _variant_spec(variant)
    normalization = spec.get("normalization", "median")
    if normalization == "pqn" and (imputation_method is not None or scaling != "standard" or apply_iqr_filter):
        raise ValueError("The approved PQN arm uses no imputation or IQR filtering and standard multivariate scaling.")
    if imputation_method is not None and imputation_method not in RF_IMPUTATION_METHODS:
        raise ValueError(f"Unknown RF imputation method: {imputation_method}")
    if scaling not in SCALING_METHODS:
        raise ValueError(f"Unknown scaling method: {scaling}")
    if output_root_name == "pipeline_test_rf":
        if imputation_method is None:
            raise ValueError("RF pipeline runs require an imputation method.")
        output = project_root / "results" / output_root_name / imputation_method / variant / scaling
    else:
        output = project_root / "results" / output_root_name / variant
    stage_names = (
        "00_inputs",
        "01_preprocessing",
        "02_qc",
        "03_differential",
        "04_multivariate",
        "05_diagnostics",
        "06_aggregation",
        "07_specification_curve",
    )
    stages = {name: output / name for name in stage_names}
    data_file = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    if not data_file.exists():
        raise FileNotFoundError(f"Source workbook is required for the pipeline run: {data_file}")
    for directory in stages.values():
        directory.mkdir(parents=True, exist_ok=True)

    sample_sheet, lipidomics = read_lipidomics_tables(data_file)
    sample_columns, blank_columns, _ = lipidomics_measurement_columns(lipidomics)
    metadata = full_lipidomics_metadata(sample_sheet, sample_columns,
                                       cage_workbook=project_root / "data" / "Samples for metabolomics.xlsx")
    if len(metadata) != 60:
        raise AssertionError(f"Expected 60 input samples, found {len(metadata)}.")
    all_raw = lipidomics.loc[:, sample_columns].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    annotations.index = lipidomics.index

    # Prevalence is deliberately measured on all 60 raw biological samples,
    # before either detection masking or the variant-specific sample deletion.
    positive = exclude_nonpositive(all_raw)
    prevalence_fraction = positive.isna().mean(axis=1)
    prevalence_table = pd.DataFrame({
        "Feature": positive.index,
        "n_samples_denominator": len(positive.columns),
        "n_missing": positive.isna().sum(axis=1).to_numpy(),
        "missing_fraction": prevalence_fraction.to_numpy(),
        "max_missing_fraction": MAX_MISSING_FRACTION,
        "filter_basis": "exclude_nonpositive(raw), pooled across all 60 biological samples",
        "excluded": prevalence_fraction.gt(MAX_MISSING_FRACTION).to_numpy(),
    })
    prevalence_table = prevalence_table.merge(annotations.reset_index(names="Feature"), on="Feature", how="left", validate="one_to_one")
    prevalence_table.to_csv(stages["01_preprocessing"] / "prevalence_filter_features.csv", index=False)
    raw_missingness_path = project_root / "results" / "mia_vs_control" / "02_qc" / "missingness" / "missingness_by_lipid.csv"
    if not raw_missingness_path.exists():
        raise FileNotFoundError(f"The reviewed raw missingness table is required: {raw_missingness_path}")
    raw_missingness = pd.read_csv(raw_missingness_path)
    if {"Feature", "n_missing"}.difference(raw_missingness.columns):
        raise KeyError("The reviewed raw missingness table must contain Feature and n_missing columns.")
    written_counts = prevalence_table.set_index("Feature")["n_missing"].astype(int)
    reviewed_counts = raw_missingness.set_index("Feature")["n_missing"].astype(int)
    written_counts.index = written_counts.index.astype(str)
    reviewed_counts.index = reviewed_counts.index.astype(str)
    if set(written_counts.index) != set(reviewed_counts.index):
        raise AssertionError("The written prevalence table and reviewed raw missingness table have different feature universes.")
    if not np.array_equal(written_counts.to_numpy(), reviewed_counts.reindex(written_counts.index).to_numpy()):
        raise AssertionError("Prevalence missing counts do not match the reviewed raw missingness table.")

    prevalence_filtered = exclude_low_prevalence_features(
        positive,
        max_missing_fraction=MAX_MISSING_FRACTION,
    )
    blank_filtered = exclude_blank_dominated_features(
        prevalence_filtered,
        blanks.loc[prevalence_filtered.index],
        blank_multiplier=FEATURE_BLANK_MULTIPLIER,
    )
    filtered_blanks = blanks.loc[blank_filtered.index]
    detection_reasons = below_detection_reasons(
        blank_filtered,
        filtered_blanks,
        blank_multiplier=FEATURE_BLANK_MULTIPLIER,
    )
    detectable = exclude_below_detection(
        blank_filtered,
        filtered_blanks,
        blank_multiplier=FEATURE_BLANK_MULTIPLIER,
    )

    feature_exclusions = [
        _feature_exclusions(
            annotations,
            prevalence_table.loc[prevalence_table["excluded"], "Feature"].tolist(),
            stage="prevalence",
            reason="missing_fraction_gt_20_percent",
            reason_detail="Computed on exclude_nonpositive(raw), pooled over all 60 samples before sample exclusion and detection masking.",
        ),
        _feature_exclusions(
            annotations,
            prevalence_filtered.index.difference(blank_filtered.index),
            stage="blank_filter",
            reason="blank_dominated_3x_mean_blank",
            reason_detail="Pooled biological median below 3 x mean blank.",
        ),
    ]
    fully_detection_excluded = detectable.index[detectable.isna().all(axis=1)]
    feature_exclusions.append(
        _feature_exclusions(
            annotations,
            fully_detection_excluded,
            stage="detection_limit",
            reason="fully_missing_after_detection_mask",
            reason_detail="All surviving positive values were below the empirical detection limit.",
        )
    )
    detectable = detectable.drop(index=fully_detection_excluded)

    detection_table = detection_reasons.rename_axis(index="Feature", columns="Sample").stack().dropna().rename("detection_limit_reason").reset_index()
    detection_table = detection_table.merge(metadata.loc[:, ["Sample", "Sample type", "Bio group", "Sex"]], on="Sample", how="left", validate="many_to_one")
    detection_table = detection_table.merge(annotations.reset_index(names="Feature"), on="Feature", how="left", validate="many_to_one")
    detection_table.to_csv(stages["01_preprocessing"] / "detection_limit_exclusions.csv", index=False)

    selected_samples, sample_exclusions = _read_outlier_evidence(
        project_root,
        metadata,
        spec["hotelling_limit"],
        stages["02_qc"],
    )
    surviving_samples = metadata.loc[~metadata["Sample"].isin(selected_samples), "Sample"].tolist()
    analysis_detection_table = detection_table.loc[detection_table["Sample"].isin(surviving_samples)].copy()
    if len(surviving_samples) != spec["expected_samples"]:
        raise AssertionError(f"Variant {variant} expected {spec['expected_samples']} samples, found {len(surviving_samples)}.")
    sample_exclusions.to_csv(stages["02_qc"] / "sample_exclusions.csv", index=False)
    if set(sample_exclusions["Sample"]) != set(selected_samples):
        raise AssertionError("Every selected sample must appear in sample_exclusions.csv.")
    persisted_sample_exclusions = pd.read_csv(stages["02_qc"] / "sample_exclusions.csv")
    if set(persisted_sample_exclusions["Sample"].astype(str)) != set(selected_samples):
        raise AssertionError("Persisted sample exclusions differ from the selected outlier samples.")
    metadata_surviving = metadata.set_index("Sample").loc[surviving_samples].reset_index()
    cell_table = metadata_surviving.assign(n=1).pivot_table(
        index="Sample type", columns=["Bio group", "Sex"], values="n", aggfunc="sum", fill_value=0
    )
    cell_table.to_csv(stages["02_qc"] / "group_sex_cell_counts.csv")
    if (cell_table.min(axis=1) < MIN_PER_CELL).any():
        raise AssertionError("The configured variant has a BioGroup x Sex cell below MIN_PER_CELL.")

    # Detection masking is complete before sample exclusion. Imputation and
    # the optional unsupervised panel filter happen after normalization.
    logged = log2_transform(detectable.loc[:, surviving_samples])
    if normalization == "pqn":
        normalized_values = pqn_normalize(logged, metadata_surviving.set_index("Sample")["Sample type"])
    else:
        normalized_values = median_normalize(logged)
    shifts = metadata_surviving.copy().set_index("Sample")
    shifts["normalization"] = normalization
    shifts["shift_log2"] = (logged - normalized_values).median(axis=0)
    shifts["extra_shift_vs_median_log2"] = (median_normalize(logged) - normalized_values).median(axis=0)
    shifts.to_csv(stages["01_preprocessing"] / "normalization_shifts.csv")
    expected_panel = blank_filtered.index[~blank_filtered.index.isin(fully_detection_excluded)]
    if not normalized_values.index.equals(expected_panel):
        raise AssertionError("The transformed feature panel changed after sample selection.")
    for region in REGIONS:
        region_mask = metadata_surviving.set_index("Sample").loc[normalized_values.columns, "Sample type"].eq(region)
        region_features = normalized_values.loc[:, region_mask]
        if not region_features.index.equals(normalized_values.index):
            raise AssertionError(f"Feature panel differs in {region}.")

    imputation_routes = pd.DataFrame("none", index=normalized_values.index, columns=normalized_values.columns)
    if imputation_method is not None:
        censoring = censoring_mask(
            blank_filtered.loc[normalized_values.index, surviving_samples],
            detection_reasons.loc[normalized_values.index, surviving_samples],
        )
        normalized_values, imputation_routes = impute_regionwise(
            normalized_values,
            censoring,
            metadata_surviving,
            imputation_method,
        )
        imputation_routes.to_csv(stages["01_preprocessing"] / "imputation_routes.csv", index_label="Feature")
        pd.DataFrame([{
            "method": imputation_method,
            "n_cells_total": int(imputation_routes.size),
            "n_cells_imputed": int(imputation_routes.loc[normalized_values.index].ne("none").sum().sum()),
            "n_halfmin": int(imputation_routes.eq("halfmin").sum().sum()),
            "n_rf_mar": int(imputation_routes.eq("rf_mar").sum().sum()),
            "n_rf_all": int(imputation_routes.eq("rf_all").sum().sum()),
            "random_state": RF_RANDOM_STATE,
            "label_free": True,
            "regionwise": True,
        }]).to_csv(stages["01_preprocessing"] / "imputation_summary.csv", index=False)

    iqr_excluded = pd.Index([], dtype=normalized_values.index.dtype)
    if apply_iqr_filter:
        normalized_values, iqr_table = filter_low_iqr_features(
            normalized_values,
            remove_fraction=IQR_REMOVE_FRACTION,
        )
        iqr_table = iqr_table.merge(
            annotations.reset_index(names="Feature"),
            on="Feature",
            how="left",
            validate="one_to_one",
        )
        iqr_table.to_csv(stages["01_preprocessing"] / "iqr_variance_filter.csv", index=False)
        iqr_excluded = iqr_table.loc[iqr_table["removed"], "Feature"]
        feature_exclusions.append(_feature_exclusions(
            annotations,
            iqr_excluded.tolist(),
            stage="iqr_variance",
            reason=f"bottom_{int(IQR_REMOVE_FRACTION * 100)}_percent_iqr",
            reason_detail="Unsupervised IQR ranking after imputation and sample exclusion; ties broken by Feature ID.",
        ))

    values = pareto_scale(normalized_values) if scaling == "pareto" else normalized_values.copy()
    values.to_csv(stages["00_inputs"] / "differential_input_matrix.csv", index_label="Feature")
    if imputation_method is not None:
        normalized_values.to_csv(stages["00_inputs"] / "normalized_log2_matrix.csv", index_label="Feature")
    limma_metadata = metadata_surviving.loc[:, ["Sample", "Sample type", "Bio group", "Sex", "Mouse number"]].rename(columns={"Sample type": "Region", "Bio group": "BioGroup"})
    limma_metadata.to_csv(stages["00_inputs"] / "differential_input_metadata.csv", index=False)

    fitted = fit_regionwise_differential(
        values,
        metadata_surviving,
        annotations=annotations,
        min_per_cell=MIN_PER_CELL,
        fdr_denominator="all_features",
        effect_scale="pareto_scaled_log2" if scaling == "pareto" else "normalized_log2",
    )
    fitted.effects.to_csv(stages["03_differential"] / "differential_effects.csv", index=False)
    fitted.feature_qc.to_csv(stages["03_differential"] / "differential_feature_qc.csv", index=False)
    run_limma(project_root, stages["00_inputs"], stages["03_differential"], scaling=scaling)
    limma_effects = pd.read_csv(stages["03_differential"] / "differential_effects_limma.csv")
    _assert_fdr_denominator(limma_effects, len(values.index), "limma differential output")
    written_features = pd.read_csv(stages["00_inputs"] / "differential_input_matrix.csv", usecols=["Feature"])
    for region, region_qc in fitted.feature_qc.groupby("Region", sort=False, observed=True):
        if not set(region_qc["Feature"].astype(str)) == set(written_features["Feature"].astype(str)):
            raise AssertionError(f"Persisted feature panel differs in {region}.")
    for (region, feature), feature_qc in fitted.feature_qc.loc[fitted.feature_qc["fit_status"].eq("excluded")].groupby(["Region", "Feature"], sort=False, observed=True):
        feature_exclusions.append(_feature_exclusions(
            annotations,
            [feature],
            stage="differential_model",
            reason="below_minimum_usable_cell_count",
            reason_detail=str(feature_qc["exclusion_reason"].iloc[0]),
            region=region,
        ))
    all_feature_exclusions = pd.concat(feature_exclusions, ignore_index=True) if feature_exclusions else pd.DataFrame(columns=_EXCLUSION_COLUMNS)
    all_feature_exclusions.to_csv(stages["01_preprocessing"] / "feature_exclusions.csv", index=False)
    expected_excluded_features = set(prevalence_table.loc[prevalence_table["excluded"], "Feature"])
    expected_excluded_features.update(prevalence_filtered.index.difference(blank_filtered.index))
    expected_excluded_features.update(fully_detection_excluded)
    expected_excluded_features.update(iqr_excluded)
    recorded_excluded_features = set(all_feature_exclusions["Feature"])
    if expected_excluded_features.difference(recorded_excluded_features):
        raise AssertionError("Every feature removed by a preprocessing stage must have an exclusion reason.")
    persisted_exclusions = pd.read_csv(stages["01_preprocessing"] / "feature_exclusions.csv")
    if set(persisted_exclusions["Feature"].astype(str)) != set(all_feature_exclusions["Feature"].astype(str)):
        raise AssertionError("Persisted feature exclusions differ from the in-memory exclusion table.")

    persisted_effects = pd.read_csv(stages["03_differential"] / "differential_effects.csv")
    _assert_fdr_denominator(persisted_effects, len(values.index), "OLS differential output")
    _write_model_contract(
        stages["00_inputs"],
        variant=variant,
        n_samples=len(surviving_samples),
        imputation_method=imputation_method or "none",
        scaling=scaling,
        iqr_filter=apply_iqr_filter,
    )

    preprocessing_diagnostics = pd.DataFrame([{
        "n_samples_input": len(all_raw.columns),
        "n_samples_after_exclusion": len(surviving_samples),
        "n_lipids_input": len(all_raw),
        "n_lipids_after_prevalence": len(prevalence_filtered),
        "n_prevalence_excluded": len(all_raw) - len(prevalence_filtered),
        "n_blank_dominated_removed": len(prevalence_filtered) - len(blank_filtered),
        "n_fully_detection_excluded": len(fully_detection_excluded),
        "n_lipids_before_iqr": len(normalized_values) + len(iqr_excluded),
        "n_iqr_excluded": len(iqr_excluded),
        "n_lipids_tested_panel": len(values),
        "n_below_detection_cells": int(detection_table.shape[0]),
        "prevalence_missingness_basis": "raw positive-only values before detection masking",
        "prevalence_pooled_across_regions": True,
    }])
    preprocessing_diagnostics.to_csv(stages["01_preprocessing"] / "preprocessing_diagnostics.csv", index=False)

    # Filtered-matrix multivariate analyses are comparability checks only.
    run_multivariate(
        normalized_values,
        metadata_surviving,
        stages["04_multivariate"],
        scaling=scaling,
        include_plsda=normalization != "pqn",
        pca_figures=True,
    )

    if normalization == "pqn":
        manifest = {
            "variant": variant, "normalization": "per-region centred median log-ratio PQN",
            "reference": "both treatments pooled within region; median-centred to zero",
            "imputation": "none", "n_input_samples": 60,
            "n_surviving_samples": len(surviving_samples), "n_tested_features": len(values),
            "scope": "differential and multivariate sensitivity only",
            "experimental_unit": "dam/cage; existing pup-level models are descriptive",
        }
        (output / "run_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        return output

    # The current primary differential output is read but never modified; it
    # supplies the comparison curve for calibration diagnostics.
    current_path = project_root / "results" / "mia_vs_control" / "03_differential" / "differential_effects.csv"
    if not current_path.exists():
        raise FileNotFoundError(f"Current differential results are required for p-value comparison: {current_path}")
    current_effects = pd.read_csv(current_path)
    pvalue_summary = pd.concat([
        summarize_p_values(current_effects, source="current"),
        summarize_p_values(fitted.effects, source="filtered"),
    ], ignore_index=True)
    pvalue_summary.to_csv(stages["05_diagnostics"] / "p_value_calibration_counts.csv", index=False)
    plot_p_value_histograms(current_effects, fitted.effects, stages["05_diagnostics"] / "figures" / "p_value_histograms")
    plot_small_p_value_counts(pvalue_summary, stages["05_diagnostics"] / "figures" / "small_p_value_counts")
    residual_table, selected_features = residual_diagnostics(values, metadata_surviving, count=DIAGNOSTIC_FEATURE_COUNT, min_per_cell=MIN_PER_CELL)
    residual_table.to_csv(stages["05_diagnostics"] / "residual_diagnostics.csv", index=False)
    selected_features.to_csv(stages["05_diagnostics"] / "diagnostic_feature_selection.csv", index=False)
    influence = sample_influence_summary(values, metadata_surviving, min_per_cell=MIN_PER_CELL)
    influence.to_csv(stages["05_diagnostics"] / "sample_influence_leave_one_out.csv", index=False)
    cross_check_qc_tables(project_root / "results" / "mia_vs_control" / "02_qc", fitted.effects).to_csv(
        stages["05_diagnostics"] / "qc_crosscheck.csv", index=False
    )
    missingness_se_crosscheck(fitted.feature_qc, fitted.effects, analysis_detection_table).to_csv(
        stages["05_diagnostics"] / "missingness_se_crosscheck.csv", index=False
    )
    empirical_features, empirical_summary, effective_tests = run_permutation_null(
        values,
        metadata_surviving,
        n_permutations=PERMUTATION_COUNT,
        random_state=PERMUTATION_RANDOM_SEED,
        min_per_cell=MIN_PER_CELL,
        exchangeability_unit="sample",
    )
    _assert_fdr_denominator(empirical_features, len(values.index), "permutation differential output")
    effective_tests.insert(1, "n_features_in_panel", len(values.index))
    effective_tests.to_csv(stages["05_diagnostics"] / "permutation_effective_tests.csv", index=False)
    effective_tests.assign(
        correlation_caveat="Strongly correlated lipid features make the effective number of independent tests lower than the nominal panel size; this descriptive estimate is not a replacement for BH."
    ).to_csv(stages["05_diagnostics"] / "multiple_testing_caveat.csv", index=False)
    empirical_features.to_csv(stages["05_diagnostics"] / "permutation_null_feature_statistics.csv", index=False)
    pd.DataFrame([
        {"column": "p_value_empirical_fdr", "family": "Region x Effect; full retained feature panel",
         "fdr_definition": "Benjamini-Hochberg of per-feature empirical p=(1+exceedances)/(1+valid draws)",
         "resolution": "p >= 1/(B+1); missing null draws can raise the feature-specific floor"},
        {"column": "empirical_null_fdr", "family": "Region x Effect; pooled feature null tails",
         "fdr_definition": "Expected null exceedances / observed discoveries at each absolute-t threshold; monotone minimum over less stringent thresholds; clipped to [0,1]",
         "resolution": "Pooled-tail FDR estimate, not BH of per-feature empirical p; no per-feature 1/(B+1) floor"},
    ]).to_csv(stages["05_diagnostics"] / "permutation_fdr_definitions.csv", index=False)
    empirical_summary.to_csv(stages["05_diagnostics"] / "permutation_null_distribution.csv", index=False)

    class_profiles: list[pd.DataFrame] = []
    class_annotations: list[pd.DataFrame] = []
    class_effects: list[pd.DataFrame] = []
    class_qc: list[pd.DataFrame] = []
    for statistic in ("mean", "median"):
        profiles, profile_annotations = aggregate_class_profiles(normalized_values, annotations, statistic=statistic)
        class_profiles.append(profiles)
        class_annotations.append(profile_annotations)
        class_analysis_values = (
            pareto_scale(drop_zero_variance_features(profiles))
            if scaling == "pareto"
            else profiles
        )
        fitted_class = fit_regionwise_differential(
            class_analysis_values,
            metadata_surviving,
            annotations=profile_annotations,
            min_per_cell=MIN_PER_CELL,
            fdr_denominator="all_features",
            effect_scale="pareto_scaled_log2" if scaling == "pareto" else "normalized_log2",
        )
        class_effects.append(fitted_class.effects)
        class_qc.append(fitted_class.feature_qc.assign(Aggregation=f"log2_{statistic}"))
    class_values = pd.concat(class_profiles, axis=0)
    class_annotation_table = pd.concat(class_annotations, axis=0)
    class_values.to_csv(stages["06_aggregation"] / "class_aggregate_input_matrix.csv", index_label="Feature")
    class_annotation_table.to_csv(stages["06_aggregation"] / "class_aggregate_annotations.csv", index_label="Feature")
    class_effect_table = pd.concat(class_effects, ignore_index=True)
    _assert_fdr_denominator(class_effect_table, len(class_profiles[0]), "class aggregate differential output")
    class_effect_table.to_csv(stages["06_aggregation"] / "class_aggregate_differential_effects.csv", index=False)
    pd.concat(class_qc, ignore_index=True).to_csv(stages["06_aggregation"] / "class_aggregate_feature_qc.csv", index=False)

    structural_annotation_table = annotate_lipid_structures(annotations.loc[normalized_values.index])
    aggregate_exclusions: list[dict[str, object]] = []
    for feature, annotation in annotations.loc[normalized_values.index].iterrows():
        lipid_class = annotation["Lipid Class"]
        if pd.isna(lipid_class) or str(lipid_class).strip() == "":
            aggregate_exclusions.append({
                "Feature": feature,
                "Lipid Name": annotation["Lipid Name"],
                "Lipid Class": lipid_class,
                "analysis_scope": "class and class-specific structural",
                "reason": "missing_lipid_class",
            })
        if not bool(structural_annotation_table.loc[feature, "parsed"]):
            aggregate_exclusions.append({
                "Feature": feature,
                "Lipid Name": annotation["Lipid Name"],
                "Lipid Class": lipid_class,
                "analysis_scope": "structural",
                "reason": "unparseable_lipid_structure",
            })
        elif bool(structural_annotation_table.loc[feature, "structural_ambiguous"]):
            aggregate_exclusions.append({
                "Feature": feature,
                "Lipid Name": annotation["Lipid Name"],
                "Lipid Class": lipid_class,
                "analysis_scope": "structural pufa_fraction",
                "reason": "sum_composition_structurally_ambiguous_for_multi_chain_class",
            })
    pd.DataFrame(aggregate_exclusions).to_csv(stages["06_aggregation"] / "aggregate_exclusions.csv", index=False)

    structural_values, structural_annotations, structural_long = structural_index_profiles(normalized_values, annotations)
    structural_values.to_csv(stages["06_aggregation"] / "structural_index_input_matrix.csv", index_label="Feature")
    structural_annotations.to_csv(stages["06_aggregation"] / "structural_index_annotations.csv", index_label="Feature")
    structural_long.to_csv(stages["06_aggregation"] / "structural_index_values_long.csv", index=False)
    structural_analysis_values = (
        pareto_scale(drop_zero_variance_features(structural_values))
        if scaling == "pareto"
        else structural_values
    )
    structural_analysis_annotations = structural_annotations.loc[structural_analysis_values.index]
    structural_fitted = fit_regionwise_differential(
        structural_analysis_values,
        metadata_surviving,
        annotations=structural_analysis_annotations,
        min_per_cell=MIN_PER_CELL,
        fdr_denominator="all_features",
        effect_scale="pareto_scaled_log2" if scaling == "pareto" else "normalized_log2",
    )
    _assert_fdr_denominator(structural_fitted.effects, len(structural_analysis_values), "structural index differential output")
    structural_fitted.effects.to_csv(stages["06_aggregation"] / "structural_index_differential_effects.csv", index=False)
    structural_fitted.feature_qc.to_csv(stages["06_aggregation"] / "structural_index_feature_qc.csv", index=False)
    pd.DataFrame([
        {
            "analysis": "class mean",
            "feature_family": "log2 class mean",
            "multiple_testing_family": "class_mean within Region x Effect",
            "n_features_input": len(class_profiles[0]),
            "linear_scale_sum_run": False,
            "effect_scale": scaling,
        },
        {
            "analysis": "class median",
            "feature_family": "log2 class median",
            "multiple_testing_family": "class_median within Region x Effect",
            "n_features_input": len(class_profiles[1]),
            "linear_scale_sum_run": False,
            "effect_scale": scaling,
        },
        {
            "analysis": "structural indices",
            "feature_family": "unweighted structural indices",
            "multiple_testing_family": "structural indices within Region x Effect",
            "n_features_input": len(structural_analysis_values),
            "linear_scale_sum_run": False,
            "effect_scale": scaling,
        },
    ]).to_csv(stages["06_aggregation"] / "aggregation_model_contract.csv", index=False)

    mde_features, mde_summary = detectable_effect_sizes(
        fitted.effects,
        alpha=POWER_ALPHA,
        target_power=POWER_TARGET,
        illustrative_litter_n=ILLUSTRATIVE_LITTER_N,
    )
    fdr_hits, _ = fdr_hit_table(fitted.effects, top_n=TOP_FDR_HITS)
    fdr_hits.to_csv(stages["07_specification_curve"] / "fdr_hits.csv", index=False)
    specification_rows: list[dict[str, object]] = []
    for (region, effect), effect_rows in fitted.effects.groupby(
        ["Region", "Effect"], sort=False, observed=True
    ):
        specification_rows.append({
            "specification": f"{imputation_method or 'none'}__{variant}__{scaling}",
            "specification_role": "single RF/scaling sensitivity variant; not the 144-specification curve",
            "prevalence_filter": True,
            "qc_cv_filter": False,
            "imputation": imputation_method or "none",
            "scaling": scaling,
            "Region": region,
            "Effect": effect,
            "n_features_tested": len(effect_rows),
            "n_features_with_valid_p_values": len(effect_rows),
            "n_features_correction_universe": len(values.index),
            "n_fdr_significant": int(effect_rows["p_value_fdr"].le(0.05).sum()),
            "smallest_q_value": effect_rows["p_value_fdr"].min(),
            "n_nominal_p_lt_0_01": int(effect_rows["p_value"].lt(0.01).sum()),
            "nominal_p_lt_0_01_expected": len(effect_rows) * 0.01,
            "n_cells_imputed": int(imputation_routes.ne("none").sum().sum()),
            "fdr_denominator": int(effect_rows["fdr_denominator"].iloc[0]),
        })
    pd.DataFrame(specification_rows).to_csv(
        stages["07_specification_curve"] / "specification_results.csv", index=False
    )
    mde_features.to_csv(stages["07_specification_curve"] / "detectable_effect_sizes.csv", index=False)
    mde_summary.to_csv(stages["07_specification_curve"] / "detectable_effect_size_summary.csv", index=False)
    plot_volcanoes(fitted.effects, mde_summary, stages["07_specification_curve"] / "figures")

    manifest = {
        "variant": variant,
        "normalization": normalization,
        "imputation_method": imputation_method or "none",
        "scaling": scaling,
        "iqr_filter": apply_iqr_filter,
        "description": spec["description"],
        "analysis_role": "sensitivity analysis; existing results/mia_vs_control remains primary",
        "n_input_samples": len(all_raw.columns),
        "n_surviving_samples": len(surviving_samples),
        "n_input_features": len(all_raw.index),
        "n_tested_features": len(values.index),
        "n_features_before_iqr": len(normalized_values) + len(iqr_excluded),
        "n_iqr_excluded": len(iqr_excluded),
        "prevalence_max_missing_fraction": MAX_MISSING_FRACTION,
        "prevalence_basis": "exclude_nonpositive(raw), pooled over all 60 samples, before detection masking and sample exclusion",
        "sample_exclusion_unit": "sample within region; other regions from the same mouse retained",
        "litter_aware_model": "deferred; pup-level independence assumption is explicit",
        "permutation_count": PERMUTATION_COUNT,
        "permutation_seed": PERMUTATION_RANDOM_SEED,
        "permutation_exchangeability_unit": "sample",
        "permutation_schemes": {
            "MIA vs Saline Control": "BioGroup within Sex",
            "MIA x Female interaction": "BioGroup within Sex",
            "Female vs Male": "Sex within BioGroup",
        },
        "permutation_caveat": "If Mouse number prefixes identify litters, sample-level permutation is anti-conservative and empirical p-values are lower bounds.",
        "aggregate_scale": "unweighted mean and median of normalized log2 species profiles; structural indices unweighted",
        "power_method": "nominal two-sided alpha 0.05, 80% normal approximation; n=8 litter result illustrative only",
        "effective_tests_method": "For each Region x Effect family, M^2 p(1-p) / Var(K), where K is the nominal p<0.05 discovery count across null permutations; descriptive only, not a replacement for BH.",
        "effective_tests_caveat": "Correlated lipid features make small-p-value counts over-dispersed, so a deficit in one cell remains weak evidence alone.",
    }
    (output / "run_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="ascii")
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variant", choices=sorted(PIPELINE_VARIANTS), required=True)
    args = parser.parse_args()
    run_pipeline_variant(Path(__file__).resolve().parents[3], args.variant)


if __name__ == "__main__":
    main()
