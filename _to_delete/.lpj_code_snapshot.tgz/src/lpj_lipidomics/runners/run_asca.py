"""Run the pre-declared ASCA+ region, group, and sex analysis."""

from __future__ import annotations

import json
from itertools import product
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import kstest, pearsonr, spearmanr

from ..multivariate.asca import (
    EFFECT_ORDER,
    SCALING_MODES,
    effect_residual_projection,
    effect_svd,
    effect_variance_table,
    fit_asca,
    fit_asca_sample_matrix,
    level_labels,
    procrustes_align,
)
from ..plotting import (
    BIO_GROUP_COLORS,
    BRAIN_REGION_COLORS,
    COLORBLIND_COLORS,
    MARKER_CYCLE,
    apply_plot_style,
    save_figure,
)
from ..statistics.asca_permutation import (
    cage_group_permutations,
    control_cage_sex_permutations,
    effect_ssq_by_scaling,
    make_spike_profile,
    mouse_group_permutations,
    region_label_permutations,
    stratified_mouse_bootstrap_indices,
)
from ..statistics.clustered import exact_empirical_p_value


POPULATIONS = {
    "prevalence20_noexclusion": "prevalence20_noexclusion",
    "prevalence20_hotelling95": "prevalence20_hotelling95",
    "prevalence20_hotelling99": "prevalence20_hotelling99",
}
MODALITIES = ("lipidomics", "metabolomics")
SCALINGS = SCALING_MODES
PRIMARY_SCALING = "autoscaled"
PERMUTATION_COUNT = 9_999
BOOTSTRAP_COUNT = 1_000
POWER_DATASETS = 200
POWER_PERMUTATIONS = 199
SPIKE_DATASETS = 50
SPIKE_PERMUTATIONS = 99
BASE_SEED = 20_261_008


def _relative(path: Path, project_root: Path) -> str:
    return str(path.relative_to(project_root))


def _read_inputs(project_root: Path, population: str, modality: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Path]:
    input_root = (
        project_root
        / "results"
        / "mia_vs_control"
        / "09_region_persistence"
        / population
        / modality
        / "00_inputs"
    )
    matrix_path = input_root / "region_input_matrix.csv"
    metadata_path = input_root / "region_input_metadata.csv"
    values = pd.read_csv(matrix_path, index_col="Feature")
    values.index = values.index.map(str)
    values.columns = values.columns.map(str)
    metadata = pd.read_csv(metadata_path)
    metadata["Sample"] = metadata["Sample"].astype(str)
    if metadata["Sample"].duplicated().any():
        raise ValueError(f"Duplicate samples in {metadata_path}.")
    missing = pd.Index(values.columns).difference(metadata["Sample"])
    if len(missing):
        raise ValueError(f"Input metadata is missing samples: {missing.tolist()}")
    metadata = metadata.set_index("Sample", drop=False).loc[list(values.columns)].reset_index(drop=True)
    numeric = values.apply(pd.to_numeric, errors="coerce")
    coercion_failed = numeric.isna() & values.notna()
    if coercion_failed.to_numpy().any():
        raise ValueError("Input matrix contains non-numeric values.")
    complete = numeric.notna().all(axis=1)
    selection = pd.DataFrame({
        "Feature": numeric.index,
        "complete_across_population": complete.to_numpy(),
        "selection_rule": "complete across all samples in this population; no imputation",
    })
    return numeric.loc[complete], metadata, selection, input_root


def _annotations(project_root: Path, modality: str) -> pd.DataFrame:
    if modality != "lipidomics":
        return pd.DataFrame(columns=["Feature", "Lipid Name", "Lipid Class"])
    path = (
        project_root
        / "results"
        / "pipeline_test"
        / "prevalence20_noexclusion"
        / "03_differential"
        / "differential_effects.csv"
    )
    if not path.exists():
        return pd.DataFrame(columns=["Feature", "Lipid Name", "Lipid Class"])
    table = pd.read_csv(path, usecols=["Feature", "Lipid Name", "Lipid Class"])
    table["Feature"] = table["Feature"].map(str)
    return table.drop_duplicates("Feature")


def _sample_metadata(fit_metadata: pd.DataFrame, row: pd.Series) -> dict[str, object]:
    result = {}
    for column in ("Sample", "Sample type", "Bio group", "Sex", "Mouse number", "Cage"):
        if column in fit_metadata:
            result[column] = row[column]
    return result


def _score_table(fit, population: str, modality: str) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for effect in EFFECT_ORDER:
        sample_scores, _, singular_values = effect_svd(fit, effect)
        labels = level_labels(fit.metadata, effect)
        for component in sample_scores.columns[1:]:
            component_number = int(component.removeprefix("PC"))
            for position, score in enumerate(sample_scores[component]):
                row = {
                    "Population": population,
                    "Modality": modality,
                    "Scaling": fit.scaling,
                    "Effect": effect,
                    "Component": component,
                    "Score type": "sample",
                    "Level": "",
                    "Score": float(score),
                    "singular_value": float(singular_values[component_number - 1]),
                }
                row.update(_sample_metadata(fit.metadata, fit.metadata.iloc[position]))
                rows.append(row)
            grouped = sample_scores.assign(Level=labels.to_numpy()).groupby(
                "Level", sort=False, observed=True
            )
            for level, group in grouped:
                rows.append({
                    "Population": population,
                    "Modality": modality,
                    "Scaling": fit.scaling,
                    "Effect": effect,
                    "Component": component,
                    "Score type": "level",
                    "Level": level,
                    "Score": float(group[component].mean()),
                    "n_observations": int(len(group)),
                    "singular_value": float(singular_values[component_number - 1]),
                })
    return pd.DataFrame(rows)


def _bootstrap_loading_intervals(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    fit,
    *,
    n_bootstraps: int,
    random_state: int,
) -> dict[str, pd.DataFrame]:
    references = {
        effect: effect_svd(fit, effect)[1] for effect in EFFECT_ORDER
    }
    samples: dict[str, np.ndarray] = {
        effect: np.empty((n_bootstraps, len(reference.columns), len(reference)), dtype=float)
        for effect, reference in references.items()
    }
    feature_names = list(fit.feature_names)
    source = values.to_numpy(dtype=float).T
    for bootstrap in range(n_bootstraps):
        if bootstrap == 0 or (bootstrap + 1) % 100 == 0:
            print(
                f"[ASCA] {fit.scaling} bootstrap {bootstrap + 1}/{n_bootstraps}",
                flush=True,
            )
        indices = stratified_mouse_bootstrap_indices(
            metadata,
            random_state=random_state + bootstrap,
        )
        boot_metadata = metadata.iloc[indices].reset_index(drop=True)
        boot_fit = fit_asca_sample_matrix(
            source[indices],
            feature_names,
            boot_metadata,
            scaling=fit.scaling,
            allow_rank_deficient=True,
        )
        for effect in EFFECT_ORDER:
            boot_loadings = effect_svd(boot_fit, effect)[1]
            reference_components = references[effect].shape[1]
            if boot_loadings.shape[1] < reference_components:
                padded = np.zeros(
                    (boot_loadings.shape[0], reference_components), dtype=float
                )
                padded[:, :boot_loadings.shape[1]] = boot_loadings.to_numpy(dtype=float)
                boot_loadings = pd.DataFrame(
                    padded,
                    index=boot_loadings.index,
                    columns=references[effect].columns,
                )
            elif boot_loadings.shape[1] > reference_components:
                boot_loadings = boot_loadings.iloc[:, :reference_components]
            aligned = procrustes_align(
                boot_loadings.to_numpy(dtype=float),
                references[effect].to_numpy(dtype=float),
            )
            samples[effect][bootstrap] = aligned.T
    result: dict[str, pd.DataFrame] = {}
    for effect, reference in references.items():
        values_array = samples[effect]
        rows = []
        for component_number, component in enumerate(reference.columns):
            rows.append(pd.DataFrame({
                "Feature": reference.index,
                "Component": component,
                "loading_q025": np.quantile(values_array[:, component_number, :], 0.025, axis=0),
                "loading_q975": np.quantile(values_array[:, component_number, :], 0.975, axis=0),
            }))
        result[effect] = pd.concat(rows, ignore_index=True)
    return result


def _loading_table(
    fit,
    intervals: dict[str, pd.DataFrame],
    annotations: pd.DataFrame,
    population: str,
    modality: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[pd.DataFrame] = []
    compositions: list[pd.DataFrame] = []
    for effect in EFFECT_ORDER:
        _, loadings, singular_values = effect_svd(fit, effect)
        table = loadings.rename_axis("Feature").reset_index().melt(
            id_vars="Feature", var_name="Component", value_name="Loading"
        )
        table["Effect"] = effect
        table["Scaling"] = fit.scaling
        table["Population"] = population
        table["Modality"] = modality
        table["absolute_loading"] = table["Loading"].abs()
        table["singular_value"] = table["Component"].map({
            f"PC{number + 1}": value for number, value in enumerate(singular_values)
        })
        table = table.merge(intervals[effect], on=["Feature", "Component"], how="left")
        if not annotations.empty:
            table = table.merge(annotations, on="Feature", how="left")
        rows.append(table)
        if "Lipid Class" in table:
            for component, component_rows in table.groupby("Component", sort=False, observed=True):
                top = component_rows.nlargest(20, "absolute_loading")
                composition = (
                    top.dropna(subset=["Lipid Class"])
                    .groupby("Lipid Class", observed=True)
                    .size()
                    .rename("n_top_features")
                    .reset_index()
                )
                if not composition.empty:
                    composition.insert(0, "Component", component)
                    composition.insert(0, "Effect", effect)
                    composition["Scaling"] = fit.scaling
                    composition["Population"] = population
                    composition["Modality"] = modality
                    composition["top_feature_count"] = len(top)
                    compositions.append(composition)
    return pd.concat(rows, ignore_index=True), (
        pd.concat(compositions, ignore_index=True)
        if compositions
        else pd.DataFrame()
    )


def _region_consistency(
    project_root: Path,
    population: str,
    modality: str,
    fit,
) -> pd.DataFrame:
    path = (
        project_root
        / "results"
        / "mia_vs_control"
        / "09_region_persistence"
        / population
        / modality
        / "03_differential"
        / "within_group_region_tests.csv"
    )
    if not path.exists():
        return pd.DataFrame()
    existing = pd.read_csv(path)
    existing["Feature"] = existing["Feature"].map(str)
    effect = fit.effects["Region"]
    rows = []
    for contrast, region_a, region_b in (
        ("Cortex - Cerebellum", "Cortex", "Cerebellum"),
        ("Cortex - Hippocampus", "Cortex", "Hippocampus"),
        ("Hippocampus - Cerebellum", "Hippocampus", "Cerebellum"),
    ):
        asca_a = effect[fit.metadata["Sample type"].eq(region_a).to_numpy()].mean(axis=0)
        asca_b = effect[fit.metadata["Sample type"].eq(region_b).to_numpy()].mean(axis=0)
        asca_profile = pd.Series(asca_a - asca_b, index=fit.feature_names, name="asca")
        subset = existing.loc[existing["Contrast"].eq(contrast)].copy()
        if subset.empty:
            continue
        subset["weighted"] = subset["estimate_log2"] * subset["n_mice"]
        pooled = subset.groupby("Feature", observed=True).agg(
            weighted=("weighted", "sum"), n=("n_mice", "sum")
        )
        pooled["persistence_profile"] = pooled["weighted"] / pooled["n"]
        feature_scales = pd.Series(fit.feature_scales, index=fit.feature_names)
        pooled["persistence_profile"] = pooled["persistence_profile"] / feature_scales
        joined = pd.concat([asca_profile, pooled["persistence_profile"]], axis=1).dropna()
        if len(joined) >= 3:
            pearson = float(pearsonr(joined.iloc[:, 0], joined.iloc[:, 1]).statistic)
            spearman = float(spearmanr(joined.iloc[:, 0], joined.iloc[:, 1]).statistic)
        else:
            pearson = spearman = np.nan
        rows.append({
            "Population": population,
            "Modality": modality,
            "Scaling": fit.scaling,
            "Contrast": contrast,
            "n_features": len(joined),
            "pearson_r": pearson,
            "spearman_r": spearman,
            "comparison": "ASCA Region effect contrast vs pooled persistence within-group estimate",
        })
    return pd.DataFrame(rows)


def _permutation_outputs(
    fits: dict[str, object],
    metadata: pd.DataFrame,
    *,
    n_random: int,
    random_state: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    prepared = {scaling: fit.prepared_data for scaling, fit in fits.items()}
    specifications = [
        ("Region", ("Region",), "within_mouse_region", "region", random_state),
        ("Group_cage", ("Group", "Region:Group"), "whole_cage", "cage", random_state + 1),
        ("Group_mouse", ("Group", "Region:Group"), "mouse_within_sex", "mouse", random_state + 2),
        ("Sex", ("Sex", "Region:Sex"), "within_control_cage", "sex", random_state + 3),
    ]
    null_rows: list[dict[str, object]] = []
    for engine, effects, unit, kind, seed in specifications:
        if kind == "region":
            permutations = region_label_permutations(
                metadata, n_random=n_random, random_state=seed
            )
        elif kind == "cage":
            permutations = cage_group_permutations(metadata)
        elif kind == "mouse":
            permutations = mouse_group_permutations(
                metadata, n_random=n_random, random_state=seed
            )
        else:
            permutations = control_cage_sex_permutations(
                metadata, n_random=n_random, random_state=seed
            )
        for permutation_id, permuted_metadata in permutations:
            statistics = effect_ssq_by_scaling(prepared, permuted_metadata, effects)
            is_observed = np.array_equal(
                permuted_metadata["Bio group"].to_numpy(),
                metadata["Bio group"].to_numpy(),
            ) and np.array_equal(
                permuted_metadata["Sample type"].to_numpy(),
                metadata["Sample type"].to_numpy(),
            ) and np.array_equal(
                permuted_metadata["Sex"].to_numpy(),
                metadata["Sex"].to_numpy(),
            )
            for scaling, effect_statistics in statistics.items():
                for effect, statistic in effect_statistics.items():
                    null_rows.append({
                        "Engine": engine,
                        "Permutation unit": unit,
                        "Permutation ID": permutation_id,
                        "Scaling": scaling,
                        "Effect": effect,
                        "SSQ": statistic,
                        "is_observed": is_observed,
                        "random_state": seed,
                    })
    null = pd.DataFrame(null_rows)
    tests: list[dict[str, object]] = []
    for (engine, unit, scaling, effect), group in null.groupby(
        ["Engine", "Permutation unit", "Scaling", "Effect"], sort=False, observed=True
    ):
        observed = float(np.square(fits[scaling].effects[effect]).sum())
        statistics = group["SSQ"].to_numpy(dtype=float)
        tests.append({
            "Engine": engine,
            "Permutation unit": unit,
            "Scaling": scaling,
            "Effect": effect,
            "observed_ssq": observed,
            "null_q025": float(np.quantile(statistics, 0.025)),
            "null_q975": float(np.quantile(statistics, 0.975)),
            "p_value": exact_empirical_p_value(observed, statistics),
            "n_permutations_including_observed": len(statistics),
            "multiplicity_correction": "none; pre-declared cage-level calibration",
        })
    return pd.DataFrame(tests), null


def _residual_factor(fit) -> np.ndarray:
    """Return a low-rank factor reproducing the residual covariance."""
    residual = fit.residual - fit.residual.mean(axis=0)
    _, singular_values, right = np.linalg.svd(residual, full_matrices=False)
    rank = min(np.linalg.matrix_rank(residual), len(singular_values))
    if rank == 0:
        return np.zeros((fit.n_features, 1), dtype=float)
    return right[:rank].T * (singular_values[:rank] / np.sqrt(max(fit.n_samples - 1, 1)))


def _power_simulation(
    fit,
    metadata: pd.DataFrame,
    *,
    n_datasets: int,
    n_permutations: int,
    spike_datasets: int,
    spike_permutations: int,
    random_state: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Calibrate mouse-level p-values and estimate Region x Group power."""
    rng = np.random.default_rng(random_state)
    factor = _residual_factor(fit)
    feature_names = list(fit.feature_names)
    null_rows: list[dict[str, object]] = []
    for dataset in range(n_datasets):
        if dataset == 0 or (dataset + 1) % 25 == 0:
            print(
                f"[ASCA] null calibration {dataset + 1}/{n_datasets}",
                flush=True,
            )
        data = rng.normal(size=(fit.n_samples, factor.shape[1])) @ factor.T
        observed = effect_ssq_by_scaling(
            {fit.scaling: data}, metadata, ("Region", "Group", "Region:Group")
        )[fit.scaling]
        region_null = region_label_permutations(
            metadata, n_random=n_permutations, random_state=random_state + dataset
        )
        group_null = mouse_group_permutations(
            metadata, n_random=n_permutations, random_state=random_state + 10_000 + dataset
        )
        nulls = {
            "Region": [
                effect_ssq_by_scaling({fit.scaling: data}, current, ("Region",))[fit.scaling]["Region"]
                for _, current in region_null
            ],
            "Group": [
                effect_ssq_by_scaling({fit.scaling: data}, current, ("Group",))[fit.scaling]["Group"]
                for _, current in group_null
            ],
            "Region:Group": [
                effect_ssq_by_scaling({fit.scaling: data}, current, ("Region:Group",))[fit.scaling]["Region:Group"]
                for _, current in mouse_group_permutations(
                    metadata, n_random=n_permutations, random_state=random_state + 20_000 + dataset
                )
            ],
        }
        for effect, values in nulls.items():
            null_rows.append({
                "kind": "null_calibration",
                "dataset": dataset,
                "Effect": effect,
                "p_value": exact_empirical_p_value(observed[effect], np.asarray(values)),
                "n_permutations": len(values),
                "scaling": fit.scaling,
            })

    cage_assignments = list(cage_group_permutations(metadata))
    mouse_assignments = list(mouse_group_permutations(
        metadata, n_random=spike_permutations, random_state=random_state + 30_000
    ))
    power_rows: list[dict[str, object]] = []
    profile = make_spike_profile(metadata)
    mia = metadata["Bio group"].eq("MIA").to_numpy(dtype=float)
    for shift, n_features in product((0.25, 0.5, 1.0), (10, 50, 200)):
        print(
            f"[ASCA] spike power shift={shift}, features={n_features}",
            flush=True,
        )
        for dataset in range(spike_datasets):
            baseline = rng.normal(size=(fit.n_samples, factor.shape[1])) @ factor.T
            data = baseline.copy()
            data[:, :min(n_features, fit.n_features)] += (
                shift * profile * mia
            )[:, None]
            observed = effect_ssq_by_scaling(
                {fit.scaling: data}, metadata, ("Region:Group",)
            )[fit.scaling]["Region:Group"]
            for engine, assignments in (
                ("cage", cage_assignments),
                ("mouse", mouse_assignments),
            ):
                null = [
                    effect_ssq_by_scaling(
                        {fit.scaling: data}, current, ("Region:Group",)
                    )[fit.scaling]["Region:Group"]
                    for _, current in assignments
                ]
                p_value = exact_empirical_p_value(observed, np.asarray(null))
                power_rows.append({
                    "kind": "spike_power",
                    "shift_sd": shift,
                    "n_spiked_features": n_features,
                    "dataset": dataset,
                    "engine": engine,
                    "p_value": p_value,
                    "detected_at_0_05": bool(p_value < 0.05),
                    "n_permutations": len(null),
                    "scaling": fit.scaling,
                })
    calibration = pd.DataFrame(null_rows)
    calibration_summary_rows = []
    for effect, values in calibration.groupby("Effect", observed=True):
        p_values = values["p_value"].to_numpy(dtype=float)
        calibration_summary_rows.append({
            "kind": "null_calibration_summary",
            "Effect": effect,
            "n_datasets": len(p_values),
            "rejection_rate_at_0_05": float(np.mean(p_values < 0.05)),
            "ks_statistic": float(kstest(p_values, "uniform").statistic),
            "ks_p_value": float(kstest(p_values, "uniform").pvalue),
        })
    power_summary = (
        pd.DataFrame(power_rows)
        .groupby(["shift_sd", "n_spiked_features", "engine", "scaling"], observed=True)
        .agg(
            detection_rate=("detected_at_0_05", "mean"),
            n_datasets=("dataset", "nunique"),
        )
        .reset_index()
    )
    return pd.concat([calibration, pd.DataFrame(calibration_summary_rows)], ignore_index=True), pd.DataFrame(power_rows), power_summary


def _save_composite_figure(
    output: Path,
    fit,
    variance: pd.DataFrame,
    permutation_tests: pd.DataFrame,
    loadings: pd.DataFrame,
    modality: str,
) -> None:
    apply_plot_style()
    figure, axes = plt.subplots(2, 2, figsize=(13, 9), constrained_layout=True)
    variance_plot = variance.loc[variance["Effect"].ne("Residual")]
    x = np.arange(len(variance_plot))
    axes[0, 0].bar(x, variance_plot["variance_share"], color=COLORBLIND_COLORS[:len(x)])
    lower = []
    upper = []
    for effect in variance_plot["Effect"]:
        row = permutation_tests.loc[
            permutation_tests["Effect"].eq(effect)
            & permutation_tests["Scaling"].eq(PRIMARY_SCALING)
        ]
        lower.append(float(row["null_q025"].iloc[0] / fit.total_ssq) if len(row) else np.nan)
        upper.append(float(row["null_q975"].iloc[0] / fit.total_ssq) if len(row) else np.nan)
    axes[0, 0].vlines(x, lower, upper, color="#333333", linewidth=2, label="permutation null 95% interval")
    axes[0, 0].set_xticks(x, variance_plot["Effect"], rotation=45, ha="right")
    axes[0, 0].set_ylabel("Structured variance share")
    axes[0, 0].set_title("Effect variance and null intervals")
    axes[0, 0].legend(frameon=False)

    region_scores, _, _ = effect_svd(fit, "Region")
    for region, color in BRAIN_REGION_COLORS.items():
        for group, marker in zip(("Saline Control", "MIA"), MARKER_CYCLE[:2]):
            mask = fit.metadata["Sample type"].eq(region) & fit.metadata["Bio group"].eq(group)
            axes[0, 1].scatter(
                region_scores.loc[mask, "PC1"],
                region_scores.loc[mask, "PC2"],
                color=color,
                marker=marker,
                edgecolor="black",
                linewidth=0.3,
                label=f"{region}, {group}",
            )
    axes[0, 1].set_xlabel("Region PC1 score")
    axes[0, 1].set_ylabel("Region PC2 score")
    axes[0, 1].set_title("Region effect plus residual")
    axes[0, 1].legend(fontsize=7, frameon=False, ncol=2)

    interaction_scores, _, _ = effect_svd(fit, "Region:Group")
    for group, marker in zip(("Saline Control", "MIA"), MARKER_CYCLE[:2]):
        mask = fit.metadata["Bio group"].eq(group)
        axes[1, 0].scatter(
            interaction_scores.loc[mask, "PC1"],
            interaction_scores.loc[mask, "PC2"],
            color=BIO_GROUP_COLORS[group],
            marker=marker,
            edgecolor="black",
            linewidth=0.3,
            label=group,
        )
    axes[1, 0].set_xlabel("Region x Group PC1 score")
    axes[1, 0].set_ylabel("Region x Group PC2 score")
    axes[1, 0].set_title("Region x Group effect")
    axes[1, 0].legend(frameon=False)

    top = loadings.loc[
        loadings["Effect"].eq("Region") & loadings["Component"].eq("PC1")
    ].nlargest(15, "absolute_loading").sort_values("Loading")
    classes = top.get("Lipid Class", pd.Series(index=top.index, dtype=object)).fillna("unannotated")
    class_names = list(dict.fromkeys(classes.tolist()))
    class_colors = {name: COLORBLIND_COLORS[i % len(COLORBLIND_COLORS)] for i, name in enumerate(class_names)}
    axes[1, 1].barh(
        top["Feature"].astype(str),
        top["Loading"],
        color=[class_colors[name] for name in classes],
    )
    axes[1, 1].set_xlabel("Region PC1 loading")
    axes[1, 1].set_title(f"Top Region PC1 loadings ({modality})")
    figure.suptitle(f"ASCA+ exploratory summary: {modality}", fontsize=14, fontweight="bold")
    save_figure(figure, output / "asca_composite")
    plt.close(figure)


def _write_modality_run(
    project_root: Path,
    output: Path,
    population: str,
    modality: str,
    *,
    permutation_count: int,
    bootstrap_count: int,
    power_datasets: int,
    overwrite: bool,
) -> dict[str, object]:
    if not overwrite and output.exists() and any(path.is_file() for path in output.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite ASCA output: {output}")
    input_stage = output / "00_inputs"
    model_stage = output / "01_model"
    inference_stage = output / "02_inference"
    for stage in (input_stage, model_stage, inference_stage):
        stage.mkdir(parents=True, exist_ok=True)

    values, metadata, selection, input_root = _read_inputs(project_root, population, modality)
    print(
        f"[ASCA] start {population}/{modality}: {len(metadata)} samples, {len(values)} complete features",
        flush=True,
    )
    values.to_csv(input_stage / "complete_feature_matrix.csv", index_label="Feature")
    metadata.to_csv(input_stage / "region_input_metadata.csv", index=False)
    selection.to_csv(input_stage / "feature_selection.csv", index=False)
    annotations = _annotations(project_root, modality)

    fits = {}
    variances = []
    score_tables = []
    loading_tables = []
    composition_tables = []
    projection_tables = []
    consistency_tables = []
    loading_intervals = {}
    for scaling in SCALINGS:
        print(f"[ASCA] fit {population}/{modality}/{scaling}", flush=True)
        fit = fit_asca(values, metadata, scaling=scaling)
        fits[scaling] = fit
        variance = effect_variance_table(fit)
        variance.insert(0, "Scaling", scaling)
        variance.insert(0, "Modality", modality)
        variance.insert(0, "Population", population)
        variances.append(variance)
        score_tables.append(_score_table(fit, population, modality))
        intervals = _bootstrap_loading_intervals(
            values,
            metadata,
            fit,
            n_bootstraps=bootstrap_count,
            random_state=BASE_SEED + list(SCALINGS).index(scaling) * 10_000,
        )
        loading_intervals[scaling] = intervals
        loadings, composition = _loading_table(
            fit, intervals, annotations, population, modality
        )
        loading_tables.append(loadings)
        if not composition.empty:
            composition_tables.append(composition)
        projections = []
        for effect in EFFECT_ORDER:
            _, effect_loadings, _ = effect_svd(fit, effect)
            projection = effect_residual_projection(fit, effect, effect_loadings)
            projection.insert(0, "Scaling", scaling)
            projection.insert(0, "Modality", modality)
            projection.insert(0, "Population", population)
            projections.append(projection)
        projection_tables.append(pd.concat(projections, ignore_index=True))
        consistency_tables.append(_region_consistency(project_root, population, modality, fit))

    print(f"[ASCA] permutations {population}/{modality}", flush=True)
    permutation_tests, permutation_null = _permutation_outputs(
        fits,
        metadata,
        n_random=permutation_count,
        random_state=BASE_SEED,
    ) if permutation_count else (
        pd.DataFrame(columns=[
            "Engine", "Permutation unit", "Scaling", "Effect", "observed_ssq",
            "null_q025", "null_q975", "p_value",
            "n_permutations_including_observed", "multiplicity_correction",
        ]),
        pd.DataFrame(columns=[
            "Engine", "Permutation unit", "Permutation ID", "Scaling", "Effect",
            "SSQ", "is_observed", "random_state",
        ]),
    )
    permutation_tests.insert(0, "Modality", modality)
    permutation_tests.insert(0, "Population", population)
    permutation_null.insert(0, "Modality", modality)
    permutation_null.insert(0, "Population", population)
    variance_table = pd.concat(variances, ignore_index=True)
    variance_table.to_csv(model_stage / "effect_variance.csv", index=False)
    pd.concat(score_tables, ignore_index=True).to_csv(model_stage / "scores.csv", index=False)
    loading_table = pd.concat(loading_tables, ignore_index=True)
    loading_table.to_csv(model_stage / "loadings.csv", index=False)
    if composition_tables:
        pd.concat(composition_tables, ignore_index=True).to_csv(
            model_stage / "loadings_class_composition.csv", index=False
        )
    pd.concat(projection_tables, ignore_index=True).to_csv(
        model_stage / "effect_residual_projection.csv", index=False
    )
    consistency = pd.concat(
        [table for table in consistency_tables if not table.empty], ignore_index=True
    ) if any(not table.empty for table in consistency_tables) else pd.DataFrame()
    consistency.to_csv(model_stage / "region_consistency.csv", index=False)
    permutation_tests.to_csv(inference_stage / "permutation_tests.csv", index=False)
    permutation_null.to_csv(inference_stage / "permutation_null_ssq.csv", index=False)

    power_files = []
    if population == "prevalence20_noexclusion" and power_datasets:
        print(f"[ASCA] power simulation {population}/{modality}", flush=True)
        calibration, spike_power, spike_summary = _power_simulation(
            fits[PRIMARY_SCALING],
            metadata,
            n_datasets=power_datasets,
            n_permutations=POWER_PERMUTATIONS,
            spike_datasets=SPIKE_DATASETS,
            spike_permutations=SPIKE_PERMUTATIONS,
            random_state=BASE_SEED + 90_000,
        )
        calibration.to_csv(inference_stage / "power_null_calibration.csv", index=False)
        spike_power.to_csv(inference_stage / "power_spike_runs.csv", index=False)
        spike_summary.to_csv(inference_stage / "power_simulation.csv", index=False)
        power_files = [
            "power_null_calibration.csv",
            "power_spike_runs.csv",
            "power_simulation.csv",
        ]

    if population == "prevalence20_noexclusion":
        figure_stage = model_stage / "figures"
        _save_composite_figure(
            figure_stage,
            fits[PRIMARY_SCALING],
            variance_table.loc[variance_table["Scaling"].eq(PRIMARY_SCALING)],
            permutation_tests,
            loading_table.loc[loading_table["Scaling"].eq(PRIMARY_SCALING)],
            modality,
        )

    reference_crosscheck = []
    if (inference_stage / "alasca_crosscheck_comparison.csv").exists():
        reference_crosscheck = [
            "alasca_crosscheck.csv",
            "alasca_crosscheck_profiles.csv",
            "alasca_crosscheck_comparison.csv",
            "alasca_crosscheck_status.csv",
        ]

    manifest = {
        "analysis": "ASCA+ multivariate region, treatment, and interaction analysis",
        "population": population,
        "modality": modality,
        "source_input": _relative(input_root, project_root),
        "n_samples": len(metadata),
        "n_features_input": len(selection),
        "n_complete_features": len(values),
        "scalings": list(SCALINGS),
        "primary_scaling": PRIMARY_SCALING,
        "missing_values": "complete features only; no imputation",
        "model": "Region + Group + Sex + Group:Sex + Mouse(Group:Sex) + Region:Group + Region:Sex + Region:Group:Sex",
        "coding": "sum-to-zero effect coding; Mouse is within Group x Sex contrast-coded",
        "experimental_unit": "cage/dam for Group; mouse for repeated regional observations",
        "permutation_units": {
            "Region": "within mouse",
            "Group_cage": "whole cage, exact 28 assignments",
            "Group_mouse": "mouse within Sex, anti-conservative sensitivity",
            "Sex": "within control cage; MIA cages unchanged and confounded",
        },
        "permutation_random_count": permutation_count,
        "permutation_scope": "primary all-60 population only" if permutation_count else "not part of declared inference; any pre-existing files are retained exploratory artifacts",
        "bootstrap_count": bootstrap_count,
        "bootstrap_unit": "mouse stratified by Group x Sex, all available regions retained",
        "bootstrap_cage_caveat": "mouse bootstrap does not resample cages; Group-related intervals are too narrow",
        "decomposition_uncertainty": "Decision 10 was not fully certain. Term contributions are X_term beta_term from one full-rank fit; centered-data identity defines the reported residual in unbalanced arms.",
        "variance_share_note": "Term SSQ shares are additive in the balanced all-60 design; under T2 imbalance, non-orthogonal term contributions can make their SSQ shares sum above one.",
        "reference_crosscheck": reference_crosscheck,
        "multiplicity": "No multiplicity correction for the pre-declared cage-level Group and Region:Group p-values; no significant label",
        "power_simulation": power_files,
        "output_stages": ["00_inputs", "01_model", "02_inference"],
    }
    with (output / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, default=str)
    print(f"[ASCA] finished {population}/{modality}", flush=True)
    return manifest


def run_asca(
    project_root: Path,
    *,
    overwrite: bool = False,
    permutation_count: int = PERMUTATION_COUNT,
    bootstrap_count: int = BOOTSTRAP_COUNT,
    power_datasets: int = POWER_DATASETS,
) -> Path:
    """Run all declared ASCA populations and modalities."""
    output_root = project_root / "results" / "mia_vs_control" / "13_asca"
    if not overwrite and output_root.exists() and any(path.is_file() for path in output_root.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite ASCA output tree: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    manifests = []
    for population in POPULATIONS:
        for modality in MODALITIES:
            manifests.append(_write_modality_run(
                project_root,
                output_root / population / modality,
                population,
                modality,
                permutation_count=permutation_count if population == "prevalence20_noexclusion" else 0,
                bootstrap_count=bootstrap_count,
                power_datasets=power_datasets,
                overwrite=overwrite,
            ))
    root_manifest = {
        "analysis": "ASCA+ multivariate region, treatment, and interaction analysis",
        "output_root": _relative(output_root, project_root),
        "populations": list(POPULATIONS),
        "modalities": list(MODALITIES),
        "scalings": list(SCALINGS),
        "runs": manifests,
        "python_implementation": "src/lpj_lipidomics/multivariate/asca.py",
        "permutation_implementation": "src/lpj_lipidomics/statistics/asca_permutation.py",
        "date_subset_sensitivity": "skipped as pre-declared",
        "explorer_app": "out of scope until results are reviewed",
    }
    with (output_root / "provenance.json").open("w", encoding="utf-8") as handle:
        json.dump(root_manifest, handle, indent=2, default=str)
    with (output_root / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(root_manifest, handle, indent=2, default=str)
    return output_root


if __name__ == "__main__":
    run_asca(Path(__file__).resolve().parents[3])
