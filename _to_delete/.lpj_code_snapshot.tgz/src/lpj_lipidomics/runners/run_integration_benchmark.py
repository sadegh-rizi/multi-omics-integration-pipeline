"""Benchmark available integration representations and within-region predictability."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cross_decomposition import PLSRegression
from sklearn.decomposition import PCA
from sklearn.linear_model import Ridge

from ..integration.common import REGIONS, VIEWS, extension_root, load_integration_inputs
from .run_integration_tests import mouse_grouped_folds, treatment_score_test


N_COMPONENTS = 5
N_PREDICTABILITY_SHUFFLES = 200


def _concatenate_blocks(blocks: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Keep feature names unique when combining views with numeric IDs."""
    return pd.concat([blocks[view].add_prefix(f"{view}:") for view in VIEWS], axis=1)


def _fit_pca_representation(train: pd.DataFrame, test: pd.DataFrame, n_components: int = N_COMPONENTS) -> tuple[np.ndarray, np.ndarray]:
    center = train.mean(axis=0)
    scale = train.std(axis=0, ddof=1).replace(0, np.nan)
    if scale.isna().any():
        raise ValueError("PCA benchmark encountered a constant feature.")
    train_scaled = (train - center) / scale
    test_scaled = (test - center) / scale
    model = PCA(n_components=min(n_components, train_scaled.shape[0] - 1, train_scaled.shape[1]))
    return model.fit_transform(train_scaled), model.transform(test_scaled)


def _nearest_centroid_accuracy(train_scores: np.ndarray, train_labels: pd.Series, test_scores: np.ndarray, test_labels: pd.Series) -> float:
    labels = list(pd.unique(train_labels))
    centroids = np.vstack([train_scores[train_labels.to_numpy() == label].mean(axis=0) for label in labels])
    predicted = np.asarray([
        labels[int(np.argmin(((score[None, :] - centroids) ** 2).sum(axis=1)))]
        for score in test_scores
    ])
    return float(np.mean(predicted == test_labels.to_numpy()))


def _block_spls_scores(train_blocks: dict[str, pd.DataFrame], test_blocks: dict[str, pd.DataFrame], train_labels: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    """Use equal-weight per-view PLS scores as the Python block.spls analogue."""
    responses = pd.get_dummies(train_labels, dtype=float).to_numpy()
    train_scores: list[np.ndarray] = []
    test_scores: list[np.ndarray] = []
    for view in VIEWS:
        train = train_blocks[view]
        test = test_blocks[view]
        center = train.mean(axis=0)
        scale = train.std(axis=0, ddof=1).replace(0, np.nan)
        if scale.isna().any():
            raise ValueError(f"Block.spls benchmark encountered a constant {view} feature.")
        train_scaled = (train - center) / scale
        test_scaled = (test - center) / scale
        model = PLSRegression(n_components=2, scale=False)
        model.fit(train_scaled.to_numpy(dtype=float), responses)
        train_score = model.transform(train_scaled.to_numpy(dtype=float))
        test_score = model.transform(test_scaled.to_numpy(dtype=float))
        train_scores.append(train_score)
        test_scores.append(test_score)
    train_joint = np.concatenate([(score - score.mean(axis=0)) / score.std(axis=0, ddof=1) for score in train_scores], axis=1)
    test_joint = np.concatenate([(score - train_score.mean(axis=0)) / train_score.std(axis=0, ddof=1) for score, train_score in zip(test_scores, train_scores)], axis=1)
    return train_joint, test_joint


def _leave_one_cage_out_folds(metadata: pd.DataFrame) -> list[tuple[np.ndarray, np.ndarray]]:
    cages = metadata["Cage"].to_numpy()
    return [
        (np.flatnonzero(cages != cage), np.flatnonzero(cages == cage))
        for cage in pd.unique(cages)
    ]


def _fold_representations(
    values: pd.DataFrame,
    folds: list[tuple[np.ndarray, np.ndarray]],
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Fit PCA separately inside each fold and return train/test scores."""
    return [
        _fit_pca_representation(values.iloc[train], values.iloc[test])
        for train, test in folds
    ]


def _pooled_oof_r2(
    source_scores: list[tuple[np.ndarray, np.ndarray]],
    target_scores: list[tuple[np.ndarray, np.ndarray]],
) -> float:
    predictions: list[np.ndarray] = []
    actuals: list[np.ndarray] = []
    for (source_train, source_test), (target_train, target_test) in zip(source_scores, target_scores):
        model = Ridge(alpha=1.0).fit(source_train, target_train)
        predictions.append(model.predict(source_test))
        actuals.append(target_test)
    predicted = np.concatenate(predictions, axis=0)
    actual = np.concatenate(actuals, axis=0)
    denominator = np.square(actual - actual.mean(axis=0)).sum()
    return float(1 - np.square(actual - predicted).sum() / denominator) if denominator else 0.0


def _benchmark_region_recovery(
    blocks: dict[str, pd.DataFrame], metadata: pd.DataFrame, project_root: Path
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    folds = mouse_grouped_folds(metadata, n_splits=5, n_repeats=10)
    concatenated = _concatenate_blocks(blocks)
    for method in ("concatenated_pca", "block_spls"):
        accuracies = []
        for train_index, test_index in folds:
            train_labels = metadata.iloc[train_index]["Sample type"]
            test_labels = metadata.iloc[test_index]["Sample type"]
            train_blocks = {view: blocks[view].iloc[train_index] for view in VIEWS}
            test_blocks = {view: blocks[view].iloc[test_index] for view in VIEWS}
            if method == "concatenated_pca":
                train_scores, test_scores = _fit_pca_representation(concatenated.iloc[train_index], concatenated.iloc[test_index])
            else:
                train_scores, test_scores = _block_spls_scores(train_blocks, test_blocks, train_labels)
            accuracies.append(_nearest_centroid_accuracy(train_scores, train_labels, test_scores, test_labels))
        rows.append({
            "method": method,
            "metric": "grouped_cv_region_accuracy",
            "mean": float(np.mean(accuracies)),
            "sd": float(np.std(accuracies, ddof=1)),
            "n_folds": len(accuracies),
            "grouping": "mouse",
        })
    existing_mofa = extension_root(project_root) / "01_mofa_within_region" / "scores.csv"
    if existing_mofa.exists():
        rows.append({
            "method": "mofa_within_region",
            "metric": "descriptive_only",
            "mean": np.nan,
            "sd": np.nan,
            "n_folds": 0,
            "grouping": "not refit in benchmark; see WP1 stability outputs",
        })
    return pd.DataFrame(rows)


def _predictability(blocks: dict[str, pd.DataFrame], metadata: pd.DataFrame, *, n_shuffles: int) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    rng = np.random.default_rng(20_261_501)
    for region in REGIONS:
        region_mask = metadata["Sample type"].eq(region).to_numpy()
        region_metadata = metadata.loc[region_mask].reset_index(drop=True)
        region_blocks = {view: blocks[view].loc[region_mask].reset_index(drop=True) for view in VIEWS}
        folds = _leave_one_cage_out_folds(region_metadata)
        source_representations = {
            view: _fold_representations(region_blocks[view], folds)
            for view in VIEWS
        }
        for target in VIEWS:
            target_representations = source_representations[target]
            observed_by_source = {
                source: _pooled_oof_r2(source_representations[source], target_representations)
                for source in VIEWS
                if source != target
            }
            null_by_source = {source: [] for source in observed_by_source}
            for _ in range(n_shuffles):
                permutation = rng.permutation(len(region_metadata))
                shuffled_target = region_blocks[target].iloc[permutation].reset_index(drop=True)
                shuffled_target_representations = _fold_representations(shuffled_target, folds)
                for source in observed_by_source:
                    null_by_source[source].append(
                        _pooled_oof_r2(source_representations[source], shuffled_target_representations)
                    )
            for source, observed_oof_r2 in observed_by_source.items():
                null_scores = np.asarray(null_by_source[source], dtype=float)
                rows.append({
                    "Region": region,
                    "source_view": source,
                    "target_view": target,
                    "observed_oof_r2": observed_oof_r2,
                    "null_mean_oof_r2": float(null_scores.mean()),
                    "null_sd_oof_r2": float(null_scores.std(ddof=1)),
                    "pairing_shuffle_p": float((1 + np.count_nonzero(null_scores >= observed_oof_r2)) / (n_shuffles + 1)),
                    "n_shuffles": n_shuffles,
                    "n_folds": len(folds),
                })
    return pd.DataFrame(rows)


def run_benchmark(project_root: Path, *, n_predictability_shuffles: int = N_PREDICTABILITY_SHUFFLES, n_mouse_permutations: int = 999) -> Path:
    blocks, metadata = load_integration_inputs(project_root)
    output_root = extension_root(project_root) / "05_benchmark"
    output_root.mkdir(parents=True, exist_ok=True)
    _benchmark_region_recovery(blocks, metadata, project_root).to_csv(output_root / "region_recovery.csv", index=False)
    _predictability(blocks, metadata, n_shuffles=n_predictability_shuffles).to_csv(output_root / "within_region_predictability.csv", index=False)
    concatenated = _concatenate_blocks(blocks)
    full_scores, _ = _fit_pca_representation(concatenated, concatenated)
    pca_scores = pd.DataFrame(full_scores[:, :2], columns=["Component1", "Component2"])
    pca_scores.insert(0, "Sample", metadata["Sample"].to_numpy())
    pca_scores.to_csv(output_root / "pca_scores.csv", index=False)
    treatment = treatment_score_test(metadata, pca_scores["Component1"], score_name="PCA:Component1", n_mouse_permutations=n_mouse_permutations)
    pd.DataFrame([treatment]).to_csv(output_root / "whole_cage_mia_negative_control.csv", index=False)
    (output_root / "manifest.json").write_text(json.dumps({
        "analysis": "methods benchmark and within-region cross-omics predictability",
        "methods": ["MOFA", "MFA", "block.spls", "concatenated-block PCA"],
        "implemented_here": ["concatenated-block PCA", "Python block.spls analogue", "ridge PC predictability"],
        "diablo": "deferred by user because the R issue remains unresolved",
        "spike_in": "omitted by confirmed D7 decision",
        "region_recovery_grouping": "mouse-grouped repeated five-fold CV",
        "predictability_grouping": "leave-one-Cage-out; Cage is the litter proxy",
        "predictability_statistic": "pooled out-of-fold R2; PCA and ridge are refit inside every held-out-cage fold",
        "pairing_shuffle_nulls": n_predictability_shuffles,
        "whole_cage_mia_permutations": n_mouse_permutations,
    }, indent=2), encoding="utf-8")
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--predictability-shuffles", type=int, default=N_PREDICTABILITY_SHUFFLES)
    parser.add_argument("--mouse-permutations", type=int, default=999)
    args = parser.parse_args()
    run_benchmark(args.project_root, n_predictability_shuffles=args.predictability_shuffles, n_mouse_permutations=args.mouse_permutations)
