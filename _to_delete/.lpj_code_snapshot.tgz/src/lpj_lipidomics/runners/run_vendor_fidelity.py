"""Render vendor-matched regional heatmaps and PLS-DA score plots."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Patch
from scipy.cluster.hierarchy import dendrogram, leaves_list, linkage
from scipy.stats import f

from ..multivariate.plsda import fit_plsda, permutation_test_plsda
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..plotting import apply_plot_style, save_figure
from ..preprocessing import preprocess_for_differential, preprocess_for_multivariate
from ..statistics.differential import fit_regionwise_differential
from ..multivariate.vendor import (
    select_top_n_by_nominal_p,
    vendor_column_order,
)


RANDOM_SEED = 20_260_721
N_PLSDA_PERMUTATIONS = 1_000
VENDOR_EXCLUDED_SAMPLE = "MB2_088-26"
REGIONS = ("Cerebellum", "Cortex", "Hippocampus")
VENDOR_COLORS = {"Saline Control": "#91c96b", "MIA": "#176b32"}
VENDOR_SIGN_FLIP = {"Cortex": (-1, -1), "Cerebellum": (-1, -1), "Hippocampus": (1, -1)}


def vendor_matched_metadata(sample_sheet: pd.DataFrame, sample_columns: list[str]) -> pd.DataFrame:
    """Align metadata and apply only the vendor's Cerebellum sample-26 omission."""
    columns = ["Sample number", "Sample type", "Mouse number", "Bio group", "Sex"]
    metadata = sample_sheet.loc[:, columns].copy()
    metadata["Sample number"] = pd.to_numeric(metadata["Sample number"], errors="raise").astype(int)
    metadata["Sample"] = metadata["Sample number"].map(lambda number: f"MB2_088-{number:02d}")
    metadata = metadata.set_index("Sample").loc[sample_columns].reset_index()
    return metadata.loc[metadata["Sample"].ne(VENDOR_EXCLUDED_SAMPLE)].copy()


def f_data_ellipse(scores: pd.DataFrame, *, level: float = 0.95, n_points: int = 100) -> np.ndarray:
    """Return a Hotelling/F data ellipse, not a confidence ellipse for a mean."""
    if len(scores) < 3:
        raise ValueError("A data ellipse requires at least three observations.")
    covariance = np.cov(scores.iloc[:, :2].to_numpy(dtype=float), rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    if np.any(eigenvalues <= 0):
        raise ValueError("Data ellipse requires non-singular score covariance.")
    radius = np.sqrt(2 * (len(scores) - 1) / (len(scores) - 2) * f.ppf(level, 2, len(scores) - 2))
    angles = np.linspace(0, 2 * np.pi, n_points)
    circle = np.column_stack((np.cos(angles), np.sin(angles)))
    return circle @ (eigenvectors * (np.sqrt(eigenvalues) * radius)).T + scores.iloc[:, :2].mean(axis=0).to_numpy()


def _plot_heatmap_vendor_style(values: pd.DataFrame, metadata: pd.DataFrame, annotations: pd.DataFrame, region: str) -> plt.Figure:
    row_linkage = linkage(values.to_numpy(dtype=float), method="ward", metric="euclidean")
    ordered_rows = values.iloc[leaves_list(row_linkage)]
    ordered_columns = vendor_column_order(metadata)
    ordered = ordered_rows.loc[:, ordered_columns]
    ordered_metadata = metadata.set_index("Sample").loc[ordered.columns]

    fig = plt.figure(figsize=(13, 10))
    grid = fig.add_gridspec(3, 3, width_ratios=(1.1, 8, 1.1), height_ratios=(0.25, 1, 8))
    strip_axis = fig.add_subplot(grid[0, 1])
    dendrogram_axis = fig.add_subplot(grid[2, 0])
    matrix_axis = fig.add_subplot(grid[2, 1])
    key_axis = fig.add_subplot(grid[1:, 2])
    strip = np.asarray([
        plt.matplotlib.colors.to_rgba(VENDOR_COLORS[group])
        for group in ordered_metadata["Bio group"]
    ])[None, :, :]
    strip_axis.imshow(strip, aspect="auto")
    strip_axis.set_axis_off()
    dendrogram(row_linkage, ax=dendrogram_axis, orientation="left", no_labels=True, color_threshold=0, above_threshold_color="#555555")
    dendrogram_axis.set_axis_off()
    image = matrix_axis.imshow(ordered.to_numpy(), cmap="RdBu_r", vmin=-3, vmax=3, aspect="auto")
    labels = annotations.reindex(ordered.index)["Lipid Name"].fillna(pd.Series(ordered.index.astype(str), index=ordered.index))
    matrix_axis.set_yticks(np.arange(len(ordered)), labels, fontsize=6)
    matrix_axis.yaxis.tick_right()
    matrix_axis.set_xticks(np.arange(len(ordered.columns)), ordered_metadata["Sample number"].astype(str), fontsize=7)
    matrix_axis.set_xlabel("Sample number")
    matrix_axis.set_title(f"Vendor-matched inputs: {region} heatmap")
    matrix_axis.grid(False)
    colorbar = fig.colorbar(image, ax=key_axis, fraction=0.6, pad=0.02)
    colorbar.set_label("Row z-score")
    key_axis.set_axis_off()
    fig.legend(
        handles=[Patch(facecolor=VENDOR_COLORS[group], label=label) for group, label in (("Saline Control", "1- Saline Control"), ("MIA", "2- MIA"))],
        loc="center right", bbox_to_anchor=(0.99, 0.88), frameon=False,
    )
    fig.tight_layout()
    return fig


def _plot_plsda_vendor_style(scores: pd.DataFrame, metadata: pd.DataFrame, variance: np.ndarray, p_value: float, region: str) -> plt.Figure:
    joined = scores.join(metadata.set_index("Sample")[["Bio group", "Sample number"]])
    # PLS component signs are arbitrary; this explicit mapping matches each vendor panel.
    x_sign, y_sign = VENDOR_SIGN_FLIP[region]
    joined["PLS 1"] *= x_sign
    joined["PLS 2"] *= y_sign
    fig, axis = plt.subplots(figsize=(7.2, 5.8))
    for group, label in (("Saline Control", "1- Saline Control"), ("MIA", "2- MIA")):
        subset = joined.loc[joined["Bio group"].eq(group)]
        ellipse = f_data_ellipse(subset[["PLS 1", "PLS 2"]])
        axis.fill(ellipse[:, 0], ellipse[:, 1], color=VENDOR_COLORS[group], alpha=0.2, zorder=1)
        axis.scatter(subset["PLS 1"], subset["PLS 2"], facecolors="none", edgecolors=VENDOR_COLORS[group], s=65, linewidth=1.2, label=label, zorder=2)
        for _, row in subset.iterrows():
            axis.annotate(str(row["Sample number"]), (row["PLS 1"], row["PLS 2"]), xytext=(4, 0), textcoords="offset points", va="center", fontsize=8)
    components = np.diff(np.r_[0, variance])
    axis.set(title="Scores Plot", xlabel=f"Component 1 ( {components[0] * 100:.0f} % )", ylabel=f"Component 2 ( {components[1] * 100:.0f} % )")
    axis.grid(True, linestyle=":", color="#CCCCCC")
    for spine in axis.spines.values():
        spine.set_visible(True)
    axis.legend(loc="upper right", frameon=True)
    fig.text(0.5, 0.01, f"Vendor-matched inputs. Full-panel exploratory PLS-DA; within-sex permutation p={p_value:.3f} ({N_PLSDA_PERMUTATIONS} permutations). Filled shapes are 95% F data ellipses, not confidence intervals for group means.", ha="center", fontsize=8, wrap=True)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    return fig


def run_vendor_fidelity(project_root: Path) -> None:
    """Write all three regional fidelity pairs without changing primary analysis outputs."""
    apply_plot_style()
    sample_sheet, lipidomics = read_lipidomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    samples, blanks, _ = lipidomics_measurement_columns(lipidomics)
    metadata = vendor_matched_metadata(sample_sheet, samples)
    raw = lipidomics.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    blank_values = lipidomics.loc[:, blanks].apply(pd.to_numeric, errors="coerce")
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    differential = fit_regionwise_differential(preprocess_for_differential(raw.loc[:, metadata["Sample"]], blank_values), metadata, annotations=annotations)
    multivariate = preprocess_for_multivariate(raw.loc[:, metadata["Sample"]], blank_values)
    output_dir = project_root / "results" / "mia_vs_control" / "05_figure_reproduction" / "vendor_matched"
    diagnostics: list[dict[str, object]] = []
    column_orders: list[dict[str, object]] = []
    for region in REGIONS:
        regional_metadata = metadata.loc[metadata["Sample type"].eq(region)]
        complete = multivariate.loc[:, regional_metadata["Sample"]].dropna(axis=0, how="any")
        top_features = select_top_n_by_nominal_p(differential.effects, region=region, eligible_features=complete.index)
        for position, sample in enumerate(vendor_column_order(regional_metadata), start=1):
            row = regional_metadata.set_index("Sample").loc[sample]
            column_orders.append({
                "Region": region,
                "column_position": position,
                "Sample": sample,
                "Sample number": row["Sample number"],
                "Bio group": row["Bio group"],
                "Sex": row["Sex"],
            })
        heatmap = _plot_heatmap_vendor_style(complete.loc[top_features], regional_metadata, annotations, region)
        save_figure(heatmap, output_dir / f"heatmap_{region.lower()}")
        plt.close(heatmap)
        labels = regional_metadata.set_index("Sample")["Bio group"]
        sexes = regional_metadata.set_index("Sample")["Sex"]
        scores, variance = fit_plsda(complete, labels)
        permutation, _ = permutation_test_plsda(complete, labels, sexes, n_permutations=N_PLSDA_PERMUTATIONS, random_state=RANDOM_SEED)
        plot = _plot_plsda_vendor_style(scores, regional_metadata, variance, float(permutation["permutation_p_value"]), region)
        save_figure(plot, output_dir / f"plsda_{region.lower()}")
        plt.close(plot)
        diagnostics.append({"Region": region, "n_samples": len(regional_metadata), "n_features": len(complete), **permutation.to_dict()})
    pd.DataFrame(diagnostics).to_csv(output_dir / "plsda_permutation_diagnostics.csv", index=False)
    pd.DataFrame(column_orders).to_csv(output_dir / "heatmap_column_order.csv", index=False)


if __name__ == "__main__":
    run_vendor_fidelity(Path(__file__).resolve().parents[3])
