"""Run the calibrated, seed-averaged Isolation Forest QC analysis."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from ..outliers.calibration import calibrate_isolation_forest, score_to_percentile
from ..outliers.detectors import isolation_forest_seed_scores
from ..multivariate.pca import fit_pca
from ..plotting import apply_plot_style, save_figure
from .common import metadata_and_values


PCA_COMPONENTS = (3, 5, 10)
SEEDS = tuple(range(20_260_826, 20_260_876))
N_ESTIMATORS = 500
N_NULL_REPLICATES = 2_000


def _plot_isolation_forest_heatmap(
    scores: pd.DataFrame,
    output_dir: Path,
    scope: str,
) -> None:
    """Plot binary IF flags with one labelled column per PC representation."""
    apply_plot_style()
    heatmap = scores.loc[scores["scope"].eq(scope)].pivot(
        index="Sample", columns="representation", values="flag_95"
    ).reindex(columns=[f"pc{q}" for q in PCA_COMPONENTS])
    fig, axis = plt.subplots(figsize=(5, max(4, len(heatmap) * 0.25)))
    axis.imshow(
        heatmap.to_numpy(dtype=float),
        aspect="auto",
        cmap=ListedColormap(["#F2F2F2", "#222222"]),
        vmin=0,
        vmax=1,
    )
    axis.set(
        yticks=np.arange(len(heatmap)),
        yticklabels=heatmap.index,
        xticks=np.arange(len(heatmap.columns)),
        xticklabels=["PC3", "PC5", "PC10"],
        xlabel="PCA representation",
        ylabel="Sample",
        title=f"Isolation Forest flags: {scope}",
    )
    axis.legend(
        handles=[
            Patch(facecolor="#222222", label="Flagged at calibrated 95% limit"),
            Patch(facecolor="#F2F2F2", edgecolor="#888888", label="Not flagged"),
        ],
        loc="upper left",
        bbox_to_anchor=(1.01, 1),
        title="Calibrated result",
    )
    save_figure(fig, output_dir / "figures" / f"stability_heatmap_{scope}")
    plt.close(fig)


def run_isolation_forest(
    project_root: Path,
    *,
    n_null_replicates: int = N_NULL_REPLICATES,
    n_estimators: int = N_ESTIMATORS,
) -> list[Path]:
    """Generate IF evidence without changing sample exclusions or conclusions."""
    analysis_complete = n_null_replicates == N_NULL_REPLICATES and n_estimators == N_ESTIMATORS
    metadata, all_values = metadata_and_values(project_root)
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc" / "ensemble" / "detector_sweeps" / "isolation_forest"
    scopes = {"pooled": metadata["Sample"].tolist()}
    scopes.update({str(region).lower(): group["Sample"].tolist() for region, group in metadata.groupby("Sample type", observed=True, sort=False)})
    score_rows: list[pd.DataFrame] = []
    limit_rows: list[dict[str, object]] = []
    rank_rows: list[pd.DataFrame] = []

    for scope, samples in scopes.items():
        complete = all_values.loc[:, samples].dropna(axis=0, how="any")
        model, scores, _ = fit_pca(complete, n_components=max(PCA_COMPONENTS))
        for q in PCA_COMPONENTS:
            representation = scores.iloc[:, :q]
            seed_scores = isolation_forest_seed_scores(
                representation,
                seeds=SEEDS,
                n_estimators=n_estimators,
                n_jobs=-1,
            )
            observed = seed_scores.mean(axis=1).rename("isolation_forest")
            limits, null_scores, false_positive_rate = calibrate_isolation_forest(
                representation,
                seeds=list(SEEDS),
                n_estimators=n_estimators,
                n_replicates=n_null_replicates,
                n_jobs=-1,
            )
            percentile = score_to_percentile(observed, null_scores)
            score_rows.append(pd.DataFrame({
                "Sample": observed.index,
                "score": observed.to_numpy(),
                "null_percentile": percentile.to_numpy(),
                "flag_95": observed.gt(limits["limit_95"]).to_numpy(),
                "flag_99": observed.gt(limits["limit_99"]).to_numpy(),
                "detector": "isolation_forest",
                "parameter_name": "seeds",
                "parameter_value": str(len(SEEDS)),
                "representation": f"pc{q}",
                "scope": scope,
                "n_estimators": n_estimators,
                "analysis_complete": analysis_complete,
            }))
            limit_rows.append({
                "scope": scope,
                "detector": "isolation_forest",
                "parameter_name": "seeds",
                "parameter_value": len(SEEDS),
                "representation": f"pc{q}",
                "n_estimators": n_estimators,
                "n_null_replicates": n_null_replicates,
                "limit_95": limits["limit_95"],
                "limit_99": limits["limit_99"],
                "false_positive_rate": false_positive_rate,
            })
            rank_table = seed_scores.rank(axis=0, ascending=False, method="min")
            rank_rows.append(pd.DataFrame({
                "Sample": rank_table.index,
                "rank_best": rank_table.min(axis=1),
                "rank_worst": rank_table.max(axis=1),
                "scope": scope,
                "representation": f"pc{q}",
            }))

    score_table = pd.concat(score_rows, ignore_index=True)
    paths = {
        "scores": output_dir / "detector_scores_long.csv",
        "limits": output_dir / "null_limits.csv",
        "ranks": output_dir / "rank_ranges.csv",
        "metadata": output_dir / "run_metadata.csv",
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    score_table.to_csv(paths["scores"], index=False)
    pd.DataFrame(limit_rows).to_csv(paths["limits"], index=False)
    pd.concat(rank_rows, ignore_index=True).to_csv(paths["ranks"], index=False)
    pd.DataFrame({
        "detector": ["Isolation Forest"],
        "seed_count": [len(SEEDS)],
        "n_estimators": [n_estimators],
        "n_null_replicates": [n_null_replicates],
        "analysis_complete": [analysis_complete],
        "candidate_verdict_available": [False],
    }).to_csv(paths["metadata"], index=False)
    for scope in scopes:
        _plot_isolation_forest_heatmap(score_table, output_dir, scope)
    return list(paths.values())


if __name__ == "__main__":
    run_isolation_forest(Path(__file__).resolve().parents[3])
