"""Create descriptive PCA loading-composition figures from full loading matrices."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import pandas as pd

from ..multivariate.loadings import align_loading_signs, class_composition, cumulative_share_curve
from ..plotting import COLORBLIND_COLORS, apply_plot_style, save_figure


def _class_bar(composition: pd.DataFrame, scope: str, output_dir: Path) -> None:
    components = composition["Component"].drop_duplicates().tolist()[:4]
    figure, axis = plt.subplots(figsize=(8, 5))
    bottom = pd.Series(0.0, index=components)
    for number, lipid_class in enumerate(composition["Lipid Class"].drop_duplicates()):
        shares = composition.loc[composition["Lipid Class"].eq(lipid_class)].set_index("Component")["squared_loading_share"].reindex(components, fill_value=0)
        axis.bar(components, shares * 100, bottom=bottom * 100, label=lipid_class, color=COLORBLIND_COLORS[number % len(COLORBLIND_COLORS)])
        bottom += shares
    axis.set(ylabel="Share of component variance (%)", ylim=(0, 100), title=f"PCA loading composition: {scope}")
    axis.legend(title="Lipid class", bbox_to_anchor=(1.02, 1), loc="upper left")
    figure.tight_layout()
    save_figure(figure, output_dir / f"loadings_class_stacked_{scope}")
    plt.close(figure)


def _cumulative_curve(curve: pd.DataFrame, scope: str, output_dir: Path) -> None:
    figure, axis = plt.subplots(figsize=(7.5, 5))
    for number, (component, rows) in enumerate(curve.groupby("Component", sort=False)):
        if number == 4:
            break
        axis.plot(rows["n_features"], rows["cumulative_squared_loading_share"] * 100, label=component, color=COLORBLIND_COLORS[number])
    reference = curve.loc[curve["Component"].eq(curve["Component"].iloc[0])]
    axis.plot(reference["n_features"], reference["uniform_share"] * 100, color="#777777", linestyle="--", label="Uniform")
    axis.set(xscale="log", xlabel="Number of strongest features", ylabel="Cumulative component variance (%)", ylim=(0, 100), title=f"PCA loading concentration: {scope}")
    axis.legend(frameon=True)
    figure.tight_layout()
    save_figure(figure, output_dir / f"loadings_cumulative_share_{scope}")
    plt.close(figure)


def _feature_bar(
    loadings: pd.DataFrame,
    scope: str,
    output_dir: Path,
    *,
    n_features: int = 10,
    output_stem: str = "loadings_feature_stacked",
) -> None:
    if n_features < 1:
        raise ValueError("n_features must be at least one.")
    if n_features > len(loadings):
        raise ValueError(f"n_features cannot exceed the number of loadings ({len(loadings)}).")
    components = loadings.columns[:4]
    figure, axis = plt.subplots(figsize=(8, 5))
    bottom = pd.Series(0.0, index=components)
    for number in range(n_features):
        shares = []
        for component in components:
            squared = loadings[component].pow(2).sort_values(ascending=False, kind="stable")
            shares.append(squared.iloc[number] / squared.sum())
        values = pd.Series(shares, index=components)
        axis.bar(components, values * 100, bottom=bottom * 100, color=COLORBLIND_COLORS[number % len(COLORBLIND_COLORS)], label=f"Top {n_features} individual features" if number == 0 else None)
        bottom += values
    axis.bar(components, (1 - bottom) * 100, bottom=bottom * 100, color="#BBBBBB", label="All other features")
    axis.set(ylabel="Share of component variance (%)", ylim=(0, 100), title=f"Top-{n_features} loading contribution: {scope}")
    axis.legend(frameon=True)
    figure.tight_layout()
    save_figure(figure, output_dir / f"{output_stem}_{scope}")
    plt.close(figure)


def _global_feature_bar(
    loadings: pd.DataFrame,
    lipid_names: pd.Series,
    scope: str,
    output_dir: Path,
    *,
    n_features: int = 20,
) -> None:
    """Plot one shared feature set ranked by squared loading across PC1-PC4."""
    if n_features < 1:
        raise ValueError("n_features must be at least one.")
    components = loadings.columns[:4]
    squared = loadings.loc[:, components].pow(2)
    ranking = squared.sum(axis=1).sort_values(ascending=False, kind="stable")
    selected = ranking.iloc[:n_features].index
    names = lipid_names.reindex(selected).astype("string").str.strip()
    fallback = pd.Series(
        [f"Feature {feature}" for feature in selected],
        index=selected,
        dtype="string",
    )
    names = names.where(names.notna() & names.ne(""), fallback).astype(str)
    colors = [plt.get_cmap("tab20", n_features)(number) for number in range(n_features)]

    figure, axis = plt.subplots(figsize=(10, 6))
    bottom = pd.Series(0.0, index=components)
    for feature, color in zip(selected, colors):
        values = squared.loc[feature, components] / squared.loc[:, components].sum()
        axis.bar(components, values * 100, bottom=bottom * 100, color=color)
        bottom += values
    axis.bar(components, (1 - bottom) * 100, bottom=bottom * 100, color="#BBBBBB")
    handles = [
        Patch(facecolor=color, edgecolor="none", label=name)
        for color, name in zip(colors, names)
    ]
    handles.append(Patch(facecolor="#BBBBBB", edgecolor="none", label="All other features"))
    axis.set(
        ylabel="Share of component variance (%)",
        ylim=(0, 100),
        title=f"Global top-{n_features} loading contribution: {scope}",
    )
    axis.legend(
        handles=handles,
        title="Lipid feature",
        bbox_to_anchor=(1.02, 1),
        loc="upper left",
        ncol=2,
        fontsize=8,
    )
    figure.text(
        0.5,
        0.01,
        f"Features ranked by summed squared loading across {', '.join(components)}.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 0.72, 1))
    save_figure(figure, output_dir / f"loadings_feature_stacked_top{n_features}_{scope}")
    plt.close(figure)


def run_loading_composition(project_root: Path) -> None:
    """Summarise all persisted PCA loading matrices using squared loadings."""
    apply_plot_style()
    multivariate = project_root / "results" / "mia_vs_control" / "04_multivariate"
    figure_dir = multivariate / "figures" / "pca"
    all_composition = []
    for path in sorted(multivariate.glob("pca_loadings_full_*.csv")):
        scope = path.stem.removeprefix("pca_loadings_full_")
        table = pd.read_csv(path)
        loadings = table.filter(regex=r"^PC ").set_axis(table["Feature"], axis=0)
        aligned = align_loading_signs(loadings)
        composition = class_composition(aligned, table.set_index("Feature")["Lipid Class"])
        composition.insert(0, "scope", scope)
        all_composition.append(composition)
        _class_bar(composition, scope, figure_dir)
        _cumulative_curve(cumulative_share_curve(aligned), scope, figure_dir)
        _feature_bar(aligned, scope, figure_dir)
        _global_feature_bar(
            aligned,
            table.set_index("Feature")["Lipid Name"],
            scope,
            figure_dir,
        )
    pd.concat(all_composition, ignore_index=True).to_csv(multivariate / "pca_class_composition.csv", index=False)


if __name__ == "__main__":
    run_loading_composition(Path(__file__).resolve().parents[3])
