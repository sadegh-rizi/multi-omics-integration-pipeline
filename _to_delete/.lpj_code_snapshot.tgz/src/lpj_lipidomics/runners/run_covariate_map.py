"""Map exploratory integration axes against design and technical covariates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ..integration.common import REGIONS, VIEWS, extension_root, load_integration_inputs, r_squared, zscore_columns
from ..runners.run_integration_tests import treatment_score_test


OLIGODENDROCYTE_GENES = ("Mbp", "Plp1", "Mag", "Mog", "Cnp", "Mobp", "Ugt8")


def _oligodendrocyte_score(project_root: Path, protein_values: pd.DataFrame, metadata: pd.DataFrame) -> tuple[pd.Series, list[str]]:
    annotation_path = project_root / "results" / "mia_vs_control" / "14_integration" / "prevalence20_noexclusion" / "00_inputs" / "proteomics_feature_annotation.csv"
    annotations = pd.read_csv(annotation_path).set_index("Protein ID")
    gene_to_features: dict[str, list[str]] = {}
    for gene in OLIGODENDROCYTE_GENES:
        selected = annotations.index[annotations["Gene"].fillna("").astype(str).str.casefold().eq(gene.casefold())]
        gene_to_features[gene] = [feature for feature in selected if feature in protein_values.columns]
    detected_genes = [gene for gene, features in gene_to_features.items() if features]
    if not detected_genes:
        return pd.Series(np.nan, index=metadata["Sample"], name="oligodendrocyte_score"), []
    gene_scores = []
    for gene in detected_genes:
        gene_values = protein_values.loc[:, gene_to_features[gene]].mean(axis=1)
        gene_scores.append(
            gene_values.groupby(metadata["Sample type"].to_numpy(), sort=False).transform(
                lambda values: (values - values.mean()) / values.std(ddof=1)
            )
        )
    score = pd.concat(gene_scores, axis=1).mean(axis=1)
    score.index = metadata["Sample"]
    score.name = "oligodendrocyte_score"
    return score, detected_genes


def _module_scores(project_root: Path, blocks: dict[str, pd.DataFrame], metadata: pd.DataFrame) -> pd.DataFrame:
    screen_root = extension_root(project_root) / "02_cross_omics_screen"
    modules_path = screen_root / "modules.csv"
    summaries = pd.read_csv(screen_root / "lipid_summary_values.csv").set_index("Sample")
    modules = pd.read_csv(modules_path)
    if "finding_candidate" in modules:
        modules = modules.loc[modules["finding_candidate"].astype(bool)]
    rows: list[pd.Series] = []
    for _, module in modules.iterrows():
        lipid_features = [feature for feature in str(module["lipid_features"]).split(";") if feature in summaries]
        target_view = str(module["target_view"])
        target_features = [feature for feature in str(module["target_features"]).split(";") if feature in blocks[target_view]]
        if not lipid_features or not target_features:
            continue
        lipid_z = summaries.loc[:, lipid_features].groupby(metadata["Sample type"].to_numpy(), sort=False).transform(lambda frame: (frame - frame.mean()) / frame.std(ddof=1)).mean(axis=1)
        target_z = zscore_columns(blocks[target_view].loc[:, target_features]).mean(axis=1)
        combined = (lipid_z.to_numpy(dtype=float) + target_z.to_numpy(dtype=float)) / 2
        rows.append(pd.Series(
            combined,
            index=metadata["Sample"],
            name=f"Module:{module['Region']}:{target_view}:{int(module['module'])}",
        ))
    if not rows:
        return pd.DataFrame(index=metadata["Sample"])
    return pd.concat(rows, axis=1)


def run_covariate_map(project_root: Path, *, n_mouse_permutations: int = 9_999) -> Path:
    blocks, metadata = load_integration_inputs(project_root)
    root = extension_root(project_root)
    factor_scores = pd.read_csv(root / "01_mofa_within_region" / "scores.csv")
    factor_scores = factor_scores.pivot(index="Sample", columns="Score name", values="Score")
    module_scores = _module_scores(project_root, blocks, metadata)
    score_values = factor_scores.join(module_scores, how="outer")
    score_values = score_values.reindex(metadata["Sample"])
    oligodendrocyte, detected_genes = _oligodendrocyte_score(project_root, blocks["proteomics"], metadata)
    covariates = metadata.set_index("Sample").loc[score_values.index].copy()
    covariates["Date collected numeric"] = pd.to_datetime(covariates["Date collected"]).map(pd.Timestamp.toordinal)
    covariates["oligodendrocyte_score"] = oligodendrocyte.reindex(covariates.index)

    output_root = root / "04_covariate_map"
    output_root.mkdir(parents=True, exist_ok=True)
    score_values.insert(0, "Sample", score_values.index)
    score_values.to_csv(output_root / "axis_scores.csv", index=False)
    rows: list[dict[str, object]] = []
    covariate_columns = {
        "Sex": "Sex",
        "Cage": "Cage",
        "Date collected": "Date collected numeric",
        "Tissue mass (mg)": "Tissue mass (mg)",
        "Sample number": "Sample number",
        "oligodendrocyte_score": "oligodendrocyte_score",
        "MIA": "Bio group",
    }
    for score_name in score_values.columns[1:]:
        values = score_values.set_index("Sample")[score_name]
        for output_name, column in covariate_columns.items():
            predictor = covariates[column]
            rows.append({
                "Score name": score_name,
                "Covariate": output_name,
                "r_squared": r_squared(values.to_numpy(), predictor),
                "n_samples": int(values.notna().sum()),
            })
        mia = treatment_score_test(
            covariates.reset_index(),
            values.reset_index(drop=True),
            score_name=score_name,
            n_mouse_permutations=n_mouse_permutations,
        )
        rows.append({
            "Score name": score_name,
            "Covariate": "MIA cage-level test",
            **mia,
        })
    covariate_table = pd.DataFrame(rows)
    covariate_table.to_csv(output_root / "factor_covariate_associations.csv", index=False)
    (output_root / "manifest.json").write_text(json.dumps({
        "analysis": "descriptive covariate map for stable MOFA factors and cross-omics module scores",
        "covariates": list(covariate_columns),
        "mia_test": "treatment_score_test with whole-cage enumeration and mouse sensitivity",
        "n_mouse_permutations": n_mouse_permutations,
        "oligodendrocyte_genes_requested": list(OLIGODENDROCYTE_GENES),
        "oligodendrocyte_genes_detected": detected_genes,
        "oligodendrocyte_standardization": "within region before averaging marker genes",
        "litter_proxy": "Cage",
        "interpretation": "covariate associations are descriptive; MIA is not the headline target",
    }, indent=2), encoding="utf-8")
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--mouse-permutations", type=int, default=9_999)
    args = parser.parse_args()
    run_covariate_map(args.project_root, n_mouse_permutations=args.mouse_permutations)
