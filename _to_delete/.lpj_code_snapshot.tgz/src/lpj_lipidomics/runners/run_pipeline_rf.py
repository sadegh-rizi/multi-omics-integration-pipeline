"""Run one RF-imputed, IQR-filtered, scaling sensitivity configuration."""

from __future__ import annotations

import argparse
from pathlib import Path

from .run_pipeline_variant import run_pipeline_variant


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--imputation",
        choices=("rf_mar_only", "rf_all"),
        required=True,
    )
    parser.add_argument(
        "--variant",
        choices=("prevalence20_t2_95", "prevalence20_t2_99", "prevalence20_noexclusion"),
        required=True,
    )
    parser.add_argument("--scaling", choices=("standard", "pareto"), required=True)
    args = parser.parse_args()
    run_pipeline_variant(
        Path(__file__).resolve().parents[3],
        args.variant,
        output_root_name="pipeline_test_rf",
        imputation_method=args.imputation,
        scaling=args.scaling,
        apply_iqr_filter=True,
    )


if __name__ == "__main__":
    main()
