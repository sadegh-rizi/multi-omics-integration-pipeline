"""Write adopted blank-filter and report-only pooled-QC diagnostics.

Tech-Mix is treated as probable pooled study-sample QC pending vendor
confirmation. The CV filter is evaluated in both directions here but is not
adopted by this script or the primary analysis pipeline.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..config import FEATURE_BLANK_MULTIPLIER, QC_CV_MIN_INJECTIONS, QC_CV_THRESHOLD
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, analysis_metadata
from ..multivariate.plsda import fit_plsda, permutation_test_plsda
from ..plotting import COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import preprocess_for_differential, preprocess_for_multivariate
from ..qc.variance import qc_injection_cv
from ..statistics.differential import fit_regionwise_differential


RANDOM_SEED = 20_260_721
N_PLSDA_PERMUTATIONS = 1_000
P_VALUE_BINS = np.array([0.0, 0.01, 0.05, 0.1, 0.5, 1.0])


def blank_dominated_feature_table(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    annotations: pd.DataFrame,
) -> pd.DataFrame:
    """Return all features with their biological-to-blank ratio and decision."""
    numeric_intensity = intensity.apply(pd.to_numeric, errors="coerce")
    mean_blank = blank_intensity.apply(pd.to_numeric, errors="coerce").fillna(0).mean(axis=1)
    median_biological = numeric_intensity.where(numeric_intensity > 0).median(axis=1, skipna=True)
    ratio = median_biological / mean_blank.where(mean_blank.gt(0))
    removed = mean_blank.gt(0) & ratio.lt(FEATURE_BLANK_MULTIPLIER)
    table = pd.DataFrame({
        "Feature": intensity.index,
        "median_biological_signal": median_biological.to_numpy(),
        "mean_blank_signal": mean_blank.to_numpy(),
        "signal_to_blank_ratio": ratio.to_numpy(),
        "blank_dominated": removed.to_numpy(),
        "blank_multiplier": FEATURE_BLANK_MULTIPLIER,
    })
    return table.merge(annotations, left_on="Feature", right_index=True, how="left", validate="one_to_one")


def _comparison_table(
    raw: pd.DataFrame,
    blanks: pd.DataFrame,
    metadata: pd.DataFrame,
    annotations: pd.DataFrame,
    cv_table: pd.DataFrame,
) -> pd.DataFrame:
    """Compare the unfiltered and QC-CV-filtered panels without selecting one."""
    rows: list[dict[str, object]] = []
    cv_keep = cv_table.index[cv_table["normalized_cv_percent"].le(QC_CV_THRESHOLD)]
    for condition, features in (("unfiltered", raw.index), ("qc_cv_filtered", cv_keep)):
        differential = preprocess_for_differential(raw.loc[features], blanks.loc[features])
        multivariate = preprocess_for_multivariate(raw.loc[features], blanks.loc[features])
        fitted = fit_regionwise_differential(differential, metadata, annotations=annotations.loc[features])
        rows.append({"condition": condition, "scope": "all", "metric": "n_features_differential", "value": len(differential)})
        rows.append({"condition": condition, "scope": "all", "metric": "n_features_multivariate", "value": len(multivariate)})

        for region in REGIONS:
            regional_metadata = metadata.loc[metadata["Sample type"].eq(region)]
            complete = multivariate.loc[:, regional_metadata["Sample"]].dropna(axis=0, how="any")
            labels = regional_metadata.set_index("Sample")["Bio group"]
            sexes = regional_metadata.set_index("Sample")["Sex"]
            scores, _ = fit_plsda(complete, labels)
            permutation, _ = permutation_test_plsda(
                complete, labels, sexes, n_permutations=N_PLSDA_PERMUTATIONS, random_state=RANDOM_SEED
            )
            rows.append({"condition": condition, "scope": region, "metric": "plsda_permutation_p_value", "value": permutation["permutation_p_value"]})
            rows.append({"condition": condition, "scope": region, "metric": "plsda_complete_features", "value": len(complete)})
            for effect, effect_rows in fitted.effects.loc[fitted.effects["Region"].eq(region)].groupby("Effect", observed=True):
                scope = f"{region}: {effect}"
                rows.append({"condition": condition, "scope": scope, "metric": "n_fdr_significant", "value": effect_rows["p_value_fdr"].le(0.05).sum()})
                histogram, _ = np.histogram(effect_rows["p_value"].dropna(), bins=P_VALUE_BINS)
                for left, right, count in zip(P_VALUE_BINS[:-1], P_VALUE_BINS[1:], histogram, strict=True):
                    rows.append({"condition": condition, "scope": scope, "metric": f"p_value_count_[{left:g},{right:g}{']' if right == 1 else ')'}", "value": count})
    return pd.DataFrame(rows)


def run_qc_filters(project_root: Path) -> None:
    """Write QC filter tables and drift diagnostics without changing source data."""
    apply_plot_style()
    results = project_root / "results" / "mia_vs_control"
    preprocessing_dir = results / "01_preprocessing"
    qc_dir = results / "02_qc"
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, lipidomics = read_lipidomics_tables(workbook)
    sample_columns, blank_columns, techmix_columns = lipidomics_measurement_columns(lipidomics)
    metadata = analysis_metadata(sample_sheet, sample_columns)
    raw = lipidomics.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    techmix = lipidomics.loc[:, techmix_columns].apply(pd.to_numeric, errors="coerce")
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    annotations.index = lipidomics.index

    blank_table = blank_dominated_feature_table(raw, blanks, annotations)
    blank_table.loc[blank_table["blank_dominated"]].to_csv(
        preprocessing_dir / "blank_dominated_features.csv", index=False
    )

    cv_table = qc_injection_cv(techmix, min_injections=QC_CV_MIN_INJECTIONS).rename_axis("Feature").reset_index()
    cv_table = cv_table.merge(annotations, left_on="Feature", right_index=True, how="left", validate="one_to_one")
    cv_table["qc_cv_threshold_percent"] = QC_CV_THRESHOLD
    cv_table["qc_cv_filter_status"] = np.select(
        [cv_table["cv_status"].eq("cv_not_assessable"), cv_table["normalized_cv_percent"].gt(QC_CV_THRESHOLD)],
        ["cv_not_assessable", "would_remove"],
        default="would_keep",
    )
    vendor_cv = pd.to_numeric(lipidomics["%CV"], errors="coerce") * 100
    cv_table["vendor_raw_cv_percent"] = vendor_cv.to_numpy()
    cv_table["raw_cv_vendor_pearson_r"] = cv_table["raw_cv_percent"].corr(cv_table["vendor_raw_cv_percent"])
    cv_table.to_csv(qc_dir / "qc_injection_cv.csv", index=False)

    medians = techmix.where(techmix > 0).median(axis=0, skipna=True)
    drift = pd.DataFrame({"injection": techmix.columns, "injection_index": range(1, len(techmix.columns) + 1), "median_positive_signal": medians.to_numpy()})
    sample_medians = raw.where(raw > 0).median(axis=0, skipna=True)
    sample_number = metadata.set_index("Sample").loc[sample_medians.index, "Sample number"]
    drift["techmix_source"] = "probable_pooled_study_sample_qc_unconfirmed"
    drift["sample_number_median_signal_pearson_r"] = sample_number.corr(sample_medians)
    drift.to_csv(qc_dir / "qc_injection_drift.csv", index=False)

    figure, axis = plt.subplots(figsize=(6.5, 4.2))
    axis.plot(drift["injection_index"], drift["median_positive_signal"], "o-", color=COLORBLIND_COLORS[0])
    axis.set(xlabel="Tech-Mix injection index", ylabel="Median positive peak area", title="Pooled-QC injection drift (report only)")
    figure.tight_layout()
    save_figure(figure, qc_dir / "figures" / "qc_injection_drift")
    plt.close(figure)

    cv_for_comparison = cv_table.set_index("Feature")
    _comparison_table(raw, blanks, metadata, annotations, cv_for_comparison).to_csv(
        qc_dir / "qc_cv_filter_comparison.csv", index=False
    )


if __name__ == "__main__":
    run_qc_filters(Path(__file__).resolve().parents[3])
