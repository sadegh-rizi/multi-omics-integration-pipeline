"""Generate regional unsupervised PCA Hotelling T-squared diagnostics."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, full_lipidomics_metadata
from ..multivariate.pca import fit_pca, hotelling_ellipse, hotelling_t2_2d
from ..plotting import BIO_GROUP_COLORS, MARKER_CYCLE, apply_plot_style, save_figure, validate_categories
from ..preprocessing import preprocess_for_multivariate


SEX_MARKERS = {"Male": MARKER_CYCLE[0], "Female": MARKER_CYCLE[1]}


def _plot_region(
    scores: pd.DataFrame,
    metadata: pd.DataFrame,
    model_variance: np.ndarray,
    *,
    region: str,
    population: str,
    n_features: int,
) -> tuple[plt.Figure, pd.DataFrame]:
    """Draw one all-sample 2-D Hotelling diagnostic and return its evidence table."""
    plotted = scores.iloc[:, :2]
    ellipse_95, limit_95 = hotelling_ellipse(plotted, alpha=0.95)
    ellipse_99, limit_99 = hotelling_ellipse(plotted, alpha=0.99)
    t2 = hotelling_t2_2d(plotted)
    figure, axis = plt.subplots(figsize=(7.2, 6.2))
    axis.plot(ellipse_95[:, 0], ellipse_95[:, 1], color="#666666", linewidth=1.1, zorder=1, label="95% Hotelling T2")
    axis.plot(ellipse_99[:, 0], ellipse_99[:, 1], color="#666666", linewidth=1.1, linestyle="--", zorder=1, label="99% Hotelling T2")
    joined = metadata.set_index("Sample").loc[plotted.index]
    validate_categories(joined["Bio group"].unique(), BIO_GROUP_COLORS, "Bio group")
    for sex, marker in SEX_MARKERS.items():
        for group, color in BIO_GROUP_COLORS.items():
            mask = joined["Sex"].eq(sex) & joined["Bio group"].eq(group)
            if not mask.any():
                continue
            points = plotted.loc[mask]
            axis.scatter(points["PC 1"], points["PC 2"], color=color, marker=marker, edgecolor="black", linewidth=0.4, s=55, label=f"{group}, {sex}", zorder=2)
    for sample, row in joined.iterrows():
        point = plotted.loc[sample]
        axis.annotate(str(row["Sample number"]), (point["PC 1"], point["PC 2"]), xytext=(4, 3), textcoords="offset points", fontsize=8, zorder=3)
    outside = joined.loc[t2.gt(limit_95), "Sample number"].astype(str).tolist()
    outside_label = ", ".join(outside) if outside else "none"
    axis.set(
        xlabel=f"PC1 ({model_variance[0] * 100:.1f}% explained variance)",
        ylabel=f"PC2 ({model_variance[1] * 100:.1f}% explained variance)",
        title=f"PCA Hotelling T2 diagnostic: {region} ({population.replace('_', ' ')})",
    )
    axis.set_aspect("equal", adjustable="datalim")
    axis.legend(frameon=True, fontsize=8)
    figure.text(0.5, 0.01, f"n={len(joined)}, complete features={n_features}; T2 limits: 95%={limit_95:.2f}, 99%={limit_99:.2f}; outside 95%: {outside_label}.", ha="center", fontsize=8)
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    table = pd.DataFrame({
        "Region": region,
        "Sample": plotted.index,
        "PC1": plotted["PC 1"].to_numpy(),
        "PC2": plotted["PC 2"].to_numpy(),
        "hotelling_t2": t2.to_numpy(),
        "hotelling_t2_95_limit": limit_95,
        "hotelling_t2_99_limit": limit_99,
        "outside_95": t2.gt(limit_95).to_numpy(),
        "outside_99": t2.gt(limit_99).to_numpy(),
        "population": population,
        "n_features": n_features,
    }).merge(
        joined.loc[:, ["Sample number", "Bio group", "Sex"]].rename_axis("Sample").reset_index(),
        on="Sample",
        how="left",
        validate="one_to_one",
    )
    return figure, table


def run_pca_ellipse(project_root: Path) -> Path:
    """Write two-population regional PCA Hotelling T-squared diagnostics."""
    apply_plot_style()
    sample_sheet, lipidomics = read_lipidomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    sample_columns, blank_columns, _ = lipidomics_measurement_columns(lipidomics)
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    output_dir = project_root / "results" / "mia_vs_control" / "04_multivariate"
    tables: list[pd.DataFrame] = []
    population = "full_data"
    metadata = full_lipidomics_metadata(sample_sheet, sample_columns)
    raw = lipidomics.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="coerce")
    values = preprocess_for_multivariate(raw, blanks)
    for region in REGIONS:
        regional_metadata = metadata.loc[metadata["Sample type"].eq(region)]
        complete = values.loc[:, regional_metadata["Sample"]].dropna(axis=0, how="any")
        model, scores, _ = fit_pca(complete, n_components=2)
        figure, table = _plot_region(scores, regional_metadata, model.explained_variance_ratio_, region=region, population=population, n_features=len(complete))
        save_figure(figure, output_dir / "figures" / "pca" / f"hotelling_fulldata_{region.lower()}")
        plt.close(figure)
        tables.append(table)
    output_path = output_dir / "pca_hotelling_t2.csv"
    pd.concat(tables, ignore_index=True).to_csv(output_path, index=False)
    return output_path


if __name__ == "__main__":
    run_pca_ellipse(Path(__file__).resolve().parents[3])
