"""Generate outstanding QC and PCA-loading figures without changing analysis inputs."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import leaves_list, linkage
from scipy.spatial.distance import pdist
from scipy.stats import beta, f

from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, full_lipidomics_metadata, lipid_annotations
from ..outliers.screen import dmodx
from ..multivariate.pca import confidence_ellipse, fit_pca
from ..multivariate.loadings import align_loading_signs, loading_concentration, top_loadings
from ..plotting import apply_plot_style, save_figure
from ..preprocessing import preprocess_for_multivariate


OUTLIER_PCS = 3


def _pca_values(values: pd.DataFrame, samples: pd.Series) -> pd.DataFrame:
    return values.loc[:, samples].dropna(axis=0, how="any")


def _plot_outliers(values: pd.DataFrame, metadata: pd.DataFrame, output_dir: Path) -> None:
    for region in REGIONS:
        regional_metadata = metadata.loc[metadata["Sample type"].eq(region)]
        complete = _pca_values(values, regional_metadata["Sample"])
        model, scores, _ = fit_pca(complete, n_components=OUTLIER_PCS)
        centered = scores.to_numpy() - scores.to_numpy().mean(axis=0)
        t2 = np.einsum("ij,jk,ik->i", centered, np.linalg.pinv(np.cov(centered, rowvar=False)), centered)
        n_samples, n_components = scores.shape
        t2_limits = {level: (n_samples - 1) ** 2 / n_samples * beta.ppf(level, n_components / 2, (n_samples - n_components - 1) / 2) for level in (0.95, 0.99)}
        raw_dmodx = dmodx(complete, model)
        normalized_dmodx = raw_dmodx / np.sqrt(np.mean(raw_dmodx.pow(2)))
        dmodx_limit = float(np.sqrt(f.ppf(0.95, complete.shape[0] - n_components, (complete.shape[0] - n_components) * (n_samples - n_components - 1))))
        table = regional_metadata.set_index("Sample").loc[scores.index, ["Sample number"]].copy()
        table["hotelling_t2"] = t2
        table["hotelling_t2_95_limit"] = t2_limits[0.95]
        table["hotelling_t2_99_limit"] = t2_limits[0.99]
        table["normalized_dmodx"] = normalized_dmodx
        table["dmodx_95_limit"] = dmodx_limit
        scope = region.lower()
        table.to_csv(output_dir / f"outlier_diagnostics_{scope}_{OUTLIER_PCS}pc.csv", index_label="Sample")
        ordered = table.sort_values("Sample number")
        for column, limits, name, ylabel in (
            ("hotelling_t2", ((t2_limits[0.95], "95%"), (t2_limits[0.99], "99%")), "t2_range_plot", f"Hotelling T2 ({OUTLIER_PCS} PCs)"),
            ("normalized_dmodx", ((dmodx_limit, "95%"),), "dmodx_plot", "Normalised DModX (2 PCs)"),
        ):
            figure, axis = plt.subplots(figsize=(9, 4.5))
            axis.scatter(ordered["Sample number"], ordered[column], color="#0072B2")
            for _, row in ordered.iterrows():
                axis.annotate(str(int(row["Sample number"])), (row["Sample number"], row[column]), fontsize=7)
            for limit, label in limits:
                axis.axhline(limit, color="#D55E00", linestyle="--", label=label)
            axis.set(xlabel="Sample number", ylabel=ylabel, title=f"{region}: {name.replace('_', ' ').title()}")
            axis.legend(frameon=False)
            figure.tight_layout()
            save_figure(figure, output_dir / "figures" / f"{name}_{scope}")
            plt.close(figure)
        figure, axis = plt.subplots(figsize=(6.5, 5.5))
        axis.scatter(table["hotelling_t2"], table["normalized_dmodx"], color="#0072B2")
        for _, row in table.iterrows():
            axis.annotate(str(int(row["Sample number"])), (row["hotelling_t2"], row["normalized_dmodx"]), fontsize=7)
        axis.axvline(t2_limits[0.95], color="#D55E00", linestyle="--")
        axis.axhline(dmodx_limit, color="#D55E00", linestyle="--")
        axis.set(xlabel=f"Hotelling T2 ({OUTLIER_PCS} PCs)", ylabel=f"Normalised DModX ({OUTLIER_PCS} PCs)", title=f"{region}: PCA influence plot")
        figure.tight_layout()
        save_figure(figure, output_dir / "figures" / f"influence_t2_vs_dmodx_{scope}")
        plt.close(figure)


def _plot_scores(values: pd.DataFrame, metadata: pd.DataFrame, output_dir: Path) -> None:
    complete = _pca_values(values, metadata["Sample"])
    model, scores, _ = fit_pca(complete)
    joined = metadata.set_index("Sample").loc[scores.index]
    for variable in ("Sample number", "Tissue mass (mg)"):
        figure, axis = plt.subplots(figsize=(7, 5.8))
        points = axis.scatter(scores["PC 1"], scores["PC 2"], c=joined[variable], cmap="viridis", edgecolor="black", linewidth=0.35)
        ellipse = confidence_ellipse(scores["PC 1"], scores["PC 2"])
        axis.plot(ellipse[:, 0], ellipse[:, 1], color="#444444", linewidth=0.8, linestyle="--")
        figure.colorbar(points, ax=axis, label=variable)
        axis.set(xlabel=f"PC 1 ({model.explained_variance_ratio_[0] * 100:.1f}%)", ylabel=f"PC 2 ({model.explained_variance_ratio_[1] * 100:.1f}%)", title=f"Pooled PCA scores: {variable}")
        if variable == "Sample number":
            figure.text(0.5, 0.01, "Sample number is a proxy for acquisition order, not the confirmed order.", ha="center", fontsize=8)
            figure.tight_layout(rect=(0, 0.04, 1, 1))
        else:
            figure.tight_layout()
        save_figure(figure, output_dir / f"scores_pooled_{variable.lower().replace(' ', '_').replace('(', '').replace(')', '')}")
        plt.close(figure)


def _plot_loadings(
    loadings: pd.DataFrame,
    annotations: pd.DataFrame,
    technical_dominated: pd.Series,
    scope: str,
    output_dir: Path,
) -> pd.DataFrame:
    aligned = align_loading_signs(loadings)
    concentration = loading_concentration(aligned)
    names = annotations["Lipid Name"].reindex(aligned.index).fillna(aligned.index.to_series())
    for component in ("PC 1", "PC 2"):
        ranked = top_loadings(aligned.loc[:, [component]], 25).sort_values("loading")
        figure, axis = plt.subplots(figsize=(8, 7))
        axis.hlines(names.reindex(ranked["Feature"]), 0, ranked["loading"], color="#777777", linewidth=0.8)
        axis.scatter(ranked["loading"], names.reindex(ranked["Feature"]), color="#0072B2", zorder=3)
        axis.axvline(0, color="#444444", linewidth=0.8)
        axis.set(xlabel=f"{component} loading", title=f"{scope}: strongest {component} loadings")
        figure.text(0.5, 0.01, "PC signs are oriented so the largest absolute loading is positive.", ha="center", fontsize=8)
        figure.tight_layout(rect=(0, 0.04, 1, 1))
        save_figure(figure, output_dir / f"loadings_lollipop_{scope}_{component.replace(' ', '').lower()}")
        plt.close(figure)
    distance = np.hypot(aligned["PC 1"], aligned["PC 2"])
    highlighted = distance.nlargest(15, keep="all").index
    figure, axis = plt.subplots(figsize=(7, 6))
    axis.scatter(aligned["PC 1"], aligned["PC 2"], color="#999999", alpha=0.35, s=12)
    axis.scatter(aligned.loc[highlighted, "PC 1"], aligned.loc[highlighted, "PC 2"], color="#D55E00", s=18)
    for feature in highlighted:
        axis.annotate(str(names.loc[feature]), (aligned.loc[feature, "PC 1"], aligned.loc[feature, "PC 2"]), fontsize=7)
    axis.axhline(0, color="#444444", linewidth=0.8); axis.axvline(0, color="#444444", linewidth=0.8)
    axis.set(xlabel="PC 1 loading", ylabel="PC 2 loading", title=f"{scope}: PC1 versus PC2 loadings")
    figure.text(0.5, 0.01, "PC signs are oriented so the largest absolute loading is positive.", ha="center", fontsize=8)
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output_dir / f"loadings_scatter_{scope}")
    plt.close(figure)
    pcs = [f"PC {number}" for number in range(1, 5)]
    features = pd.Index([])
    for component in pcs:
        features = features.union(top_loadings(aligned.loc[:, [component]], 20)["Feature"])
    heatmap = aligned.loc[features, pcs]
    order = leaves_list(linkage(pdist(heatmap.to_numpy()), method="average")) if len(heatmap) > 1 else np.array([0])
    heatmap = heatmap.iloc[order]
    figure, axis = plt.subplots(figsize=(7, max(5, len(heatmap) * 0.14)))
    image = axis.imshow(heatmap, aspect="auto", cmap="coolwarm", vmin=-heatmap.abs().to_numpy().max(), vmax=heatmap.abs().to_numpy().max())
    axis.set(xticks=range(len(pcs)), xticklabels=pcs, yticks=range(len(heatmap)), yticklabels=names.reindex(heatmap.index), title=f"{scope}: top PC1-PC4 loadings")
    figure.colorbar(image, ax=axis, label="Loading")
    figure.text(0.5, 0.01, "PC signs are oriented so the largest absolute loading is positive.", ha="center", fontsize=8)
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output_dir / f"loadings_heatmap_{scope}")
    plt.close(figure)
    technical_rows = []
    for component in aligned:
        features = top_loadings(aligned.loc[:, [component]], 25)["Feature"]
        technical_rows.append({
            "Component": component,
            "n_features": 25,
            "technical_dominated_top_25_fraction": technical_dominated.reindex(features).fillna(False).mean(),
        })
    return concentration.assign(scope=scope).merge(
        pd.DataFrame(technical_rows), on=["Component", "n_features"], how="left"
    )


def run_qc_completion(project_root: Path) -> None:
    """Write the outstanding non-ratio QC and loading outputs."""
    apply_plot_style()
    sample_sheet, lipidomics = read_lipidomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    samples, blank_columns, _ = lipidomics_measurement_columns(lipidomics)
    metadata = full_lipidomics_metadata(sample_sheet, samples)
    raw = lipidomics.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    annotations = lipid_annotations(lipidomics)
    values = preprocess_for_multivariate(raw, blanks)
    results = project_root / "results" / "mia_vs_control"
    qc = results / "02_qc"
    pca_dir = results / "04_multivariate" / "figures" / "pca"
    _plot_outliers(values, metadata, qc)
    _plot_scores(values, metadata, pca_dir)
    technical = pd.read_csv(qc / "technical_vs_biological_variance.csv")
    concentration = []
    for scope, scoped_metadata in [("pooled", metadata), *[(region.lower(), metadata.loc[metadata["Sample type"].eq(region)]) for region in REGIONS]]:
        complete = _pca_values(values, scoped_metadata["Sample"])
        _, _, loadings = fit_pca(complete, n_components=4)
        scope_technical = technical.drop_duplicates("Feature") if scope == "pooled" else technical.loc[technical["Region"].str.lower().eq(scope)]
        concentration.append(_plot_loadings(
            loadings,
            annotations,
            scope_technical.set_index("Feature")["technical_dominated"],
            scope,
            pca_dir,
        ))
    pd.concat(concentration, ignore_index=True).to_csv(results / "04_multivariate" / "pca_loading_concentration.csv", index=False)


if __name__ == "__main__":
    run_qc_completion(Path(__file__).resolve().parents[3])
