"""Run the reproducible MIA/control analysis and figure-reproduction pipeline.

This script writes all-60 outputs only when explicitly invoked. Sample-level
Hotelling exclusions are selected by the separate sensitivity runners.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..config import CAGE_METADATA_WORKBOOK, MIN_PER_CELL
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, analysis_metadata, full_lipidomics_metadata, lipid_annotations
from ..multivariate.loadings import align_loading_signs
from ..multivariate.pca import confidence_ellipse, fit_pca, loadings_table, scree_table
from ..multivariate.pca_metadata import (
    between_group_r2 as _between_group_r2,
    linear_score_r2 as _linear_score_r2,
    score_attribution,
    pooled_region_group_composite,
)
from ..outliers.screen import sample_outlier_table
from ..plotting import (
    BIO_GROUP_COLORS,
    BRAIN_REGION_COLORS,
    COLORBLIND_COLORS,
    SEX_COLORS,
    apply_plot_style,
    MARKER_CYCLE,
    save_figure,
    validate_categories,
)
from ..preprocessing import (
    below_detection_reasons,
    exclude_below_detection,
    exclude_blank_dominated_features,
    exclude_nonpositive,
    log2_transform,
    preprocess_for_differential,
    preprocess_for_multivariate,
)
from ..qc.variance import biological_variance_by_region, technical_variance, variance_ratio_table
from ..statistics.variance import permanova_by_region
from ..statistics.differential import fit_regionwise_differential
from .run_outlier_screen import run_outlier_screen
from .pipeline_stages import run_limma


RANDOM_SEED = 20_260_721
TISSUE_MASS_COLORS = ("#DDEAF2", "#6FA8C9", "#1F5A89")
ATTRIBUTION_COLORS = {
    "Region": COLORBLIND_COLORS[0],
    "Bio group": COLORBLIND_COLORS[1],
    "Sex": COLORBLIND_COLORS[2],
    "Tissue mass": COLORBLIND_COLORS[3],
    "Cage": COLORBLIND_COLORS[4],
    "Collection date": COLORBLIND_COLORS[5],
}
CAGE_COLORS = (*COLORBLIND_COLORS, "#000000")
CAGE_MARKERS = MARKER_CYCLE[:8]


full_analysis_metadata = full_lipidomics_metadata


def _scree_group_specs(
    metadata: pd.DataFrame,
    scope: str,
) -> list[tuple[str, list[str], str]]:
    """Return the total and metadata-defined sample groups for grouped scree plots."""
    specs = [(f"Total (n={len(metadata)})", metadata["Sample"].tolist(), "#333333")]
    grouped_variables = []
    if scope == "pooled":
        grouped_variables.append(("Sample type", BRAIN_REGION_COLORS))
    grouped_variables.extend([
        ("Bio group", BIO_GROUP_COLORS),
        ("Sex", SEX_COLORS),
    ])

    for variable, palette in grouped_variables:
        validate_categories(metadata[variable].dropna().unique(), palette, variable)
        for category, color in palette.items():
            samples = metadata.loc[metadata[variable].eq(category), "Sample"].tolist()
            if samples:
                specs.append((f"{variable}: {category} (n={len(samples)})", samples, color))

    mass = pd.to_numeric(metadata["Tissue mass (mg)"], errors="raise")
    mass_bins = pd.qcut(mass, 3, duplicates="raise")
    for number, category in enumerate(mass_bins.cat.categories):
        samples = metadata.loc[mass_bins.eq(category), "Sample"].tolist()
        specs.append((f"Tissue mass: {category} (n={len(samples)})", samples, TISSUE_MASS_COLORS[number]))
    return specs


def _write_grouped_scree(
    complete: pd.DataFrame,
    metadata: pd.DataFrame,
    total_model: object,
    scope: str,
    output_dir: Path,
) -> None:
    """Write grouped descriptive scree bars for the first four components."""
    components = [f"PC {number}" for number in range(1, 5)]
    specs = _scree_group_specs(metadata, scope)
    variance = []
    for number, (_, samples, _) in enumerate(specs):
        model = total_model if number == 0 else fit_pca(
            complete.loc[:, samples],
            n_components=len(components),
        )[0]
        variance.append(model.explained_variance_ratio_[:len(components)] * 100)

    figure, axis = plt.subplots(figsize=(12, 6.5))
    positions = np.arange(len(components))
    width = 0.8 / len(specs)
    for number, ((label, _, color), values) in enumerate(zip(specs, variance)):
        offset = (number - (len(specs) - 1) / 2) * width
        axis.bar(positions + offset, values, width=width, color=color, label=label)
    axis.set(
        xticks=positions,
        xticklabels=components,
        xlabel="Principal component",
        ylabel="Variance explained (%)",
        ylim=(0, 100),
        title=f"Grouped PCA scree: {scope}",
    )
    axis.legend(title="PCA population", bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
    figure.text(
        0.5,
        0.01,
        "Each bar is a separate descriptive PCA fit on the same complete, preprocessed feature matrix; bars are grouped, not additive.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.05, 0.72, 1))
    save_figure(figure, output_dir / f"scree_grouped_{scope}")
    plt.close(figure)


def _write_score_attribution(
    scores: pd.DataFrame,
    model_variance: np.ndarray,
    metadata: pd.DataFrame,
    scope: str,
    output_dir: Path,
) -> None:
    """Write factor-associated shares for PC1–PC5 of the original PCA."""
    components = scores.columns[:5].tolist()
    factor_specs = []
    if scope == "pooled":
        factor_specs.append(("Region", "Sample type", "categorical", ATTRIBUTION_COLORS["Region"]))
    factor_specs.extend([
        ("Bio group", "Bio group", "categorical", ATTRIBUTION_COLORS["Bio group"]),
        ("Sex", "Sex", "categorical", ATTRIBUTION_COLORS["Sex"]),
        ("Tissue mass", "Tissue mass (mg)", "continuous", ATTRIBUTION_COLORS["Tissue mass"]),
        ("Cage", "Cage", "categorical", ATTRIBUTION_COLORS["Cage"]),
        ("Collection date", "Date collected", "categorical", ATTRIBUTION_COLORS["Collection date"]),
    ])

    attribution = score_attribution(scores, model_variance, metadata, scope)
    attribution.to_csv(output_dir.parent.parent / f"pca_score_attribution_{scope}.csv", index=False)
    scores.to_csv(output_dir.parent.parent / f"pca_scores_{scope}.csv", index_label="Sample")
    if scope == "pooled":
        pooled_region_group_composite(scores, model_variance, metadata, attribution,
                                      output_dir / "scores_pooled_region_group_composite")

    figure, axis = plt.subplots(figsize=(11, 6.5))
    positions = np.arange(len(components))
    series = [("Total PC variance", "Total", "#333333")]
    series.extend((factor, factor, color) for factor, _, _, color in factor_specs)
    width = 0.8 / len(series)
    for number, (label, factor, color) in enumerate(series):
        values = attribution.loc[attribution["Factor"].eq(factor)].set_index("Component").loc[components, "factor_share_of_total_variance"] * 100
        offset = (number - (len(series) - 1) / 2) * width
        axis.bar(positions + offset, values, width=width, color=color, label=label)
    axis.set(
        xticks=positions,
        xticklabels=components,
        xlabel="Principal component",
        ylabel="Share of total PCA input variance (%)",
        ylim=(0, 100),
        title=f"PCA score variance attribution: {scope}",
    )
    axis.legend(title="Variance source", bbox_to_anchor=(1.02, 1), loc="upper left")
    figure.text(
        0.5,
        0.01,
        "Colored bars are factor-associated portions of each PC; factors overlap and are not additive.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.05, 0.76, 1))
    save_figure(figure, output_dir / f"scree_attribution_{scope}")
    plt.close(figure)


def _write_pca_figures(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    scope: str,
    output_dir: Path,
    annotations: pd.DataFrame,
    technical_variance_table: pd.DataFrame,
    variables: tuple[str, ...],
) -> None:
    complete = values.loc[:, metadata["Sample"]].dropna(axis=0, how="any")
    model, scores, loadings = fit_pca(complete)
    scree_table(model).to_csv(output_dir.parent.parent / f"pca_scree_{scope}.csv", index=False)
    loading_table = loadings_table(loadings, annotations)
    loading_table.merge(
        technical_variance_table.loc[:, ["Feature", "technical_dominated"]], on="Feature", how="left"
    ).to_csv(output_dir.parent.parent / f"pca_loadings_{scope}.csv", index=False)
    full_loadings = align_loading_signs(loadings).rename_axis("Feature").reset_index().merge(
        annotations, left_on="Feature", right_index=True, how="left", validate="one_to_one"
    )
    full_loadings.to_csv(output_dir.parent.parent / f"pca_loadings_full_{scope}.csv", index=False)

    fig, axis = plt.subplots(figsize=(7, 4.8))
    scree = scree_table(model)
    positions = np.arange(1, len(scree) + 1)
    axis.bar(positions, scree["variance_explained"] * 100, color=COLORBLIND_COLORS[0], label="Per component")
    axis.plot(positions, scree["cumulative_variance_explained"] * 100, "o-", color=COLORBLIND_COLORS[1], label="Cumulative")
    axis.set(xlabel="Principal component", ylabel="Variance explained (%)", title=f"PCA scree: {scope}")
    axis.legend(frameon=False)
    save_figure(fig, output_dir / f"scree_{scope}")
    plt.close(fig)
    _write_grouped_scree(complete, metadata, model, scope, output_dir)
    _write_score_attribution(scores, model.explained_variance_ratio_, metadata, scope, output_dir)

    plot_metadata = metadata.set_index("Sample").loc[scores.index]
    palettes = {
        "Sample type": BRAIN_REGION_COLORS,
        "Bio group": BIO_GROUP_COLORS,
        "Sex": SEX_COLORS,
    }
    if "Cage" in variables:
        cage_categories = sorted(plot_metadata["Cage"].dropna().astype(str).unique())
        palettes["Cage"] = dict(zip(cage_categories, CAGE_COLORS, strict=False))
    if "Date collected" in variables:
        plot_metadata["Date collected"] = pd.to_datetime(plot_metadata["Date collected"]).dt.strftime("%Y-%m-%d")
        palettes["Date collected"] = dict(zip(sorted(plot_metadata["Date collected"].unique()), COLORBLIND_COLORS))
    for variable in variables:
        fig, axis = plt.subplots(figsize=(7, 5.8))
        variable_values = plot_metadata[variable]
        if variable in palettes:
            categories = variable_values.drop_duplicates().tolist()
            palette = palettes[variable]
            validate_categories(categories, palette, variable)
            ellipse_groups = []
            for category in categories:
                subset = scores.loc[variable_values.eq(category)]
                marker = CAGE_MARKERS[categories.index(category)] if variable in {"Cage", "Date collected"} else "o"
                axis.scatter(
                    subset["PC 1"],
                    subset["PC 2"],
                    color=palette[category],
                    marker=marker,
                    edgecolor="black",
                    linewidth=0.35,
                    label=str(category),
                )
                ellipse_groups.append((str(category), subset))
            axis.legend(title=variable, frameon=True, loc="best")
            if variable not in {"Cage", "Date collected"}:
                for _, subset in ellipse_groups:
                    if len(subset) >= 3:
                        ellipse = confidence_ellipse(subset["PC 1"], subset["PC 2"])
                        axis.plot(ellipse[:, 0], ellipse[:, 1], color="#444444", linewidth=0.8, linestyle="--", label=None)
        elif variable == "Tissue mass (mg)":
            mass = pd.to_numeric(variable_values, errors="raise")
            labels = pd.qcut(mass, 3, duplicates="raise")
            categories = labels.cat.categories
            palette = ["#DDEAF2", "#6FA8C9", "#1F5A89"]
            for category, color in zip(categories, palette):
                subset = scores.loc[labels.eq(category)]
                axis.scatter(subset["PC 1"], subset["PC 2"], color=color, edgecolor="black", linewidth=0.35, label=f"{category.left:.0f}-{category.right:.0f} mg")
            axis.legend(title="Tissue mass", frameon=True, loc="best")
            correlation_1 = scores["PC 1"].corr(mass)
            correlation_2 = scores["PC 2"].corr(mass)
            fig.text(0.5, 0.01, f"Pooled tertiles; Pearson r: PC1 = {correlation_1:.2f}, PC2 = {correlation_2:.2f}.", ha="center", fontsize=8)
        else:
            points = axis.scatter(scores["PC 1"], scores["PC 2"], c=variable_values, cmap="viridis", edgecolor="black", linewidth=0.35)
            fig.colorbar(points, ax=axis, label=variable)
            ellipse = confidence_ellipse(scores["PC 1"], scores["PC 2"])
            axis.plot(ellipse[:, 0], ellipse[:, 1], color="#444444", linewidth=0.8, linestyle="--", label=None)
        axis.axhline(0, color="#BBBBBB", linewidth=0.8)
        axis.axvline(0, color="#BBBBBB", linewidth=0.8)
        axis.set(
            xlabel=f"PC 1 ({model.explained_variance_ratio_[0] * 100:.1f}%)",
            ylabel=f"PC 2 ({model.explained_variance_ratio_[1] * 100:.1f}%)",
            title=f"PCA scores: {scope}, coloured by {variable}",
        )
        note = "Dashed lines are 95% normal-theory data ellipses, not confidence intervals for group means."
        if variable == "Sample number":
            note += " Sample number is a proxy for acquisition order, not confirmed order."
        if variable != "Tissue mass (mg)":
            fig.text(0.5, 0.01, note, ha="center", fontsize=8)
        fig.tight_layout(rect=(0, 0.04, 1, 1))
        variable_name = variable.lower().replace(" ", "_").replace("(", "").replace(")", "")
        if variable == "Tissue mass (mg)":
            variable_name = "tissue_mass_binned"
        save_figure(fig, output_dir / f"scores_{scope}_{variable_name}")
        plt.close(fig)
def run_mia_vs_control(project_root: Path) -> None:
    """Regenerate the staged MIA/control outputs after explicitly invoking this script."""
    apply_plot_style()
    results = project_root / "results" / "mia_vs_control"
    inputs, preprocessing, qc, differential_dir, multivariate, reproduction, annotation = [
        results / name for name in ("00_inputs", "01_preprocessing", "02_qc", "03_differential", "04_multivariate", "05_figure_reproduction", "06_annotation")
    ]
    for directory in (inputs, preprocessing, qc, differential_dir, multivariate, reproduction, annotation):
        directory.mkdir(parents=True, exist_ok=True)

    sample_sheet, lipidomics = read_lipidomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    sample_columns, blank_columns, techmix_columns = lipidomics_measurement_columns(lipidomics)
    cage_workbook = project_root / "data" / CAGE_METADATA_WORKBOOK
    full_metadata = full_analysis_metadata(
        sample_sheet,
        sample_columns,
        cage_workbook=cage_workbook,
    )
    metadata = analysis_metadata(
        sample_sheet,
        sample_columns,
        cage_workbook=cage_workbook,
    )
    all_raw = lipidomics.loc[:, sample_columns].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    annotations.index = lipidomics.index
    raw = all_raw.loc[:, metadata["Sample"]]

    # QC and modelling both use all acquired biological samples.
    blank_filtered = exclude_blank_dominated_features(all_raw, blanks)
    filtered_blanks = blanks.loc[blank_filtered.index]
    report_positive = exclude_nonpositive(blank_filtered)
    detection_reasons = below_detection_reasons(report_positive, filtered_blanks)
    detection = detection_reasons.rename_axis(index="Feature", columns="Sample").stack().dropna().rename("detection_limit_reason").reset_index()
    detection = detection.merge(metadata.loc[:, ["Sample", "Sample type"]], on="Sample", how="left", validate="many_to_one").merge(annotations, left_on="Feature", right_index=True, how="left", validate="many_to_one")
    differential_values = preprocess_for_differential(raw, blanks)
    multivariate_values = preprocess_for_multivariate(raw, blanks)
    qc_multivariate_values = preprocess_for_multivariate(all_raw, blanks)
    fully_excluded = detection_reasons.index[report_positive.mask(detection_reasons.notna()).isna().all(axis=1)]
    fully_excluded_table = annotations.loc[fully_excluded].copy()
    fully_excluded_table.index.name = "Feature"
    preprocessing_diagnostics = pd.DataFrame({"n_lipids_input": [len(raw)], "n_blank_dominated_removed": [len(raw) - len(blank_filtered)], "n_lipids_multivariate": [len(multivariate_values)], "n_below_detection_cells": [len(detection)]})
    preprocessing_diagnostics.to_csv(preprocessing / "preprocessing_diagnostics.csv", index=False)
    detection.to_csv(preprocessing / "detection_limit_exclusions.csv", index=False)
    fully_excluded_table.to_csv(preprocessing / "detection_limit_fully_excluded_features.csv")
    detection.groupby(["Lipid Class", "detection_limit_reason"], observed=True).size().rename("n_values").reset_index().to_csv(preprocessing / "detection_limit_exclusions_by_lipid_class.csv", index=False)

    differential_values.to_csv(inputs / "differential_input_matrix.csv", index_label="Feature")
    limma_metadata = metadata.loc[:, ["Sample", "Sample type", "Bio group", "Sex", "Mouse number"]].rename(columns={"Sample type": "Region", "Bio group": "BioGroup"})
    limma_metadata.to_csv(inputs / "differential_input_metadata.csv", index=False)
    fitted = fit_regionwise_differential(
        differential_values,
        metadata,
        annotations=annotations,
        min_per_cell=MIN_PER_CELL,
    )
    fitted.effects.to_csv(differential_dir / "differential_effects.csv", index=False)
    fitted.feature_qc.to_csv(differential_dir / "differential_feature_qc.csv", index=False)
    run_limma(project_root, inputs, differential_dir, fdr_denominator="fitted")

    positive = exclude_nonpositive(raw)
    techmix = log2_transform(exclude_below_detection(exclude_nonpositive(lipidomics.loc[:, techmix_columns]), blanks))
    biological = log2_transform(exclude_below_detection(exclude_nonpositive(all_raw), blanks))
    technical = technical_variance(techmix)
    variance_table = variance_ratio_table(technical, biological_variance_by_region(biological, full_metadata), technical_counts=techmix.notna().sum(axis=1))
    variance_table = variance_table.merge(annotations, left_on="Feature", right_index=True, how="left", validate="many_to_one")
    variance_table.to_csv(qc / "technical_vs_biological_variance.csv", index=False)
    run_outlier_screen(project_root)

    permanova, permanova_diagnostics = permanova_by_region(multivariate_values, metadata)
    permanova.to_csv(multivariate / "permanova_by_region.csv", index=False)
    permanova_diagnostics.to_csv(multivariate / "permanova_diagnostics.csv", index=False)
    pca_dir = multivariate / "figures" / "pca"
    for region in REGIONS:
        _write_pca_figures(
            qc_multivariate_values,
            full_metadata.loc[full_metadata["Sample type"].eq(region)],
            region.lower(),
            pca_dir,
            annotations,
            variance_table.loc[variance_table["Region"].eq(region)],
            ("Bio group", "Sex", "Cage"),
        )
    _write_pca_figures(
        qc_multivariate_values,
        full_metadata,
        "pooled",
        pca_dir,
        annotations,
        variance_table.drop_duplicates("Feature"),
        ("Sample type", "Bio group", "Sex", "Cage", "Date collected", "Sample number", "Tissue mass (mg)"),
    )


if __name__ == "__main__":
    run_mia_vs_control(Path(__file__).resolve().parents[3])
