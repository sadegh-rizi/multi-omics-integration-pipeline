"""Run the planned region-wise differential model before outlier exclusion."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..config import MIN_PER_CELL
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import full_lipidomics_metadata
from ..preprocessing import preprocess_for_differential
from ..statistics.differential import fit_regionwise_differential


def run_full_60_differential(project_root: Path) -> None:
    """Write a full-sample sensitivity analysis without replacing the primary result."""
    sample_sheet, lipidomics = read_lipidomics_tables(
        project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    )
    samples, blank_columns, _ = lipidomics_measurement_columns(lipidomics)
    metadata = full_lipidomics_metadata(sample_sheet, samples)
    raw = lipidomics.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    values = preprocess_for_differential(raw, blanks).dropna(axis=0, how="all")
    fitted = fit_regionwise_differential(
        values,
        metadata,
        annotations=annotations,
        min_per_cell=MIN_PER_CELL,
    )
    output = project_root / "results" / "mia_vs_control" / "03_differential" / "full_60_samples"
    output.mkdir(parents=True, exist_ok=True)
    metadata.to_csv(output / "differential_metadata.csv", index=False)
    fitted.effects.to_csv(output / "differential_effects.csv", index=False)
    fitted.feature_qc.to_csv(output / "differential_feature_qc.csv", index=False)


if __name__ == "__main__":
    run_full_60_differential(Path(__file__).resolve().parents[3])
