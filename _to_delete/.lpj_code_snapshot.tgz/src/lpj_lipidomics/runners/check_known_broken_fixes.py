"""Predeclared project-data regression checks for the 2026-09-26 fixes."""

import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np
import pandas as pd


def write_run_provenance(project_root: Path, output: Path) -> None:
    """Record the git baseline plus exact working-source and input identities."""
    files = [*sorted((project_root / "src").rglob("*.py")), project_root / "src" / "differential_moderated.R",
             project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx",
             project_root / "data" / "Samples for metabolomics.xlsx"]
    hashes = {str(path.relative_to(project_root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    manifest = {
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=project_root, text=True).strip(),
        "working_tree_source_diff": bool(subprocess.check_output(["git", "status", "--porcelain", "--", "src"], cwd=project_root)),
        "sha256": hashes,
        "source_sheets": ["Sample Sheet", "Lipidomics", "Metabolomics", "Samples to be shipped"],
        "prompt": "prompts/2026-10-01-known-broken-fixes-implementation-v1.md",
        "model": "openai/gpt-6-astra",
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "provenance.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def check_g9(project_root: Path, rerun: Path) -> pd.DataFrame:
    original = project_root / "results" / "pipeline_test" / "prevalence20_noexclusion"
    rows = []
    for relative, keys in [
        ("03_differential/differential_effects.csv", ["Feature", "Region", "Effect"]),
        ("05_diagnostics/permutation_effective_tests.csv", ["Region", "Effect"]),
        *[(f"02_qc/outlier_screen_{region}.csv", ["Sample"]) for region in ("cerebellum", "cortex", "hippocampus")],
    ]:
        old = pd.read_csv(original / relative).set_index(keys).sort_index()
        new = pd.read_csv(rerun / relative).set_index(keys).sort_index()
        if not old.index.equals(new.index):
            raise AssertionError(f"G9 key mismatch: {relative}")
        columns = ["estimate_log2", "standard_error", "p_value", "p_value_fdr"] if "differential_effects" in relative else old.columns
        for column in columns:
            if pd.api.types.is_numeric_dtype(old[column]) and not pd.api.types.is_bool_dtype(old[column]):
                difference = (old[column] - new[column]).abs().max()
                passed = np.allclose(old[column], new[column], atol=1e-8, rtol=0, equal_nan=True)
            else:
                difference = np.nan
                passed = old[column].fillna("").astype(str).equals(new[column].fillna("").astype(str))
            rows.append({"table": relative, "column": column, "max_absolute_difference": difference, "passed": bool(passed)})
    checks = pd.DataFrame(rows)
    checks.to_csv(rerun / "05_diagnostics" / "g9_regression_checks.csv", index=False)
    if not checks["passed"].all():
        raise AssertionError("G9 regression failed; inspect g9_regression_checks.csv before accepting the rerun.")
    return checks


def check_pca_reference(arm: Path, modality: str) -> pd.DataFrame:
    table = pd.read_csv(arm / "04_multivariate" / "pca_score_attribution_pooled.csv").set_index(["Component", "Factor"])
    expected = {"lipidomics": [("PC 1", "Region", .80), ("PC 1", "Bio group", .001),
                               ("PC 4", "Bio group", .045), ("PC 4", "Cage", .36), ("PC 4", "Collection date", .31)],
                "metabolomics": [("PC 1", "Region", .85), ("PC 1", "Bio group", .002),
                                  ("PC 4", "Bio group", .21), ("PC 4", "Cage", .70), ("PC 4", "Collection date", .57)]}
    checks = []
    for pc, factor, reference in expected[modality]:
        actual = table.loc[(pc, factor), "factor_score_r2"]
        checks.append({"Component": pc, "Factor": factor, "reference": reference, "actual": actual,
                       "passed": bool(abs(actual - reference) <= .01)})
    actual = table.loc[("PC 1", "Total"), "pc_variance_explained"]
    reference = .327 if modality == "lipidomics" else .311
    checks.append({"Component": "PC 1", "Factor": "explained variance", "reference": reference,
                   "actual": actual, "passed": bool(abs(actual - reference) <= .01)})
    checks = pd.DataFrame(checks)
    checks.to_csv(arm / "04_multivariate" / "pca_reference_checks.csv", index=False)
    if not checks["passed"].all():
        raise AssertionError(f"Pooled PCA reference tolerance exceeded: {modality}")
    return checks


def check_region_persistence(project_root: Path, previous: dict[str, pd.DataFrame]) -> pd.DataFrame:
    root = project_root / "results" / "mia_vs_control" / "09_region_persistence"
    reference = pd.read_csv(project_root / "doc" / "context" / "reference" / "disattenuation_reference.csv")
    reference = reference.loc[reference["population"].eq("all 60")].set_index("contrast")
    expected = {
        "prevalence20_noexclusion": [(10, 10), (10, 10), (10, 10)],
        "prevalence20_hotelling95": [(9, 8), (9, 7), (8, 9)],
        "prevalence20_hotelling99": [(10, 8), (10, 8), (10, 10)],
    }
    names = ["Cortex - Cerebellum", "Cortex - Hippocampus", "Hippocampus - Cerebellum"]
    checks = []
    for population, counts in expected.items():
        for modality in ("lipidomics", "metabolomics"):
            output = root / population / modality
            table = pd.read_csv(output / "02_qc" / "disattenuated_concordance.csv").set_index("Contrast")
            counts_table = pd.read_csv(output / "02_qc" / "concordance.csv").set_index("Contrast")
            for name, (control, mia) in zip(names, counts):
                base = {"population": population, "modality": modality, "Contrast": name}
                checks.append({**base, "check": "point inside interval", "passed": bool(table.loc[name, "point_inside_interval"])})
                checks.append({**base, "check": "contrast-specific pairing counts", "passed":
                               bool(counts_table.loc[name, "n_mice_control"] == control and counts_table.loc[name, "n_mice_mia"] == mia)})
                if population == "prevalence20_noexclusion":
                    point_error = abs(table.loc[name, "disattenuated_concordance"] - previous[modality].loc[name, "disattenuated_concordance"])
                    checks.append({**base, "check": "point estimate unchanged at 1e-10", "value": point_error, "passed": bool(point_error <= 1e-10)})
                    if modality == "lipidomics":
                        for bound, ref_bound in [("bootstrap_q025", "ci_lo"), ("bootstrap_q975", "ci_hi")]:
                            actual, target = table.loc[name, bound], reference.loc[name, ref_bound]
                            if name == "Cortex - Hippocampus" and ref_bound == "ci_hi":
                                passed = actual > 0 and abs(np.log(actual / target)) <= np.log(1.15)
                            else:
                                passed = abs(actual - target) <= .05
                            checks.append({**base, "check": bound, "value": actual, "reference": target, "passed": bool(passed)})
                        if name == "Cortex - Cerebellum":
                            checks.append({**base, "check": "positive-control CI covers 1", "passed":
                                           bool(table.loc[name, "bootstrap_q025"] <= 1 <= table.loc[name, "bootstrap_q975"])})
            if population == "prevalence20_noexclusion":
                interaction = pd.read_csv(output / "03_differential" / "region_interactions.csv")
                count = int(interaction["q_value_raw"].lt(.05).sum())
                checks.append({"population": population, "modality": modality,
                               "check": "all-60 interaction q<0.05 count unchanged", "value": count, "passed": count == 0})
    checks = pd.DataFrame(checks)
    checks.to_csv(root / "regression_checks.csv", index=False)
    if not checks["passed"].all():
        raise AssertionError("Region-persistence tolerance failure; investigate regression_checks.csv before accepting.")
    return checks
