"""Build aligned multi-omics blocks for the confirmed integration plan."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from ..io.proteomics import read_perseus_proteomics, sha256_file


POPULATION = "prevalence20_noexclusion"
MODALITIES = ("lipidomics", "metabolomics", "proteomics")
REGIONS = ("Cerebellum", "Cortex", "Hippocampus")
MARKERS = (
    ("Gabra6", "Cerebellum"),
    ("Calb1", "Cerebellum"),
    ("Satb2", "Cortex"),
    ("Tbr1", "Cortex"),
)
_SAMPLE_NUMBER_PATTERN = re.compile(r"^MB2_088-(\d+)$")


def _persistence_root(project_root: Path, modality: str) -> Path:
    return (
        project_root
        / "results"
        / "mia_vs_control"
        / "09_region_persistence"
        / POPULATION
        / modality
        / "00_inputs"
    )


def _read_persistence_block(
    project_root: Path,
    modality: str,
) -> tuple[pd.DataFrame, pd.DataFrame, Path, Path]:
    input_root = _persistence_root(project_root, modality)
    matrix_path = input_root / "region_input_matrix.csv"
    metadata_path = input_root / "region_input_metadata.csv"
    values = pd.read_csv(matrix_path, index_col="Feature")
    values.index = values.index.astype(str)
    values.columns = [_canonical_sample_id(sample) for sample in values.columns]
    values = values.apply(pd.to_numeric, errors="coerce")
    metadata = pd.read_csv(metadata_path)
    metadata["Sample"] = metadata["Sample"].map(_canonical_sample_id)
    if metadata["Sample"].duplicated().any() or values.columns.duplicated().any():
        raise ValueError(f"Duplicate sample identifiers in {modality} persistence inputs.")
    if set(values.columns) != set(metadata["Sample"]):
        raise ValueError(f"{modality} samples do not match its persistence metadata.")
    metadata = metadata.set_index("Sample", drop=False).loc[list(values.columns)].reset_index(drop=True)
    if values.isna().to_numpy().any():
        complete = values.notna().all(axis=1)
        values = values.loc[complete]
    if values.empty:
        raise ValueError(f"No complete {modality} features remain for integration.")
    return values, metadata, matrix_path, metadata_path


def _canonical_sample_id(sample: object) -> str:
    """Normalize padded and unpadded persistence sample IDs to one key."""
    text = str(sample).strip()
    match = _SAMPLE_NUMBER_PATTERN.fullmatch(text)
    if match is None:
        raise ValueError(f"Invalid integration sample identifier: {sample!r}")
    number = int(match.group(1))
    if not 1 <= number <= 60:
        raise ValueError(f"Integration sample number is outside 1..60: {sample!r}")
    return f"MB2_088-{number:02d}"


def _validate_metadata(metadata: pd.DataFrame) -> None:
    required = {
        "Sample", "Sample number", "Sample type", "Mouse number", "Bio group",
        "Sex", "Cage", "Date collected", "Tissue mass (mg)",
    }
    missing = required.difference(metadata.columns)
    if missing:
        raise KeyError(f"Integration metadata is missing columns: {sorted(missing)}")
    if len(metadata) != 60 or metadata["Mouse number"].nunique() != 20:
        raise ValueError("The integration input must contain all 60 samples from 20 mice.")
    if metadata[["Mouse number", "Sample type"]].duplicated().any():
        raise ValueError("Each mouse must have at most one sample per region.")
    region_counts = metadata.groupby("Mouse number", observed=True)["Sample type"].nunique()
    if not region_counts.eq(3).all():
        raise ValueError("Every mouse must contribute all three regions.")
    cage_group_counts = metadata.groupby("Cage", observed=True)["Bio group"].nunique()
    if not cage_group_counts.eq(1).all():
        raise ValueError("Each cage must have one treatment label.")


def _check_metadata_agreement(left: pd.DataFrame, right: pd.DataFrame, modality: str) -> None:
    columns = ["Sample number", "Sample type", "Mouse number", "Bio group", "Sex", "Cage"]
    left_key = left.set_index("Sample")[columns].sort_index()
    right_key = right.set_index("Sample")[columns].sort_index()
    if not left_key.equals(right_key):
        raise ValueError(f"Lipidomics and {modality} metadata disagree.")


def _proteomics_inputs(project_root: Path, metadata: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Path]]:
    files = {
        "Cerebellum": project_root / "data" / "proteomics_Cerebellum_matrix 38_after data imputation ND_prior to ANOVA.txt",
        "Cortex": project_root / "data" / "proteomics_Cortex_matrix 77_after data imputation ND_prior to ANOVA.txt",
        "Hippocampus": project_root / "data" / "proteomics_Hippocampus_matrix 23_after data imputation ND_prior to ANOVA.txt",
    }
    region_values: dict[str, pd.DataFrame] = {}
    annotations: dict[str, pd.DataFrame] = {}
    for region, path in files.items():
        values, current_annotations = read_perseus_proteomics(path, expected_region=region)
        expected_samples = metadata.loc[metadata["Sample type"].eq(region), "Sample"]
        if set(values.columns) != set(expected_samples):
            raise ValueError(f"{region} proteomics samples do not match study metadata.")
        region_values[region] = values.loc[:, list(expected_samples)]
        annotations[region] = current_annotations

    shared = set.intersection(*(set(values.index) for values in region_values.values()))
    if not shared:
        raise ValueError("No Protein IDs are shared across all proteomics regions.")
    shared_ids = sorted(shared)
    combined = pd.concat(
        [region_values[region].loc[shared_ids] for region in REGIONS],
        axis=1,
    )
    combined = combined.loc[:, metadata["Sample"]]
    combined.index.name = "Protein ID"
    annotation = annotations[REGIONS[0]].loc[shared_ids, ["Gene"]].copy()
    annotation.index.name = "Protein ID"
    return combined, annotation, files


def _marker_checks(values: pd.DataFrame, annotations: pd.DataFrame, metadata: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    genes = annotations["Gene"].fillna("").str.casefold()
    for gene, target_region in MARKERS:
        protein_ids = annotations.index[genes.eq(gene.casefold())]
        if len(protein_ids) == 0:
            rows.append({
                "Gene": gene,
                "expected_region": target_region,
                "status": "not_detected",
                "n_proteins": 0,
            })
            continue
        protein = protein_ids[0]
        differences: list[float] = []
        for _, mouse_rows in metadata.groupby("Mouse number", observed=True):
            target = mouse_rows.loc[mouse_rows["Sample type"].eq(target_region), "Sample"]
            other = mouse_rows.loc[~mouse_rows["Sample type"].eq(target_region), "Sample"]
            if len(target) != 1 or len(other) != 2:
                continue
            differences.append(float(values.loc[protein, target.iloc[0]] - values.loc[protein, other].mean()))
        mean_difference = float(np.mean(differences)) if differences else np.nan
        rows.append({
            "Gene": gene,
            "Protein ID": protein,
            "expected_region": target_region,
            "status": "detected",
            "n_proteins": len(protein_ids),
            "n_mouse_pairs": len(differences),
            "mean_target_minus_other_log2": mean_difference,
            "direction_matches": bool(mean_difference > 0) if np.isfinite(mean_difference) else False,
        })
    return pd.DataFrame(rows)


def build_integration_inputs(
    project_root: Path,
    *,
    output_root: Path | None = None,
    overwrite: bool = False,
) -> Path:
    """Write aligned all-60 blocks and source provenance for the integration."""
    if output_root is None:
        output_root = project_root / "results" / "mia_vs_control" / "14_integration" / POPULATION
    if not overwrite and output_root.exists() and any(path.is_file() for path in output_root.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite integration inputs: {output_root}")

    lipid_values, metadata, lipid_matrix_path, lipid_metadata_path = _read_persistence_block(project_root, "lipidomics")
    metabolite_values, metabolite_metadata, metabolite_matrix_path, metabolite_metadata_path = _read_persistence_block(project_root, "metabolomics")
    _validate_metadata(metadata)
    _check_metadata_agreement(metadata, metabolite_metadata, "metabolomics")
    if list(lipid_values.columns) != list(metadata["Sample"]):
        lipid_values = lipid_values.loc[:, metadata["Sample"]]
    metabolite_values = metabolite_values.loc[:, metadata["Sample"]]
    proteomics_values, proteomics_annotations, proteomics_files = _proteomics_inputs(project_root, metadata)

    blocks_root = output_root / "00_inputs" / "blocks"
    blocks_root.mkdir(parents=True, exist_ok=True)
    block_values = {
        "lipidomics": lipid_values,
        "metabolomics": metabolite_values,
        "proteomics": proteomics_values,
    }
    for modality, values in block_values.items():
        block = values.T.copy()
        block.insert(0, "Sample", block.index)
        block.to_csv(blocks_root / f"{modality}.csv", index=False)
    metadata.to_csv(output_root / "00_inputs" / "sample_metadata.csv", index=False)
    proteomics_annotations.reset_index().to_csv(
        output_root / "00_inputs" / "proteomics_feature_annotation.csv", index=False
    )
    marker_checks = _marker_checks(proteomics_values, proteomics_annotations, metadata)
    marker_checks.to_csv(output_root / "00_inputs" / "proteomics_marker_checks.csv", index=False)

    source_files = {
        "lipidomics_matrix": lipid_matrix_path,
        "lipidomics_metadata": lipid_metadata_path,
        "metabolomics_matrix": metabolite_matrix_path,
        "metabolomics_metadata": metabolite_metadata_path,
        **{f"proteomics_{region}": path for region, path in proteomics_files.items()},
    }
    provenance = {
        "analysis": "multi-omics integration input construction",
        "population": POPULATION,
        "n_samples": len(metadata),
        "n_mice": int(metadata["Mouse number"].nunique()),
        "features": {modality: int(len(values)) for modality, values in block_values.items()},
        "proteomics_shared_proteins": int(len(proteomics_values)),
        "proteomics_scale": "delivered log2 MaxLFQ Unique Intensity; already ND-imputed",
        "lipidomics_metabolomics_scale": "existing log2 median-normalized persistence inputs",
        "missing_value_policy": "complete lipid/metabolite features; no new imputation",
        "source_files": {
            str(path.relative_to(project_root)): sha256_file(path)
            for path in source_files.values()
        },
        "output_files": [
            "00_inputs/blocks/lipidomics.csv",
            "00_inputs/blocks/metabolomics.csv",
            "00_inputs/blocks/proteomics.csv",
            "00_inputs/sample_metadata.csv",
            "00_inputs/proteomics_feature_annotation.csv",
            "00_inputs/proteomics_marker_checks.csv",
        ],
        "region_run_structure": "unknown; register A12 must be answered before biological interpretation",
    }
    with (output_root / "provenance.json").open("w", encoding="utf-8") as handle:
        json.dump(provenance, handle, indent=2)
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    build_integration_inputs(args.project_root, overwrite=args.overwrite)
