"""Shared grouped inference and calibration for integration outputs."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import ttest_ind

from ..statistics.clustered import cage_group_assignments, exact_empirical_p_value


def mouse_grouped_folds(
    metadata: pd.DataFrame,
    *,
    n_splits: int = 5,
    n_repeats: int = 10,
    random_state: int = 20_261_011,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Return repeated folds whose train/test sets never split a mouse."""
    if n_splits < 2 or n_repeats < 1:
        raise ValueError("n_splits must be at least 2 and n_repeats must be positive.")
    if "Mouse number" not in metadata:
        raise KeyError("Metadata is missing 'Mouse number'.")
    mice = metadata["Mouse number"].drop_duplicates().to_numpy()
    if len(mice) < n_splits:
        raise ValueError("There are fewer mice than requested CV folds.")

    rng = np.random.default_rng(random_state)
    folds: list[tuple[np.ndarray, np.ndarray]] = []
    for _ in range(n_repeats):
        shuffled = rng.permutation(mice)
        for test_mice in np.array_split(shuffled, n_splits):
            test_mask = metadata["Mouse number"].isin(test_mice).to_numpy()
            test = np.flatnonzero(test_mask)
            train = np.flatnonzero(~test_mask)
            if set(metadata.iloc[train]["Mouse number"]) & set(metadata.iloc[test]["Mouse number"]):
                raise AssertionError("A grouped fold split a mouse.")
            folds.append((train, test))
    return folds


def mouse_group_assignments(
    metadata: pd.DataFrame,
    *,
    n_permutations: int,
    random_state: int = 20_261_012,
) -> list[pd.Series]:
    """Shuffle treatment labels across mice within sex, preserving counts."""
    if n_permutations < 1:
        raise ValueError("n_permutations must be positive.")
    required = {"Mouse number", "Sex", "Bio group"}
    missing = required.difference(metadata.columns)
    if missing:
        raise KeyError(f"Metadata is missing columns: {sorted(missing)}")
    mouse_info = metadata.loc[:, ["Mouse number", "Sex", "Bio group"]].drop_duplicates("Mouse number")
    if len(mouse_info) != metadata["Mouse number"].nunique():
        raise ValueError("Each mouse must have one Sex and Bio group label.")
    rng = np.random.default_rng(random_state)
    assignments: list[pd.Series] = []
    for _ in range(n_permutations):
        labels_by_mouse = mouse_info.set_index("Mouse number")["Bio group"].copy()
        for _, rows in mouse_info.groupby("Sex", sort=False, observed=True):
            mice = rows["Mouse number"].to_numpy()
            labels_by_mouse.loc[mice] = rng.permutation(rows["Bio group"].to_numpy())
        assignments.append(
            metadata["Mouse number"].map(labels_by_mouse).rename("Bio group")
        )
    return assignments


def _mouse_assignment_matrix(
    metadata: pd.DataFrame,
    *,
    n_permutations: int,
    random_state: int,
) -> np.ndarray:
    """Generate the same sex-stratified assignments as arrays for repeated tests."""
    if n_permutations < 1:
        raise ValueError("n_permutations must be positive.")
    required = {"Mouse number", "Sex", "Bio group"}
    missing = required.difference(metadata.columns)
    if missing:
        raise KeyError(f"Metadata is missing columns: {sorted(missing)}")
    mouse_info = metadata.loc[:, ["Mouse number", "Sex", "Bio group"]].drop_duplicates("Mouse number")
    if len(mouse_info) != metadata["Mouse number"].nunique():
        raise ValueError("Each mouse must have one Sex and Bio group label.")

    mouse_sexes = mouse_info["Sex"].to_numpy()
    original_labels = mouse_info["Bio group"].to_numpy()
    sex_indices = [
        np.flatnonzero(mouse_sexes == sex)
        for sex in pd.unique(mouse_sexes)
    ]
    rng = np.random.default_rng(random_state)
    assignments = np.empty((n_permutations, len(mouse_info)), dtype=object)
    for permutation in range(n_permutations):
        labels = original_labels.copy()
        for indices in sex_indices:
            labels[indices] = rng.permutation(original_labels[indices])
        assignments[permutation] = labels
    return assignments


def _welch_statistics(scores: pd.Series, labels: pd.Series) -> tuple[float, float]:
    groups = list(labels.dropna().unique())
    if len(groups) != 2:
        raise ValueError("Treatment tests require exactly two groups.")
    left = scores.loc[labels.eq(groups[0])].to_numpy(dtype=float)
    right = scores.loc[labels.eq(groups[1])].to_numpy(dtype=float)
    test = ttest_ind(left, right, equal_var=False, nan_policy="raise")
    return float(test.statistic), float(test.pvalue)


def _r_squared(scores: pd.Series, labels: pd.Series) -> float:
    finite = scores.notna() & labels.notna()
    scores = scores.loc[finite].astype(float)
    labels = labels.loc[finite]
    if len(scores) < 2 or scores.var(ddof=0) == 0:
        return 0.0
    grand_mean = float(scores.mean())
    between = sum(
        len(group) * (float(group.mean()) - grand_mean) ** 2
        for _, group in scores.groupby(labels, observed=True)
    )
    return float(np.clip(between / float(((scores - grand_mean) ** 2).sum()), 0.0, 1.0))


def _mouse_level_scores(metadata: pd.DataFrame, scores: pd.Series, labels: pd.Series) -> pd.DataFrame:
    frame = pd.DataFrame({
        "Mouse number": metadata["Mouse number"].to_numpy(),
        "Cage": metadata["Cage"].to_numpy(),
        "Score": scores.to_numpy(dtype=float),
        "Bio group": labels.to_numpy(),
    })
    mouse = frame.groupby("Mouse number", sort=False, observed=True).agg(
        Score=("Score", "mean"),
        Cage=("Cage", "first"),
        **{"Bio group": ("Bio group", "first")},
    )
    return mouse.reset_index()


def _mouse_null_statistics(
    metadata: pd.DataFrame,
    observed: pd.DataFrame,
    *,
    n_permutations: int,
    random_state: int,
) -> np.ndarray:
    """Calculate mouse-permutation Welch statistics without per-permutation groupbys."""
    assignments = _mouse_assignment_matrix(
        metadata,
        n_permutations=n_permutations,
        random_state=random_state,
    )
    labels = assignments
    values = observed["Score"].to_numpy(dtype=float)
    groups = list(pd.unique(labels[0]))
    if len(groups) != 2:
        raise ValueError("Treatment tests require exactly two permuted groups.")

    left = labels == groups[0]
    right = ~left
    n_left = left.sum(axis=1)
    n_right = right.sum(axis=1)
    left_sum = left @ values
    right_sum = right @ values
    left_mean = left_sum / n_left
    right_mean = right_sum / n_right
    left_ss = left @ np.square(values) - np.square(left_sum) / n_left
    right_ss = right @ np.square(values) - np.square(right_sum) / n_right
    left_var = left_ss / (n_left - 1)
    right_var = right_ss / (n_right - 1)
    standard_error = np.sqrt(left_var / n_left + right_var / n_right)
    return np.divide(
        left_mean - right_mean,
        standard_error,
        out=np.full(n_permutations, np.nan, dtype=float),
        where=standard_error > 0,
    )


def treatment_score_test(
    metadata: pd.DataFrame,
    scores: pd.Series,
    *,
    score_name: str,
    n_mouse_permutations: int = 9_999,
    random_state: int = 20_261_013,
) -> dict[str, object]:
    """Apply the declared cage-primary three-part treatment decision rule."""
    if len(metadata) != len(scores):
        raise ValueError("Scores must have one value per metadata row.")
    if metadata["Cage"].isna().any():
        raise ValueError("Treatment tests require nonmissing cage labels.")

    observed = _mouse_level_scores(metadata, scores, metadata["Bio group"])
    observed_t, observed_mouse_p = _welch_statistics(observed["Score"], observed["Bio group"])
    cage_scores = observed.groupby("Cage", sort=False, observed=True).agg(
        Score=("Score", "mean"), **{"Bio group": ("Bio group", "first")}
    )
    group_r2 = _r_squared(observed["Score"], observed["Bio group"])
    cage_r2 = _r_squared(cage_scores["Score"], cage_scores["Bio group"])

    cage_null: list[float] = []
    for assignment in cage_group_assignments(metadata):
        current = _mouse_level_scores(metadata, scores, assignment)
        cage_null.append(_welch_statistics(current["Score"], current["Bio group"])[0])
    cage_p = exact_empirical_p_value(observed_t, np.asarray(cage_null))

    mouse_null = _mouse_null_statistics(
        metadata,
        observed,
        n_permutations=n_mouse_permutations,
        random_state=random_state,
    )
    mouse_p = exact_empirical_p_value(observed_t, mouse_null)
    cage_floor = 1 / len(cage_null)
    return {
        "Score name": score_name,
        "observed_welch_t": observed_t,
        "mouse_welch_p": observed_mouse_p,
        "cage_permutation_p": cage_p,
        "mouse_permutation_p": mouse_p,
        "group_r_squared": group_r2,
        "cage_r_squared": cage_r2,
        "cage_p_floor": cage_floor,
        "cage_decision_rule": "cage p equals floor; mouse p < 0.05; group R2 > cage R2",
        "treatment_associated_under_rule": bool(
            np.isclose(cage_p, cage_floor) and mouse_p < 0.05 and group_r2 > cage_r2
        ),
        "interpretation": "not separable from cage and date" if np.isclose(cage_p, cage_floor) and mouse_p < 0.05 and group_r2 > cage_r2 else "descriptive/non-associated under fixed rule",
        "n_cage_assignments": len(cage_null),
        "n_mouse_permutations": len(mouse_null),
    }


def null_calibration(
    metadata: pd.DataFrame,
    *,
    n_datasets: int = 200,
    random_state: int = 20_261_014,
) -> pd.DataFrame:
    """Calibrate mouse-level Welch p-values with and without cage effects."""
    if n_datasets < 1:
        raise ValueError("n_datasets must be positive.")
    rng = np.random.default_rng(random_state)
    rows: list[dict[str, object]] = []
    for cage_effect in (False, True):
        for dataset in range(n_datasets):
            cage_offsets = {
                cage: (rng.normal() if cage_effect else 0.0)
                for cage in metadata["Cage"].drop_duplicates()
            }
            values = np.asarray([
                rng.normal() + cage_offsets[cage]
                for cage in metadata["Cage"]
            ])
            result = treatment_score_test(
                metadata,
                pd.Series(values),
                score_name="null",
                n_mouse_permutations=999,
                random_state=random_state + dataset,
            )
            rows.append({
                "cage_random_effect": cage_effect,
                "dataset": dataset,
                "mouse_permutation_p": result["mouse_permutation_p"],
                "cage_permutation_p": result["cage_permutation_p"],
            })
    return pd.DataFrame(rows)


def run_integration_tests(
    project_root: Path,
    *,
    n_mouse_permutations: int = 9_999,
    calibration_datasets: int = 200,
    overwrite: bool = False,
) -> Path:
    """Run shared treatment tests on standardized model score exports."""
    input_root = project_root / "results" / "mia_vs_control" / "14_integration" / "prevalence20_noexclusion"
    output_root = input_root / "04_tests"
    if not overwrite and output_root.exists() and any(path.is_file() for path in output_root.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite integration tests: {output_root}")
    metadata = pd.read_csv(input_root / "00_inputs" / "sample_metadata.csv")
    rows: list[dict[str, object]] = []
    for model_directory in ("01_mofa", "02_diablo_region", "03_control_reference"):
        score_path = input_root / model_directory / "scores.csv"
        if not score_path.exists():
            continue
        if score_path.stat().st_size == 0:
            continue
        try:
            scores = pd.read_csv(score_path)
        except pd.errors.EmptyDataError:
            continue
        required = {"Sample", "Score name", "Score"}
        missing = required.difference(scores.columns)
        if missing:
            raise KeyError(f"{score_path} is missing columns: {sorted(missing)}")
        for score_name, group in scores.groupby("Score name", sort=False):
            aligned = metadata.set_index("Sample").loc[group["Sample"]].reset_index()
            if len(group) != len(aligned):
                raise ValueError(f"Score {score_name} is not complete in {score_path}.")
            rows.append(treatment_score_test(
                aligned,
                group["Score"].reset_index(drop=True),
                score_name=f"{model_directory}:{score_name}",
                n_mouse_permutations=n_mouse_permutations,
            ))
    output_root.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_root / "treatment_tests.csv", index=False)
    folds = mouse_grouped_folds(metadata)
    pd.DataFrame([
        {"fold": number, "n_train": len(train), "n_test": len(test), "train_mice": ";".join(sorted(metadata.iloc[train]["Mouse number"].unique()))}
        for number, (train, test) in enumerate(folds)
    ]).to_csv(output_root / "grouped_folds.csv", index=False)
    null_calibration(metadata, n_datasets=calibration_datasets).to_csv(
        output_root / "null_calibration.csv", index=False
    )
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--mouse-permutations", type=int, default=9_999)
    parser.add_argument("--calibration-datasets", type=int, default=200)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    run_integration_tests(
        args.project_root,
        n_mouse_permutations=args.mouse_permutations,
        calibration_datasets=args.calibration_datasets,
        overwrite=args.overwrite,
    )
