"""Generate the missingness overview and confounding report."""

from __future__ import annotations

from pathlib import Path
import json

import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import numpy as np
import pandas as pd

from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import full_lipidomics_metadata
from ..plotting import apply_plot_style, save_figure, BIO_GROUP_COLORS, SEX_COLORS, BRAIN_REGION_COLORS, COLORBLIND_COLORS
from ..preprocessing import (
    exclude_nonpositive,
    exclude_blank_dominated_features,
    below_detection_reasons,
    exclude_below_detection,
    exclude_low_prevalence_features,
)
from ..qc import missingness

def write_json(path: Path, data: dict):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def main():
    apply_plot_style()

    out_dir = Path("results/mia_vs_control/02_qc/missingness")
    out_dir.mkdir(parents=True, exist_ok=True)
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load data
    data_path = Path("data/1 MB2_088_Lalowski_Report_Final.xlsx")
    sample_sheet, lipidomics = read_lipidomics_tables(data_path)
    sample_columns, blank_columns, techmix_columns = lipidomics_measurement_columns(lipidomics)

    metadata = full_lipidomics_metadata(sample_sheet, sample_columns)

    # Keep integer index for intensity/blanks, extract annotations separately
    raw_intensity = lipidomics.loc[:, sample_columns].apply(pd.to_numeric, errors="coerce")
    raw_blank = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")

    lipid_annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    lipid_annotations.index = lipidomics.index
    lipid_annotations.index.name = "Feature"

    raw_intensity.index = lipid_annotations.index
    raw_blank.index = lipid_annotations.index

    # Raw pre-filter state: non-positive mapped to NaN
    intensity = exclude_nonpositive(raw_intensity)

    # =========================================================================
    # Part 1: Raw missingness overview
    # =========================================================================

    feat_missing = missingness.missingness_by_feature(intensity, lipid_annotations)
    feat_missing.to_csv(out_dir / "missingness_by_lipid.csv", index=False)

    sample_missing = missingness.missingness_by_sample(intensity, metadata)
    sample_missing.to_csv(out_dir / "missingness_by_sample.csv", index=False)

    overall_cells_missing = intensity.isna().sum().sum()
    overall_total_cells = intensity.size
    pct_cells_missing = (overall_cells_missing / overall_total_cells) * 100

    pct_lipids_complete = (feat_missing["n_missing"] == 0).mean() * 100
    pct_samples_complete = (sample_missing["n_missing"] == 0).mean() * 100
    pct_lipids_fully_missing = (feat_missing["n_missing"] == intensity.shape[1]).mean() * 100

    pd.DataFrame([{
        "pct_cells_missing": pct_cells_missing,
        "pct_lipids_fully_complete": pct_lipids_complete,
        "pct_samples_fully_complete": pct_samples_complete,
        "pct_lipids_fully_missing": pct_lipids_fully_missing
    }]).to_csv(out_dir / "missingness_summary.csv", index=False)

    # Figure: Lipid histogram
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.hist(feat_missing["pct_missing"], bins=30, color=COLORBLIND_COLORS[0])
    ax.set_yscale("log")
    ax.set(xlabel="Missingness per lipid (%)", ylabel="Count")
    save_figure(fig, fig_dir / "missingness_per_lipid_histogram")
    plt.close(fig)

    # Figure: Sample histogram, colored by Bio group
    fig, ax = plt.subplots(figsize=(6, 4))
    for group, color in BIO_GROUP_COLORS.items():
        subset = sample_missing[sample_missing["Bio group"] == group]
        ax.hist(subset["pct_missing"], bins=15, alpha=0.6, label=group, color=color)
    ax.set(xlabel="Missingness per sample (%)", ylabel="Count")
    ax.legend(frameon=False)
    save_figure(fig, fig_dir / "missingness_per_sample_histogram")
    plt.close(fig)

    # Figure: Heatmap
    lipids_with_missing = feat_missing[feat_missing["n_missing"] > 0]["Feature"].tolist()
    if lipids_with_missing:
        heatmap_data = intensity.loc[lipids_with_missing].notna().astype(int)

        annot_sub = lipid_annotations.loc[lipids_with_missing].sort_values("Lipid Class")
        heatmap_data = heatmap_data.loc[annot_sub.index]

        meta_sorted = metadata.sort_values(["Bio group", "Sex", "Sample type"])
        heatmap_data = heatmap_data[meta_sorted["Sample"]]

        import matplotlib.patches as mpatches
        from matplotlib.gridspec import GridSpec

        fig = plt.figure(figsize=(12, 8))
        gs = GridSpec(3, 1, height_ratios=[0.02, 0.02, 1], hspace=0.05)
        ax_bio = fig.add_subplot(gs[0])
        ax_sex = fig.add_subplot(gs[1])
        ax_main = fig.add_subplot(gs[2])

        bio_colors = meta_sorted["Bio group"].map(BIO_GROUP_COLORS).tolist()
        sex_colors = meta_sorted["Sex"].map(SEX_COLORS).tolist()

        from matplotlib.colors import to_rgba
        bio_rgba = np.array([to_rgba(c) for c in bio_colors])[np.newaxis, ...]
        sex_rgba = np.array([to_rgba(c) for c in sex_colors])[np.newaxis, ...]

        ax_bio.imshow(bio_rgba, aspect='auto')
        ax_sex.imshow(sex_rgba, aspect='auto')

        ax_bio.set_xticks([])
        ax_bio.set_yticks([])
        ax_bio.set_ylabel("Bio group ", rotation=0, ha='right', va='center', fontsize=9)

        ax_sex.set_xticks([])
        ax_sex.set_yticks([])
        ax_sex.set_ylabel("Sex ", rotation=0, ha='right', va='center', fontsize=9)

        cmap = ListedColormap(["#f0f0f0", COLORBLIND_COLORS[0]])
        im = ax_main.imshow(heatmap_data, cmap=cmap, aspect='auto', interpolation='none')
        ax_main.set(ylabel=f"Lipids with any missingness (n={len(lipids_with_missing)})", xlabel="Samples (n=60)")
        ax_main.set_xticks([])
        ax_main.set_yticks([])

        patches = [mpatches.Patch(color=c, label=l) for l, c in BIO_GROUP_COLORS.items()]
        patches += [mpatches.Patch(color=c, label=l) for l, c in SEX_COLORS.items()]
        ax_main.legend(handles=patches, bbox_to_anchor=(1.02, 1.05), loc='upper left', borderaxespad=0., frameon=False)

        save_figure(fig, fig_dir / "missingness_heatmap")
        plt.close(fig)

        # Second heatmap: Region first, then Bio group
        meta_sorted_region = metadata.sort_values(["Sample type", "Bio group"])
        heatmap_data_region = intensity.loc[lipids_with_missing].notna().astype(int)
        heatmap_data_region = heatmap_data_region.loc[annot_sub.index]
        heatmap_data_region = heatmap_data_region[meta_sorted_region["Sample"]]

        fig2 = plt.figure(figsize=(12, 8))
        gs2 = GridSpec(3, 1, height_ratios=[0.02, 0.02, 1], hspace=0.05)
        ax_reg2 = fig2.add_subplot(gs2[0])
        ax_bio2 = fig2.add_subplot(gs2[1])
        ax_main2 = fig2.add_subplot(gs2[2])

        reg_colors2 = meta_sorted_region["Sample type"].map(BRAIN_REGION_COLORS).tolist()
        bio_colors2 = meta_sorted_region["Bio group"].map(BIO_GROUP_COLORS).tolist()

        reg_rgba2 = np.array([to_rgba(c) for c in reg_colors2])[np.newaxis, ...]
        bio_rgba2 = np.array([to_rgba(c) for c in bio_colors2])[np.newaxis, ...]

        ax_reg2.imshow(reg_rgba2, aspect='auto')
        ax_bio2.imshow(bio_rgba2, aspect='auto')

        ax_reg2.set_xticks([])
        ax_reg2.set_yticks([])
        ax_reg2.set_ylabel("Region ", rotation=0, ha='right', va='center', fontsize=9)

        ax_bio2.set_xticks([])
        ax_bio2.set_yticks([])
        ax_bio2.set_ylabel("Bio group ", rotation=0, ha='right', va='center', fontsize=9)

        im2 = ax_main2.imshow(heatmap_data_region, cmap=cmap, aspect='auto', interpolation='none')
        ax_main2.set(ylabel=f"Lipids with any missingness (n={len(lipids_with_missing)})", xlabel="Samples (n=60)")
        ax_main2.set_xticks([])
        ax_main2.set_yticks([])

        patches2 = [mpatches.Patch(color=c, label=l) for l, c in BRAIN_REGION_COLORS.items()]
        patches2 += [mpatches.Patch(color=c, label=l) for l, c in BIO_GROUP_COLORS.items()]
        ax_main2.legend(handles=patches2, bbox_to_anchor=(1.02, 1.05), loc='upper left', borderaxespad=0., frameon=False)

        save_figure(fig2, fig_dir / "missingness_heatmap_by_region")
        plt.close(fig2)

    # =========================================================================
    # Part 2: Confounding Check
    # =========================================================================

    # Bio group
    group_summary = missingness.missingness_by_group(sample_missing, "Bio group")
    group_test = missingness.test_missingness_by_group(sample_missing, "Bio group", "MIA", "Saline Control")
    group_summary.to_csv(out_dir / "missingness_by_sample_and_group.csv", index=False)
    write_json(out_dir / "missingness_by_sample_and_group_test.json", group_test)

    # Region and Sex
    region_summary = missingness.missingness_by_group(sample_missing, "Sample type")
    region_summary.to_csv(out_dir / "missingness_by_sample_and_region.csv", index=False)
    sex_summary = missingness.missingness_by_group(sample_missing, "Sex")
    sex_summary.to_csv(out_dir / "missingness_by_sample_and_sex.csv", index=False)

    # Class x Group Fisher tests
    class_group_sum = missingness.missingness_by_class_and_group(intensity, lipid_annotations, metadata, "Bio group")
    class_fisher = missingness.fisher_test_by_class(class_group_sum, "Bio group", "MIA", "Saline Control")
    class_group_sum.to_csv(out_dir / "missingness_by_class_and_group_summary.csv", index=False)
    class_fisher.to_csv(out_dir / "missingness_by_class_and_group.csv", index=False)

    # Figure: Box/strip plot per Region
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharey=True)
    regions = ["Cortex", "Cerebellum", "Hippocampus"]
    for i, region in enumerate(regions):
        ax = axes[i]
        subset = sample_missing[sample_missing["Sample type"] == region]

        # Plot Saline Control and MIA
        for j, group in enumerate(["Saline Control", "MIA"]):
            grp_data = subset[subset["Bio group"] == group]["pct_missing"]
            color = BIO_GROUP_COLORS[group]

            # Boxplot
            ax.boxplot(grp_data, positions=[j], widths=0.5, patch_artist=True,
                       boxprops=dict(facecolor=color, alpha=0.5, color=color),
                       capprops=dict(color=color),
                       whiskerprops=dict(color=color),
                       medianprops=dict(color="black", linewidth=1.5),
                       showfliers=False)

            # Stripplot
            jitter = np.random.normal(0, 0.05, size=len(grp_data))
            ax.scatter(np.repeat(j, len(grp_data)) + jitter, grp_data,
                       color=color, alpha=0.8, edgecolors='none', zorder=3)

        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Saline Control", "MIA"])
        ax.set(title=region, ylabel="Missingness per sample (%)" if i == 0 else "")
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    plt.tight_layout()
    save_figure(fig, fig_dir / "missingness_by_region_and_group")
    plt.close(fig)

    # =========================================================================
    # Part 3: Filter Impacts
    # =========================================================================

    intensity_blank_filtered = exclude_blank_dominated_features(intensity, raw_blank)

    reasons = below_detection_reasons(intensity_blank_filtered, raw_blank.loc[intensity_blank_filtered.index])
    intensity_det_filtered = exclude_below_detection(intensity_blank_filtered, raw_blank.loc[intensity_blank_filtered.index])

    intensity_prev_filtered = exclude_low_prevalence_features(intensity_det_filtered, max_missing_fraction=0.20)

    # 3.1 Value-level (below detection masking)
    mask = reasons.notna()
    long_reasons = mask.rename_axis(index="Feature", columns="Sample").stack().reset_index(name="reason")
    long_reasons = long_reasons.merge(metadata[["Sample", "Bio group", "Sample type"]], on="Sample", how="left")

    mask_counts = long_reasons.groupby(["Bio group", "Sample type"]).size().reset_index(name="n_masked_cells")

    mask_pct = []
    n_features = intensity_blank_filtered.shape[0]
    for _, row in mask_counts.iterrows():
        bg = row["Bio group"]
        st = row["Sample type"]
        n_samps = metadata[(metadata["Bio group"] == bg) & (metadata["Sample type"] == st)].shape[0]
        tot = n_features * n_samps
        mask_pct.append((row["n_masked_cells"] / tot) * 100 if tot > 0 else 0)
    mask_counts["pct_masked_cells"] = mask_pct
    mask_counts.to_csv(out_dir / "detection_limit_masking_by_group.csv", index=False)

    # 3.2 Blank-dominated
    removed_blank = set(intensity.index) - set(intensity_blank_filtered.index)
    if removed_blank:
        blank_medians = []
        numeric_intensity = raw_intensity.loc[list(removed_blank)]
        for lip in removed_blank:
            lip_name = lipid_annotations.loc[lip, "Lipid Name"]
            mia_samps = metadata[metadata["Bio group"] == "MIA"]["Sample"]
            ctrl_samps = metadata[metadata["Bio group"] == "Saline Control"]["Sample"]

            med_mia = numeric_intensity.loc[lip, mia_samps].where(numeric_intensity.loc[lip, mia_samps] > 0).median(skipna=True)
            med_ctrl = numeric_intensity.loc[lip, ctrl_samps].where(numeric_intensity.loc[lip, ctrl_samps] > 0).median(skipna=True)

            blank_medians.append({
                "Feature": lip_name,
                "median_intensity_MIA": med_mia,
                "median_intensity_Saline_Control": med_ctrl
            })
        pd.DataFrame(blank_medians).to_csv(out_dir / "blank_dominated_medians_by_group.csv", index=False)
    else:
        pd.DataFrame(columns=["Feature", "median_intensity_MIA", "median_intensity_Saline_Control"]).to_csv(out_dir / "blank_dominated_medians_by_group.csv", index=False)

    # 3.3 Prevalence filter
    removed_prev = set(intensity_det_filtered.index) - set(intensity_prev_filtered.index)
    if removed_prev:
        prev_breakdown = []
        mia_samps = metadata[metadata["Bio group"] == "MIA"]["Sample"]
        ctrl_samps = metadata[metadata["Bio group"] == "Saline Control"]["Sample"]

        for lip in removed_prev:
            lip_name = lipid_annotations.loc[lip, "Lipid Name"]
            n_mia = intensity_det_filtered.loc[lip, mia_samps].isna().sum()
            n_ctrl = intensity_det_filtered.loc[lip, ctrl_samps].isna().sum()

            pct_mia = (n_mia / len(mia_samps)) * 100
            pct_ctrl = (n_ctrl / len(ctrl_samps)) * 100

            prev_breakdown.append({
                "Feature": lip_name,
                "n_missing_MIA": n_mia,
                "pct_missing_MIA": pct_mia,
                "n_missing_Saline_Control": n_ctrl,
                "pct_missing_Saline_Control": pct_ctrl
            })
        pd.DataFrame(prev_breakdown).to_csv(out_dir / "prevalence_flagged_by_group.csv", index=False)
    else:
        pd.DataFrame(columns=[
            "Feature", "n_missing_MIA", "pct_missing_MIA",
            "n_missing_Saline_Control", "pct_missing_Saline_Control"
        ]).to_csv(out_dir / "prevalence_flagged_by_group.csv", index=False)

    # 3.4 Stage summary
    stages = [
        ("Raw", intensity),
        ("Blank-filtered", intensity_blank_filtered),
        ("Detection-masked", intensity_det_filtered),
        ("Prevalence-filtered", intensity_prev_filtered)
    ]

    stage_summary = missingness.filtering_stage_summary(intensity, stages, metadata, "Bio group", "MIA", "Saline Control")
    stage_summary.to_csv(out_dir / "filtering_stage_summary.csv", index=False)

if __name__ == "__main__":
    main()
