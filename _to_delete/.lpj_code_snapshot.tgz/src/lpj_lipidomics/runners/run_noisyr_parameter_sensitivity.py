"""Explore panel-scaled noisyR windows without altering the manual QC method."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..config import (
    NOISYR_MIN_COMPARATORS_PER_REFERENCE,
    NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
    NOISYR_MIN_PAIRWISE_OBSERVATIONS,
    NOISYR_STEP_FEATURES,
    NOISYR_SUSTAINED_WINDOWS,
    NOISYR_WINDOW_FRACTION,
    NOISYR_WINDOW_FRACTIONS,
    NOISYR_WINDOW_MIN_FEATURES,
)
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, full_lipidomics_metadata, lipid_feature_rows
from ..noisyr import panel_scaled_window_parameters, run_noisyr, threshold_median
from ..plotting import COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import exclude_below_detection, exclude_nonpositive, log2_transform
from ..qc.abundance_similarity import abundance_similarity_curve


# Retained as a simple exported description of the sensitivity grid.
PARAMETERS = tuple(
    (fraction, step)
    for fraction in NOISYR_WINDOW_FRACTIONS
    for step in NOISYR_STEP_FEATURES
)


def _plot_sensitivity(
    label: str,
    input_arm: str,
    manual_curve: pd.DataFrame,
    noisy_curves: list[tuple[str, pd.DataFrame]],
    output_dir: Path,
) -> None:
    figure, axis = plt.subplots(figsize=(8, 5.5))
    axis.plot(
        manual_curve["median_log2_abundance"],
        manual_curve["median_pearson"],
        color="#222222",
        linewidth=2,
        label="Manual",
    )
    for number, (parameter_label, curve) in enumerate(noisy_curves):
        axis.plot(
            curve["median_log2_abundance"],
            curve["median_pearson"],
            color=COLORBLIND_COLORS[number % len(COLORBLIND_COLORS)],
            alpha=0.7,
            label=parameter_label,
        )
    axis.axhline(0.25, color="#777777", linestyle="--", linewidth=0.8)
    axis.set(
        xlabel="Log2 positive raw peak area",
        ylabel="Correlation",
        ylim=(-1, 1),
        title=f"noisyR panel-scaled window sensitivity: {label} ({input_arm})",
    )
    axis.legend(frameon=True, ncol=2, fontsize=7)
    figure.tight_layout()
    suffix = "" if input_arm == "raw" else f"_{input_arm}"
    save_figure(figure, output_dir / f"noisyr_window_sensitivity_{label}{suffix}")
    plt.close(figure)


def run_noisyr_parameter_sensitivity(project_root: Path) -> None:
    """Write raw and detection-masked panel-scaled window sensitivities."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, report = read_lipidomics_tables(workbook)
    samples, blank_columns, techmix = lipidomics_measurement_columns(report)
    metadata = full_lipidomics_metadata(sample_sheet, samples)
    features = lipid_feature_rows(report)
    raw = features.loc[:, samples].apply(pd.to_numeric, errors="raise")
    raw_blanks = features.loc[:, blank_columns].apply(pd.to_numeric, errors="raise")
    techmix_raw = features.loc[:, techmix].apply(pd.to_numeric, errors="raise")
    positive = exclude_nonpositive(raw)
    positive_techmix = exclude_nonpositive(techmix_raw)
    masked = exclude_below_detection(positive, raw_blanks)
    masked_techmix = exclude_below_detection(positive_techmix, raw_blanks)

    output = project_root / "results" / "mia_vs_control" / "02_qc" / "noisyr_parameter_sensitivity"
    work_dir = output / "work"
    figure_dir = output / "figures"
    work_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    manifest: dict[str, object] = {
        "window_fraction": NOISYR_WINDOW_FRACTION,
        "window_floor_features": NOISYR_WINDOW_MIN_FEATURES,
        "step_features": list(NOISYR_STEP_FEATURES),
        "sensitivity_window_fractions": list(NOISYR_WINDOW_FRACTIONS),
        "min_pairwise_observations": NOISYR_MIN_PAIRWISE_OBSERVATIONS,
        "min_comparators_per_reference": NOISYR_MIN_COMPARATORS_PER_REFERENCE,
        "sustained_windows": NOISYR_SUSTAINED_WINDOWS,
        "scopes": {},
    }
    scopes = [
        (
            region.lower(),
            positive.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]],
            masked.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]],
        )
        for region in REGIONS
    ]
    scopes.append(("techmix", positive_techmix, masked_techmix))

    for label, raw_values, masked_values in scopes:
        scope_manifest: dict[str, object] = {
            "n_features": len(raw_values),
            "window_parameters": {},
        }
        for input_arm, values in (("raw", raw_values), ("detection_masked", masked_values)):
            log_values = log2_transform(values)
            base_window, base_step = panel_scaled_window_parameters(
                len(values),
                NOISYR_WINDOW_FRACTION,
                minimum_features=NOISYR_WINDOW_MIN_FEATURES,
            )
            manual = abundance_similarity_curve(
                log_values,
                window_size=base_window,
                step=base_step,
                min_pairwise_correlations_per_point=NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
                min_comparators_per_reference=NOISYR_MIN_COMPARATORS_PER_REFERENCE,
                min_pairwise_observations=NOISYR_MIN_PAIRWISE_OBSERVATIONS,
            )
            noisy_curves: list[tuple[str, pd.DataFrame]] = []
            for fraction in NOISYR_WINDOW_FRACTIONS:
                window_size, _ = panel_scaled_window_parameters(
                    len(values),
                    fraction,
                    minimum_features=NOISYR_WINDOW_MIN_FEATURES,
                )
                scope_manifest["window_parameters"][str(fraction)] = {
                    "window_size": window_size,
                    "window_fraction_realized": window_size / len(values),
                }
                for step in NOISYR_STEP_FEATURES:
                    curve, thresholds, status = run_noisyr(
                        log_values,
                        work_dir,
                        label if input_arm == "raw" else f"detection_masked_{label}",
                        project_root,
                        window=window_size,
                        step=step,
                    )
                    threshold = threshold_median(thresholds, status)
                    if curve is None:
                        n_curve_points = 0
                        n_curve_points_below_full_pairwise_set = np.nan
                    else:
                        n_curve_points = len(curve)
                        full_pairwise_set = len(values.columns) * (len(values.columns) - 1)
                        n_curve_points_below_full_pairwise_set = int(
                            curve["n_pairwise_correlations"].lt(full_pairwise_set).sum()
                        )
                    rows.append({
                        "scope": label,
                        "input_arm": input_arm,
                        "window_fraction": fraction,
                        "window_floor_features": NOISYR_WINDOW_MIN_FEATURES,
                        "window_fraction_realized": window_size / len(values),
                        "window_features": window_size,
                        "step_features": step,
                        "step_fraction_of_window": step / window_size,
                        "status": status,
                        "threshold_log2_abundance_median": threshold,
                        "n_curve_points": n_curve_points,
                        "n_curve_points_below_full_pairwise_set": n_curve_points_below_full_pairwise_set,
                        "n_features_input": len(values),
                        "n_missing_input_cells": int(values.isna().sum().sum()),
                        "min_pairwise_observations": NOISYR_MIN_PAIRWISE_OBSERVATIONS,
                        "min_comparators_per_reference": NOISYR_MIN_COMPARATORS_PER_REFERENCE,
                        "input_definition": (
                            "log2 positive raw peak areas before detection-limit filtering"
                            if input_arm == "raw"
                            else "log2 positive raw peak areas after empirical per-lipid detection-limit masking"
                        ),
                    })
                    if status == "completed" and curve is not None:
                        noisy_curves.append((f"f={fraction:g}, s={step}", curve))
            _plot_sensitivity(label, input_arm, manual, noisy_curves, figure_dir)
        manifest["scopes"][label] = scope_manifest

    pd.DataFrame(rows).to_csv(output / "noisyr_parameter_sensitivity.csv", index=False)
    with (output / "noisyr_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    run_noisyr_parameter_sensitivity(Path(__file__).resolve().parents[3])
