"""Recalibrate Mahalanobis without repeating completed detector fits."""

from __future__ import annotations

from pathlib import Path

from .run_outlier_ensemble import recalibrate_existing_mahalanobis


def run_mahalanobis_calibration_fix(project_root: Path) -> list[Path]:
    """Update Mahalanobis rows and dependent ensemble outputs from cached tables."""
    return recalibrate_existing_mahalanobis(project_root)


if __name__ == "__main__":
    run_mahalanobis_calibration_fix(Path(__file__).resolve().parents[3])
