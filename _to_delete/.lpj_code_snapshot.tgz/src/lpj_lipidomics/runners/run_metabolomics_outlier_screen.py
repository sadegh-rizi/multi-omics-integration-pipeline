"""Run the pre-specified metabolomics and cross-modality outlier screen."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import beta, f

from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.metabolomics import metabolomics_measurement_columns, metabolomics_sample_numbers, read_metabolomics_tables
from ..io.study_design import REGIONS, full_lipidomics_metadata, metabolomics_metadata
from ..metabolomics_preprocessing import preprocess_metabolomics
from ..multivariate.pca import fit_pca
from ..outliers.screen import dmodx
from ..plotting import apply_plot_style, save_figure
from ..preprocessing import preprocess_for_multivariate
from ..qc.cross_modality import SHARED_PROVENANCE_CAVEAT, concordance_table


N_COMPONENTS = 3


def _diagnostics(values: pd.DataFrame, metadata: pd.DataFrame, region: str) -> pd.DataFrame:
    complete = values.loc[:, metadata["Sample"]].dropna(axis=0, how="any")
    if N_COMPONENTS >= min(complete.shape) or len(metadata) <= N_COMPONENTS + 1:
        raise ValueError(f"{region}: insufficient rank for a {N_COMPONENTS}-PC screen.")
    model, scores, _ = fit_pca(complete, n_components=N_COMPONENTS)
    centered = scores.to_numpy(dtype=float) - scores.to_numpy(dtype=float).mean(axis=0)
    t2 = np.einsum("ij,jk,ik->i", centered, np.linalg.pinv(np.cov(centered, rowvar=False)), centered)
    n_samples, n_components = scores.shape
    t2_limit = (n_samples - 1) ** 2 / n_samples * beta.ppf(0.95, n_components / 2, (n_samples - n_components - 1) / 2)
    raw_dmodx = dmodx(complete, model)
    normalized_dmodx = raw_dmodx / np.sqrt(np.mean(raw_dmodx.pow(2)))
    dmodx_limit = float(np.sqrt(f.ppf(0.95, complete.shape[0] - n_components, (complete.shape[0] - n_components) * (n_samples - n_components - 1))))
    table = metadata.set_index("Sample").loc[scores.index].copy()
    table["Region"] = region
    table["hotelling_t2"] = t2
    table["hotelling_t2_95_limit"] = t2_limit
    table["hotelling_t2_95_flag"] = table["hotelling_t2"].gt(t2_limit)
    table["normalized_dmodx"] = normalized_dmodx
    table["dmodx_95_limit"] = dmodx_limit
    table["normalized_dmodx_95_flag"] = table["normalized_dmodx"].gt(dmodx_limit)
    for statistic in ("hotelling_t2", "normalized_dmodx"):
        table[f"{statistic}_rank_descending"] = table[statistic].rank(ascending=False, method="min").astype(int)
        table[f"{statistic}_percentile"] = table[statistic].rank(pct=True, method="max")
    return table.reset_index()


def _plot_influence(table: pd.DataFrame, path: Path) -> None:
    figure, axis = plt.subplots(figsize=(6.5, 5.5))
    axis.scatter(table["hotelling_t2"], table["normalized_dmodx"], color="#0072B2")
    for _, row in table.iterrows():
        axis.annotate(str(int(row["Sample number"])), (row["hotelling_t2"], row["normalized_dmodx"]), fontsize=7)
    axis.axvline(table["hotelling_t2_95_limit"].iat[0], color="#D55E00", linestyle="--", label="95% limits")
    axis.axhline(table["dmodx_95_limit"].iat[0], color="#D55E00", linestyle="--")
    axis.set(xlabel="Hotelling T2 (3 PCs)", ylabel="Normalised DModX (3 PCs)", title=f"{table['Region'].iat[0]}: PCA influence plot")
    axis.legend(frameon=False)
    figure.tight_layout()
    save_figure(figure, path)
    plt.close(figure)


def _plot_concordance(table: pd.DataFrame, path: Path) -> None:
    counts = table.groupby(["lipidomics_flag", "metabolomics_flag"])["n_samples"].sum()
    matrix = np.array([[counts.get((False, False), 0), counts.get((False, True), 0)], [counts.get((True, False), 0), counts.get((True, True), 0)]])
    figure, axis = plt.subplots(figsize=(5.8, 5.2))
    image = axis.imshow(matrix, cmap="Blues")
    for (row, column), count in np.ndenumerate(matrix):
        axis.text(column, row, str(count), ha="center", va="center", fontsize=14)
    statistic = table["statistic"].iat[0]
    expected = table["expected_concordant_under_independence"].iat[0]
    axis.set(
        xticks=[0, 1], xticklabels=["not flagged", "flagged"],
        yticks=[0, 1], yticklabels=["not flagged", "flagged"],
        xlabel="Metabolomics 95% flag", ylabel="Lipidomics 95% flag",
        title=f"{statistic}: regional concordance\nExpected joint flags under independence: {expected:g}",
    )
    figure.colorbar(image, ax=axis, label="Samples")
    figure.text(0.01, 0.01, SHARED_PROVENANCE_CAVEAT, ha="left", va="bottom", fontsize=7, wrap=True)
    figure.tight_layout(rect=(0, 0.11, 1, 1))
    save_figure(figure, path)
    plt.close(figure)


def run_metabolomics_outlier_screen(project_root: Path) -> list[Path]:
    """Write Part A preprocessing, outlier, vendor, and concordance outputs."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, metabolomics = read_metabolomics_tables(workbook)
    samples, blanks, _ = metabolomics_measurement_columns(metabolomics)
    raw = metabolomics.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    values, preprocessing_diagnostics, blank_features, mode_medians = preprocess_metabolomics(
        raw, metabolomics.loc[:, blanks], metabolomics["Method"],
    )
    preprocessing_dir = project_root / "results" / "metabolomics" / "01_preprocessing"
    preprocessing_dir.mkdir(parents=True, exist_ok=True)
    paths = [preprocessing_dir / "metabolomics_preprocessing_diagnostics.csv", preprocessing_dir / "blank_dominated_features.csv", preprocessing_dir / "mode_sample_log2_medians.csv"]
    preprocessing_diagnostics.to_csv(paths[0], index=False)
    blank_features.to_csv(paths[1], index=False)
    mode_medians.to_csv(paths[2])

    metadata = metabolomics_metadata(
        sample_sheet,
        samples,
        zero_padded=False,
        include_tissue_mass=False,
    )
    _ = metabolomics_sample_numbers(samples)  # Validates the integer cross-assay join key.
    qc_dir = project_root / "results" / "metabolomics" / "02_qc"
    metabolic_tables = []
    for region, regional_metadata in metadata.groupby("Sample type", sort=False, observed=True):
        table = _diagnostics(values, regional_metadata, region)
        path = qc_dir / f"outlier_screen_{region.lower()}.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        table.to_csv(path, index=False)
        _plot_influence(table, qc_dir / "figures" / f"influence_t2_vs_dmodx_{region.lower()}")
        paths.append(path)
        metabolic_tables.append(table)
    pooled = _diagnostics(values, metadata, "Pooled")
    pooled_path = qc_dir / "outlier_screen_pooled.csv"
    pooled.to_csv(pooled_path, index=False)
    _plot_influence(pooled, qc_dir / "figures" / "influence_t2_vs_dmodx_pooled")
    paths.append(pooled_path)

    lipid_sheet, lipidomics = read_lipidomics_tables(workbook)
    lipid_samples, lipid_blanks, _ = lipidomics_measurement_columns(lipidomics)
    lipid_values = preprocess_for_multivariate(lipidomics.loc[:, lipid_samples], lipidomics.loc[:, lipid_blanks])
    lipid_metadata = full_lipidomics_metadata(lipid_sheet, lipid_samples)
    lipid_tables = [_diagnostics(lipid_values, group, region) for region, group in lipid_metadata.groupby("Sample type", sort=False, observed=True)]
    cross_dir = project_root / "results" / "cross_modality"
    cross_dir.mkdir(parents=True, exist_ok=True)
    concordance_tables = []
    for statistic in ("hotelling_t2", "normalized_dmodx"):
        table = concordance_table(pd.concat(lipid_tables), pd.concat(metabolic_tables), statistic)
        path = cross_dir / f"concordance_{statistic}.csv"
        table.to_csv(path, index=False)
        _plot_concordance(table, cross_dir / "figures" / f"concordance_{statistic}")
        paths.append(path)
        concordance_tables.append(table)
    combined_concordance_path = cross_dir / "concordance_table.csv"
    pd.concat(concordance_tables, ignore_index=True).to_csv(combined_concordance_path, index=False)
    paths.append(combined_concordance_path)
    all_metabolomics_diagnostics = pd.concat([*metabolic_tables, pooled], ignore_index=True)
    vendor = all_metabolomics_diagnostics.loc[
        all_metabolomics_diagnostics["Sample number"].eq(26)
    ].copy()
    vendor["vendor_call"] = "Excluded by vendor on metabolomics grounds"
    vendor["interpretation_caveat"] = SHARED_PROVENANCE_CAVEAT
    vendor_path = cross_dir / "vendor_sample26_check.csv"
    vendor.to_csv(vendor_path, index=False)
    paths.append(vendor_path)
    return paths


if __name__ == "__main__":
    run_metabolomics_outlier_screen(Path(__file__).resolve().parents[3])
