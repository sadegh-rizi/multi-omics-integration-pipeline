"""Generate abundance-similarity noise-floor diagnostics without filtering data."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..qc.abundance_similarity import (
    CORRELATION_AGGREGATION,
    DEFAULT_THRESHOLD_RULES,
    NOISYR_COUNT_ORDERING,
    REFERENCE_WINDOW_ABUNDANCE,
    abundance_similarity_curve,
    candidate_thresholds,
    compare_noise_criteria,
)
from ..config import (
    FEATURE_BLANK_MULTIPLIER,
    NOISYR_MIN_COMPARATORS_PER_REFERENCE,
    NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
    NOISYR_MIN_PAIRWISE_OBSERVATIONS,
    NOISYR_SUSTAINED_WINDOWS,
    QC_CV_MIN_INJECTIONS,
    QC_CV_THRESHOLD,
)
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, full_lipidomics_metadata, lipid_annotations, lipid_feature_rows
from ..plotting import BRAIN_REGION_COLORS, COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import exclude_blank_dominated_features, exclude_nonpositive, log2_transform, median_normalize
from ..qc.variance import qc_injection_cv


TECHMIX_REGION = "all"
TECHMIX_REFERENCE_STATUS = "probable_pooled_study_sample_qc_unconfirmed"
WINDOW_SIZE = 100
WINDOW_STEP = 20
PLATEAU_FRACTION = 0.20
CONVERGENCE_TOLERANCE = 0.05

_CURVE_COLUMNS = [
    "source",
    "region",
    "window_index",
    "median_log2_abundance",
    "median_pearson",
    "q25_pearson",
    "q75_pearson",
    "median_spearman",
    "n_reference_samples",
    "n_pairwise_correlations",
    "n_lipids_in_window",
    "median_lipids_in_correlation",
    "window_size",
    "ordering_method",
    "reference_window_abundance",
    "correlation_aggregation",
    "min_comparators_per_reference",
    "min_pairwise_correlations_per_point",
    "min_pairwise_observations",
]

_THRESHOLD_LABELS = {
    "pearson_gt_0_25": "Pearson > 0.25",
    "pearson_gt_0_50": "Pearson > 0.50",
    "pearson_90pct_plateau": "90% plateau",
    "bio_tech_gap_le_0_05": "Abundance-aligned biological-technical gap <= 0.05",
    "pearson_sustained_gt_0_25": "Pearson > 0.25 for 5 consecutive windows",
}


def _variant_curves_and_thresholds(
    biological_values: pd.DataFrame,
    techmix_values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    analysis_variant: str,
    normalization: str,
    window_size: int,
) -> tuple[dict[str, pd.DataFrame], pd.DataFrame, pd.DataFrame]:
    """Calculate all regional biological curves against one Tech-Mix reference curve."""
    techmix_curve = abundance_similarity_curve(
        techmix_values,
        window_size=window_size,
        step=WINDOW_STEP,
        min_pairwise_correlations_per_point=NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
        min_comparators_per_reference=NOISYR_MIN_COMPARATORS_PER_REFERENCE,
        min_pairwise_observations=NOISYR_MIN_PAIRWISE_OBSERVATIONS,
    )
    if techmix_curve.empty:
        raise ValueError("Tech-Mix has no aggregate curve supported by at least 10 pairwise correlations.")

    curves: dict[str, pd.DataFrame] = {}
    threshold_rows: list[pd.DataFrame] = []
    for region in REGIONS:
        regional_metadata = metadata.loc[metadata["Sample type"].eq(region)]
        regional_values = biological_values.loc[:, regional_metadata["Sample"]]
        curve = abundance_similarity_curve(
            regional_values,
            window_size=window_size,
            step=WINDOW_STEP,
            min_pairwise_correlations_per_point=NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
            min_comparators_per_reference=NOISYR_MIN_COMPARATORS_PER_REFERENCE,
            min_pairwise_observations=NOISYR_MIN_PAIRWISE_OBSERVATIONS,
        )
        if curve.empty:
            raise ValueError(f"{region} has no aggregate curve supported by at least 10 pairwise correlations.")
        curves[region] = curve

        thresholds = candidate_thresholds(
            curve,
            technical_curve=techmix_curve,
            rules=DEFAULT_THRESHOLD_RULES,
            plateau_fraction=PLATEAU_FRACTION,
            convergence_tolerance=CONVERGENCE_TOLERANCE,
            sustained_windows=NOISYR_SUSTAINED_WINDOWS,
        )
        thresholds.insert(0, "region", region)
        thresholds.insert(1, "analysis_variant", analysis_variant)
        thresholds["normalization"] = normalization
        thresholds["analysis_population"] = "all 60 samples"
        thresholds["window_size"] = window_size
        thresholds["window_step"] = WINDOW_STEP
        thresholds["ordering_method"] = NOISYR_COUNT_ORDERING
        thresholds["reference_window_abundance"] = REFERENCE_WINDOW_ABUNDANCE
        thresholds["correlation_aggregation"] = CORRELATION_AGGREGATION
        thresholds["min_comparators_per_reference"] = NOISYR_MIN_COMPARATORS_PER_REFERENCE
        thresholds["min_pairwise_correlations_per_point"] = NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT
        thresholds["n_biological_reference_samples"] = len(regional_metadata)
        thresholds["n_biological_directed_pairwise_comparisons"] = len(regional_metadata) * (len(regional_metadata) - 1)
        thresholds["n_techmix_injections"] = techmix_values.shape[1]
        thresholds["n_techmix_directed_pairwise_comparisons"] = techmix_values.shape[1] * (techmix_values.shape[1] - 1)
        thresholds["techmix_reference_status"] = TECHMIX_REFERENCE_STATUS
        thresholds["threshold_peak_area"] = np.where(
            thresholds["normalization"].eq("none") & thresholds["threshold_log2_abundance"].notna(),
            2 ** thresholds["threshold_log2_abundance"],
            np.nan,
        )
        threshold_rows.append(thresholds)

    return curves, techmix_curve, pd.concat(threshold_rows, ignore_index=True)


def _add_window_size_sensitivity(thresholds: pd.DataFrame) -> pd.DataFrame:
    """Attach reported window-size ranges without selecting a stability cutoff."""
    result = thresholds.copy()
    result["window_size_sensitivity_status"] = pd.NA
    result["window_size_threshold_log2_min"] = np.nan
    result["window_size_threshold_log2_max"] = np.nan
    result["window_size_threshold_log2_range"] = np.nan
    window_variants = {"primary", "window_size_50", "window_size_200"}
    window_rows = result.loc[result["analysis_variant"].isin(window_variants)]

    for _, rows in window_rows.groupby(["region", "threshold_rule"], observed=True):
        row_indexes = rows.index
        if set(rows["analysis_variant"]) != window_variants or not rows["status"].eq("found").all():
            result.loc[row_indexes, "window_size_sensitivity_status"] = "not_all_window_sizes_reached"
            continue
        minimum = rows["threshold_log2_abundance"].min()
        maximum = rows["threshold_log2_abundance"].max()
        result.loc[row_indexes, "window_size_sensitivity_status"] = "all_window_sizes_reached"
        result.loc[row_indexes, "window_size_threshold_log2_min"] = minimum
        result.loc[row_indexes, "window_size_threshold_log2_max"] = maximum
        result.loc[row_indexes, "window_size_threshold_log2_range"] = maximum - minimum
    return result


def _plot_region_curve(
    region: str,
    biological_curve: pd.DataFrame,
    techmix_curve: pd.DataFrame,
    thresholds: pd.DataFrame,
    output_dir: Path,
) -> None:
    figure, axis = plt.subplots(figsize=(8.5, 5.4))
    biological_color, technical_color = COLORBLIND_COLORS[:2]

    axis.plot(
        biological_curve["median_log2_abundance"],
        biological_curve["median_pearson"],
        color=biological_color,
        linewidth=2,
        marker="o",
        markersize=3,
        label="Biological samples",
    )
    axis.fill_between(
        biological_curve["median_log2_abundance"],
        biological_curve["q25_pearson"],
        biological_curve["q75_pearson"],
        color=biological_color,
        alpha=0.18,
    )
    axis.plot(
        techmix_curve["median_log2_abundance"],
        techmix_curve["median_pearson"],
        color=technical_color,
        linewidth=2,
        linestyle="--",
        marker="s",
        markersize=3,
        label="Tech-Mix repeatability reference",
    )
    axis.fill_between(
        techmix_curve["median_log2_abundance"],
        techmix_curve["q25_pearson"],
        techmix_curve["q75_pearson"],
        color=technical_color,
        alpha=0.14,
    )

    for color, (_, threshold) in zip(COLORBLIND_COLORS[2:], thresholds.iterrows()):
        if threshold["status"] == "found":
            label = _THRESHOLD_LABELS[threshold["threshold_rule"]]
            persistence = threshold["threshold_persists_through_high_abundance"]
            if pd.notna(persistence) and not bool(persistence):
                label += " (non-persistent)"
            axis.axvline(
                threshold["threshold_log2_abundance"],
                color=color,
                linewidth=1.1,
                linestyle=":",
                label=label,
            )

    axis.axhline(0, color="#777777", linewidth=0.8)
    axis.set(
        xlabel="Median reference-window mean log2 positive raw peak area",
        ylabel="Median correlation across reference samples",
        ylim=(-1, 1),
        title=f"Abundance-similarity curve: {region}",
    )
    axis.legend(frameon=True, loc="best")
    figure.text(
        0.5,
        0.01,
        "Each reference sample is ranked by its own abundance; its window abundance is the arithmetic mean (noisyR count-matrix approach).\n"
        "Bands show the 25th-75th percentile across reference samples. "
        "Gap candidates linearly interpolate Tech-Mix correlation at each biological window abundance within the shared range. "
        "'Non-persistent' means later windows fail the same rule. Tech-Mix provenance is unconfirmed.",
        ha="center",
        fontsize=7.5,
    )
    figure.tight_layout(rect=(0, 0.07, 1, 1))
    save_figure(figure, output_dir / f"abundance_similarity_{region.lower()}")
    plt.close(figure)


def _plot_summary(biological_curves: dict[str, pd.DataFrame], output_dir: Path) -> None:
    figure, axis = plt.subplots(figsize=(8.5, 5.4))
    markers = {"Cerebellum": "o", "Cortex": "s", "Hippocampus": "^"}
    for region in REGIONS:
        curve = biological_curves[region]
        color = BRAIN_REGION_COLORS[region]
        axis.plot(
            curve["median_log2_abundance"],
            curve["median_pearson"],
            color=color,
            linewidth=2,
            marker=markers[region],
            markersize=3,
            label=region,
        )
        axis.fill_between(
            curve["median_log2_abundance"],
            curve["q25_pearson"],
            curve["q75_pearson"],
            color=color,
            alpha=0.12,
        )

    axis.axhline(0, color="#777777", linewidth=0.8)
    axis.set(
        xlabel="Median reference-window mean log2 positive raw peak area",
        ylabel="Median biological correlation across reference samples",
        ylim=(-1, 1),
        title="Abundance-similarity curves by brain region",
    )
    axis.legend(title="Region", frameon=True, loc="best")
    figure.text(
        0.5,
        0.01,
        "Each reference sample is ranked by its own abundance; window abundance is an arithmetic mean and bands show the 25th-75th percentile across reference samples.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output_dir / "abundance_similarity_summary")
    plt.close(figure)


def _overlap_table(
    biological_values: pd.DataFrame,
    metadata: pd.DataFrame,
    annotations: pd.DataFrame,
    primary_thresholds: pd.DataFrame,
    blank_flags: pd.Series,
    cv_table: pd.DataFrame,
) -> pd.DataFrame:
    """Write feature-level flags plus contingency and Jaccard summaries per rule."""
    cv_assessable = cv_table["cv_status"].eq("assessable")
    cv_flags = cv_table["normalized_cv_percent"].gt(QC_CV_THRESHOLD)
    records: list[pd.DataFrame] = []

    for region in REGIONS:
        regional_values = biological_values.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]]
        median_abundance = regional_values.median(axis=1, skipna=True)
        base = pd.DataFrame({
            "median_log2_abundance": median_abundance,
            "blank_dominated": blank_flags,
            "qc_cv_above_30": cv_flags,
            "qc_cv_status": cv_table["cv_status"],
        })
        eligible = cv_assessable & base["median_log2_abundance"].notna()
        eligibility = {
            "region": region,
            "n_features_input": len(base),
            "n_features_eligible": int(eligible.sum()),
            "n_cv_not_assessable": int((~cv_assessable).sum()),
            "n_missing_median_log2_abundance": int(base["median_log2_abundance"].isna().sum()),
        }

        thresholds = primary_thresholds.loc[primary_thresholds["region"].eq(region)]
        for _, threshold in thresholds.iterrows():
            persistence = threshold["threshold_persists_through_high_abundance"]
            if threshold["status"] != "found":
                candidate_interpretation = "threshold_unavailable"
            elif pd.notna(persistence) and bool(persistence):
                candidate_interpretation = "persistent_candidate_threshold"
            else:
                candidate_interpretation = "nonpersistent_candidate_not_a_floor"
            context = {
                "region": region,
                "threshold_rule": threshold["threshold_rule"],
                "threshold_log2_abundance": threshold["threshold_log2_abundance"],
                "threshold_status": threshold["status"],
                "threshold_persists_through_high_abundance": threshold[
                    "threshold_persists_through_high_abundance"
                ],
                "n_later_windows_failing_rule": threshold["n_later_windows_failing_rule"],
                "comparison_alignment": threshold["comparison_alignment"],
                "technical_log2_abundance_at_threshold": threshold[
                    "technical_log2_abundance_at_threshold"
                ],
                "ordering_method": threshold["ordering_method"],
                "reference_window_abundance": threshold["reference_window_abundance"],
                "correlation_aggregation": threshold["correlation_aggregation"],
                "n_abundance_aligned_curve_points": threshold[
                    "n_abundance_aligned_curve_points"
                ],
                "n_biological_points_outside_technical_abundance_range": threshold[
                    "n_biological_points_outside_technical_abundance_range"
                ],
                "candidate_interpretation": candidate_interpretation,
                **eligibility,
            }
            records.append(pd.DataFrame([{**context, "record_type": "eligibility"}]))
            if threshold["status"] != "found":
                records.append(pd.DataFrame([{**context, "record_type": "threshold_unavailable"}]))
                continue

            feature_rows = base.loc[eligible].copy()
            feature_rows["abundance_below_floor"] = feature_rows["median_log2_abundance"].lt(
                threshold["threshold_log2_abundance"]
            )
            feature_rows = feature_rows.join(annotations, how="left")
            feature_rows = feature_rows.rename_axis("Feature").reset_index()
            feature_rows = feature_rows.assign(record_type="feature", **context)
            records.append(feature_rows)

            contingency, jaccard = compare_noise_criteria(
                feature_rows.set_index("Feature")["abundance_below_floor"],
                feature_rows.set_index("Feature")["blank_dominated"],
                feature_rows.set_index("Feature")["qc_cv_above_30"],
            )
            records.append(contingency.assign(record_type="contingency", **context))
            records.append(jaccard.assign(record_type="jaccard", **context))

    return pd.concat(records, ignore_index=True, sort=False)


def _report_curve_diagnostics(
    biological_curves: dict[str, pd.DataFrame],
    techmix_curve: pd.DataFrame,
) -> None:
    """Print pre-specified sanity checks; warnings require review before interpretation."""
    technical_by_abundance = (
        techmix_curve.dropna(subset=["median_log2_abundance", "median_pearson"])
        .loc[:, ["median_log2_abundance", "median_pearson"]]
        .groupby("median_log2_abundance", as_index=False, sort=True)
        .median()
    )
    for region, biological_curve in biological_curves.items():
        abundance_trend = biological_curve["median_log2_abundance"].corr(
            biological_curve["median_pearson"], method="spearman"
        )
        aligned = biological_curve.dropna(
            subset=["median_log2_abundance", "median_pearson"]
        ).copy()
        if len(technical_by_abundance) >= 2:
            aligned = aligned.loc[
                aligned["median_log2_abundance"].between(
                    technical_by_abundance["median_log2_abundance"].min(),
                    technical_by_abundance["median_log2_abundance"].max(),
                    inclusive="both",
                )
            ].copy()
            aligned["technical_median_pearson"] = np.interp(
                aligned["median_log2_abundance"],
                technical_by_abundance["median_log2_abundance"],
                technical_by_abundance["median_pearson"],
            )
        else:
            aligned = aligned.iloc[0:0].assign(technical_median_pearson=pd.Series(dtype=float))
        biological_above_techmix = int(
            aligned["median_pearson"].gt(aligned["technical_median_pearson"]).sum()
        )
        print(
            f"{region}: abundance-correlation Spearman trend={abundance_trend:.3f}; "
            "abundance-aligned windows with biological correlation above Tech-Mix="
            f"{biological_above_techmix}/{len(aligned)}"
        )
        if not np.isfinite(abundance_trend) or abundance_trend <= 0:
            print(f"WARNING: {region} curve is flat or decreasing with abundance; review before interpretation.")
        if aligned.empty:
            print(f"WARNING: {region} has no shared abundance range with the Tech-Mix reference.")
        if biological_above_techmix:
            print(f"WARNING: {region} has biological windows above the Tech-Mix reference; review pairing and input provenance.")


def _report_threshold_diagnostics(
    primary_thresholds: pd.DataFrame,
    thresholds: pd.DataFrame,
) -> None:
    """Print pre-specified threshold-shape and window-size sensitivity warnings."""
    nonpersistent = primary_thresholds.loc[
        primary_thresholds["status"].eq("found")
        & primary_thresholds["threshold_persists_through_high_abundance"].eq(False)
    ]
    for region, rows in nonpersistent.groupby("region", observed=True):
        print(
            f"WARNING: {region} has non-persistent candidate threshold(s): "
            f"{', '.join(rows['threshold_rule'])}."
        )

    window_size_rows = thresholds.loc[
        thresholds["analysis_variant"].eq("primary")
        & thresholds["window_size_sensitivity_status"].eq("not_all_window_sizes_reached")
    ]
    for region, rows in window_size_rows.groupby("region", observed=True):
        print(
            f"WARNING: {region} rule(s) were not reached at every requested window size: "
            f"{', '.join(rows['threshold_rule'])}."
        )


def run_abundance_similarity(project_root: Path) -> None:
    """Generate the report-only abundance-similarity diagnostic and sensitivities."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    qc_dir = project_root / "results" / "mia_vs_control" / "02_qc"
    figure_dir = qc_dir / "figures"
    qc_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    sample_sheet, lipidomics_report = read_lipidomics_tables(workbook)
    sample_columns, blank_columns, techmix_columns = lipidomics_measurement_columns(lipidomics_report)
    lipidomics = lipid_feature_rows(lipidomics_report)
    metadata = full_lipidomics_metadata(sample_sheet, sample_columns)
    if len(metadata) != 60:
        raise ValueError(f"Expected all 60 biological samples, found {len(metadata)}.")
    if set(metadata["Sample type"]) != set(REGIONS):
        raise ValueError(f"Expected regions {REGIONS}, found {sorted(metadata['Sample type'].unique())}.")
    if not metadata.groupby("Sample type", observed=True).size().eq(20).all():
        raise ValueError("Each region must contain 20 biological samples.")
    if metadata["Mouse number"].nunique() != 20:
        raise ValueError("Expected 20 mice in the full analysis population.")
    if not metadata.groupby("Mouse number", observed=True).size().eq(len(REGIONS)).all():
        raise ValueError("Each mouse must contribute one sample to every region.")
    raw = lipidomics.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="raise")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="raise")
    techmix_raw = lipidomics.loc[:, techmix_columns].apply(pd.to_numeric, errors="raise")
    annotations = lipid_annotations(lipidomics)

    biological_log2 = log2_transform(exclude_nonpositive(raw))
    techmix_log2 = log2_transform(exclude_nonpositive(techmix_raw))
    variants = [
        ("primary", biological_log2, techmix_log2, metadata, "none", WINDOW_SIZE),
        ("window_size_50", biological_log2, techmix_log2, metadata, "none", 50),
        ("window_size_200", biological_log2, techmix_log2, metadata, "none", 200),
        (
            "median_normalized",
            median_normalize(biological_log2),
            median_normalize(techmix_log2),
            metadata,
            "median_normalized",
            WINDOW_SIZE,
        ),
    ]

    primary_curves: dict[str, pd.DataFrame] | None = None
    primary_techmix_curve: pd.DataFrame | None = None
    all_thresholds: list[pd.DataFrame] = []
    for variant in variants:
        name, biological_values, technical_values, variant_metadata, normalization, window_size = variant
        curves, techmix_curve, thresholds = _variant_curves_and_thresholds(
            biological_values,
            technical_values,
            variant_metadata,
            analysis_variant=name,
            normalization=normalization,
            window_size=window_size,
        )
        all_thresholds.append(thresholds)
        if name == "primary":
            primary_curves = curves
            primary_techmix_curve = techmix_curve

    if primary_curves is None or primary_techmix_curve is None:
        raise RuntimeError("Primary abundance-similarity curves were not calculated.")

    curve_rows = [
        curve.assign(source="biological", region=region)
        for region, curve in primary_curves.items()
    ]
    curve_rows.append(primary_techmix_curve.assign(source="techmix", region=TECHMIX_REGION))
    curve_table = pd.concat(curve_rows, ignore_index=True).loc[:, _CURVE_COLUMNS]
    curve_table.to_csv(qc_dir / "abundance_similarity_curve.csv", index=False)

    thresholds_table = _add_window_size_sensitivity(pd.concat(all_thresholds, ignore_index=True))
    thresholds_table["n_lipid_feature_rows"] = len(lipidomics)
    thresholds_table["n_nonfeature_report_rows_excluded"] = len(lipidomics_report) - len(lipidomics)
    thresholds_table.to_csv(qc_dir / "abundance_similarity_thresholds.csv", index=False)

    primary_thresholds = thresholds_table.loc[
        thresholds_table["analysis_variant"].eq("primary")
    ].copy()
    blank_filtered = exclude_blank_dominated_features(
        raw, blanks, blank_multiplier=FEATURE_BLANK_MULTIPLIER
    )
    blank_flags = pd.Series(
        ~raw.index.isin(blank_filtered.index), index=raw.index, name="blank_dominated"
    )
    cv_table = qc_injection_cv(techmix_raw, min_injections=QC_CV_MIN_INJECTIONS)
    overlap = _overlap_table(
        biological_log2,
        metadata,
        annotations,
        primary_thresholds,
        blank_flags,
        cv_table,
    )
    overlap.to_csv(qc_dir / "abundance_similarity_filter_overlap.csv", index=False)

    for region in REGIONS:
        _plot_region_curve(
            region,
            primary_curves[region],
            primary_techmix_curve,
            primary_thresholds.loc[primary_thresholds["region"].eq(region)],
            figure_dir,
        )
    _plot_summary(primary_curves, figure_dir)
    _report_curve_diagnostics(primary_curves, primary_techmix_curve)
    _report_threshold_diagnostics(primary_thresholds, thresholds_table)


if __name__ == "__main__":
    run_abundance_similarity(Path(__file__).resolve().parents[3])
