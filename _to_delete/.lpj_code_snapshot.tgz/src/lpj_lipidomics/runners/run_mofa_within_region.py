"""Fit the exploratory multi-group and within-region MOFA+ analyses."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

from ..integration.common import REGIONS, VIEWS, extension_root, load_integration_inputs


N_FACTORS = 15
N_ITERATIONS = 1_000
N_SEEDS = 10
N_SHUFFLES = 20
SEED_START = 20_261_301
LOADING_RECOVERY_THRESHOLD = 0.8


def _recovered_loading_correlations(
    matched: np.ndarray,
    threshold: float = LOADING_RECOVERY_THRESHOLD,
) -> np.ndarray:
    """Keep only factor matches that clear the predeclared recovery threshold."""
    return np.where(matched >= threshold, matched, np.nan)


def _fit_mofa(
    blocks: dict[str, pd.DataFrame],
    metadata: pd.DataFrame,
    *,
    seed: int,
    iterations: int,
    group_names: tuple[str, ...] = REGIONS,
) -> tuple[np.ndarray, list[np.ndarray], list[str], list[np.ndarray]]:
    from mofapy2.run.entry_point import entry_point

    group_indices = [np.flatnonzero(metadata["Sample type"].eq(region).to_numpy()) for region in group_names]
    data = [[blocks[view].iloc[indices].to_numpy(dtype=float) for indices in group_indices] for view in VIEWS]
    sample_names = [[str(sample) for sample in metadata.iloc[indices]["Sample"]] for indices in group_indices]
    model = entry_point()
    model.set_data_matrix(
        data,
        views_names=list(VIEWS),
        groups_names=list(group_names),
        samples_names=sample_names,
        features_names=[[f"{view}::{feature}" for feature in blocks[view].columns.astype(str)] for view in VIEWS],
    )
    model.set_data_options(scale_views=True, center_groups=True)
    model.set_model_options(factors=N_FACTORS, ard_factors=True)
    model.set_train_options(
        iter=iterations,
        startELBO=1,
        freqELBO=1,
        convergence_mode="fast",
        dropR2=0.02,
        seed=seed,
        quiet=True,
        verbose=False,
    )
    model.build()
    model.run()
    expectations = model.model.getExpectations()
    factors = np.asarray(expectations["Z"]["E"], dtype=float)
    weights = [np.asarray(view["E"], dtype=float) for view in expectations["W"]]
    concatenated_samples = [sample for group in sample_names for sample in group]
    return factors, weights, concatenated_samples, group_indices


def _loading_vector(weights: list[np.ndarray]) -> np.ndarray:
    return np.concatenate([
        np.nan_to_num(weight, nan=0.0).ravel()
        for weight in weights
    ])


def _match_loadings(reference: list[np.ndarray], candidate: list[np.ndarray]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    reference_vector = np.column_stack([
        _loading_vector([weight[:, index:index + 1] for weight in reference])
        for index in range(reference[0].shape[1])
    ])
    candidate_vector = np.column_stack([
        _loading_vector([weight[:, index:index + 1] for weight in candidate])
        for index in range(candidate[0].shape[1])
    ])
    correlation = np.corrcoef(reference_vector.T, candidate_vector.T)[: reference_vector.shape[1], reference_vector.shape[1] :]
    correlation = np.nan_to_num(correlation, nan=0.0)
    rows, columns = linear_sum_assignment(-np.abs(correlation))
    matched = np.full(reference_vector.shape[1], np.nan)
    signs = np.ones(reference_vector.shape[1])
    candidate_indices = np.full(reference_vector.shape[1], -1, dtype=int)
    for row, column in zip(rows, columns):
        matched[row] = abs(correlation[row, column])
        signs[row] = 1 if correlation[row, column] >= 0 else -1
        candidate_indices[row] = column
    return matched, signs, candidate_indices


def _variance_table(
    blocks: dict[str, pd.DataFrame],
    factors: np.ndarray,
    weights: list[np.ndarray],
    sample_order: list[str],
    metadata: pd.DataFrame,
) -> pd.DataFrame:
    ordered = metadata.set_index("Sample").loc[sample_order].reset_index()
    rows: list[dict[str, object]] = []
    start = 0
    for region in REGIONS:
        n_samples = int(ordered["Sample type"].eq(region).sum())
        region_factors = factors[start : start + n_samples]
        for view, weight in zip(VIEWS, weights):
            values = blocks[view].set_axis(blocks[view].index.astype(str)).loc[sample_order].to_numpy(dtype=float)
            values = values[start : start + n_samples]
            for factor in range(factors.shape[1]):
                reconstruction = region_factors[:, factor, None] * weight[:, factor][None, :]
                denominator = float(np.square(values - values.mean(axis=0)).sum())
                numerator = float(np.square(reconstruction - reconstruction.mean(axis=0)).sum())
                rows.append({
                    "Region": region,
                    "View": view,
                    "Factor": f"Factor{factor + 1}",
                    "variance_explained": numerator / denominator if denominator else 0.0,
                    "active_in_view": numerator / denominator >= 0.02 if denominator else False,
                })
        start += n_samples
    return pd.DataFrame(rows)


def _top_loading_table(
    weights: list[np.ndarray],
    blocks: dict[str, pd.DataFrame],
    stable: list[int],
    *,
    fraction: float,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for view, weight in zip(VIEWS, weights):
        for factor in stable:
            n_features = max(1, int(np.ceil(weight.shape[0] * fraction)))
            order = np.argsort(np.abs(weight[:, factor]))[::-1][:n_features]
            for rank, position in enumerate(order, start=1):
                rows.append({
                    "View": view,
                    "Factor": f"Factor{factor + 1}",
                    "Feature": blocks[view].columns[position],
                    "Weight": float(weight[position, factor]),
                    "absolute_weight": float(abs(weight[position, factor])),
                    "rank": rank,
                })
    return pd.DataFrame(rows)


def run_mofa_within_region(
    project_root: Path,
    *,
    iterations: int = N_ITERATIONS,
    n_seeds: int = N_SEEDS,
    n_shuffles: int = N_SHUFFLES,
) -> Path:
    blocks, metadata = load_integration_inputs(project_root)
    output_root = extension_root(project_root) / "01_mofa_within_region"
    output_root.mkdir(parents=True, exist_ok=True)
    seeds = tuple(SEED_START + index for index in range(n_seeds))

    runs = [_fit_mofa(blocks, metadata, seed=seed, iterations=iterations) for seed in seeds]
    reference_factors, reference_weights, sample_order, _ = runs[0]
    aligned_factors = [reference_factors]
    aligned_weights = [reference_weights]
    correlations = [np.ones(reference_factors.shape[1])]
    for factors, weights, candidate_samples, _ in runs[1:]:
        candidate_order = [candidate_samples.index(sample) for sample in sample_order]
        reordered_factors = factors[candidate_order]
        matched, signs, candidate_indices = _match_loadings(reference_weights, weights)
        reordered_factors = np.full((len(reordered_factors), reference_factors.shape[1]), np.nan)
        reordered_weights = [np.full((weight.shape[0], reference_factors.shape[1]), np.nan) for weight in weights]
        for reference_index, candidate_index in enumerate(candidate_indices):
            if candidate_index < 0:
                continue
            reordered_factors[:, reference_index] = factors[candidate_order, candidate_index] * signs[reference_index]
            for view_index, weight in enumerate(weights):
                if candidate_index < weight.shape[1]:
                    reordered_weights[view_index][:, reference_index] = weight[:, candidate_index] * signs[reference_index]
        aligned_factors.append(reordered_factors)
        aligned_weights.append(reordered_weights)
        correlations.append(_recovered_loading_correlations(matched))
    correlation_matrix = np.vstack(correlations)
    stable = [index for index in range(reference_factors.shape[1]) if np.isfinite(correlation_matrix[:, index]).sum() >= 8]
    stability = pd.DataFrame([
        {
            "Factor": f"Factor{index + 1}",
            "n_recovered": int(np.isfinite(correlation_matrix[:, index]).sum()),
            "median_absolute_loading_correlation": float(np.nanmedian(correlation_matrix[:, index])),
            "stable_8_of_10": index in stable,
        }
        for index in range(reference_factors.shape[1])
    ])
    score_rows = []
    for index in stable:
        for sample, score in zip(sample_order, reference_factors[:, index]):
            score_rows.append({"Sample": sample, "Score name": f"Factor{index + 1}", "Score": float(score)})
    pd.DataFrame(score_rows).to_csv(output_root / "scores.csv", index=False)
    variance = _variance_table(blocks, reference_factors, reference_weights, sample_order, metadata)
    variance["stable_8_of_10"] = variance["Factor"].str.replace("Factor", "").astype(int).sub(1).isin(stable)
    variance.to_csv(output_root / "variance_explained.csv", index=False)
    stability.to_csv(output_root / "factor_stability.csv", index=False)
    _top_loading_table(reference_weights, blocks, stable, fraction=0.05).to_csv(output_root / "top_features.csv", index=False)
    _top_loading_table(reference_weights, blocks, stable, fraction=0.10).to_csv(
        output_root / "top_features_sensitivity_10pct.csv", index=False
    )

    replication_rows: list[dict[str, object]] = []
    region_weights: dict[str, list[np.ndarray]] = {}
    for region in REGIONS:
        mask = metadata["Sample type"].eq(region)
        region_blocks = {view: block.iloc[mask.to_numpy()].reset_index(drop=True) for view, block in blocks.items()}
        region_metadata = metadata.loc[mask].reset_index(drop=True)
        region_run = _fit_mofa(region_blocks, region_metadata, seed=seeds[0], iterations=iterations, group_names=(region,))
        region_weights[region] = region_run[1]
        replication_rows.append({"Region": region, "n_factors": region_run[0].shape[1]})
    for left_index, left_region in enumerate(REGIONS):
        for right_region in REGIONS[left_index + 1 :]:
            matched, _, _ = _match_loadings(region_weights[left_region], region_weights[right_region])
            replication_rows.append({"Region": f"{left_region} vs {right_region}", "median_loading_correlation": float(np.nanmedian(matched)), "n_matches_ge_0.5": int(np.count_nonzero(matched >= 0.5))})
    pd.DataFrame(replication_rows).to_csv(output_root / "region_replication.csv", index=False)

    shuffle_rows: list[dict[str, object]] = []
    rng = np.random.default_rng(20_261_320)
    for shuffle in range(n_shuffles):
        shuffled = {view: block.copy() for view, block in blocks.items()}
        for region in REGIONS:
            positions = np.flatnonzero(metadata["Sample type"].eq(region).to_numpy())
            for view in VIEWS[1:]:
                shuffled[view].iloc[positions] = shuffled[view].iloc[rng.permutation(positions)].to_numpy()
        _, weights, _, _ = _fit_mofa(shuffled, metadata, seed=20_261_400 + shuffle, iterations=iterations)
        shared = []
        for weight in weights:
            shared.append(float(np.square(weight).sum()))
        shuffle_rows.append({"shuffle": shuffle, "total_weight_energy": sum(shared)})
    pd.DataFrame(shuffle_rows).to_csv(output_root / "pairing_shuffle_negative_control.csv", index=False)
    (output_root / "manifest.json").write_text(json.dumps({
        "analysis": "multi-group and within-region MOFA+ exploratory discovery",
        "regions": list(REGIONS),
        "views": list(VIEWS),
        "initial_factors": N_FACTORS,
        "n_seeds": n_seeds,
        "iterations": iterations,
        "stable_rule": f"recovered in at least 8 of 10 seeded grouped fits by absolute loading correlation >= {LOADING_RECOVERY_THRESHOLD}",
        "loading_recovery_threshold": LOADING_RECOVERY_THRESHOLD,
        "top_loading_fraction": 0.05,
        "top_loading_sensitivity_fraction": 0.10,
        "pairing_shuffles": n_shuffles,
        "litter_leave_out": "Cage is used as the litter proxy; no separate litter field exists",
        "region_replication_rule": "loading correlation >= 0.5 in at least two regions",
    }, indent=2), encoding="utf-8")
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--iterations", type=int, default=N_ITERATIONS)
    parser.add_argument("--n-seeds", type=int, default=N_SEEDS)
    parser.add_argument("--shuffles", type=int, default=N_SHUFFLES)
    args = parser.parse_args()
    run_mofa_within_region(args.project_root, iterations=args.iterations, n_seeds=args.n_seeds, n_shuffles=args.shuffles)
