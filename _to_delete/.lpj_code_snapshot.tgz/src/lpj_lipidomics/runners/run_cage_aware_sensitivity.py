"""Run the declared cage/date sensitivity analyses without replacing primary outputs."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from patsy import PatsyError
import statsmodels.formula.api as smf

from ..config import (
    CAGE_ICC_BOOTSTRAPS,
    CAGE_ICC_RANDOM_SEED,
    CAGE_METADATA_WORKBOOK,
    CAGE_SENSITIVITY_ARMS,
    MIN_PER_CELL,
)
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import analysis_metadata, full_lipidomics_metadata
from ..multivariate.pca import fit_pca
from ..plotting import BIO_GROUP_COLORS, apply_plot_style, save_figure
from ..preprocessing import preprocess_for_differential, preprocess_for_multivariate
from ..statistics.clustered import (
    cage_permutation_ceiling,
    collapse_to_cage_means,
    intraclass_correlation,
    sex_exchangeability_summary,
)
from ..statistics.permutation import run_permutation_null
from .run_mia_vs_control import CAGE_COLORS, CAGE_MARKERS


_GROUP_TERM = "C(BioGroup, Treatment(reference='Saline Control'))[T.MIA]"
_PRIMARY_FORMULA = (
    "value ~ C(BioGroup, Treatment(reference='Saline Control')) * "
    "C(Sex, Treatment(reference='Male'))"
)
_DATE_FORMULA = _PRIMARY_FORMULA + " + C(CollectionCohort)"
_DATE_MATCHED_FORMULA = (
    "value ~ C(BioGroup, Treatment(reference='Saline Control')) + "
    "C(Sex, Treatment(reference='Male'))"
)


def _bh_adjust(p_values: pd.Series) -> pd.Series:
    result = pd.Series(np.nan, index=p_values.index, dtype=float)
    ordered = p_values.dropna().sort_values()
    if ordered.empty:
        return result
    ranks = np.arange(1, len(ordered) + 1)
    adjusted = np.minimum.accumulate((ordered.to_numpy() * len(ordered) / ranks)[::-1])[::-1]
    result.loc[ordered.index] = np.clip(adjusted, 0, 1)
    return result


def _design_frame(values: pd.Series, metadata: pd.DataFrame) -> pd.DataFrame:
    frame = metadata.loc[:, ["Sample", "Bio group", "Sex", "Cage", "Collection cohort"]].copy()
    frame = frame.rename(columns={"Bio group": "BioGroup", "Collection cohort": "CollectionCohort"})
    frame["value"] = pd.to_numeric(values.reindex(frame["Sample"]).to_numpy(), errors="coerce")
    return frame.dropna(subset=["value"])


def _fit_ols_arm(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    region: str,
    arm: str,
    formula: str,
) -> pd.DataFrame:
    """Fit one declared feature-wise OLS sensitivity arm."""
    rows: list[dict[str, object]] = []
    region_metadata = metadata.loc[metadata["Sample type"].eq(region)].copy()
    region_values = values.loc[:, region_metadata["Sample"]]
    for feature, feature_values in region_values.iterrows():
        analysis = _design_frame(feature_values, region_metadata)
        row: dict[str, object] = {
            "Arm": arm,
            "Region": region,
            "Feature": feature,
            "n_usable": len(analysis),
            "formula": formula,
        }
        if set(analysis["BioGroup"]) != {"Saline Control", "MIA"}:
            row["fit_status"] = "not_estimable"
            rows.append(row)
            continue
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                model = smf.ols(formula, data=analysis).fit()
            if _GROUP_TERM not in model.params:
                row["fit_status"] = "not_estimable"
            elif model.df_resid <= 0 or not np.isfinite(model.pvalues[_GROUP_TERM]):
                row.update({
                    "fit_status": "not_estimable",
                    "failure_reason": "non-positive residual degrees of freedom or non-finite p-value",
                })
            else:
                confidence = model.conf_int().loc[_GROUP_TERM]
                row.update({
                    "fit_status": "fitted",
                    "estimate_log2": model.params[_GROUP_TERM],
                    "standard_error": model.bse[_GROUP_TERM],
                    "ci_lower_log2": confidence.iloc[0],
                    "ci_upper_log2": confidence.iloc[1],
                    "p_value": model.pvalues[_GROUP_TERM],
                    "residual_df": model.df_resid,
                })
            if caught:
                row["warning_message"] = " | ".join(str(warning.message) for warning in caught)
        except (ValueError, np.linalg.LinAlgError, ZeroDivisionError, PatsyError) as error:
            row.update({"fit_status": "failed", "failure_reason": str(error)})
        rows.append(row)
    return pd.DataFrame(rows)


def _fit_cage_mean_arm(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    region: str,
) -> pd.DataFrame:
    cage_values, cage_metadata = collapse_to_cage_means(
        values.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]],
        metadata.loc[metadata["Sample type"].eq(region)],
    )
    cage_metadata = cage_metadata.rename(columns={"Bio group": "BioGroup"})
    frame_metadata = cage_metadata.loc[:, ["Sample", "BioGroup", "Sex", "Cage", "Collection cohort"]]
    rows: list[dict[str, object]] = []
    for feature, feature_values in cage_values.iterrows():
        analysis = frame_metadata.copy()
        analysis["value"] = pd.to_numeric(feature_values.reindex(analysis["Sample"]).to_numpy(), errors="coerce")
        analysis = analysis.dropna(subset=["value"])
        row: dict[str, object] = {
            "Arm": "A",
            "Region": region,
            "Feature": feature,
            "n_cages": len(analysis),
            "n_control_cages": int(analysis["BioGroup"].eq("Saline Control").sum()),
            "n_mia_cages": int(analysis["BioGroup"].eq("MIA").sum()),
            "formula": "cage means ~ BioGroup",
        }
        if set(analysis["BioGroup"]) != {"Saline Control", "MIA"}:
            row["fit_status"] = "not_estimable"
            rows.append(row)
            continue
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                model = smf.ols(
                    "value ~ C(BioGroup, Treatment(reference='Saline Control'))",
                    data=analysis,
                ).fit()
            if model.df_resid <= 0 or not np.isfinite(model.pvalues[_GROUP_TERM]):
                row.update({
                    "fit_status": "not_estimable",
                    "failure_reason": "non-positive residual degrees of freedom or non-finite p-value",
                })
            else:
                confidence = model.conf_int().loc[_GROUP_TERM]
                row.update({
                    "fit_status": "fitted",
                    "estimate_log2": model.params[_GROUP_TERM],
                    "standard_error": model.bse[_GROUP_TERM],
                    "ci_lower_log2": confidence.iloc[0],
                    "ci_upper_log2": confidence.iloc[1],
                    "p_value": model.pvalues[_GROUP_TERM],
                    "residual_df": model.df_resid,
                })
            if caught:
                row["warning_message"] = " | ".join(str(warning.message) for warning in caught)
        except (ValueError, np.linalg.LinAlgError, KeyError, ZeroDivisionError, PatsyError) as error:
            row.update({"fit_status": "failed", "failure_reason": str(error)})
        rows.append(row)
    return pd.DataFrame(rows)


def _fit_random_intercept_arm(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    region: str,
) -> pd.DataFrame:
    """Fit arm B and retain singular/failed fits for accounting."""
    region_metadata = metadata.loc[metadata["Sample type"].eq(region)].copy()
    region_values = values.loc[:, region_metadata["Sample"]]
    rows: list[dict[str, object]] = []
    for feature, feature_values in region_values.iterrows():
        analysis = _design_frame(feature_values, region_metadata)
        row: dict[str, object] = {
            "Arm": "B",
            "Region": region,
            "Feature": feature,
            "n_usable": len(analysis),
            "formula": _PRIMARY_FORMULA + " with random intercept for Cage",
        }
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                model = smf.mixedlm(
                    _PRIMARY_FORMULA,
                    analysis,
                    groups=analysis["Cage"],
                ).fit(reml=False, method="lbfgs", disp=False)
            messages = " | ".join(str(warning.message) for warning in caught)
            group_variance = float(model.cov_re.iloc[0, 0])
            singular = (
                not model.converged
                or not np.isfinite(group_variance)
                or group_variance <= 1e-10
                or any(term in messages.lower() for term in ("singular", "boundary"))
            )
            row.update({
                "fit_status": "singular" if singular else "fitted",
                "estimate_log2": model.params.get(_GROUP_TERM, np.nan),
                "standard_error": model.bse.get(_GROUP_TERM, np.nan),
                "p_value": model.pvalues.get(_GROUP_TERM, np.nan),
                "cage_variance": group_variance,
                "warning_message": messages,
            })
        # MixedLM uses several numerical exception classes depending on the
        # feature's missingness and the optimizer's boundary behaviour.
        except Exception as error:  # noqa: BLE001
            row.update({"fit_status": "failed", "failure_reason": str(error)})
        rows.append(row)
    return pd.DataFrame(rows)


def _add_fdr(results: pd.DataFrame) -> pd.DataFrame:
    results = results.copy()
    results["p_value_fdr"] = np.nan
    for _, indices in results.groupby(["Arm", "Region"], observed=True).groups.items():
        results.loc[indices, "p_value_fdr"] = _bh_adjust(results.loc[indices, "p_value"])
    return results


def _serializable_date(value: object) -> object:
    if isinstance(value, (pd.Timestamp, np.datetime64)):
        return pd.Timestamp(value).strftime("%Y-%m-%d")
    return value


def _write_cage_pca(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    scope: str,
    output_dir: Path,
) -> None:
    """Write a descriptive PCA score plot with redundant cage encoding."""
    complete = values.loc[:, metadata["Sample"]].dropna(axis=0, how="any")
    model, scores, _ = fit_pca(complete)
    plot_metadata = metadata.set_index("Sample").loc[scores.index]
    categories = sorted(plot_metadata["Cage"].astype(str).unique())

    figure, axis = plt.subplots(figsize=(8.5, 6.2))
    for number, cage in enumerate(categories):
        subset = scores.loc[plot_metadata["Cage"].astype(str).eq(cage)]
        axis.scatter(
            subset["PC 1"],
            subset["PC 2"],
            color=CAGE_COLORS[number % len(CAGE_COLORS)],
            marker=CAGE_MARKERS[number % len(CAGE_MARKERS)],
            edgecolor="black",
            linewidth=0.35,
            label=cage,
        )
    axis.axhline(0, color="#BBBBBB", linewidth=0.8)
    axis.axvline(0, color="#BBBBBB", linewidth=0.8)
    axis.set(
        xlabel=f"PC 1 ({model.explained_variance_ratio_[0] * 100:.1f}%)",
        ylabel=f"PC 2 ({model.explained_variance_ratio_[1] * 100:.1f}%)",
        title=f"PCA scores: {scope}, highlighted by cage",
    )
    axis.legend(title="Cage", frameon=True, bbox_to_anchor=(1.02, 1), loc="upper left")
    figure.text(
        0.5,
        0.01,
        "Cage identity is shown by both color and marker. This is a descriptive design diagnostic, not an inferential test.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 0.78, 1))
    save_figure(figure, output_dir / f"scores_{scope}_cage")
    plt.close(figure)


def _plot_legend_handles() -> tuple[list[Line2D], list[Line2D]]:
    treatment_handles = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="none",
            markerfacecolor=BIO_GROUP_COLORS[group],
            markeredgecolor="black",
            markersize=7,
            label=group,
        )
        for group in ("Saline Control", "MIA")
    ]
    sex_handles = [
        Line2D(
            [0],
            [0],
            marker=marker,
            color="black",
            markerfacecolor="white",
            markeredgecolor="black",
            linestyle="None",
            markersize=7,
            label=sex,
        )
        for sex, marker in (("Male", "o"), ("Female", "^"))
    ]
    return treatment_handles, sex_handles


def _write_treatment_sex_cage_pca(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    scope: str,
    population: str,
    output_dir: Path,
) -> None:
    """Show treatment, sex, and cage nesting on one descriptive PCA."""
    complete = values.loc[:, metadata["Sample"]].dropna(axis=0, how="any")
    model, scores, _ = fit_pca(complete)
    plot_metadata = metadata.set_index("Sample").loc[scores.index].copy()
    plot_metadata["Cage"] = plot_metadata["Cage"].astype(str)

    figure, axis = plt.subplots(figsize=(9.5, 6.5))
    for cage, cage_metadata in plot_metadata.groupby("Cage", sort=True, observed=True):
        cage_scores = scores.loc[cage_metadata.index]
        centroid = cage_scores.loc[:, ["PC 1", "PC 2"]].mean()
        axis.scatter(
            centroid["PC 1"],
            centroid["PC 2"],
            marker="D",
            facecolor="white",
            edgecolor="black",
            linewidth=0.8,
            s=42,
            zorder=3,
        )
        axis.annotate(
            cage,
            (centroid["PC 1"], centroid["PC 2"]),
            xytext=(5, 5),
            textcoords="offset points",
            fontsize=8,
            zorder=4,
        )
        for sample in cage_metadata.index:
            point = scores.loc[sample]
            axis.plot(
                [centroid["PC 1"], point["PC 1"]],
                [centroid["PC 2"], point["PC 2"]],
                color="#888888",
                linewidth=0.7,
                alpha=0.55,
                zorder=1,
            )
            axis.scatter(
                point["PC 1"],
                point["PC 2"],
                color=BIO_GROUP_COLORS[cage_metadata.loc[sample, "Bio group"]],
                marker={"Male": "o", "Female": "^"}[cage_metadata.loc[sample, "Sex"]],
                edgecolor="black",
                linewidth=0.35,
                s=42,
                zorder=2,
            )

    axis.axhline(0, color="#BBBBBB", linewidth=0.8)
    axis.axvline(0, color="#BBBBBB", linewidth=0.8)
    axis.set(
        xlabel=f"PC 1 ({model.explained_variance_ratio_[0] * 100:.1f}%)",
        ylabel=f"PC 2 ({model.explained_variance_ratio_[1] * 100:.1f}%)",
        title=f"PCA scores: {scope}, treatment, sex, and cage ({population})",
    )
    treatment_handles, sex_handles = _plot_legend_handles()
    treatment_legend = axis.legend(
        handles=treatment_handles,
        title="Treatment",
        frameon=True,
        loc="upper left",
        bbox_to_anchor=(1.02, 1),
    )
    axis.add_artist(treatment_legend)
    axis.legend(
        handles=sex_handles,
        title="Sex",
        frameon=True,
        loc="upper left",
        bbox_to_anchor=(1.02, 0.72),
    )
    figure.text(
        0.5,
        0.01,
        (
            "Color = treatment; marker = sex; labels and connector lines = cage. Diamonds are cage centroids. Descriptive only."
            if scope != "pooled"
            else "Color = treatment; marker = sex; labels and connector lines = cage. Pooled points are three tissue observations per mouse. Descriptive only."
        ),
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 0.78, 1))
    save_figure(figure, output_dir / f"scores_{scope}_treatment_sex_cage_{population}")
    plt.close(figure)


def _write_within_cage_distance_plot(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    scope: str,
    population: str,
    output_dir: Path,
) -> None:
    """Quantify each mouse's PC1-PC2 distance from its cage centroid."""
    complete = values.loc[:, metadata["Sample"]].dropna(axis=0, how="any")
    _, scores, _ = fit_pca(complete)
    plot_metadata = metadata.set_index("Sample").loc[scores.index].copy()
    plot_metadata["Cage"] = plot_metadata["Cage"].astype(str)
    score_coordinates = scores.loc[:, ["PC 1", "PC 2"]]
    centroids = score_coordinates.join(plot_metadata["Cage"]).groupby(
        "Cage", observed=True
    )[["PC 1", "PC 2"]].mean()
    distances = score_coordinates.join(plot_metadata["Cage"]).copy()
    distances["distance_to_cage_centroid"] = np.sqrt(
        (distances["PC 1"] - distances["Cage"].map(centroids["PC 1"])) ** 2
        + (distances["PC 2"] - distances["Cage"].map(centroids["PC 2"])) ** 2
    )
    distances = distances.join(plot_metadata.loc[:, ["Bio group", "Sex", "Mouse number"]])
    distances.insert(0, "Sample", distances.index)
    distances.insert(1, "Region", scope)
    distances.insert(2, "Population", population)
    distances.to_csv(output_dir.parent.parent / f"within_cage_distance_{scope}_{population}.csv", index=False)

    cages = sorted(distances["Cage"].unique())
    figure, axis = plt.subplots(figsize=(10, 5.8))
    for number, cage in enumerate(cages):
        subset = distances.loc[distances["Cage"].eq(cage)].sort_values("Sample")
        offsets = np.linspace(-0.16, 0.16, len(subset)) if len(subset) > 1 else np.array([0.0])
        for offset, (_, row) in zip(offsets, subset.iterrows()):
            axis.scatter(
                number + offset,
                row["distance_to_cage_centroid"],
                color=BIO_GROUP_COLORS[row["Bio group"]],
                marker={"Male": "o", "Female": "^"}[row["Sex"]],
                edgecolor="black",
                linewidth=0.35,
                s=48,
            )
    mouse_counts = plot_metadata.groupby("Cage", observed=True)["Mouse number"].nunique()
    observation_counts = plot_metadata.groupby("Cage", observed=True).size()
    axis.set(
        xticks=np.arange(len(cages)),
        xticklabels=[
            f"{cage}\nM={int(mouse_counts[cage])}; O={int(observation_counts[cage])}"
            for cage in cages
        ],
        xlabel="Cage",
        ylabel=(
            "Distance to cage centroid (PC 1-PC 2 score units)"
            if scope != "pooled"
            else "Distance to cage centroid (pooled tissue-sample PC 1-PC 2 units)"
        ),
        title=(
            f"Within-cage PCA variation: {scope} ({population})"
            if scope != "pooled"
            else f"Pooled tissue-sample variation by cage ({population})"
        ),
    )
    axis.tick_params(axis="x", labelrotation=35)
    for label in axis.get_xticklabels():
        label.set_ha("right")
    treatment_handles, sex_handles = _plot_legend_handles()
    treatment_legend = axis.legend(handles=treatment_handles, title="Treatment", frameon=True, loc="upper left", bbox_to_anchor=(1.02, 1))
    axis.add_artist(treatment_legend)
    axis.legend(handles=sex_handles, title="Sex", frameon=True, loc="upper left", bbox_to_anchor=(1.02, 0.68))
    axis.text(
        0.01,
        0.98,
        (
            "Singleton cages have distance = 0 by definition; they provide no within-cage variation estimate."
            if scope != "pooled"
            else "Pooled scope has three tissue observations per mouse; regional panels are the mouse-level view."
        ),
        transform=axis.transAxes,
        va="top",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.10, 0.78, 1))
    save_figure(figure, output_dir / f"within_cage_distance_{scope}_{population}")
    plt.close(figure)


def run_cage_aware_sensitivity(project_root: Path) -> None:
    """Write arms A-D, ICC intervals, and the cage-structure manifest."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    cage_workbook = project_root / "data" / CAGE_METADATA_WORKBOOK
    sample_sheet, report = read_lipidomics_tables(workbook)
    sample_columns, blank_columns, _ = lipidomics_measurement_columns(report)
    full_metadata = full_lipidomics_metadata(
        sample_sheet,
        sample_columns,
        cage_workbook=cage_workbook,
    )
    metadata = analysis_metadata(
        sample_sheet,
        sample_columns,
        cage_workbook=cage_workbook,
    )
    all_raw = report.loc[:, sample_columns].apply(pd.to_numeric, errors="coerce")
    blanks = report.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    pca_values = preprocess_for_multivariate(all_raw, blanks)
    raw = report.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="coerce")
    values = preprocess_for_differential(raw, blanks)

    output = project_root / "results" / "mia_vs_control" / "08_cage_structure"
    output.mkdir(parents=True, exist_ok=True)
    pca_output = output / "figures" / "pca"
    for region in sorted(full_metadata["Sample type"].unique()):
        _write_cage_pca(
            pca_values,
            full_metadata.loc[full_metadata["Sample type"].eq(region)],
            scope=region.lower(),
            output_dir=pca_output,
        )
        _write_treatment_sex_cage_pca(
            pca_values,
            full_metadata.loc[full_metadata["Sample type"].eq(region)],
            scope=region.lower(),
            population="full",
            output_dir=pca_output,
        )
        _write_within_cage_distance_plot(
            pca_values,
            full_metadata.loc[full_metadata["Sample type"].eq(region)],
            scope=region.lower(),
            population="full",
            output_dir=pca_output,
        )
    _write_cage_pca(pca_values, full_metadata, scope="pooled", output_dir=pca_output)
    _write_treatment_sex_cage_pca(
        pca_values,
        full_metadata,
        scope="pooled",
        population="full",
        output_dir=pca_output,
    )
    _write_within_cage_distance_plot(
        pca_values,
        full_metadata,
        scope="pooled",
        population="full",
        output_dir=pca_output,
    )
    full_metadata.to_csv(output / "metadata_with_cage_structure.csv", index=False)

    mouse_metadata = full_metadata.drop_duplicates("Mouse number")
    cage_summary = (
        mouse_metadata.groupby("Cage", sort=False, observed=True)
        .agg(
            n_mice=("Mouse number", "nunique"),
            bio_group=("Bio group", "first"),
            sexes=("Sex", lambda values: ";".join(sorted(values.astype(str).unique()))),
            collection_date=("Date collected", "first"),
            collection_cohort=("Collection cohort", "first"),
        )
        .reset_index()
    )
    cage_summary["collection_date"] = cage_summary["collection_date"].map(_serializable_date)
    cage_summary.to_csv(output / "cage_summary.csv", index=False)

    result_frames: list[pd.DataFrame] = []
    for region in sorted(metadata["Sample type"].unique()):
        arm_a = _fit_cage_mean_arm(values, metadata, region=region)
        arm_b = _fit_random_intercept_arm(values, metadata, region=region)
        arm_c = _fit_ols_arm(values, metadata, region=region, arm="C", formula=_DATE_FORMULA)
        date_matched = metadata.loc[
            metadata["Date collected"].eq(pd.Timestamp("2024-06-11"))
        ].copy()
        arm_d = _fit_ols_arm(
            values.loc[:, date_matched["Sample"]],
            date_matched,
            region=region,
            arm="D",
            formula=_DATE_MATCHED_FORMULA,
        )
        for arm, frame in (("A", arm_a), ("B", arm_b), ("C", arm_c), ("D", arm_d)):
            frame = _add_fdr(frame)
            frame.to_csv(output / f"arm_{arm.lower()}_{region.lower()}.csv", index=False)
            result_frames.append(frame)

        region_values = values.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]]
        region_metadata = metadata.loc[metadata["Sample type"].eq(region)]
        permutation_features, permutation_summary, permutation_effective = run_permutation_null(
            region_values,
            region_metadata,
            min_per_cell=MIN_PER_CELL,
            exchangeability_unit="cage",
            block_column="Cage",
            effects=("MIA vs Saline Control",),
        )
        permutation_features.to_csv(output / f"cage_permutation_{region.lower()}.csv", index=False)
        permutation_summary.to_csv(output / f"cage_permutation_summary_{region.lower()}.csv", index=False)
        permutation_effective.to_csv(output / f"cage_permutation_effective_tests_{region.lower()}.csv", index=False)

        icc = intraclass_correlation(
            region_values,
            region_metadata,
            n_bootstraps=CAGE_ICC_BOOTSTRAPS,
            random_state=CAGE_ICC_RANDOM_SEED,
        )
        icc.insert(1, "Region", region)
        icc.to_csv(output / f"icc_{region.lower()}.csv", index=False)

    all_results = pd.concat(result_frames, ignore_index=True)
    all_results.to_csv(output / "cage_aware_effects.csv", index=False)
    fit_counts = (
        all_results.groupby(["Arm", "Region", "fit_status"], observed=True)
        .size()
        .rename("n_features")
        .reset_index()
    )
    fit_counts.to_csv(output / "fit_status_counts.csv", index=False)

    ceiling = cage_permutation_ceiling(metadata)
    ceiling["minimum_bh_q_value_at_950_features"] = 950 / ceiling["n_distinct_assignments"]
    manifest = {
        "analysis": "cage and collection-date sensitivity layer",
        "primary_analysis_unchanged": True,
        "design_sample_count": len(full_metadata),
        "analysis_sample_count": len(metadata),
        "experimental_unit": "dam/cage",
        "cage_equals_dam_confirmed": True,
        "arm_definitions": CAGE_SENSITIVITY_ARMS,
        "arm_a_collapse_unit": "cage means",
        "sex_exchangeability": sex_exchangeability_summary(metadata),
        "permutation_ceiling": ceiling,
        "date_matched_subset": {
            "date": "2024-06-11",
            "n_samples": int(metadata["Date collected"].eq(pd.Timestamp("2024-06-11")).sum()),
            "n_cages": int(metadata.loc[metadata["Date collected"].eq(pd.Timestamp("2024-06-11")), "Cage"].nunique()),
        },
        "processed_date": sorted(
            full_metadata["Date processed"].map(_serializable_date).astype(str).unique()
        ),
        "icc_interval_method": "cage bootstrap percentile interval",
        "icc_bootstraps": CAGE_ICC_BOOTSTRAPS,
        "icc_random_seed": CAGE_ICC_RANDOM_SEED,
    }
    with (output / "cage_structure_manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":
    run_cage_aware_sensitivity(Path(__file__).resolve().parents[3])
