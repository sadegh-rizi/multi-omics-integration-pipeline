"""Run the pre-specified within-region cross-omics association screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist
from scipy.cluster.hierarchy import fcluster, linkage

from ..integration.common import POPULATION, REGIONS, extension_root, load_integration_inputs, spearman_matrix
from ..lipid_features import build_lipid_summary_features, load_selected_lipid_annotations


THRESHOLD = 0.6
N_SHUFFLES = 200
N_BOOTSTRAPS = 100
RANDOM_SEED = 20_261_201
MODULE_DISTANCE_THRESHOLD = 0.5


def _association_count(correlation: np.ndarray, threshold: float = THRESHOLD) -> int:
    return int(np.count_nonzero(np.abs(correlation) >= threshold))


def _correlation_distance_labels(profiles: np.ndarray) -> np.ndarray:
    """Cluster association profiles with correlation distance (1 - r)."""
    if profiles.shape[0] == 1:
        return np.ones(1, dtype=int)
    distances = pdist(profiles, metric="correlation")
    distances = np.nan_to_num(distances, nan=1.0, posinf=1.0, neginf=1.0)
    return fcluster(
        linkage(distances, method="average"),
        t=MODULE_DISTANCE_THRESHOLD,
        criterion="distance",
    )


def _hierarchical_modules(
    correlation: np.ndarray,
    lipid_features: list[str],
    target_features: list[str],
    *,
    threshold: float = THRESHOLD,
) -> list[dict[str, object]]:
    """Cluster the thresholded bipartite association matrix into modules."""
    active = np.abs(correlation) >= threshold
    lipid_positions = np.flatnonzero(active.any(axis=1))
    target_positions = np.flatnonzero(active.any(axis=0))
    if len(lipid_positions) < 2 or len(target_positions) < 2:
        return []

    profiles = correlation[lipid_positions][:, target_positions]
    lipid_labels = _correlation_distance_labels(profiles)
    target_labels = _correlation_distance_labels(profiles.T)
    modules: list[dict[str, object]] = []
    module_number = 0
    for lipid_cluster in np.unique(lipid_labels):
        row_positions = lipid_positions[lipid_labels == lipid_cluster]
        for target_cluster in np.unique(target_labels):
            column_positions = target_positions[target_labels == target_cluster]
            submatrix = active[np.ix_(row_positions, column_positions)]
            if not submatrix.any() or int(submatrix.sum()) < 2:
                continue
            module_number += 1
            modules.append({
                "module": module_number,
                "lipid_features": ";".join(lipid_features[index] for index in row_positions),
                "target_features": ";".join(target_features[index] for index in column_positions),
                "n_lipid_features": len(row_positions),
                "n_target_features": len(column_positions),
                "n_thresholded_pairs": int(submatrix.sum()),
                "mean_absolute_rho": float(np.abs(correlation[np.ix_(row_positions, column_positions)][submatrix]).mean()),
            })
    return modules


def _module_bootstrap_stability(
    full_modules: list[dict[str, object]],
    lipid_values: pd.DataFrame,
    target_values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    n_bootstraps: int,
    seed: int,
) -> pd.DataFrame:
    """Match bootstrap biclusters to the full-data modules by member Jaccard."""
    if not full_modules:
        return pd.DataFrame(columns=["module", "n_bootstraps", "stable_fraction", "stable_70_percent"])
    rng = np.random.default_rng(seed)
    cages = metadata["Cage"].drop_duplicates().to_numpy()
    bootstrap_members: dict[int, list[tuple[set[str], set[str]]]] = {int(row["module"]): [] for row in full_modules}
    full_sets = {
        int(row["module"]): (
            set(str(row["lipid_features"]).split(";")),
            set(str(row["target_features"]).split(";")),
        )
        for row in full_modules
    }
    for _ in range(n_bootstraps):
        selected_cages = rng.choice(cages, size=len(cages), replace=True)
        selected_positions = np.concatenate([
            np.flatnonzero(metadata["Cage"].to_numpy() == cage)
            for cage in selected_cages
        ])
        correlation = spearman_matrix(
            lipid_values.iloc[selected_positions].reset_index(drop=True),
            target_values.iloc[selected_positions].reset_index(drop=True),
        )
        candidates = _hierarchical_modules(correlation, list(lipid_values.columns), list(target_values.columns))
        candidate_sets = [
            (set(str(row["lipid_features"]).split(";")), set(str(row["target_features"]).split(";")))
            for row in candidates
        ]
        for module, (full_lipids, full_targets) in full_sets.items():
            best = 0.0
            for candidate_lipids, candidate_targets in candidate_sets:
                lipid_jaccard = len(full_lipids & candidate_lipids) / len(full_lipids | candidate_lipids)
                target_jaccard = len(full_targets & candidate_targets) / len(full_targets | candidate_targets)
                best = max(best, min(lipid_jaccard, target_jaccard))
            bootstrap_members[module].append((set(), set()) if best < 0.7 else (full_lipids, full_targets))
    rows = []
    for module, matches in bootstrap_members.items():
        stable_fraction = sum(bool(lipids) and bool(targets) for lipids, targets in matches) / n_bootstraps
        rows.append({
            "module": module,
            "n_bootstraps": n_bootstraps,
            "stable_fraction": stable_fraction,
            "stable_70_percent": stable_fraction >= 0.7,
        })
    return pd.DataFrame(rows)


def _screen_view(
    lipid_values: pd.DataFrame,
    target_values: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    view: str,
    n_shuffles: int,
    n_bootstraps: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    observed_counts: list[dict[str, object]] = []
    pair_rows: list[dict[str, object]] = []
    module_rows: list[dict[str, object]] = []
    stability_rows: list[pd.DataFrame] = []
    rng = np.random.default_rng(seed)
    for region in REGIONS:
        mask = metadata["Sample type"].eq(region).to_numpy()
        lipid_region = lipid_values.loc[mask].reset_index(drop=True)
        target_region = target_values.loc[mask].reset_index(drop=True)
        correlation = spearman_matrix(lipid_region, target_region)
        observed_count = _association_count(correlation)
        null_counts = np.empty(n_shuffles, dtype=int)
        for shuffle in range(n_shuffles):
            order = rng.permutation(len(target_region))
            null_counts[shuffle] = _association_count(
                spearman_matrix(lipid_region, target_region.iloc[order].reset_index(drop=True))
            )
        observed_counts.append({
            "Region": region,
            "target_view": view,
            "threshold": THRESHOLD,
            "observed_count": observed_count,
            "null_mean": float(null_counts.mean()),
            "null_sd": float(null_counts.std(ddof=1)),
            "null_z": float((observed_count - null_counts.mean()) / null_counts.std(ddof=1)) if null_counts.std(ddof=1) else np.nan,
            "pairing_shuffle_p": float((1 + np.count_nonzero(null_counts >= observed_count)) / (n_shuffles + 1)),
            "n_shuffles": n_shuffles,
        })
        active = np.abs(correlation) >= THRESHOLD
        for lipid_index, target_index in zip(*np.where(active)):
            pair_rows.append({
                "Region": region,
                "target_view": view,
                "LipidFeature": lipid_region.columns[lipid_index],
                "TargetFeature": target_region.columns[target_index],
                "rho": float(correlation[lipid_index, target_index]),
                "threshold": THRESHOLD,
            })
        modules = _hierarchical_modules(correlation, list(lipid_region.columns), list(target_region.columns))
        for row in modules:
            module_rows.append({"Region": region, "target_view": view, **row})
        stability = _module_bootstrap_stability(
            modules,
            lipid_region,
            target_region,
            metadata.loc[mask].reset_index(drop=True),
            n_bootstraps=n_bootstraps,
            seed=seed + len(module_rows) + 1,
        )
        if not stability.empty:
            stability.insert(0, "Region", region)
            stability.insert(1, "target_view", view)
            stability_rows.append(stability)
    return (
        pd.DataFrame(observed_counts),
        pd.DataFrame(pair_rows),
        pd.DataFrame(module_rows),
        pd.concat(stability_rows, ignore_index=True) if stability_rows else pd.DataFrame(),
    )


def _annotate_region_replication(modules: pd.DataFrame, stability: pd.DataFrame) -> pd.DataFrame:
    if modules.empty:
        return modules
    result = modules.copy()
    if not stability.empty:
        result = result.merge(
            stability.loc[:, ["Region", "target_view", "module", "stable_70_percent"]],
            on=["Region", "target_view", "module"],
            how="left",
            validate="one_to_one",
        )
    else:
        result["stable_70_percent"] = False
    replicated: list[int] = []
    for index, row in result.iterrows():
        row_lipids = set(str(row["lipid_features"]).split(";"))
        row_targets = set(str(row["target_features"]).split(";"))
        regions = {str(row["Region"])}
        for _, candidate in result.loc[result["target_view"].eq(row["target_view"])].iterrows():
            if candidate["Region"] == row["Region"]:
                continue
            candidate_lipids = set(str(candidate["lipid_features"]).split(";"))
            candidate_targets = set(str(candidate["target_features"]).split(";"))
            if (
                len(row_lipids & candidate_lipids) / len(row_lipids | candidate_lipids) >= 0.5
                and len(row_targets & candidate_targets) / len(row_targets | candidate_targets) >= 0.5
            ):
                regions.add(str(candidate["Region"]))
        replicated.append(len(regions))
    result["n_regions_matched"] = replicated
    result["replicated_two_regions"] = result["n_regions_matched"].ge(2)
    result["finding_candidate"] = result["stable_70_percent"].fillna(False) & result["replicated_two_regions"]
    return result


def run_screen(project_root: Path, *, n_shuffles: int = N_SHUFFLES, n_bootstraps: int = N_BOOTSTRAPS) -> Path:
    blocks, metadata = load_integration_inputs(project_root)
    annotations = load_selected_lipid_annotations(project_root, blocks["lipidomics"].columns)
    lipid_values, definitions = build_lipid_summary_features(blocks["lipidomics"], annotations)
    output_root = extension_root(project_root) / "02_cross_omics_screen"
    output_root.mkdir(parents=True, exist_ok=True)
    lipid_values.insert(0, "Sample", lipid_values.index)
    lipid_values.to_csv(output_root / "lipid_summary_values.csv", index=False)
    definitions.to_csv(output_root / "lipid_summary_definitions.csv")

    summary_tables = []
    pair_tables = []
    module_tables = []
    stability_tables = []
    for number, view in enumerate(("metabolomics", "proteomics")):
        summary, pairs, modules, stability = _screen_view(
            lipid_values.set_index("Sample"),
            blocks[view],
            metadata,
            view=view,
            n_shuffles=n_shuffles,
            n_bootstraps=n_bootstraps,
            seed=RANDOM_SEED + number * 1000,
        )
        summary_tables.append(summary)
        pair_tables.append(pairs)
        module_tables.append(modules)
        if not stability.empty:
            stability_tables.append(stability)
    pd.concat(summary_tables, ignore_index=True).to_csv(output_root / "association_null_summary.csv", index=False)
    pd.concat(pair_tables, ignore_index=True).to_csv(output_root / "thresholded_pairs_supplement.csv", index=False)
    modules = pd.concat(module_tables, ignore_index=True) if module_tables else pd.DataFrame()
    stability = pd.concat(stability_tables, ignore_index=True) if stability_tables else pd.DataFrame()
    modules = _annotate_region_replication(modules, stability)
    modules.to_csv(output_root / "modules.csv", index=False)
    if not stability.empty:
        stability.to_csv(output_root / "module_stability.csv", index=False)
    modules.loc[modules["finding_candidate"]].to_csv(output_root / "replicated_stable_modules.csv", index=False)
    manifest = {
        "analysis": "within-region Spearman cross-omics association screen",
        "population": POPULATION,
        "lipid_summary_count": int(lipid_values.shape[1] - 1),
        "unannotated_delivered_lipid_features_dropped": int(blocks["lipidomics"].shape[1] - len(annotations)),
        "regions": list(REGIONS),
        "correlation_threshold": THRESHOLD,
        "pairing_shuffles": n_shuffles,
        "litter_proxy": "Cage; no separate litter field is present in the integration metadata",
        "module_bootstraps": n_bootstraps,
        "module_rule": "hierarchical clustering of thresholded association profiles with correlation distance (1-r); stable if matched at min row/column Jaccard >= 0.7 in >=70% cage bootstraps",
        "interpretation": "thresholded pairs are supplementary; findings are module-level only",
    }
    (output_root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--shuffles", type=int, default=N_SHUFFLES)
    parser.add_argument("--bootstraps", type=int, default=N_BOOTSTRAPS)
    args = parser.parse_args()
    run_screen(args.project_root, n_shuffles=args.shuffles, n_bootstraps=args.bootstraps)
