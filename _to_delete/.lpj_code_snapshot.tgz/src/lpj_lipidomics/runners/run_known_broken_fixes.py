"""Execute the approved regeneration in two independently runnable passes.

Run with ``python -m lpj_lipidomics.runners.run_known_broken_fixes regions``
or ``... normalization``. Both write the paths approved in the fixes plan.
Tolerance failures stop the pass and leave its diagnostic tables for review.
"""

from pathlib import Path
import sys

import pandas as pd

from ..plotting import apply_plot_style
from .check_known_broken_fixes import check_g9, check_pca_reference, check_region_persistence, write_run_provenance
from .run_mia_vs_control import run_mia_vs_control
from .run_metabolomics_pca import run_metabolomics_pca
from .run_pipeline_variant import run_pipeline_variant
from .run_pqn_sensitivity import run_metabolomics_normalization_arm, compare_normalization_arms
from .run_region_persistence import run_region_persistence


def run_region_regressions(project_root: Path) -> None:
    root = project_root / "results" / "mia_vs_control" / "09_region_persistence"
    previous = {}
    for modality in ("lipidomics", "metabolomics"):
        path = root / "prevalence20_noexclusion" / modality / "02_qc" / "disattenuated_concordance.csv"
        previous[modality] = pd.read_csv(path).set_index("Contrast")
    write_run_provenance(project_root, root)
    print("Regenerating region persistence: 3 populations x 2 modalities", flush=True)
    run_region_persistence(project_root, overwrite=True)
    checks = check_region_persistence(project_root, previous)
    print(f"Region-persistence regressions passed: {len(checks)}", flush=True)


def run_normalization_regressions(project_root: Path) -> None:
    apply_plot_style()
    primary = project_root / "results" / "mia_vs_control"
    write_run_provenance(project_root, primary)
    print("Regenerating all-60 primary differential/PCA and metabolomics PCA", flush=True)
    run_mia_vs_control(project_root)
    run_metabolomics_pca(project_root)
    write_run_provenance(project_root, project_root / "results" / "metabolomics")
    run_filtered_regressions(project_root)


def run_filtered_regressions(project_root: Path) -> None:
    """Resume the filtered passes after the all-60 primary outputs exist."""
    apply_plot_style()
    print("G9: complete all-60 filtered rerun in sibling tree", flush=True)
    median = run_pipeline_variant(project_root, "prevalence20_noexclusion", output_root_name="pipeline_test_rerun")
    write_run_provenance(project_root, median)
    checks = check_g9(project_root, median)
    print(f"G9 regressions passed: {len(checks)}", flush=True)
    check_pca_reference(median, "lipidomics")

    print("Lipidomics PQN sensitivity", flush=True)
    pqn = run_pipeline_variant(project_root, "prevalence20_noexclusion_pqn", output_root_name="pipeline_test_rerun")
    write_run_provenance(project_root, pqn)
    print(compare_normalization_arms(median, pqn, "lipidomics").to_string(index=False), flush=True)

    print("Metabolomics median/PQN sensitivity", flush=True)
    median = run_metabolomics_normalization_arm(project_root, "median")
    write_run_provenance(project_root, median)
    check_pca_reference(median, "metabolomics")
    pqn = run_metabolomics_normalization_arm(project_root, "pqn")
    write_run_provenance(project_root, pqn)
    print(compare_normalization_arms(median, pqn, "metabolomics").to_string(index=False), flush=True)
    print("Normalization and PCA regression pass completed", flush=True)


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[3]
    if sys.argv[1:] == ["regions"]:
        run_region_regressions(root)
    elif sys.argv[1:] == ["normalization"]:
        run_normalization_regressions(root)
    elif sys.argv[1:] == ["filtered"]:
        run_filtered_regressions(root)
    else:
        raise SystemExit("Choose exactly one pass: regions, normalization, or filtered (resume)")
