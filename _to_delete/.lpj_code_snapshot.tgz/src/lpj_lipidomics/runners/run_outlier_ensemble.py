"""Run the prespecified multi-detector exploratory outlier ensemble.

The script creates QC evidence only.  It never changes the primary-analysis
sample exclusions configured in :mod:`analysis_config`.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

import numpy as np
import pandas as pd

from ..outliers.calibration import (
    calibrate_ensemble,
    calibrate_isolation_forest,
    calibrate_ledoit_wolf_sweep,
    calibrate_knn_sweep,
    calibrate_lof_sweep,
    score_to_percentile,
    simulate_null_limits,
    verify_false_positive_rate,
)
from ..outliers.detectors import (
    distance_contrast,
    isolation_forest_rank_range,
    isolation_forest_score,
    isolation_forest_seed_scores,
    kernel_pca_reconstruction_distance,
    knn_mean_distance,
    knn_mean_distance_sweep,
    ledoit_wolf_auto_intensity,
    ledoit_wolf_mahalanobis,
    ledoit_wolf_mahalanobis_sweep,
    local_outlier_factor,
    local_outlier_factor_sweep,
)
from ..outliers.ensemble import apply_stability_rule, combine_percentiles, stability_fraction
from ..outliers.plots import plot_outlier_diagnostics, sample_label_mapping
from ..outliers.screen import hotelling_t2
from ..multivariate.pca import fit_pca
from .common import metadata_and_values


PCA_COMPONENTS = (3, 5, 10)
GAMMAS = tuple(np.logspace(-2, 0, 9))
SEEDS = tuple(range(20_260_826, 20_260_876))
NON_IF_NULL_REPLICATES = 200
ISOLATION_FOREST_NULL_REPLICATES = 50
ISOLATION_FOREST_ESTIMATORS = 100
CALIBRATION_STAGES = ("contaminated", "trimmed")
MAHALANOBIS_SWEEP_MIN = 0.875
SHRINKAGES = tuple(alpha for alpha in np.linspace(0, 1, 9) if alpha >= MAHALANOBIS_SWEEP_MIN)


_metadata_and_values = metadata_and_values


def _build_evaluation(
    values: pd.DataFrame,
    scores: pd.Series,
    limits: pd.Series,
    null_scores: pd.Series,
    scorer: Callable[[pd.DataFrame], pd.Series],
    calibration_values: pd.DataFrame,
    *,
    scope: str,
    detector: str,
    parameter_name: str,
    parameter_value: str | int | float,
    representation: str,
    counts_for_stability: bool,
    calibration_stage: str,
    n_null_replicates: int,
    calibration_status: str | None = None,
) -> tuple[pd.DataFrame, dict[str, object]]:
    valid = _valid_calibration(limits, null_scores)
    percentiles = score_to_percentile(scores, null_scores) if valid else pd.Series(np.nan, index=scores.index)
    limit_95 = float(limits.get("limit_95", np.nan))
    limit_99 = float(limits.get("limit_99", np.nan))
    effective_counts = counts_for_stability and valid
    table = pd.DataFrame({
        "Sample": scores.index,
        "score": scores.to_numpy(),
        "null_percentile": percentiles.to_numpy(),
        "flag_95": scores.gt(limit_95).to_numpy() if valid else False,
        "flag_99": scores.gt(limit_99).to_numpy() if valid else False,
        "detector": detector,
        "parameter_name": parameter_name,
        "parameter_value": str(parameter_value),
        "representation": representation,
        "scope": scope,
        "calibration_stage": calibration_stage,
        "counts_for_stability": effective_counts,
        "n_null_replicates": n_null_replicates,
    })
    summary = {
        "scope": scope,
        "detector": detector,
        "parameter_name": parameter_name,
        "parameter_value": str(parameter_value),
        "representation": representation,
        "calibration_stage": calibration_stage,
        "limit_95": limit_95,
        "limit_99": limit_99,
        "false_positive_rate": verify_false_positive_rate(
            values,
            scorer,
            limit_95=limit_95,
            calibration_values=calibration_values,
            n_replicates=n_null_replicates,
        ) if valid else np.nan,
        "calibration_status": calibration_status or ("ok" if valid else "broken"),
        "n_null_replicates": n_null_replicates,
        "counts_for_stability": effective_counts,
    }
    return table, summary


def _evaluate_staged(
    values: pd.DataFrame,
    scorer: Callable[[pd.DataFrame], pd.Series],
    *,
    scope: str,
    detector: str,
    parameter_name: str,
    parameter_value: str | int | float,
    representation: str,
    counts_for_stability: bool,
    n_null_replicates: int,
) -> tuple[list[pd.DataFrame], list[dict[str, object]]]:
    scores = scorer(values)
    stage2_fallback = False
    try:
        stage1_limits, stage1_null_scores = simulate_null_limits(values, scorer, n_replicates=n_null_replicates)
    except ValueError:
        stage1_limits = pd.Series({"limit_95": np.nan, "limit_99": np.nan})
        stage1_null_scores = pd.Series(dtype=float)
    if _valid_calibration(stage1_limits, stage1_null_scores):
        stage1_flags = scores.gt(stage1_limits["limit_95"])
        retained = values.loc[~stage1_flags]
    else:
        retained = values.iloc[0:0]
    try:
        stage2_limits, stage2_null_scores = (
            simulate_null_limits(
                values,
                scorer,
                calibration_values=retained,
                n_replicates=n_null_replicates,
            )
            if len(retained) >= 2
            else (pd.Series({"limit_95": np.nan, "limit_99": np.nan}), pd.Series(dtype=float))
        )
    except ValueError:
        stage2_limits = pd.Series({"limit_95": np.nan, "limit_99": np.nan})
        stage2_null_scores = pd.Series(dtype=float)
    if (
        not _valid_calibration(stage2_limits, stage2_null_scores)
        and detector == "mahalanobis"
        and parameter_name == "shrinkage"
        and str(parameter_value) == "auto"
        and _valid_calibration(stage1_limits, stage1_null_scores)
    ):
        # A low selected shrinkage can flag every sample. There is no valid
        # covariance left to trim against, so retain its stage-1 null as an
        # explicit, non-stability-counting ensemble representative.
        stage2_limits = stage1_limits
        stage2_null_scores = stage1_null_scores
        stage2_fallback = True
    records = []
    summaries = []
    stage2_calibration_values = values if stage2_fallback else retained
    for stage, limits, null_scores, calibration_values in (
        ("contaminated", stage1_limits, stage1_null_scores, values),
        ("trimmed", stage2_limits, stage2_null_scores, stage2_calibration_values),
    ):
        table, summary = _build_evaluation(
            values,
            scores,
            limits,
            null_scores,
            scorer,
            calibration_values,
            scope=scope,
            detector=detector,
            parameter_name=parameter_name,
            parameter_value=parameter_value,
            representation=representation,
            counts_for_stability=counts_for_stability,
            calibration_stage=stage,
            n_null_replicates=n_null_replicates,
            calibration_status="fallback_contaminated" if stage == "trimmed" and stage2_fallback else None,
        )
        records.append(table)
        summaries.append(summary)
    return records, summaries


def _evaluate_sweep(
    observed: pd.DataFrame,
    stage_limits: dict[str, pd.DataFrame],
    stage_null_scores: dict[str, dict[object, pd.Series]],
    parameters: list[object],
    *,
    scope: str,
    detector: str,
    parameter_name: str,
    representation: str,
    counts_for_stability: Callable[[object], bool] | bool,
    n_null_replicates: int,
) -> tuple[list[pd.DataFrame], list[dict[str, object]]]:
    """Build long evidence rows from a detector sweep calibrated in one pass."""
    records: list[pd.DataFrame] = []
    summaries: list[dict[str, object]] = []
    for stage in CALIBRATION_STAGES:
        limits = stage_limits[stage]
        null_scores = stage_null_scores[stage]
        for column, parameter in enumerate(parameters):
            scores = observed.iloc[:, column].rename("score")
            limits_row = limits.loc[parameter]
            parameter_null_scores = null_scores.get(parameter, pd.Series(dtype=float))
            valid = _valid_calibration(limits_row, parameter_null_scores)
            is_auto_mahalanobis = (
                detector == "mahalanobis"
                and parameter_name == "shrinkage"
                and (str(parameter) == "auto" or float(parameter) not in SHRINKAGES)
            )
            fallback = stage == "trimmed" and is_auto_mahalanobis and not valid
            if fallback:
                limits_row = stage_limits["contaminated"].loc[parameter]
                parameter_null_scores = stage_null_scores["contaminated"].get(parameter, pd.Series(dtype=float))
                valid = _valid_calibration(limits_row, parameter_null_scores)
            null_percentile = score_to_percentile(scores, parameter_null_scores) if valid else pd.Series(np.nan, index=scores.index)
            counts = counts_for_stability(parameter) if callable(counts_for_stability) else counts_for_stability
            counts = counts and valid and not fallback
            records.append(pd.DataFrame({
                "Sample": scores.index,
                "score": scores.to_numpy(),
                "null_percentile": null_percentile.to_numpy(),
                "flag_95": scores.gt(limits_row["limit_95"]).to_numpy() if valid else False,
                "flag_99": scores.gt(limits_row["limit_99"]).to_numpy() if valid else False,
                "detector": detector,
                "parameter_name": parameter_name,
                "parameter_value": str(parameter),
                "representation": representation,
                "scope": scope,
                "calibration_stage": stage,
                "counts_for_stability": counts,
                "n_null_replicates": n_null_replicates,
                "calibration_status": "fallback_contaminated" if fallback else ("ok" if valid else "broken"),
            }))
            summaries.append({
                "scope": scope,
                "detector": detector,
                "parameter_name": parameter_name,
                "parameter_value": str(parameter),
                "representation": representation,
                "calibration_stage": stage,
                "limit_95": limits_row.get("limit_95", np.nan),
                "limit_99": limits_row.get("limit_99", np.nan),
                "false_positive_rate": limits_row.get("false_positive_rate", np.nan),
                "n_null_replicates": n_null_replicates,
                "counts_for_stability": counts,
                "calibration_status": "fallback_contaminated" if fallback else ("ok" if valid else "broken"),
            })
    return records, summaries


def _calibrate_sweep_stages(
    values: pd.DataFrame,
    observed: pd.DataFrame,
    parameters: list[object],
    calibrator: Callable[[pd.DataFrame, list[object], pd.DataFrame], tuple[pd.DataFrame, dict[object, pd.Series]]],
) -> tuple[dict[str, pd.DataFrame], dict[str, dict[object, pd.Series]]]:
    """Calibrate a sweep, grouping stage-2 parameters by their trim mask."""
    try:
        stage1_limits, stage1_null_scores = calibrator(values, parameters, values)
    except ValueError:
        stage1_limits, stage1_null_scores = _broken_sweep_calibration(parameters)
    grouped_parameters: dict[tuple[bool, ...], list[object]] = {}
    for column, parameter in enumerate(parameters):
        flags = observed.iloc[:, column].gt(stage1_limits.loc[parameter, "limit_95"]) if _valid_calibration(stage1_limits.loc[parameter], stage1_null_scores.get(parameter, pd.Series(dtype=float))) else pd.Series(False, index=values.index)
        grouped_parameters.setdefault(tuple(flags.tolist()), []).append(parameter)
    stage2_limits: dict[object, pd.Series] = {}
    stage2_null_scores: dict[object, pd.Series] = {}
    for mask, group_parameters in grouped_parameters.items():
        retained = values.loc[~pd.Series(mask, index=values.index)]
        if len(retained) < 2:
            limits, null_scores = _broken_sweep_calibration(group_parameters)
        else:
            try:
                limits, null_scores = calibrator(values, group_parameters, retained)
            except ValueError:
                limits, null_scores = _broken_sweep_calibration(group_parameters)
        for parameter in group_parameters:
            stage2_limits[parameter] = limits.loc[parameter]
            stage2_null_scores[parameter] = null_scores[parameter]
    return (
        {"contaminated": stage1_limits, "trimmed": pd.DataFrame(stage2_limits).T},
        {"contaminated": stage1_null_scores, "trimmed": stage2_null_scores},
    )


def _valid_calibration(limits: pd.Series, null_scores: pd.Series) -> bool:
    """Return whether a calibration cell has finite limits and null scores."""
    return (
        len(null_scores) > 0
        and np.isfinite(float(limits.get("limit_95", np.nan)))
        and np.isfinite(float(limits.get("limit_99", np.nan)))
    )


def _broken_sweep_calibration(parameters: list[object]) -> tuple[pd.DataFrame, dict[object, pd.Series]]:
    """Represent an uncalibratable sweep cell without stopping other cells."""
    limits = pd.DataFrame(
        {
            "limit_95": np.nan,
            "limit_99": np.nan,
            "false_positive_rate": np.nan,
        },
        index=parameters,
    )
    return limits, {parameter: pd.Series(dtype=float, name="null_score") for parameter in parameters}


def _evaluate_mahalanobis_auto(
    values: pd.DataFrame,
    *,
    scope: str,
    n_null_replicates: int,
) -> tuple[list[pd.DataFrame], list[dict[str, object]]]:
    """Evaluate the selected shrinkage through the batched sweep calibrator."""
    auto_shrinkage = ledoit_wolf_auto_intensity(values)
    observed = ledoit_wolf_mahalanobis_sweep(values, shrinkages=[auto_shrinkage])
    stage_limits, stage_null_scores = _calibrate_sweep_stages(
        values,
        observed,
        [auto_shrinkage],
        lambda frame, parameters, calibration: calibrate_ledoit_wolf_sweep(
            frame,
            shrinkages=parameters,
            calibration_values=calibration,
            n_replicates=n_null_replicates,
            batch_size=16,
        ),
    )
    records, summaries = _evaluate_sweep(
        observed,
        stage_limits,
        stage_null_scores,
        [auto_shrinkage],
        scope=scope,
        detector="mahalanobis",
        parameter_name="shrinkage",
        representation="raw",
        counts_for_stability=False,
        n_null_replicates=n_null_replicates,
    )
    for record in records:
        record["parameter_value"] = "auto"
    for summary in summaries:
        summary["parameter_value"] = "auto"
        summary["auto_shrinkage"] = auto_shrinkage
    return records, summaries


def _finalize_ensemble_outputs(
    project_root: Path,
    metadata: pd.DataFrame,
    all_values: pd.DataFrame,
    records: list[pd.DataFrame],
    limits: list[dict[str, object]],
    concentration: list[dict[str, object]],
    rank_ranges: list[pd.DataFrame],
    *,
    include_isolation_forest: bool,
    n_null_replicates: int,
    isolation_forest_replicates: int,
    isolation_forest_estimators: int,
    analysis_complete: bool,
) -> list[Path]:
    """Build dependent stability, verdict, table, and figure outputs."""
    long_scores = pd.concat(records, ignore_index=True)
    null_limits = pd.DataFrame(limits)
    stable = stability_fraction(long_scores.loc[long_scores["counts_for_stability"]]).reset_index()
    verdicts: list[pd.DataFrame] = []
    ensemble_limits: list[pd.DataFrame] = []
    for scope, scope_scores in long_scores.groupby("scope", observed=True):
        scope_samples = sorted(scope_scores["Sample"].unique())
        stage_rules: dict[str, pd.DataFrame] = {}
        for stage, suffix in (("contaminated", "stage1"), ("trimmed", "stage2")):
            stable_stage = stable.loc[stable["scope"].eq(scope) & stable["calibration_stage"].eq(stage)]
            if stable_stage.empty:
                stage_rule = pd.DataFrame(index=scope_samples, columns=["stable_detector_count", "stable_non_covariance_count", "candidate_outlier"])
            else:
                stage_rule = apply_stability_rule(stable_stage).reindex(scope_samples)
            stage_rule[["stable_detector_count", "stable_non_covariance_count"]] = stage_rule[
                ["stable_detector_count", "stable_non_covariance_count"]
            ].fillna(0).astype(int)
            stage_rule["candidate_outlier"] = stage_rule["candidate_outlier"].fillna(False).astype(bool)
            stage_rules[stage] = stage_rule.rename(columns={
                "stable_detector_count": f"stable_detector_count_{suffix}",
                "stable_non_covariance_count": f"stable_non_covariance_count_{suffix}",
                "candidate_outlier": f"candidate_outlier_{suffix}",
            })
        verdict = stage_rules["contaminated"].join(stage_rules["trimmed"])
        verdict["stable_detector_count"] = verdict["stable_detector_count_stage2"]
        verdict["stable_non_covariance_count"] = verdict["stable_non_covariance_count_stage2"]
        verdict["ensemble_complete"] = include_isolation_forest and analysis_complete
        verdict["candidate_outlier"] = pd.NA
        verdict["ensemble_status"] = "not_evaluated"
        verdict["ensemble_missing_representatives"] = ""
        if not include_isolation_forest:
            verdict["ensemble_status"] = "partial_no_isolation_forest"
            verdict["scope"] = scope
            verdicts.append(verdict.reset_index(names="Sample"))
            continue

        def representative_for_stage(stage: str) -> tuple[pd.DataFrame | None, list[str]]:
            representative = pd.DataFrame(index=scope_samples)
            missing: list[str] = []
            lof_detector = "lof" if scope == "pooled" else "lof_supporting"
            specifications = (
                ("mahalanobis", "mahalanobis", "auto", "raw"),
                ("knn", "knn_isotropic", str(round(np.sqrt(len(scope_samples)))), "pc3"),
                ("isolation_forest", "isolation_forest", "50", "pc3"),
                ("lof", lof_detector, "10" if scope == "pooled" else "8", "pc3"),
                ("kernel_pca", "kernel_pca", str(GAMMAS[4]), "pc3"),
            )
            for name, detector, parameter, representation in specifications:
                selected = scope_scores.loc[
                    scope_scores["calibration_stage"].eq(stage)
                    & scope_scores["detector"].eq(detector)
                    & scope_scores["parameter_value"].eq(parameter)
                    & scope_scores["representation"].eq(representation)
                ].set_index("Sample")["null_percentile"].reindex(scope_samples)
                if selected.isna().any():
                    missing.append(f"{detector}:{parameter}:{representation}:{stage}")
                    continue
                representative[name] = selected.to_numpy()
            return (representative if not missing else None), missing

        representative_stage1, missing_stage1 = representative_for_stage("contaminated")
        representative_stage2, missing_stage2 = representative_for_stage("trimmed")
        missing_representatives = missing_stage1 + missing_stage2
        if missing_representatives:
            verdict["ensemble_complete"] = False
            verdict["ensemble_status"] = "broken_missing_representative"
            verdict["ensemble_missing_representatives"] = "; ".join(missing_representatives)
            verdict["scope"] = scope
            verdicts.append(verdict.reset_index(names="Sample"))
            continue
        assert representative_stage1 is not None and representative_stage2 is not None
        score_source = all_values.loc[:, scope_samples].dropna(axis=0, how="any")
        pca_model, pca_scores, _ = fit_pca(score_source, n_components=3)
        verdict["hotelling_t2"] = hotelling_t2(pca_scores)["hotelling_t2"].reindex(scope_samples).to_numpy()
        auto_shrinkage = ledoit_wolf_auto_intensity(score_source.T)

        def pc_scores(frame: pd.DataFrame) -> pd.DataFrame:
            transformed = pca_model.transform(frame.to_numpy(dtype=float))
            return pd.DataFrame(transformed, index=frame.index, columns=pca_scores.columns)

        ensemble_functions = {
            "mahalanobis": lambda frame: ledoit_wolf_mahalanobis(frame, parameter=auto_shrinkage),
            "knn": lambda frame: knn_mean_distance(pc_scores(frame), parameter=round(np.sqrt(len(frame))), weighting="isotropic"),
            "isolation_forest": lambda frame: isolation_forest_score(pc_scores(frame), parameter=SEEDS, n_estimators=isolation_forest_estimators),
            "lof": lambda frame: local_outlier_factor(pc_scores(frame), parameter=10 if scope == "pooled" else 8),
            "kernel_pca": lambda frame: kernel_pca_reconstruction_distance(pc_scores(frame), parameter=GAMMAS[4], n_components=3),
        }
        ensemble_stage1 = combine_percentiles(representative_stage1)
        stage1_limits, stage1_rates = calibrate_ensemble(
            score_source.T,
            ensemble_functions,
            n_replicates=isolation_forest_replicates,
        )
        stage1_flag = ensemble_stage1["trinity_mean"].gt(stage1_limits.loc["trinity_mean", "limit_95"])
        retained_for_ensemble = score_source.loc[:, ~stage1_flag.to_numpy()]
        ensemble_stage2 = combine_percentiles(representative_stage2)
        stage2_limits, stage2_rates = calibrate_ensemble(
            score_source.T,
            ensemble_functions,
            calibration_values=retained_for_ensemble.T,
            n_replicates=isolation_forest_replicates,
        )
        verdict = verdict.join(ensemble_stage1.add_suffix("_stage1")).join(ensemble_stage2.add_suffix("_stage2"))
        for stage, combination, calibrated_limits in (
            ("stage1", ensemble_stage1, stage1_limits),
            ("stage2", ensemble_stage2, stage2_limits),
        ):
            for name in calibrated_limits.index:
                verdict[f"{name}_flag_95_{stage}"] = combination[name].gt(calibrated_limits.loc[name, "limit_95"])
        verdict["trinity_mean"] = verdict["trinity_mean_stage2"]
        verdict["five_detector_mean"] = verdict["five_detector_mean_stage2"]
        verdict["flag_stage1"] = verdict["trinity_mean_flag_95_stage1"]
        verdict["flag_stage2"] = verdict["trinity_mean_flag_95_stage2"]
        verdict["calibration_sensitive"] = verdict["flag_stage1"] != verdict["flag_stage2"]
        verdict["candidate_outlier"] = verdict["candidate_outlier_stage2"] & ~verdict["calibration_sensitive"]
        if not analysis_complete:
            verdict["candidate_outlier"] = pd.NA
        auto_fallback = scope_scores.loc[
            scope_scores["detector"].eq("mahalanobis")
            & scope_scores["parameter_value"].eq("auto")
            & scope_scores["calibration_status"].eq("fallback_contaminated")
        ].shape[0] > 0
        verdict["ensemble_status"] = (
            "complete_with_mahalanobis_auto_fallback" if auto_fallback else "complete"
        ) if analysis_complete else "partial_nonstandard_calibration"
        for stage, calibrated_limits, calibrated_rates in (
            ("contaminated", stage1_limits, stage1_rates),
            ("trimmed", stage2_limits, stage2_rates),
        ):
            summary = calibrated_limits.join(calibrated_rates).reset_index(names="combination")
            summary["scope"] = scope
            summary["calibration_stage"] = stage
            summary["n_null_replicates"] = isolation_forest_replicates
            summary["isolation_forest_estimators"] = isolation_forest_estimators
            ensemble_limits.append(summary)
        verdict["scope"] = scope
        verdicts.append(verdict.reset_index(names="Sample"))

    verdict_table = pd.concat(verdicts, ignore_index=True)
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc" / "ensemble"
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "scores": output_dir / "detector_scores_long.csv",
        "limits": output_dir / "null_limits.csv",
        "stability": output_dir / "stability_fractions.csv",
        "verdict": output_dir / "ensemble_verdict.csv",
        "concentration": output_dir / "distance_concentration_diagnostic.csv",
        "ranks": output_dir / "isolation_forest_rank_ranges.csv",
        "ensemble_limits": output_dir / "ensemble_null_limits.csv",
        "run_metadata": output_dir / "run_metadata.csv",
    }
    long_scores.to_csv(paths["scores"], index=False)
    null_limits.to_csv(paths["limits"], index=False)
    stable.to_csv(paths["stability"], index=False)
    verdict_table.to_csv(paths["verdict"], index=False)
    pd.DataFrame(concentration).to_csv(paths["concentration"], index=False)
    if rank_ranges:
        pd.concat(rank_ranges, ignore_index=True).to_csv(paths["ranks"], index=False)
    else:
        pd.DataFrame(columns=["Sample", "isolation_forest_rank_best", "isolation_forest_rank_worst", "scope", "representation"]).to_csv(paths["ranks"], index=False)
    if ensemble_limits:
        pd.concat(ensemble_limits, ignore_index=True).to_csv(paths["ensemble_limits"], index=False)
    else:
        pd.DataFrame(columns=["combination", "scope", "calibration_stage", "limit_95", "limit_99", "false_positive_rate"]).to_csv(paths["ensemble_limits"], index=False)
    all_scopes_complete = bool(verdict_table["ensemble_complete"].fillna(False).all())
    pd.DataFrame({
        "include_isolation_forest": [include_isolation_forest],
        "isolation_forest_estimators": [isolation_forest_estimators],
        "non_if_n_null_replicates": [n_null_replicates],
        "isolation_forest_n_null_replicates": [isolation_forest_replicates],
        "ensemble_n_null_replicates": [isolation_forest_replicates],
        "mahalanobis_sweep_min": [MAHALANOBIS_SWEEP_MIN],
        "ensemble_complete": [include_isolation_forest and analysis_complete and all_scopes_complete],
        "candidate_verdict_available": [include_isolation_forest and analysis_complete and all_scopes_complete],
    }).to_csv(paths["run_metadata"], index=False)
    plot_outlier_diagnostics(
        long_scores,
        null_limits,
        verdict_table,
        output_dir / "figures",
        sample_labels=sample_label_mapping(metadata),
    )
    return list(paths.values())


def recalibrate_existing_mahalanobis(
    project_root: Path,
    *,
    n_null_replicates: int = NON_IF_NULL_REPLICATES,
    isolation_forest_replicates: int = ISOLATION_FOREST_NULL_REPLICATES,
    isolation_forest_estimators: int = ISOLATION_FOREST_ESTIMATORS,
) -> list[Path]:
    """Replace only Mahalanobis rows and rebuild dependent ensemble outputs."""
    metadata, all_values = _metadata_and_values(project_root)
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc" / "ensemble"
    existing_scores = pd.read_csv(output_dir / "detector_scores_long.csv")
    existing_limits = pd.read_csv(output_dir / "null_limits.csv")
    records = [existing_scores.loc[~existing_scores["detector"].eq("mahalanobis")]]
    limits = existing_limits.loc[~existing_limits["detector"].eq("mahalanobis")].to_dict(orient="records")
    concentration = pd.read_csv(output_dir / "distance_concentration_diagnostic.csv").to_dict(orient="records")
    rank_path = output_dir / "isolation_forest_rank_ranges.csv"
    rank_ranges = [pd.read_csv(rank_path)] if rank_path.exists() else []
    scopes = {"pooled": metadata["Sample"].tolist()}
    scopes.update({str(region).lower(): group["Sample"].tolist() for region, group in metadata.groupby("Sample type", observed=True, sort=False)})
    for scope, samples in scopes.items():
        raw = all_values.loc[:, samples].dropna(axis=0, how="any").T
        shrinkage_values = list(SHRINKAGES)
        observed = ledoit_wolf_mahalanobis_sweep(raw, shrinkages=shrinkage_values)
        stage_limits, stage_null_scores = _calibrate_sweep_stages(
            raw,
            observed,
            shrinkage_values,
            lambda frame, parameters, calibration: calibrate_ledoit_wolf_sweep(
                frame,
                shrinkages=parameters,
                calibration_values=calibration,
                n_replicates=n_null_replicates,
                batch_size=16,
            ),
        )
        sweep_records, sweep_limits = _evaluate_sweep(
            observed,
            stage_limits,
            stage_null_scores,
            shrinkage_values,
            scope=scope,
            detector="mahalanobis",
            parameter_name="shrinkage",
            representation="raw",
            counts_for_stability=True,
            n_null_replicates=n_null_replicates,
        )
        auto_records, auto_limits = _evaluate_mahalanobis_auto(
            raw,
            scope=scope,
            n_null_replicates=n_null_replicates,
        )
        records.extend(sweep_records + auto_records)
        limits.extend(sweep_limits + auto_limits)
    analysis_complete = (
        n_null_replicates == NON_IF_NULL_REPLICATES
        and isolation_forest_replicates == ISOLATION_FOREST_NULL_REPLICATES
        and isolation_forest_estimators == ISOLATION_FOREST_ESTIMATORS
    )
    return _finalize_ensemble_outputs(
        project_root,
        metadata,
        all_values,
        records,
        limits,
        concentration,
        rank_ranges,
        include_isolation_forest=True,
        n_null_replicates=n_null_replicates,
        isolation_forest_replicates=isolation_forest_replicates,
        isolation_forest_estimators=isolation_forest_estimators,
        analysis_complete=analysis_complete,
    )


def run_outlier_ensemble(
    project_root: Path,
    *,
    include_isolation_forest: bool = True,
    n_null_replicates: int = NON_IF_NULL_REPLICATES,
    isolation_forest_replicates: int = ISOLATION_FOREST_NULL_REPLICATES,
    isolation_forest_estimators: int = ISOLATION_FOREST_ESTIMATORS,
) -> list[Path]:
    """Generate multi-detector evidence; mark outputs partial when IF is omitted."""
    analysis_complete = (
        n_null_replicates == NON_IF_NULL_REPLICATES
        and isolation_forest_replicates == ISOLATION_FOREST_NULL_REPLICATES
        and isolation_forest_estimators == ISOLATION_FOREST_ESTIMATORS
    )
    metadata, all_values = _metadata_and_values(project_root)
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc" / "ensemble"
    records: list[pd.DataFrame] = []
    limits: list[dict[str, object]] = []
    concentration: list[dict[str, object]] = []
    rank_ranges: list[pd.DataFrame] = []
    scopes = {"pooled": metadata["Sample"].tolist()}
    scopes.update({str(region).lower(): group["Sample"].tolist() for region, group in metadata.groupby("Sample type", observed=True, sort=False)})

    for scope, samples in scopes.items():
        complete = all_values.loc[:, samples].dropna(axis=0, how="any")
        raw = complete.T
        n_samples = len(raw)
        k_values = list(range(2, 26 if scope == "pooled" else 16))
        model, full_scores, _ = fit_pca(complete, n_components=max(PCA_COMPONENTS))
        representations = {f"pc{q}": (full_scores.iloc[:, :q], model.explained_variance_[:q]) for q in PCA_COMPONENTS}
        concentration.append({"scope": scope, "representation": "raw", "k": 2, "relative_contrast": distance_contrast(raw, k=2)})

        # Raw-space proximity scores are retained only as the degeneracy diagnostic.
        for representation, (scores, eigenvalues) in representations.items():
            concentration.append({"scope": scope, "representation": representation, "k": 2, "relative_contrast": distance_contrast(scores, k=2)})
            weightings = ["isotropic"]
            if eigenvalues.min() >= 0.01 * eigenvalues.max():
                weightings.append("soft")
            else:
                limits.append({"scope": scope, "detector": "knn_soft", "parameter_name": "eigenvalue_floor", "parameter_value": "all", "representation": representation, "status": "skipped_eigenvalue_floor", "counts_for_stability": False})
            for weighting in weightings:
                knn_values = scores if weighting == "isotropic" else scores.divide(np.sqrt(eigenvalues), axis=1)
                knn_stage_limits, knn_stage_null_scores = _calibrate_sweep_stages(
                    knn_values,
                    knn_mean_distance_sweep(knn_values, k_values=k_values),
                    k_values,
                    lambda frame, parameters, calibration: calibrate_knn_sweep(
                        frame,
                        k_values=parameters,
                        calibration_values=calibration,
                        n_replicates=n_null_replicates,
                    ),
                )
                knn_observed = knn_mean_distance_sweep(knn_values, k_values=k_values)
                knn_records, knn_summaries = _evaluate_sweep(
                    knn_observed,
                    knn_stage_limits,
                    knn_stage_null_scores,
                    k_values,
                    scope=scope,
                    detector=f"knn_{weighting}",
                    parameter_name="k",
                    representation=representation,
                    counts_for_stability=True,
                    n_null_replicates=n_null_replicates,
                )
                records.extend(knn_records); limits.extend(knn_summaries)
            lof_values = list(range(10, 26)) if scope == "pooled" else list(range(2, 16))
            lof_observed = local_outlier_factor_sweep(scores, k_values=lof_values)
            lof_detector = "lof" if scope == "pooled" else "lof_supporting"
            lof_stage_limits, lof_stage_null_scores = _calibrate_sweep_stages(
                scores,
                lof_observed,
                lof_values,
                lambda frame, parameters, calibration: calibrate_lof_sweep(
                    frame,
                    k_values=parameters,
                    calibration_values=calibration,
                    n_replicates=n_null_replicates,
                ),
            )
            lof_records, lof_summaries = _evaluate_sweep(
                lof_observed,
                lof_stage_limits,
                lof_stage_null_scores,
                lof_values,
                scope=scope,
                detector=lof_detector,
                parameter_name="k",
                representation=representation,
                counts_for_stability=scope == "pooled",
                n_null_replicates=n_null_replicates,
            )
            records.extend(lof_records); limits.extend(lof_summaries)
            if include_isolation_forest:
                seed_scores = isolation_forest_seed_scores(
                    scores,
                    seeds=SEEDS,
                    n_estimators=isolation_forest_estimators,
                )
                observed = seed_scores.mean(axis=1).rename("isolation_forest")
                try:
                    stage1_if_limits, stage1_if_null_scores, stage1_if_rate = calibrate_isolation_forest(
                        scores,
                        seeds=SEEDS,
                        n_estimators=isolation_forest_estimators,
                        n_replicates=isolation_forest_replicates,
                    )
                except ValueError:
                    stage1_if_limits = pd.Series({"limit_95": np.nan, "limit_99": np.nan})
                    stage1_if_null_scores = pd.Series(dtype=float)
                    stage1_if_rate = np.nan
                if _valid_calibration(stage1_if_limits, stage1_if_null_scores):
                    stage1_if_flags = observed.gt(stage1_if_limits["limit_95"])
                    retained = scores.loc[~stage1_if_flags]
                else:
                    retained = scores.iloc[0:0]
                try:
                    stage2_if_limits, stage2_if_null_scores, stage2_if_rate = (
                        calibrate_isolation_forest(
                            scores,
                            seeds=SEEDS,
                            n_estimators=isolation_forest_estimators,
                            calibration_values=retained,
                            n_replicates=isolation_forest_replicates,
                        )
                        if len(retained) >= 2
                        else (pd.Series({"limit_95": np.nan, "limit_99": np.nan}), pd.Series(dtype=float), np.nan)
                    )
                except ValueError:
                    stage2_if_limits = pd.Series({"limit_95": np.nan, "limit_99": np.nan})
                    stage2_if_null_scores = pd.Series(dtype=float)
                    stage2_if_rate = np.nan
                for stage, if_limits, if_null_scores, if_rate in (
                    ("contaminated", stage1_if_limits, stage1_if_null_scores, stage1_if_rate),
                    ("trimmed", stage2_if_limits, stage2_if_null_scores, stage2_if_rate),
                ):
                    valid = _valid_calibration(if_limits, if_null_scores)
                    records.append(pd.DataFrame({
                        "Sample": observed.index,
                        "score": observed.to_numpy(),
                        "null_percentile": score_to_percentile(observed, if_null_scores).to_numpy() if valid else np.nan,
                        "flag_95": observed.gt(if_limits["limit_95"]).to_numpy() if valid else False,
                        "flag_99": observed.gt(if_limits["limit_99"]).to_numpy() if valid else False,
                        "detector": "isolation_forest",
                        "parameter_name": "seeds",
                        "parameter_value": "50",
                        "representation": representation,
                        "scope": scope,
                        "calibration_stage": stage,
                        "counts_for_stability": valid,
                        "n_null_replicates": isolation_forest_replicates,
                        "calibration_status": "ok" if valid else "broken",
                    }))
                    limits.append({
                        "scope": scope,
                        "detector": "isolation_forest",
                        "parameter_name": "seeds",
                        "parameter_value": "50",
                        "representation": representation,
                        "calibration_stage": stage,
                        "limit_95": if_limits["limit_95"],
                        "limit_99": if_limits["limit_99"],
                        "false_positive_rate": if_rate,
                        "n_null_replicates": isolation_forest_replicates,
                        "n_estimators": isolation_forest_estimators,
                        "counts_for_stability": valid,
                        "calibration_status": "ok" if valid else "broken",
                    })
                rank_table = seed_scores.rank(axis=0, ascending=False, method="min")
                ranks = pd.DataFrame({
                    "Sample": rank_table.index,
                    "isolation_forest_rank_best": rank_table.min(axis=1),
                    "isolation_forest_rank_worst": rank_table.max(axis=1),
                })
                ranks["scope"] = scope; ranks["representation"] = representation; rank_ranges.append(ranks)
            for gamma in GAMMAS:
                kernel_records, kernel_summaries = _evaluate_staged(
                    scores,
                    lambda frame, gamma=gamma, q=scores.shape[1]: kernel_pca_reconstruction_distance(frame, parameter=gamma, n_components=q),
                    scope=scope,
                    detector="kernel_pca",
                    parameter_name="gamma",
                    parameter_value=gamma,
                    representation=representation,
                    counts_for_stability=True,
                    n_null_replicates=n_null_replicates,
                )
                records.extend(kernel_records); limits.extend(kernel_summaries)
        auto_shrinkage = ledoit_wolf_auto_intensity(raw)
        shrinkage_values = list(SHRINKAGES)
        lw_observed = ledoit_wolf_mahalanobis_sweep(raw, shrinkages=shrinkage_values)
        lw_stage_limits, lw_stage_null_scores = _calibrate_sweep_stages(
            raw,
            lw_observed,
            shrinkage_values,
            lambda frame, parameters, calibration: calibrate_ledoit_wolf_sweep(
                frame,
                shrinkages=parameters,
                calibration_values=calibration,
                n_replicates=n_null_replicates,
                batch_size=16,
            ),
        )
        lw_records, lw_summaries = _evaluate_sweep(
            lw_observed,
            lw_stage_limits,
            lw_stage_null_scores,
            shrinkage_values,
            scope=scope,
            detector="mahalanobis",
            parameter_name="shrinkage",
            representation="raw",
            counts_for_stability=lambda parameter: parameter != auto_shrinkage,
            n_null_replicates=n_null_replicates,
        )
        records.extend(lw_records); limits.extend(lw_summaries)

        auto_records, auto_summaries = _evaluate_mahalanobis_auto(
            raw,
            scope=scope,
            n_null_replicates=n_null_replicates,
        )
        records.extend(auto_records); limits.extend(auto_summaries)

    return _finalize_ensemble_outputs(
        project_root,
        metadata,
        all_values,
        records,
        limits,
        concentration,
        rank_ranges,
        include_isolation_forest=include_isolation_forest,
        n_null_replicates=n_null_replicates,
        isolation_forest_replicates=isolation_forest_replicates,
        isolation_forest_estimators=isolation_forest_estimators,
        analysis_complete=analysis_complete,
    )
if __name__ == "__main__":
    run_outlier_ensemble(Path(__file__).resolve().parents[3])
