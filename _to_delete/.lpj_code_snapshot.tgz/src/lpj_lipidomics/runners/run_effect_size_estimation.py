"""Exploratory MIA effect-size estimation: lipid species, lipid classes,
the C1-C8 composites from the 2026-10-05 plan, and matched proteomics sets.

Status: EXPLORATORY, not the pre-registered two-stage run of
`doc/decisions/2026-10-05-biology-in-the-data-plan.md`. The composite
definitions and expected directions come from that plan (written before this
run), but the label-blind freeze (stage 1) was never done and a post hoc
class-level scan preceded this run. Read every number as estimation.

Unit of analysis: one sample per mouse within a region (20 mice: 10 MIA,
10 saline control). Experimental unit for MIA: the cage (dam + litter),
8 cages split 2/6, so the exact cage-permutation p has a floor of 1/28.
Mouse-level confidence intervals ignore litter clustering and are optimistic.
"""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from ..plotting import BIO_GROUP_COLORS, apply_plot_style, save_figure
from .run_integration_tests import treatment_score_test

REGIONS = ["Cerebellum", "Cortex", "Hippocampus"]
DATE_MATCHED = "2024-06-11"  # the only collection date with both groups
SEED = 20261012

# Protein sets (gene symbols) matched to lipid hypotheses. Only detected genes are used.
PROTEIN_SETS = {
    "myelin structural (C1)": ["Mbp", "Plp1", "Mag", "Mog", "Cnp", "Mobp", "Ugt8"],
    "plasmalogen synthesis (C6)": ["Gnpat", "Agps", "Far1"],
    "ganglioside catabolism (C8)": ["Hexb", "Gm2a", "Psap"],
    "sphingolipid metabolism (C4)": ["Cers2", "Cers6", "Sptlc2", "Smpd3", "Asah1"],
}


# ---------------------------------------------------------------- inputs
def load_inputs(root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    lip_dir = root / "results/pipeline_test/prevalence20_noexclusion"
    integ = root / "results/mia_vs_control/14_integration/prevalence20_noexclusion/00_inputs"
    lipids = pd.read_csv(lip_dir / "00_inputs/differential_input_matrix.csv", index_col=0)  # log2, median-normalized, NA kept
    names = (pd.read_csv(lip_dir / "03_differential/differential_effects.csv")
             .drop_duplicates("Feature").set_index("Feature")[["Lipid Name", "Lipid Class"]]
             .reindex(lipids.index))
    meta = pd.read_csv(integ / "sample_metadata.csv").set_index("Sample")
    proteins = pd.read_csv(integ / "blocks/proteomics.csv", index_col=0).T  # proteins x samples, log2 MaxLFQ (ND-imputed)
    protein_genes = pd.read_csv(integ / "proteomics_feature_annotation.csv").set_index("Protein ID")["Gene"]
    meta = meta.loc[lipids.columns]
    return lipids, names, meta, proteins, protein_genes


def annotate_lipids(names: pd.DataFrame) -> pd.DataFrame:
    """Add ether flag, resolved acyl length for sphingolipids, and a subclass label."""
    out = names.copy()
    out["ether"] = out["Lipid Name"].str.contains(r"\((?:O|P)-", regex=True, na=False)
    out["subclass"] = np.where(out["ether"], out["Lipid Class"] + "-ether", out["Lipid Class"])
    # e.g. SM(d18:1_24:0) -> 24; sum-composition names like SM(d42:1) stay NaN (not resolvable)
    acyl = out["Lipid Name"].str.extract(r"^[A-Za-z0-9]+\([dmt]\d+:\d+_(\d+):\d+\)")[0]
    out["sphingo_acyl_c"] = pd.to_numeric(acyl, errors="coerce")
    return out


# ---------------------------------------------------------------- effects
def mia_effects(values: pd.DataFrame, meta: pd.DataFrame) -> pd.DataFrame:
    """Sex-balanced MIA effect per row: mean over sexes of (MIA - control).

    values: features x samples (one region). Pooled residual variance from the
    four group x sex cells gives the SE (mouse-level, ignores litter).
    """
    cells = {}
    for group in ["MIA", "Saline Control"]:
        for sex in ["Male", "Female"]:
            cols = meta.index[(meta["Bio group"] == group) & (meta["Sex"] == sex)]
            v = values[cols]
            cells[(group, sex)] = (v.mean(axis=1), v.var(axis=1, ddof=1), v.notna().sum(axis=1))
    diff = sum(cells[("MIA", s)][0] - cells[("Saline Control", s)][0] for s in ["Male", "Female"]) / 2
    resid_df = sum(c[2] - 1 for c in cells.values())
    s2 = sum((c[2] - 1) * c[1] for c in cells.values()) / resid_df
    se = np.sqrt(s2 * sum(1 / c[2] for c in cells.values()) / 4)
    tcrit = stats.t.ppf(0.975, resid_df.clip(lower=1))
    return pd.DataFrame({
        "estimate_log2": diff, "se_log2": se, "d": diff / np.sqrt(s2),
        "ci_lower_log2": diff - tcrit * se, "ci_upper_log2": diff + tcrit * se, "resid_df": resid_df,
    })


def robustness(values: pd.DataFrame, meta: pd.DataFrame) -> pd.DataFrame:
    """Leave-one-cage-out range, per-sex estimates and the date-matched estimate (log2)."""
    loco = []
    for cage in meta["Cage"].unique():
        keep = meta.index[meta["Cage"] != cage]
        loco.append(mia_effects(values[keep], meta.loc[keep])["estimate_log2"])
    loco = pd.concat(loco, axis=1)
    out = pd.DataFrame({"loco_min_log2": loco.min(axis=1), "loco_max_log2": loco.max(axis=1)})
    for sex in ["Male", "Female"]:
        m = meta[meta["Sex"] == sex]
        out[f"{sex.lower()}_only_log2"] = (values[m.index[m["Bio group"] == "MIA"]].mean(axis=1)
                                          - values[m.index[m["Bio group"] == "Saline Control"]].mean(axis=1))
    m = meta[meta["Date collected"] == DATE_MATCHED]
    out["date_matched_log2"] = mia_effects(values[m.index], m)["estimate_log2"]
    return out


def score_test(score: pd.Series, meta: pd.DataFrame, name: str) -> dict[str, object]:
    """Cage-permutation Welch test from the integration runner (floor 1/28)."""
    aligned = meta.loc[score.index].reset_index()
    result = treatment_score_test(aligned, score.reset_index(drop=True), score_name=name, n_mouse_permutations=9_999)
    return {k: result[k] for k in ["observed_welch_t", "cage_permutation_p", "mouse_permutation_p", "group_r_squared", "cage_r_squared"]}


# ---------------------------------------------------------------- composites C1-C8
def composite_members(ann: pd.DataFrame) -> dict[str, tuple[pd.Index, pd.Index]]:
    """(numerator, denominator) feature sets, as defined in the 2026-10-05 plan §4.4."""
    cls, name = ann["Lipid Class"], ann["Lipid Name"].fillna("")
    gpl = cls.isin(["PC", "PE", "PS", "PI", "PG", "PA", "CL", "PIP", "LPC", "LPE", "LPS", "LPG", "LPA", "LPI"])
    long_sphingo = cls.isin(["SM", "Cer", "Hex1Cer"]) & (ann["sphingo_acyl_c"] >= 24)
    myelin = cls.isin(["Hex1Cer", "ST"]) | (cls.eq("PE") & ann["ether"]) | long_sphingo
    pepc = cls.isin(["PE", "PC"])
    idx = ann.index
    return {
        "C1 myelin lipid index": (idx[myelin], idx[gpl & ~myelin]),
        "C2 DHA share (PE+PC)": (idx[pepc & name.str.contains("22:6")], idx[pepc]),
        "C3 AA:DHA (PE+PC)": (idx[pepc & name.str.contains("20:4")], idx[pepc & name.str.contains("22:6")]),
        "C4 Cer:SM": (idx[cls.eq("Cer")], idx[cls.eq("SM")]),
        "C5 lyso:parent": (idx[cls.isin(["LPC", "LPE"])], idx[cls.isin(["PC", "PE"])]),
        "C6 ether-PE fraction": (idx[cls.eq("PE") & ann["ether"]], idx[cls.eq("PE")]),
        "C7 cardiolipin": (idx[cls.eq("CL")], idx[cls.isin(["PC", "PE", "PS", "PI"])]),
        "C8 ganglioside maturity": (idx[cls.isin(["GD1a", "GD1b", "GT1a", "GQ1b"])], idx[cls.isin(["GM3", "GD3", "GM2", "GD2", "GT3"])]),
    }


def composite_scores(region_values: pd.DataFrame, members: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    """log2(sum numerator / sum denominator) per sample, on linear intensities.

    Within-sample ratios cancel the per-sample median normalization. Only
    features complete in this region are summed, so missingness cannot move a ratio.
    """
    complete = region_values.dropna(axis=0)
    linear = np.power(2.0, complete)
    scores, counts = {}, []
    for name, (num, den) in members.items():
        num_c, den_c = complete.index.intersection(num), complete.index.intersection(den)
        counts.append({"composite": name, "n_numerator": len(num_c), "n_denominator": len(den_c)})
        if len(num_c) and len(den_c):
            scores[name] = np.log2(linear.loc[num_c].sum() / linear.loc[den_c].sum())
    return pd.DataFrame(scores).T, pd.DataFrame(counts)


# ---------------------------------------------------------------- main
def run(root: Path, overwrite: bool = False) -> Path:
    out_dir = root / "results/mia_vs_control/15_effect_sizes/prevalence20_noexclusion"
    if not overwrite and out_dir.exists() and any(out_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite {out_dir}")
    out_dir.mkdir(parents=True, exist_ok=True)
    lipids, names, meta, proteins, protein_genes = load_inputs(root)
    ann = annotate_lipids(names)
    members = composite_members(ann)

    feature_rows, equiv_rows, class_rows, comp_rows, count_rows = [], [], [], [], []
    region_effects = {}
    for region in REGIONS:
        m = meta[meta["Sample type"] == region]
        values = lipids[m.index]

        # 1. species-level effects with robustness checks
        eff = mia_effects(values, m).join(robustness(values, m))
        eff = ann[["Lipid Name", "Lipid Class", "subclass"]].join(eff).assign(Region=region)
        feature_rows.append(eff)
        region_effects[region] = eff["estimate_log2"]

        # 2. which effect sizes can be ruled out (mouse-level CI, optimistic)
        ok = eff["se_log2"].notna()
        row = {"Region": region, "n_lipids": int(ok.sum()),
               "median_abs_fold_change": float(2 ** eff.loc[ok, "estimate_log2"].abs().median())}
        for fc in [1.25, 1.5, 2.0]:
            inside = (eff["ci_lower_log2"] > -np.log2(fc)) & (eff["ci_upper_log2"] < np.log2(fc))
            row[f"share_ci_excludes_gt_{fc}x"] = float(inside[ok].mean())
        equiv_rows.append(row)

        # 3. post hoc class / subclass shifts (mean of species log2 effects)
        for sub, idx in ann.groupby("subclass").groups.items():
            if len(idx) < 8:
                continue
            e = eff.loc[idx]
            class_rows.append({"Region": region, "subclass": sub, "n_species": len(idx),
                               **{c: e[c].mean() for c in ["estimate_log2", "loco_min_log2", "loco_max_log2",
                                                            "male_only_log2", "female_only_log2", "date_matched_log2"]},
                               "share_species_down": float((e["estimate_log2"] < 0).mean())})

        # 4. pre-defined composites C1-C8
        scores, counts = composite_scores(values, members)
        count_rows.append(counts.assign(Region=region))
        comp_eff = mia_effects(scores, m).join(robustness(scores, m))
        sd = scores.std(axis=1, ddof=1)
        for name in scores.index:
            comp_rows.append({"Region": region, "composite": name, **comp_eff.loc[name].to_dict(),
                              "effect_in_sd": comp_eff.loc[name, "estimate_log2"] / sd[name],
                              **score_test(scores.loc[name], m, f"{region}:{name}")})

    pd.concat(feature_rows).rename_axis("Feature").to_csv(out_dir / "01_lipid_species_effects.csv")
    pd.DataFrame(equiv_rows).to_csv(out_dir / "02_effects_ruled_out.csv", index=False)
    corr = [{"pair": f"{a}-{b}", "pearson_r": float(pd.concat([region_effects[a], region_effects[b]], axis=1).dropna().corr().iloc[0, 1])}
            for a, b in [("Cortex", "Cerebellum"), ("Hippocampus", "Cerebellum"), ("Cortex", "Hippocampus")]]
    pd.DataFrame(corr).to_csv(out_dir / "03_cross_region_effect_correlation.csv", index=False)
    pd.DataFrame(class_rows).to_csv(out_dir / "04_class_shifts_posthoc.csv", index=False)
    pd.DataFrame(comp_rows).to_csv(out_dir / "05_composites_C1_C8.csv", index=False)
    pd.concat(count_rows).to_csv(out_dir / "05_composite_member_counts.csv", index=False)

    # 5. proteomics: matched protein sets (mean within-region z of member proteins)
    rng = np.random.default_rng(SEED)
    set_rows, protein_rows, sanity_rows = [], [], []
    gene_of = protein_genes.reindex(proteins.index)
    for region in REGIONS:
        m = meta[meta["Sample type"] == region]
        values = proteins[m.index]
        z = values.sub(values.mean(axis=1), axis=0).div(values.std(axis=1, ddof=1), axis=0)
        per_protein = mia_effects(values, m)
        for set_name, genes in PROTEIN_SETS.items():
            ids = gene_of.index[gene_of.isin(genes)]
            for pid in ids:
                protein_rows.append({"Region": region, "set": set_name, "Protein ID": pid, "Gene": gene_of[pid],
                                     **per_protein.loc[pid, ["estimate_log2", "d", "ci_lower_log2", "ci_upper_log2"]].to_dict()})
            score = z.loc[ids].mean()
            score_eff = mia_effects(score.to_frame().T, m).join(robustness(score.to_frame().T, m)).iloc[0]
            # reference: how unusual is this set's mean d among random protein sets of the same size?
            random_d = [per_protein["d"].iloc[rng.choice(len(per_protein), len(ids), replace=False)].mean() for _ in range(2000)]
            set_d = per_protein.loc[ids, "d"].mean()
            set_rows.append({"Region": region, "set": set_name, "genes_detected": ";".join(gene_of[ids]),
                             "effect_in_sd": score_eff["estimate_log2"], **score_eff.to_dict(),
                             "mean_protein_d": set_d, "random_set_percentile": float(np.mean(np.abs(random_d) >= abs(set_d))),
                             **score_test(score, m, f"{region}:{set_name}")})
    # region sanity check in controls: myelin proteins should be highest in cerebellum at P14
    ctrl = meta[meta["Bio group"] == "Saline Control"]
    for gene in PROTEIN_SETS["myelin structural (C1)"] + ["Calb1", "Gfap"]:
        ids = gene_of.index[gene_of == gene]
        for pid in ids:
            sanity_rows.append({"Gene": gene, "Protein ID": pid,
                                **{r: float(proteins.loc[pid, ctrl.index[ctrl["Sample type"] == r]].mean()) for r in REGIONS}})
    pd.DataFrame(set_rows).to_csv(out_dir / "06_proteomics_set_effects.csv", index=False)
    pd.DataFrame(protein_rows).to_csv(out_dir / "06_proteomics_protein_effects.csv", index=False)
    pd.DataFrame(sanity_rows).to_csv(out_dir / "06_proteomics_region_sanity_controls.csv", index=False)

    # 6. are lipid and protein myelin signals independent? (same tissue piece -> probably not)
    myelin_rows, per_mouse = [], {}
    for region in REGIONS:
        m = meta[meta["Sample type"] == region]
        scores, _ = composite_scores(lipids[m.index], members)
        values = proteins[m.index]
        z = values.sub(values.mean(axis=1), axis=0).div(values.std(axis=1, ddof=1), axis=0)
        prot = z.loc[gene_of.index[gene_of.isin(PROTEIN_SETS["myelin structural (C1)"])]].mean()
        d = pd.DataFrame({"lipid_C1": scores.loc["C1 myelin lipid index"], "protein_myelin_z": prot}).join(
            m[["Bio group", "Sex", "Cage", "Date collected"]])
        per_mouse[region] = d
        ctrl_rows = d["Bio group"] == "Saline Control"
        slope, intercept = np.polyfit(d["lipid_C1"], d["protein_myelin_z"], 1)
        resid = d["protein_myelin_z"] - (slope * d["lipid_C1"] + intercept)
        myelin_rows.append({"Region": region,
                            "r_lipid_protein_all": d["lipid_C1"].corr(d["protein_myelin_z"]),
                            "r_lipid_protein_controls": d.loc[ctrl_rows, "lipid_C1"].corr(d.loc[ctrl_rows, "protein_myelin_z"]),
                            "protein_mia_minus_ctrl_sd": d.loc[~ctrl_rows, "protein_myelin_z"].mean() - d.loc[ctrl_rows, "protein_myelin_z"].mean(),
                            "protein_mia_minus_ctrl_after_lipid_sd": resid[~ctrl_rows].mean() - resid[ctrl_rows].mean()})
    pd.DataFrame(myelin_rows).to_csv(out_dir / "07_myelin_lipid_protein_crosscheck.csv", index=False)
    hip = per_mouse["Hippocampus"]
    hip.groupby(["Bio group", "Cage", "Sex", "Date collected"])[["lipid_C1", "protein_myelin_z"]].agg(["mean", "size"]).to_csv(
        out_dir / "07_hippocampus_myelin_by_cage.csv")

    # figures
    apply_plot_style()
    comp = pd.DataFrame(comp_rows)
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.2), sharey=True)
    order = list(members)
    for ax, region in zip(axes, REGIONS):
        c = comp[comp["Region"] == region].set_index("composite").reindex(order)
        sd = (c["estimate_log2"] / c["effect_in_sd"])  # region SD of each composite score
        y = np.arange(len(order))[::-1]
        ax.hlines(y, c["loco_min_log2"] / sd, c["loco_max_log2"] / sd, color="0.75", lw=6, label="leave-one-litter-out range")
        ax.errorbar(c["effect_in_sd"], y, xerr=[(c["estimate_log2"] - c["ci_lower_log2"]) / sd, (c["ci_upper_log2"] - c["estimate_log2"]) / sd],
                    fmt="o", color="black", ms=5, capsize=2, label="estimate, 95% CI (mouse-level)")
        ax.axvline(0, color="0.4", lw=0.8)
        ax.set_title(region)
        ax.set_xlabel("MIA − control (SD of composite)")
    axes[0].set_yticks(np.arange(len(order))[::-1], order)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.06))
    fig.suptitle("Pre-defined lipid composites C1–C8: exploratory estimates, all 60 samples", fontsize=10)
    save_figure(fig, out_dir / "figures" / "composite_effects_forest")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.2, 4.4))
    for (group, cage), g in hip.groupby(["Bio group", "Cage"]):
        matched = (g["Date collected"] == DATE_MATCHED).all()
        ax.scatter(g["lipid_C1"], g["protein_myelin_z"], s=55, color=BIO_GROUP_COLORS.get(group, "0.5"),
                   marker="o" if matched else "^", edgecolor="black", lw=0.5)
        ax.annotate(cage[-3:], (g["lipid_C1"].mean(), g["protein_myelin_z"].mean()), fontsize=6, alpha=0.7)
    ax.set_xlabel("Lipid myelin index C1 (log2 ratio)")
    ax.set_ylabel("Myelin protein score (mean z of 7 proteins)")
    ax.set_title(f"Hippocampus: r = {hip['lipid_C1'].corr(hip['protein_myelin_z']):.2f}", fontsize=10)
    for label, colour in BIO_GROUP_COLORS.items():
        ax.scatter([], [], color=colour, edgecolor="black", lw=0.5, label=label)
    ax.scatter([], [], marker="o", color="white", edgecolor="black", label="litter from 2024-06-11")
    ax.scatter([], [], marker="^", color="white", edgecolor="black", label="litter from another date")
    ax.legend(fontsize=7, frameon=False, loc="upper left")
    save_figure(fig, out_dir / "figures" / "hippocampus_myelin_lipid_vs_protein")
    plt.close(fig)

    # provenance
    inputs = [root / "results/pipeline_test/prevalence20_noexclusion/00_inputs/differential_input_matrix.csv",
              root / "results/mia_vs_control/14_integration/prevalence20_noexclusion/00_inputs/sample_metadata.csv",
              root / "results/mia_vs_control/14_integration/prevalence20_noexclusion/00_inputs/blocks/proteomics.csv"]
    commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True).stdout.strip()
    dirty = bool(subprocess.run(["git", "status", "--porcelain"], cwd=root, capture_output=True, text=True).stdout.strip())
    manifest = {
        "analysis": "exploratory MIA effect-size estimation (lipids, C1-C8 composites, proteomics sets)",
        "status": "EXPLORATORY - not the pre-registered two-stage run; see module docstring",
        "population": "prevalence20_noexclusion, all 60 samples",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit": commit, "git_worktree_dirty": dirty,
        "inputs_sha256": {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
        "inference_note": "mouse-level CIs ignore litter clustering (optimistic); cage-permutation p floor = 1/28 = 0.036",
        "prompt_record": "prompts/2026-10-12-effect-size-estimation-v1.md",
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=1))
    return out_dir


if __name__ == "__main__":
    print(run(Path(__file__).resolve().parents[3], overwrite=True))
