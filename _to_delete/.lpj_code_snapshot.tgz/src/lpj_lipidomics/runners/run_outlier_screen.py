"""Generate standalone regional PCA outlier-screen reports."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..config import (
    OUTLIER_SCREEN_PCS,
    ROBUST_MAHALANOBIS_PCS,
    SAMPLE_OUTLIER_EXCLUSIONS,
)
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import full_lipidomics_metadata
from ..multivariate.pca import fit_pca
from ..outliers.screen import sample_outlier_table
from ..preprocessing import preprocess_for_multivariate


def run_outlier_screen(project_root: Path) -> list[Path]:
    """Write one evidence table per region without excluding newly flagged samples."""
    data_file = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc"
    sample_sheet, lipidomics = read_lipidomics_tables(data_file)
    sample_columns, blank_columns, _ = lipidomics_measurement_columns(lipidomics)

    metadata = full_lipidomics_metadata(sample_sheet, sample_columns)
    if len(metadata) != 60:
        raise ValueError(f"Expected 60 samples before outlier screening, found {len(metadata)}.")

    raw_intensity = lipidomics.loc[:, metadata["Sample"]].apply(pd.to_numeric, errors="coerce")
    blank_intensity = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    values = preprocess_for_multivariate(raw_intensity, blank_intensity)
    output_paths: list[Path] = []
    for region, region_metadata in metadata.groupby("Sample type", sort=False, observed=True):
        samples = region_metadata["Sample"].tolist()
        complete = values.loc[:, samples].dropna(axis=0, how="any")
        if OUTLIER_SCREEN_PCS > min(complete.shape):
            raise ValueError(f"{region}: insufficient PCA rank for {OUTLIER_SCREEN_PCS} PCs.")
        model, scores, _ = fit_pca(complete, n_components=OUTLIER_SCREEN_PCS)
        diagnostics = sample_outlier_table(
            complete,
            model,
            scores,
            robust_scores=scores.iloc[:, :ROBUST_MAHALANOBIS_PCS],
        )
        diagnostics.index.name = "Sample"
        diagnostics = diagnostics.reset_index().merge(
            region_metadata.loc[:, ["Sample", "Sample number", "Mouse number", "Bio group", "Sex"]],
            on="Sample",
            how="left",
            validate="one_to_one",
        )
        diagnostics["listed_for_sample_exclusion"] = diagnostics["Sample"].isin(SAMPLE_OUTLIER_EXCLUSIONS)
        path = output_dir / f"outlier_screen_{region.lower()}.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        diagnostics.to_csv(path, index=False)
        output_paths.append(path)
    return output_paths


if __name__ == "__main__":
    run_outlier_screen(Path(__file__).resolve().parents[3])
