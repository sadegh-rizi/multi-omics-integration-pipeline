"""All-60 metabolomics normalization arms and paired PQN/median comparisons."""

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from ..config import MAX_MISSING_FRACTION, MIN_PER_CELL
from ..io.metabolomics import read_metabolomics_tables, metabolomics_measurement_columns
from ..io.study_design import metabolomics_metadata
from ..metabolomics_preprocessing import preprocess_metabolomics
from ..multivariate.pca_metadata import between_group_r2
from ..statistics.differential import fit_regionwise_differential
from .pipeline_stages import run_limma, run_multivariate


def run_metabolomics_normalization_arm(project_root: Path, normalization: str) -> Path:
    """Use the existing per-region treatment × sex model, with no imputation."""
    variant = "prevalence20_noexclusion" + ("_pqn" if normalization == "pqn" else "")
    output = project_root / "results" / "metabolomics_pipeline_rerun" / variant
    stages = {name: output / name for name in ("00_inputs", "01_preprocessing", "03_differential", "04_multivariate")}
    for directory in stages.values():
        directory.mkdir(parents=True, exist_ok=True)
    sheet, report = read_metabolomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    samples, blanks, _ = metabolomics_measurement_columns(report)
    metadata = metabolomics_metadata(sheet, samples, zero_padded=False,
                                    cage_workbook=project_root / "data" / "Samples for metabolomics.xlsx")
    raw = report.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    blank_values = report.loc[:, blanks].apply(pd.to_numeric, errors="coerce")
    values, diagnostics, excluded, shifts = preprocess_metabolomics(
        raw, blank_values, report["Method"], max_missing_fraction=MAX_MISSING_FRACTION,
        normalization=normalization, groups=metadata.set_index("Sample")["Sample type"],
    )
    _, _, _, median_shifts = preprocess_metabolomics(
        raw, blank_values, report["Method"], max_missing_fraction=MAX_MISSING_FRACTION,
    )
    shift_table = shifts.rename_axis(columns="Sample").stack().rename("shift_log2").reset_index()
    extra = (shifts - median_shifts).rename_axis(columns="Sample").stack().rename("extra_shift_vs_median_log2").reset_index()
    shift_table = shift_table.merge(extra, on=["Method", "Sample"], validate="one_to_one").merge(metadata, on="Sample", validate="many_to_one")
    shift_table["normalization"] = normalization
    shift_table.to_csv(stages["01_preprocessing"] / "normalization_shifts.csv", index=False)
    diagnostics.to_csv(stages["01_preprocessing"] / "preprocessing_diagnostics.csv", index=False)
    excluded.to_csv(stages["01_preprocessing"] / "blank_dominated_features.csv", index=False)
    values.to_csv(stages["00_inputs"] / "differential_input_matrix.csv", index_label="Feature")
    metadata.to_csv(stages["00_inputs"] / "analysis_metadata.csv", index=False)
    metadata.loc[:, ["Sample", "Sample type", "Bio group", "Sex", "Mouse number"]].rename(
        columns={"Sample type": "Region", "Bio group": "BioGroup"},
    ).to_csv(stages["00_inputs"] / "differential_input_metadata.csv", index=False)
    fitted = fit_regionwise_differential(values, metadata, annotations=report.loc[:, ["Metabolite", "Method"]],
                                        min_per_cell=MIN_PER_CELL, fdr_denominator="all_features")
    fitted.effects.to_csv(stages["03_differential"] / "differential_effects.csv", index=False)
    fitted.feature_qc.to_csv(stages["03_differential"] / "differential_feature_qc.csv", index=False)
    run_limma(project_root, stages["00_inputs"], stages["03_differential"])
    run_multivariate(values, metadata, stages["04_multivariate"], include_plsda=False, pca_figures=True)
    (output / "run_manifest.json").write_text(json.dumps({
        "variant": variant, "modality": "metabolomics", "normalization": normalization,
        "normalization_by": "acquisition mode; PQN reference pools treatments within region and is median-centred",
        "n_input_samples": 60, "n_surviving_samples": len(metadata), "n_tested_features": len(values),
        "imputation": "none", "model": "value ~ BioGroup * Sex within region",
        "fdr_family": "full retained feature panel within Region x Effect",
        "experimental_unit": "dam/cage; pup-level models remain descriptive",
    }, indent=2) + "\n", encoding="utf-8")
    return output


def compare_normalization_arms(median_arm: Path, pqn_arm: Path, modality: str) -> pd.DataFrame:
    """Write effect/SE comparisons and the predeclared sensitivity checks."""
    destination = pqn_arm / "05_diagnostics"
    destination.mkdir(parents=True, exist_ok=True)
    keys = ["Feature", "Region", "Effect"]
    median = pd.read_csv(median_arm / "03_differential" / "differential_effects.csv")
    pqn = pd.read_csv(pqn_arm / "03_differential" / "differential_effects.csv")
    columns = [*keys, "estimate_log2", "standard_error", "p_value", "p_value_fdr"]
    paired = median[columns].merge(pqn[columns], on=keys, suffixes=("_median", "_pqn"),
                                   how="outer", validate="one_to_one", indicator=True)
    if not paired["_merge"].eq("both").all():
        raise AssertionError("Normalization arms have different fitted feature keys.")
    paired["estimate_difference_log2"] = paired["estimate_log2_pqn"] - paired["estimate_log2_median"]
    for arm in ("median", "pqn"):
        paired[f"t_{arm}"] = paired[f"estimate_log2_{arm}"] / paired[f"standard_error_{arm}"]
    paired["q05_status_changed"] = paired["p_value_fdr_median"].lt(0.05) != paired["p_value_fdr_pqn"].lt(0.05)
    paired.to_csv(destination / "normalization_effect_comparison.csv", index=False)
    paired.loc[paired["q05_status_changed"]].to_csv(destination / "normalization_changed_q05.csv", index=False)
    rows = []
    for (region, effect), current in paired.groupby(["Region", "Effect"], sort=False):
        row = {"Region": region, "Effect": effect,
               "spearman_t": spearmanr(current["t_median"], current["t_pqn"]).statistic,
               "n_changed_q05": int(current["q05_status_changed"].sum())}
        for arm in ("median", "pqn"):
            row[f"n_q_lt_05_{arm}"] = int(current[f"p_value_fdr_{arm}"].lt(0.05).sum())
            row[f"min_q_{arm}"] = current[f"p_value_fdr_{arm}"].min()
        rows.append(row)
    summary = pd.DataFrame(rows)
    summary.to_csv(destination / "normalization_comparison_summary.csv", index=False)
    shifts = pd.read_csv(pqn_arm / "01_preprocessing" / "normalization_shifts.csv")
    if "Method" not in shifts:
        shifts["Method"] = "lipidomics"
    shift_rows = []
    for mode, current in shifts.groupby("Method", sort=False):
        extra = current["extra_shift_vs_median_log2"]
        shift_rows.append({"Method": mode, "shift_sd_log2": extra.std(ddof=1),
                           "r2_group": between_group_r2(extra, current["Bio group"]),
                           "r2_region": between_group_r2(extra, current["Sample type"])})
    shift_summary = pd.DataFrame(shift_rows)
    shift_summary.to_csv(destination / "normalization_shift_summary.csv", index=False)
    expected_sd = 0.065 if modality == "lipidomics" else 0.051
    checks = pd.DataFrame([
        {"check": "t-statistic Spearman >= 0.95 in every Region x Effect", "passed": bool(summary["spearman_t"].ge(0.95).all())},
        {"check": "extra shift SD within 0.02 log2 of exploratory reference", "passed": bool((shift_summary["shift_sd_log2"] - expected_sd).abs().le(0.02).all())},
        {"check": "extra shift group R2 <= 0.05", "passed": bool(shift_summary["r2_group"].le(0.05).all())},
    ])
    checks.to_csv(destination / "normalization_validation.csv", index=False)
    if not checks["passed"].all():
        raise AssertionError(f"PQN tolerance failure ({modality}); investigate {destination}")
    return summary
