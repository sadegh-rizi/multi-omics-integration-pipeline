"""Run the confirmed MOFA+ all-sample integration analysis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment


VIEW_NAMES = ("lipidomics", "metabolomics", "proteomics")
SEEDS = tuple(range(20_261_101, 20_261_111))
N_FACTORS = 15
N_ITERATIONS = 1_000
N_SHUFFLES = 20


def _load_inputs(input_root: Path) -> tuple[list[pd.DataFrame], pd.DataFrame]:
    blocks: list[pd.DataFrame] = []
    sample_order: pd.Index | None = None
    for view in VIEW_NAMES:
        table = pd.read_csv(input_root / "00_inputs" / "blocks" / f"{view}.csv")
        if "Sample" not in table:
            raise KeyError(f"{view} block is missing the Sample column.")
        table = table.set_index("Sample")
        table.index = table.index.astype(str)
        if table.index.has_duplicates:
            raise ValueError(f"{view} block contains duplicate samples.")
        if table.isna().to_numpy().any():
            raise ValueError(f"MOFA requires complete values; {view} contains missing values.")
        if sample_order is None:
            sample_order = table.index
        elif not table.index.equals(sample_order):
            raise ValueError("MOFA blocks do not have identical sample order.")
        blocks.append(table.apply(pd.to_numeric, errors="raise"))
    assert sample_order is not None
    metadata = pd.read_csv(input_root / "00_inputs" / "sample_metadata.csv")
    metadata["Sample"] = metadata["Sample"].astype(str)
    metadata = metadata.set_index("Sample").loc[sample_order].reset_index()
    return blocks, metadata


def _fit_mofa(
    blocks: list[pd.DataFrame],
    *,
    seed: int,
    iterations: int = N_ITERATIONS,
) -> tuple[np.ndarray, list[np.ndarray], np.ndarray]:
    """Fit one MOFA model using the package's one-group nested input API."""
    from mofapy2.run.entry_point import entry_point

    model = entry_point()
    data = [[block.to_numpy(dtype=float)] for block in blocks]
    model.set_data_matrix(
        data,
        views_names=list(VIEW_NAMES),
        samples_names=[[str(sample) for sample in blocks[0].index]],
        features_names=[
            [f"{view}::{feature}" for feature in block.columns.astype(str)]
            for view, block in zip(VIEW_NAMES, blocks)
        ],
    )
    model.set_data_options(scale_views=True, center_groups=True)
    model.set_model_options(factors=N_FACTORS)
    model.set_train_options(
        iter=iterations,
        startELBO=1,
        freqELBO=1,
        convergence_mode="fast",
        dropR2=0.02,
        seed=seed,
        quiet=True,
        verbose=False,
    )
    model.build()
    model.run()
    expectations = model.model.getExpectations()
    factors = np.asarray(expectations["Z"]["E"], dtype=float)
    weights = [np.asarray(view["E"], dtype=float) for view in expectations["W"]]
    variance_explained = np.asarray(model.model.calculate_variance_explained()[0], dtype=float)
    return factors, weights, variance_explained


def _match_factor_order(
    reference: np.ndarray,
    candidate: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, list[tuple[int, int, float]]]:
    """Match candidate factors to a reference by absolute score correlation."""
    correlation = np.corrcoef(reference.T, candidate.T)[: reference.shape[1], reference.shape[1] :]
    correlation = np.nan_to_num(correlation, nan=0.0)
    rows, columns = linear_sum_assignment(-np.abs(correlation))
    aligned = np.full((candidate.shape[0], reference.shape[1]), np.nan, dtype=float)
    matched = np.full(reference.shape[1], np.nan, dtype=float)
    pairs: list[tuple[int, int, float]] = []
    for reference_index, candidate_index in zip(rows, columns):
        sign = 1.0 if correlation[reference_index, candidate_index] >= 0 else -1.0
        aligned[:, reference_index] = sign * candidate[:, candidate_index]
        matched[reference_index] = abs(correlation[reference_index, candidate_index])
        pairs.append((reference_index, candidate_index, sign))
    return aligned, matched, pairs


def _r_squared(values: np.ndarray, predictor: pd.Series) -> float:
    numeric = predictor
    if not pd.api.types.is_numeric_dtype(numeric):
        design = pd.get_dummies(numeric.astype(str), drop_first=False, dtype=float).to_numpy()
    else:
        design = numeric.to_numpy(dtype=float)[:, None]
    design = np.column_stack([np.ones(len(design)), design])
    fitted = design @ np.linalg.lstsq(design, values, rcond=None)[0]
    total = float(np.square(values - values.mean()).sum())
    return float(1.0 - np.square(values - fitted).sum() / total) if total else 0.0


def _association_table(factors: np.ndarray, metadata: pd.DataFrame) -> pd.DataFrame:
    covariates = (
        "Sample type", "Sex", "Bio group", "Cage", "Date collected", "Tissue mass (mg)"
    )
    rows: list[dict[str, object]] = []
    for factor_number in range(factors.shape[1]):
        for covariate in covariates:
            predictor = metadata[covariate]
            if covariate == "Date collected":
                predictor = pd.to_datetime(predictor).map(pd.Timestamp.toordinal)
            rows.append({
                "Factor": f"Factor{factor_number + 1}",
                "Covariate": covariate,
                "r_squared": _r_squared(factors[:, factor_number], predictor),
            })
    return pd.DataFrame(rows)


def _stable_factor_table(
    runs: list[tuple[np.ndarray, list[np.ndarray], np.ndarray]],
) -> tuple[pd.DataFrame, list[int], list[np.ndarray], list[np.ndarray]]:
    reference = runs[0][0]
    aligned_factors = [reference]
    aligned_weights = [runs[0][1]]
    correlations = [np.ones(reference.shape[1])]
    for factors, weights, _ in runs[1:]:
        aligned, matched, pairs = _match_factor_order(reference, factors)
        aligned_factors.append(aligned)
        reordered_weights = []
        for reference_weights, candidate_weights in zip(aligned_weights[0], weights):
            reordered = np.full(
                (candidate_weights.shape[0], reference.shape[1]),
                np.nan,
                dtype=float,
            )
            for reference_index, candidate_index, sign in pairs:
                if candidate_index < candidate_weights.shape[1]:
                    reordered[:, reference_index] = sign * candidate_weights[:, candidate_index]
            reordered_weights.append(reordered)
        aligned_weights.append(reordered_weights)
        correlations.append(matched)
    correlation_matrix = np.vstack(correlations)
    stable = [
        number for number in range(reference.shape[1])
        if np.isfinite(correlation_matrix[:, number]).sum() >= 8
    ]
    rows = []
    for number in range(reference.shape[1]):
        finite = correlation_matrix[:, number][np.isfinite(correlation_matrix[:, number])]
        rows.append({
            "Factor": f"Factor{number + 1}",
            "n_recovered": len(finite),
            "median_absolute_score_correlation": float(np.median(finite)) if len(finite) else np.nan,
            "stable_8_of_10": number in stable,
        })
    return pd.DataFrame(rows), stable, aligned_factors, aligned_weights


def _factor_outputs(
    blocks: list[pd.DataFrame],
    metadata: pd.DataFrame,
    runs: list[tuple[np.ndarray, list[np.ndarray], np.ndarray]],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    stability, stable, aligned_factors, aligned_weights = _stable_factor_table(runs)
    first_factors, _, first_variance = runs[0]
    score_rows: list[dict[str, object]] = []
    for factor_number in stable:
        for row_number, sample in enumerate(metadata["Sample"]):
            score_rows.append({
                "Sample": sample,
                "Score name": f"Factor{factor_number + 1}",
                "Score": float(first_factors[row_number, factor_number]),
            })
    scores = pd.DataFrame(score_rows)

    variance_rows: list[dict[str, object]] = []
    for view_number, view in enumerate(VIEW_NAMES):
        for factor_number in range(first_variance.shape[1]):
            variance_rows.append({
                "View": view,
                "Factor": f"Factor{factor_number + 1}",
                "variance_explained": float(first_variance[view_number, factor_number]),
                "active_in_view": bool(first_variance[view_number, factor_number] >= 0.02),
                "stable_8_of_10": factor_number in stable,
            })
    variance = pd.DataFrame(variance_rows)

    top_rows: list[dict[str, object]] = []
    for view_number, view in enumerate(VIEW_NAMES):
        for factor_number in stable:
            weights = np.nanmedian(
                np.stack([
                    run_weights[view_number][:, factor_number]
                    if run_weights[view_number].shape[1] > factor_number
                    else np.full(run_weights[view_number].shape[0], np.nan)
                    for run_weights in aligned_weights
                ]),
                axis=0,
            )
            order = np.argsort(np.abs(weights))[::-1][:50]
            for rank, feature_number in enumerate(order, start=1):
                top_rows.append({
                    "View": view,
                    "Factor": f"Factor{factor_number + 1}",
                    "Feature": blocks[view_number].columns[feature_number],
                    "Weight": float(weights[feature_number]),
                    "absolute_weight": float(abs(weights[feature_number])),
                    "rank": rank,
                })
    return scores, variance, pd.DataFrame(top_rows), stability


def _run_shuffled_control(blocks: list[pd.DataFrame], *, n_shuffles: int) -> pd.DataFrame:
    rng = np.random.default_rng(20_261_120)
    rows: list[dict[str, object]] = []
    for shuffle in range(n_shuffles):
        shuffled: list[pd.DataFrame] = []
        for block in blocks:
            order = rng.permutation(len(block))
            shuffled.append(block.iloc[order].reset_index(drop=True).set_axis(block.index, axis=0))
        _, _, variance = _fit_mofa(shuffled, seed=20_261_200 + shuffle)
        active_in_views = (variance >= 0.02).sum(axis=0)
        shared = np.sort(variance.sum(axis=0)[active_in_views > 1])[::-1]
        rows.append({
            "shuffle": shuffle,
            "maximum_shared_variance_explained": float(shared[0]) if len(shared) else 0.0,
            "n_shared_factors": int((active_in_views > 1).sum()),
            "n_factors": variance.shape[1],
        })
    return pd.DataFrame(rows)


def run_mofa(
    project_root: Path,
    *,
    overwrite: bool = False,
    n_shuffles: int = N_SHUFFLES,
    iterations: int = N_ITERATIONS,
    seeds: tuple[int, ...] = SEEDS,
) -> Path:
    """Fit MOFA+ over all 60 samples and write declared diagnostics."""
    input_root = project_root / "results" / "mia_vs_control" / "14_integration" / "prevalence20_noexclusion"
    output_root = input_root / "01_mofa"
    if not overwrite and output_root.exists() and any(path.is_file() for path in output_root.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite MOFA output: {output_root}")
    blocks, metadata = _load_inputs(input_root)
    if len(seeds) < 1:
        raise ValueError("At least one MOFA seed is required.")
    runs = [_fit_mofa(blocks, seed=seed, iterations=iterations) for seed in seeds]
    scores, variance, top_features, stability = _factor_outputs(blocks, metadata, runs)
    output_root.mkdir(parents=True, exist_ok=True)
    scores.to_csv(output_root / "scores.csv", index=False)
    variance.to_csv(output_root / "variance_explained.csv", index=False)
    top_features.to_csv(output_root / "top_features.csv", index=False)
    stability.to_csv(output_root / "factor_stability.csv", index=False)
    associations = _association_table(runs[0][0], metadata)
    associations.to_csv(output_root / "factor_associations.csv", index=False)
    shuffled = _run_shuffled_control(blocks, n_shuffles=n_shuffles)
    shuffled.to_csv(output_root / "negative_control.csv", index=False)
    active_shared = variance.loc[variance["stable_8_of_10"]].groupby("Factor", observed=True)["active_in_view"].sum()
    region_r2 = associations.loc[associations["Covariate"].eq("Sample type")].set_index("Factor")["r_squared"]
    positive_control = {
        "stable_region_factor_found": bool(
            any(
                stability.set_index("Factor").loc[factor, "stable_8_of_10"]
                and region_r2.get(factor, 0.0) >= 0.5
                and active_shared.get(factor, 0) >= 2
                for factor in stability["Factor"]
            )
        ),
        "stable_factor_active_in_two_views": bool((active_shared >= 2).any()),
        "region_positive_control_rule": "stable factor with region R2 >= 0.5 and active in at least two views",
        "note": "Region R2 is reported in factor_associations.csv; this flag only checks stability and view activity.",
    }
    with (output_root / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump({
            "analysis": "MOFA+ unsupervised integration",
            "input_root": str(input_root.relative_to(project_root)),
            "views": list(VIEW_NAMES),
            "n_seeds": len(seeds),
            "seeds": list(seeds),
            "initial_factors": N_FACTORS,
            "training_iterations": iterations,
            "drop_factor_threshold": 0.02,
            "scale_views": True,
            "stable_factor_rule": "recovered in at least 8 of 10 seeds by absolute score-correlation matching",
            "negative_control_shuffles": n_shuffles,
            "positive_control": positive_control,
            "treatment_tests": "written by run_integration_tests.py from standardized scores.csv",
        }, handle, indent=2)
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--shuffles", type=int, default=N_SHUFFLES)
    parser.add_argument("--iterations", type=int, default=N_ITERATIONS)
    parser.add_argument("--n-seeds", type=int, default=len(SEEDS))
    args = parser.parse_args()
    run_mofa(
        args.project_root,
        overwrite=args.overwrite,
        n_shuffles=args.shuffles,
        iterations=args.iterations,
        seeds=SEEDS[:args.n_seeds],
    )
