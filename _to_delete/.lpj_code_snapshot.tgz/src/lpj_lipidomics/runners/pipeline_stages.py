"""Reusable stage functions for sensitivity-analysis pipeline runners."""

from __future__ import annotations

from pathlib import Path
import shutil
import subprocess

import pandas as pd

from ..config import PERMUTATION_RANDOM_SEED
from ..imputation import impute_rf_all, impute_rf_mar_only
from ..multivariate.pca import fit_pca, scree_table
from ..multivariate.plsda import permutation_test_plsda
from ..preprocessing import drop_zero_variance_features, pareto_scale
from ..statistics.variance import permanova_by_region


RF_IMPUTATION_METHODS = {"rf_mar_only", "rf_all"}


def impute_regionwise(
    values: pd.DataFrame,
    censoring: pd.DataFrame,
    metadata: pd.DataFrame,
    method: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Apply the selected RF imputer independently within each brain region."""
    if method not in RF_IMPUTATION_METHODS:
        raise ValueError(f"Unknown RF imputation method: {method}")
    imputer = impute_rf_mar_only if method == "rf_mar_only" else impute_rf_all
    completed = values.copy()
    routes = pd.DataFrame("none", index=values.index, columns=values.columns)
    for _, region_metadata in metadata.groupby("Sample type", sort=False, observed=True):
        samples = region_metadata["Sample"].tolist()
        region_values, region_routes = imputer(
            values.loc[:, samples],
            censoring.loc[:, samples],
        )
        completed.loc[:, samples] = region_values
        routes.loc[:, samples] = region_routes
    return completed, routes


def run_multivariate(
    values: pd.DataFrame,
    metadata: pd.DataFrame,
    output_directory: Path,
    *,
    scaling: str = "standard",
    include_plsda: bool = True,
    pca_figures: bool = False,
) -> None:
    """Write filtered-matrix PERMANOVA and PCA comparability tables."""
    variable = drop_zero_variance_features(values)
    if scaling == "pareto":
        scaled = pareto_scale(variable)
    else:
        scaled = (variable.subtract(variable.mean(axis=1), axis=0)).divide(variable.std(axis=1, ddof=1), axis=0)
    permanova, diagnostics = permanova_by_region(
        scaled,
        metadata,
        n_permutations=999,
        random_state=PERMUTATION_RANDOM_SEED,
    )
    # The region-by-term multiplicity family is still an open methodological
    # decision, so do not present the helper's provisional adjusted column.
    permanova.drop(columns=["p_value_fdr"], errors="ignore").to_csv(
        output_directory / "permanova_by_region.csv", index=False
    )
    pd.DataFrame([{
        "metric": "p_value_fdr",
        "status": "not reported",
        "note": "The PERMANOVA multiplicity family across regions and sequential terms remains unresolved.",
    }]).to_csv(output_directory / "permanova_multiplicity_note.csv", index=False)
    diagnostics.to_csv(output_directory / "permanova_diagnostics.csv", index=False)
    scree_rows: list[pd.DataFrame] = []
    pls_rows: list[dict[str, object]] = []
    for region, region_metadata in metadata.groupby("Sample type", sort=False, observed=True):
        samples = region_metadata["Sample"].tolist()
        complete = scaled.loc[:, samples].dropna(axis=0, how="any")
        if min(complete.shape) < 2:
            continue
        model, _, _ = fit_pca(complete)
        table = scree_table(model)
        table.insert(0, "Region", region)
        scree_rows.append(table)
        if not include_plsda:
            continue
        labels = region_metadata.set_index("Sample").loc[samples, "Bio group"]
        sexes = region_metadata.set_index("Sample").loc[samples, "Sex"]
        permutation, _ = permutation_test_plsda(
            complete,
            labels,
            sexes,
            n_permutations=999,
            random_state=PERMUTATION_RANDOM_SEED,
        )
        pls_rows.append({
            "Region": region,
            "n_samples": len(samples),
            "n_features_used": len(complete),
            "feature_panel": "full filtered panel after complete-case requirement",
            **permutation.to_dict(),
            "selection_caveat": "No top-50 selection; complete-case restriction is applied before the descriptive PLS-DA check.",
        })
    if scree_rows:
        pd.concat(scree_rows, ignore_index=True).to_csv(output_directory / "pca_scree_by_region.csv", index=False)
    if include_plsda:
        pd.DataFrame(pls_rows).to_csv(output_directory / "plsda_permutation_diagnostics.csv", index=False)
    if pca_figures:
        from .run_metabolomics_pca import _write_scope

        figures = output_directory / "figures" / "pca"
        figures.mkdir(parents=True, exist_ok=True)
        for region, region_metadata in metadata.groupby("Sample type", sort=False, observed=True):
            _write_scope(scaled, region_metadata, region.lower(), ("Bio group", "Sex"), figures)
        _write_scope(scaled, metadata, "pooled",
                     ("Sample type", "Bio group", "Sex", "Cage", "Date collected", "Sample number", "Tissue mass (mg)"), figures)


def run_limma(
    project_root: Path,
    input_directory: Path,
    output_directory: Path,
    *,
    scaling: str = "standard",
    fdr_denominator: str = "all_features",
) -> None:
    """Run the parallel limma model on the variant's explicitly written inputs."""
    rscript = shutil.which("Rscript")
    if rscript is None:
        raise RuntimeError("Rscript is required for the planned limma-moderated parallel model.")
    subprocess.run(
        [
            rscript,
            str(project_root / "src" / "differential_moderated.R"),
            str(input_directory / "differential_input_matrix.csv"),
            str(input_directory / "differential_input_metadata.csv"),
            str(output_directory / "differential_effects_limma.csv"),
            fdr_denominator,
            "pareto_scaled_log2" if scaling == "pareto" else "normalized_log2",
        ],
        check=True,
    )
