"""Regenerate outlier diagnostic figures from completed ensemble tables."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from ..io.lipidomics import read_table_after_header
from ..outliers.plots import plot_outlier_diagnostics, sample_label_mapping


def _sample_labels(project_root: Path) -> dict[str, str]:
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet = read_table_after_header(workbook, "Sample Sheet", "Sample ID")
    metadata = sample_sheet.loc[:, ["Sample number", "Bio group", "Sex"]].copy()
    metadata["Sample number"] = pd.to_numeric(metadata["Sample number"], errors="raise").astype(int)
    metadata["Sample"] = metadata["Sample number"].map(lambda number: f"MB2_088-{number:02d}")
    return sample_label_mapping(metadata)


def run_outlier_diagnostic_plots(project_root: Path) -> None:
    """Read completed ensemble outputs and write the diagnostic figure set."""
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc" / "ensemble"
    scores = pd.read_csv(output_dir / "detector_scores_long.csv")
    limits = pd.read_csv(output_dir / "null_limits.csv")
    verdict = pd.read_csv(output_dir / "ensemble_verdict.csv")
    plot_outlier_diagnostics(
        scores,
        limits,
        verdict,
        output_dir / "figures",
        sample_labels=_sample_labels(project_root),
    )


if __name__ == "__main__":
    run_outlier_diagnostic_plots(Path(__file__).resolve().parents[3])
