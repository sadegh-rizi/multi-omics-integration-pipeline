"""Efficient calibrated k-NN-only exploratory outlier sweep."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

from ..outliers.calibration import calibrate_knn_sweep, score_to_percentile
from ..outliers.detectors import distance_contrast, knn_mean_distance
from ..multivariate.pca import fit_pca
from ..plotting import apply_plot_style, save_figure
from .common import metadata_and_values


PCA_COMPONENTS = (3, 5, 10)
N_NULL_REPLICATES = 2_000


def plot_knn_sweep_figures(scores_table: pd.DataFrame, output_dir: Path) -> None:
    """Plot binary k-NN sweep results from an already calibrated long table."""
    apply_plot_style()
    for scope, scope_scores in scores_table.groupby("scope", observed=True):
        heatmap_cases = (
            ("pc3", "knn_isotropic", "PC3, isotropic"),
            ("pc5", "knn_isotropic", "PC5, isotropic"),
            ("pc10", "knn_isotropic", "PC10, isotropic"),
            ("pc10_soft", "knn_soft", "PC10, soft-weighted"),
        )
        for filename, detector, label in heatmap_cases:
            case_scores = scope_scores.loc[
                scope_scores["detector"].eq(detector)
                & scope_scores["representation"].eq("pc10" if filename == "pc10_soft" else filename)
            ]
            heatmap = case_scores.assign(k_numeric=lambda table: table["parameter_value"].astype(int)).pivot(
                index="Sample", columns="k_numeric", values="flag_95"
            ).sort_index(axis=1)
            fig, axis = plt.subplots(figsize=(8, max(4, len(heatmap) * 0.25)))
            axis.imshow(heatmap.to_numpy(dtype=float), aspect="auto", cmap=ListedColormap(["#F2F2F2", "#222222"]), vmin=0, vmax=1)
            axis.set(
                yticks=np.arange(len(heatmap)),
                yticklabels=heatmap.index,
                xticks=np.arange(len(heatmap.columns)),
                xticklabels=[f"k={k}" for k in heatmap.columns],
                xlabel="Neighbour count k",
                ylabel="Sample",
                title=f"k-NN stability sweep: {scope}, {label}",
            )
            axis.tick_params(axis="x", labelrotation=90)
            axis.legend(
                handles=[Patch(facecolor="#222222", label="Flagged at calibrated 95% limit"), Patch(facecolor="#F2F2F2", edgecolor="#888888", label="Not flagged")],
                loc="upper left",
                bbox_to_anchor=(1.01, 1),
                title="Calibrated result",
            )
            save_figure(fig, output_dir / "figures" / f"stability_heatmap_{scope}_{filename}")
            plt.close(fig)
        for detector, detector_scores in scope_scores.groupby("detector", observed=True):
            fig, axis = plt.subplots(figsize=(6, 4))
            for representation, representation_scores in detector_scores.groupby("representation", observed=True):
                flagged = representation_scores.groupby("parameter_value", observed=True)["flag_95"].mean()
                axis.plot(flagged.index.astype(int), flagged.to_numpy(), marker="o", label=representation)
            axis.set(title=f"k-NN flagged proportion: {scope}", xlabel="Neighbour count k", ylabel="Samples flagged at 95%", ylim=(0, 1))
            axis.legend(title="Representation")
            save_figure(fig, output_dir / "figures" / f"sweep_curves_{detector}_{scope}")
            plt.close(fig)


def run_knn_outlier_sweep(project_root: Path) -> list[Path]:
    """Write calibrated k-NN evidence without a multi-method verdict."""
    metadata, all_values = metadata_and_values(project_root)
    output_dir = project_root / "results" / "mia_vs_control" / "02_qc" / "ensemble" / "detector_sweeps" / "knn"
    records: list[pd.DataFrame] = []
    limit_rows: list[pd.DataFrame] = []
    diagnostics: list[dict[str, object]] = []
    scopes = {"pooled": metadata["Sample"].tolist()}
    scopes.update({str(region).lower(): group["Sample"].tolist() for region, group in metadata.groupby("Sample type", observed=True, sort=False)})

    for scope, samples in scopes.items():
        complete = all_values.loc[:, samples].dropna(axis=0, how="any")
        raw = complete.T
        k_values = list(range(3, 13 if scope == "pooled" else 9))
        diagnostics.append({"scope": scope, "representation": "raw", "k": 2, "relative_contrast": distance_contrast(raw, k=2), "calibrated": False})
        model, scores, _ = fit_pca(complete, n_components=max(PCA_COMPONENTS))
        for q in PCA_COMPONENTS:
            pc_scores = scores.iloc[:, :q]
            eigenvalues = model.explained_variance_[:q]
            for weighting in ("isotropic", "soft"):
                if weighting == "soft" and eigenvalues.min() < 0.01 * eigenvalues.max():
                    diagnostics.append({"scope": scope, "representation": f"pc{q}_{weighting}", "k": 2, "relative_contrast": np.nan, "calibrated": False, "status": "skipped_eigenvalue_floor"})
                    continue
                values = pc_scores if weighting == "isotropic" else pc_scores.divide(np.sqrt(eigenvalues), axis=1)
                diagnostics.append({"scope": scope, "representation": f"pc{q}_{weighting}", "k": 2, "relative_contrast": distance_contrast(values, k=2), "calibrated": True})
                limits, null_scores = calibrate_knn_sweep(values, k_values=k_values, n_replicates=N_NULL_REPLICATES)
                for k in k_values:
                    observed = knn_mean_distance(values, parameter=k)
                    percentile = score_to_percentile(observed, null_scores[k])
                    records.append(pd.DataFrame({
                        "Sample": observed.index,
                        "score": observed.to_numpy(),
                        "null_percentile": percentile.to_numpy(),
                        "flag_95": observed.gt(limits.loc[k, "limit_95"]).to_numpy(),
                        "flag_99": observed.gt(limits.loc[k, "limit_99"]).to_numpy(),
                        "detector": f"knn_{weighting}",
                        "parameter_name": "k",
                        "parameter_value": str(k),
                        "representation": f"pc{q}",
                        "scope": scope,
                        "analysis_complete": False,
                    }))
                summary = limits.reset_index()
                summary["scope"] = scope
                summary["detector"] = f"knn_{weighting}"
                summary["representation"] = f"pc{q}"
                limit_rows.append(summary.rename(columns={"k": "parameter_value"}))

    scores_table = pd.concat(records, ignore_index=True)
    stability = scores_table.groupby(["Sample", "scope", "detector"], observed=True)["flag_95"].mean().rename("stability_fraction").reset_index()
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "scores": output_dir / "detector_scores_long.csv",
        "limits": output_dir / "null_limits.csv",
        "stability": output_dir / "stability_fractions.csv",
        "diagnostics": output_dir / "distance_concentration_diagnostic.csv",
        "metadata": output_dir / "run_metadata.csv",
    }
    scores_table.to_csv(paths["scores"], index=False)
    pd.concat(limit_rows, ignore_index=True).to_csv(paths["limits"], index=False)
    stability.to_csv(paths["stability"], index=False)
    pd.DataFrame(diagnostics).to_csv(paths["diagnostics"], index=False)
    pd.DataFrame({"detectors": ["k-NN isotropic and soft-weighted only"], "ensemble_complete": [False], "candidate_verdict_available": [False]}).to_csv(paths["metadata"], index=False)

    plot_knn_sweep_figures(scores_table, output_dir)
    return list(paths.values())


if __name__ == "__main__":
    run_knn_outlier_sweep(Path(__file__).resolve().parents[3])
