"""Generate the all-metabolite, all-sample metabolomics missingness heatmap."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, to_rgba
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd

from ..io.metabolomics import metabolomics_measurement_columns, read_metabolomics_tables
from ..io.study_design import metabolomics_metadata
from ..plotting import BIO_GROUP_COLORS, BRAIN_REGION_COLORS, COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import exclude_nonpositive


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_metabolomics_missingness(project_root: Path) -> Path:
    """Write raw metabolomics missingness tables and the annotated heatmap."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, report = read_metabolomics_tables(workbook)
    samples, _, _ = metabolomics_measurement_columns(report)

    metabolites = report["Metabolite"].astype(str)
    if metabolites.duplicated().any():
        raise ValueError("Metabolomics report contains duplicated metabolite names.")
    intensity = report.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    intensity.index = metabolites
    intensity = exclude_nonpositive(intensity)
    metadata = metabolomics_metadata(sample_sheet, samples, zero_padded=False)
    metadata = metadata.sort_values(["Sample type", "Bio group", "Sample number"])
    intensity = intensity.loc[:, metadata["Sample"]]

    output_directory = project_root / "results" / "metabolomics" / "02_qc" / "missingness"
    output_directory.mkdir(parents=True, exist_ok=True)
    observed = intensity.notna().astype(int)
    missing_by_metabolite = pd.DataFrame({
        "Metabolite": observed.index,
        "n_missing": observed.eq(0).sum(axis=1).to_numpy(),
    })
    missing_by_metabolite["pct_missing"] = missing_by_metabolite["n_missing"] / len(samples) * 100
    missing_by_metabolite.to_csv(output_directory / "missingness_by_metabolite.csv", index=False)

    missing_by_sample = pd.DataFrame({
        "Sample": observed.columns,
        "n_missing": observed.eq(0).sum(axis=0).to_numpy(),
    })
    missing_by_sample["pct_missing"] = missing_by_sample["n_missing"] / len(observed) * 100
    missing_by_sample.to_csv(output_directory / "missingness_by_sample.csv", index=False)
    observed.to_csv(output_directory / "missingness_matrix.csv", index_label="Metabolite")
    pd.DataFrame([{
        "n_metabolites": len(observed),
        "n_samples": len(observed.columns),
        "n_missing_cells": int(observed.eq(0).sum().sum()),
        "pct_cells_missing": float(observed.eq(0).mean().mean() * 100),
        "missing_encoding": "NaN and non-positive biological values",
    }]).to_csv(output_directory / "missingness_summary.csv", index=False)
    metadata.to_csv(output_directory / "sample_order.csv", index=False)

    from matplotlib.gridspec import GridSpec

    region_colors = np.array([to_rgba(BRAIN_REGION_COLORS[value]) for value in metadata["Sample type"]])[np.newaxis, ...]
    condition_colors = np.array([to_rgba(BIO_GROUP_COLORS[value]) for value in metadata["Bio group"]])[np.newaxis, ...]
    figure = plt.figure(figsize=(12, 8))
    grid = GridSpec(3, 1, height_ratios=[0.02, 0.02, 1], hspace=0.05)
    region_axis = figure.add_subplot(grid[0])
    condition_axis = figure.add_subplot(grid[1])
    heatmap_axis = figure.add_subplot(grid[2])
    region_axis.imshow(region_colors, aspect="auto")
    condition_axis.imshow(condition_colors, aspect="auto")
    for axis in (region_axis, condition_axis):
        axis.set_xticks([])
        axis.set_yticks([])
        for spine in axis.spines.values():
            spine.set_visible(False)
    region_axis.set_ylabel("Region", rotation=0, ha="right", va="center", fontsize=9)
    condition_axis.set_ylabel("Condition", rotation=0, ha="right", va="center", fontsize=9)

    cmap = ListedColormap(["#f0f0f0", COLORBLIND_COLORS[0]])
    heatmap_axis.imshow(observed.to_numpy(), cmap=cmap, aspect="auto", interpolation="none")
    heatmap_axis.set(
        ylabel=f"All metabolites (n={len(observed)})",
        xlabel=f"Samples (n={len(observed.columns)})",
    )
    heatmap_axis.set_xticks([])
    heatmap_axis.set_yticks([])
    handles = [
        mpatches.Patch(color=color, label=label)
        for label, color in BRAIN_REGION_COLORS.items()
    ]
    handles += [
        mpatches.Patch(color=color, label=label)
        for label, color in BIO_GROUP_COLORS.items()
    ]
    handles += [
        mpatches.Patch(color="#f0f0f0", label="Missing"),
        mpatches.Patch(color=COLORBLIND_COLORS[0], label="Observed"),
    ]
    heatmap_axis.legend(handles=handles, bbox_to_anchor=(1.02, 1.05), loc="upper left", borderaxespad=0.0, frameon=False)
    save_figure(figure, output_directory / "missingness_heatmap")
    plt.close(figure)

    manifest = {
        "analysis": "raw metabolomics missingness across all metabolites and biological samples",
        "input_workbook": str(workbook.relative_to(project_root)),
        "input_sheet": "Metabolomics",
        "n_metabolites": len(observed),
        "n_samples": len(observed.columns),
        "sample_annotations": ["Region", "Condition"],
        "missing_encoding": "NaN and non-positive biological values",
        "code_sha256": _sha256(project_root / "src" / "lpj_lipidomics" / "runners" / "run_metabolomics_missingness.py"),
    }
    (output_directory / "missingness_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return output_directory


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    return parser.parse_args()


if __name__ == "__main__":
    arguments = _parse_args()
    run_metabolomics_missingness(arguments.project_root)
