"""Generate descriptive regional and pooled metabolomics PCA figures."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..io.lipidomics import read_lipidomics_tables
from ..io.metabolomics import metabolomics_measurement_columns, read_metabolomics_tables
from ..io.study_design import REGIONS, metabolomics_metadata
from ..metabolomics_preprocessing import preprocess_metabolomics
from ..multivariate.pca import confidence_ellipse, fit_pca, scree_table
from ..plotting import BIO_GROUP_COLORS, BRAIN_REGION_COLORS, SEX_COLORS, COLORBLIND_COLORS, MARKER_CYCLE, apply_plot_style, save_figure, validate_categories
from ..preprocessing import autoscale
from .run_mia_vs_control import _write_score_attribution


def _write_scope(values: pd.DataFrame, metadata: pd.DataFrame, scope: str, variables: tuple[str, ...], output_dir: Path) -> None:
    complete = values.loc[:, metadata["Sample"]].dropna(axis=0, how="any")
    model, scores, _ = fit_pca(complete)
    scree = scree_table(model)
    scree.to_csv(output_dir.parent.parent / f"pca_scree_{scope}.csv", index=False)
    _write_score_attribution(scores, model.explained_variance_ratio_, metadata, scope, output_dir)
    figure, axis = plt.subplots(figsize=(7, 4.8))
    positions = np.arange(1, len(scree) + 1)
    axis.bar(positions, scree["variance_explained"] * 100, color="#0072B2", label="Per component")
    axis.plot(positions, scree["cumulative_variance_explained"] * 100, "o-", color="#D55E00", label="Cumulative")
    axis.set(xlabel="Principal component", ylabel="Variance explained (%)", title=f"PCA scree: {scope}")
    axis.legend(frameon=False)
    figure.tight_layout()
    save_figure(figure, output_dir / f"scree_{scope}")
    plt.close(figure)

    joined = metadata.set_index("Sample").loc[scores.index]
    palettes = {"Sample type": BRAIN_REGION_COLORS, "Bio group": BIO_GROUP_COLORS, "Sex": SEX_COLORS}
    for variable in ("Cage", "Date collected"):
        if variable in variables:
            if variable == "Date collected":
                joined[variable] = pd.to_datetime(joined[variable]).dt.strftime("%Y-%m-%d")
            palettes[variable] = dict(zip(sorted(joined[variable].unique()), (*COLORBLIND_COLORS, "#000000")))
    for variable in variables:
        figure, axis = plt.subplots(figsize=(7, 5.8))
        values_to_plot = joined[variable]
        note = "Dashed lines are 95% normal-theory data ellipses, not confidence intervals for group means."
        if variable in palettes:
            categories = values_to_plot.drop_duplicates().tolist()
            validate_categories(categories, palettes[variable], variable)
            for category in categories:
                subset = scores.loc[values_to_plot.eq(category)]
                marker = MARKER_CYCLE[categories.index(category)] if variable in {"Cage", "Date collected"} else "o"
                axis.scatter(subset["PC 1"], subset["PC 2"], color=palettes[variable][category], marker=marker, edgecolor="black", linewidth=0.35, label=str(category))
                if len(subset) >= 3 and variable not in {"Cage", "Date collected"}:
                    ellipse = confidence_ellipse(subset["PC 1"], subset["PC 2"])
                    axis.plot(ellipse[:, 0], ellipse[:, 1], color="#444444", linewidth=0.8, linestyle="--")
            axis.legend(title=variable, frameon=True, loc="best")
        elif variable == "Tissue mass (mg)":
            mass = pd.to_numeric(values_to_plot, errors="raise")
            bins = pd.qcut(mass, 3)
            for category, color in zip(bins.cat.categories, ("#DDEAF2", "#6FA8C9", "#1F5A89")):
                subset = scores.loc[bins.eq(category)]
                axis.scatter(subset["PC 1"], subset["PC 2"], color=color, edgecolor="black", linewidth=0.35, label=f"{category.left:.0f}-{category.right:.0f} mg")
            axis.legend(title="Tissue mass", frameon=True, loc="best")
            note = f"Pooled tertiles; Pearson r: PC1 = {scores['PC 1'].corr(mass):.2f}, PC2 = {scores['PC 2'].corr(mass):.2f}."
        else:
            points = axis.scatter(scores["PC 1"], scores["PC 2"], c=values_to_plot, cmap="viridis", edgecolor="black", linewidth=0.35)
            figure.colorbar(points, ax=axis, label=variable)
            note += " Sample number is a proxy for acquisition order, not confirmed order."
        ellipse = confidence_ellipse(scores["PC 1"], scores["PC 2"])
        axis.plot(ellipse[:, 0], ellipse[:, 1], color="#444444", linewidth=0.8, linestyle="--")
        axis.axhline(0, color="#BBBBBB", linewidth=0.8)
        axis.axvline(0, color="#BBBBBB", linewidth=0.8)
        axis.set(xlabel=f"PC 1 ({model.explained_variance_ratio_[0] * 100:.1f}%)", ylabel=f"PC 2 ({model.explained_variance_ratio_[1] * 100:.1f}%)", title=f"PCA scores: {scope}, coloured by {variable}")
        figure.text(0.5, 0.01, note, ha="center", fontsize=8)
        figure.tight_layout(rect=(0, 0.04, 1, 1))
        name = "tissue_mass_binned" if variable == "Tissue mass (mg)" else variable.lower().replace(" ", "_")
        save_figure(figure, output_dir / f"scores_{scope}_{name}")
        plt.close(figure)


def run_metabolomics_pca(project_root: Path) -> None:
    """Write full-sample descriptive PCA plots for the metabolomics panel."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, table = read_metabolomics_tables(workbook)
    samples, blanks, _ = metabolomics_measurement_columns(table)
    normalized, _, _, _ = preprocess_metabolomics(table.loc[:, samples], table.loc[:, blanks], table["Method"])
    values = autoscale(normalized)
    metadata = metabolomics_metadata(sample_sheet, samples, zero_padded=False,
                                    cage_workbook=project_root / "data" / "Samples for metabolomics.xlsx")
    output_dir = project_root / "results" / "metabolomics" / "04_multivariate" / "figures" / "pca"
    output_dir.mkdir(parents=True, exist_ok=True)
    for region in REGIONS:
        _write_scope(values, metadata.loc[metadata["Sample type"].eq(region)], region.lower(), ("Bio group", "Sex"), output_dir)
    _write_scope(values, metadata, "pooled", ("Sample type", "Bio group", "Sex", "Cage", "Date collected", "Sample number", "Tissue mass (mg)"), output_dir)


if __name__ == "__main__":
    run_metabolomics_pca(Path(__file__).resolve().parents[3])
