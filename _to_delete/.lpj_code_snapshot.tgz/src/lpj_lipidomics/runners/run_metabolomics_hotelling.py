"""Generate metabolomics PCA Hotelling ellipses and 3-PC T2 range plots."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from ..io.metabolomics import metabolomics_measurement_columns, read_metabolomics_tables
from ..io.study_design import REGIONS, metabolomics_metadata
from ..metabolomics_preprocessing import preprocess_metabolomics
from ..multivariate.pca import fit_pca
from ..outliers.screen import hotelling_t2
from ..plotting import apply_plot_style, save_figure
from ..preprocessing import autoscale
from .run_pca_ellipse import _plot_region


def _range_plot(scores: pd.DataFrame, metadata: pd.DataFrame, scope: str, output_dir: Path) -> None:
    diagnostics = hotelling_t2(scores)
    table = metadata.set_index("Sample").loc[scores.index].join(diagnostics).sort_values("Sample number")
    figure, axis = plt.subplots(figsize=(9, 4.5))
    axis.scatter(table["Sample number"], table["hotelling_t2"], color="#0072B2")
    for _, row in table.iterrows():
        axis.annotate(str(int(row["Sample number"])), (row["Sample number"], row["hotelling_t2"]), fontsize=7)
    axis.axhline(table["hotelling_t2_95_limit"].iat[0], color="#D55E00", linestyle="--", label="95% Beta limit")
    axis.axhline(table["hotelling_t2_99_limit"].iat[0], color="#D55E00", linestyle=":", label="99% Beta limit")
    axis.set(xlabel="Sample number", ylabel="Hotelling T2 (3 PCs)", title=f"Metabolomics {scope}: Hotelling T2 range")
    axis.legend(frameon=False)
    figure.tight_layout()
    save_figure(figure, output_dir / f"t2_range_plot_{scope.lower()}")
    plt.close(figure)


def run_metabolomics_hotelling(project_root: Path) -> None:
    """Write full-sample regional and pooled Hotelling diagnostics."""
    apply_plot_style()
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, table = read_metabolomics_tables(workbook)
    samples, blanks, _ = metabolomics_measurement_columns(table)
    normalized, _, _, _ = preprocess_metabolomics(table.loc[:, samples], table.loc[:, blanks], table["Method"])
    values = autoscale(normalized)
    metadata = metabolomics_metadata(sample_sheet, samples, zero_padded=False)
    multivariate = project_root / "results" / "metabolomics" / "04_multivariate"
    pca_dir = multivariate / "figures" / "pca"
    qc_dir = project_root / "results" / "metabolomics" / "02_qc" / "figures"
    evidence = []
    for region in (*REGIONS, "Pooled"):
        scoped_metadata = metadata if region == "Pooled" else metadata.loc[metadata["Sample type"].eq(region)]
        complete = values.loc[:, scoped_metadata["Sample"]].dropna(axis=0, how="any")
        model_2d, scores_2d, _ = fit_pca(complete, n_components=2)
        figure, table_2d = _plot_region(scores_2d, scoped_metadata, model_2d.explained_variance_ratio_, region=region, population="full_data", n_features=len(complete))
        save_figure(figure, pca_dir / f"hotelling_fulldata_{region.lower()}")
        plt.close(figure)
        evidence.append(table_2d)
        _, scores_3d, _ = fit_pca(complete, n_components=3)
        _range_plot(scores_3d, scoped_metadata, region, qc_dir)
    pd.concat(evidence, ignore_index=True).to_csv(multivariate / "pca_hotelling_t2.csv", index=False)


if __name__ == "__main__":
    run_metabolomics_hotelling(Path(__file__).resolve().parents[3])
