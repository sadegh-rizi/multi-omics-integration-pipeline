"""Generate regional metabolomics feature-space PCA and co-abundance outputs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..config import (
    FEATURE_HEATMAP_MAX_FEATURES,
    FEATURE_MODULE_BOOTSTRAP_COUNT,
    FEATURE_MODULE_DISTANCE_CUT,
    FEATURE_MODULE_MIN_SIZE,
    FEATURE_MODULE_NULL_COUNT,
    FEATURE_MODULE_STABILITY_FLOOR,
    FEATURE_PCA_BOOTSTRAP_COUNT,
    FEATURE_PCA_RANDOM_SEED,
    FEATURE_PCA_SPLIT_HALF_FLOOR,
)
from ..io.metabolomics import metabolomics_measurement_columns, read_metabolomics_tables
from ..io.study_design import REGIONS, metabolomics_metadata
from ..metabolomics_preprocessing import preprocess_metabolomics
from ..multivariate.features import (
    assign_hierarchical_modules,
    bootstrap_feature_loadings,
    bootstrap_module_comembership,
    fit_feature_margin_svd,
    fit_sample_space_loadings,
    loading_annotation_composition,
    loading_stability_summary,
    module_annotation_composition,
    module_stability_summary,
    permuted_null_module_sizes,
    spearman_correlation,
    split_half_loading_stability,
)
from ..plotting import BIO_GROUP_COLORS, COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import exclude_nonpositive


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _write_matrix(table: pd.DataFrame, path: Path) -> None:
    table.to_csv(path, index=False)


def _load_metabolomics(
    project_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, object]]:
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, report = read_metabolomics_tables(workbook)
    samples, blanks, _ = metabolomics_measurement_columns(report)

    metabolite_names = report["Metabolite"].astype(str)
    if metabolite_names.duplicated().any():
        raise ValueError("Metabolomics report contains duplicated metabolite names.")

    raw = report.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    raw.index = metabolite_names
    blank = report.loc[:, blanks].apply(pd.to_numeric, errors="coerce")
    blank.index = metabolite_names
    methods = report["Method"].copy()
    methods.index = metabolite_names

    processed, diagnostics, blank_features, mode_medians = preprocess_metabolomics(raw, blank, methods)
    annotations = report.loc[:, ["Metabolite ID", "Pathway", "Method"]].copy()
    annotations.index = metabolite_names
    annotations.index.name = "Feature"
    metadata = metabolomics_metadata(sample_sheet, samples, zero_padded=False)
    return raw, exclude_nonpositive(raw), processed, annotations, metadata, {
        "diagnostics": diagnostics,
        "blank_features": blank_features,
        "mode_medians": mode_medians,
        "workbook": workbook,
        "n_raw_features": len(raw),
    }


def _plot_feature_view(
    table: pd.DataFrame,
    output: Path,
    *,
    region: str,
    n_samples: int,
) -> None:
    figure, axis = plt.subplots(figsize=(8.5, 6.5))
    axis.scatter(
        table["PC 1"],
        table["PC 2"],
        color=COLORBLIND_COLORS[0],
        edgecolor="black",
        linewidth=0.25,
        s=25,
        alpha=0.8,
    )
    axis.axhline(0, color="#BBBBBB", linewidth=0.7)
    axis.axvline(0, color="#BBBBBB", linewidth=0.7)
    axis.set(
        xlabel="PC 1 feature loading (unitless)",
        ylabel="PC 2 feature loading (unitless)",
        title=f"Feature view of metabolomics PCA loadings: {region}",
    )
    figure.text(
        0.5,
        0.01,
        f"Feature-side view of the sample PCA decomposition; n={n_samples} regional samples; loadings are descriptive, not regulatory evidence.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output)
    plt.close(figure)


def _plot_loading_stability(
    stability: pd.DataFrame,
    output: Path,
    *,
    region: str,
    n_samples: int,
) -> None:
    ordering = (
        stability.groupby("Feature", sort=False)["top_decile_fraction"]
        .max()
        .sort_values(ascending=False, kind="stable")
        .index
    )
    positions = np.arange(len(ordering))
    figure, axis = plt.subplots(figsize=(11, 6.5))
    for number, component in enumerate(stability["Component"].drop_duplicates()):
        rows = stability.loc[stability["Component"].eq(component)].set_index("Feature").loc[ordering]
        axis.vlines(
            positions,
            rows["loading_q025"],
            rows["loading_q975"],
            color=COLORBLIND_COLORS[number],
            linewidth=0.45,
            alpha=0.45,
        )
        axis.scatter(positions, rows["loading_median"], color=COLORBLIND_COLORS[number], s=5, label=component)
    axis.set(
        xlabel="Metabolites ordered by maximum bootstrap top-decile frequency",
        ylabel="Sign-aligned feature loading (unitless)",
        title=f"Metabolomics feature-loading stability: {region}",
    )
    axis.legend(title="Component", frameon=True)
    figure.text(
        0.5,
        0.01,
        f"Points are bootstrap medians; vertical ranges are 95% bootstrap intervals; n={n_samples}. PC interpretation requires split-half loading correlation >= 0.50.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output)
    plt.close(figure)


def _heatmap_features(
    modules: pd.Series,
    module_summary: pd.DataFrame,
    loadings: pd.DataFrame,
    maximum: int,
) -> tuple[pd.Index, str]:
    reportable = set(module_summary.loc[module_summary["reportable"], "module"])
    ordering: list[str] = []
    for module, feature_index in modules.groupby(modules, sort=False).groups.items():
        if module not in reportable:
            continue
        ranked = loadings.loc[feature_index].abs().sum(axis=1).sort_values(ascending=False, kind="stable")
        ordering.extend(ranked.index.tolist())
    if not reportable:
        ordering = loadings.abs().sum(axis=1).sort_values(ascending=False, kind="stable").index.tolist()
        basis = "No module cleared the stability floor; metabolites shown by loading rank"
    else:
        basis = f"Metabolites from {len(reportable)} reportable modules, then loading rank"
    if len(ordering) < maximum:
        remainder = loadings.index.difference(ordering)
        remainder = loadings.loc[remainder].abs().sum(axis=1).sort_values(ascending=False, kind="stable").index
        ordering.extend(remainder.tolist())
    return pd.Index(ordering[:maximum], name="Feature"), basis


def _plot_correlation_heatmap(
    correlation: pd.DataFrame,
    selected: pd.Index,
    output: Path,
    *,
    region: str,
    n_samples: int,
    selection_basis: str,
) -> None:
    selected_correlation = correlation.loc[selected, selected]
    figure, axis = plt.subplots(figsize=(9.0, 8.5))
    image = axis.imshow(
        selected_correlation.to_numpy(),
        cmap="coolwarm",
        vmin=-1,
        vmax=1,
        interpolation="nearest",
        aspect="auto",
    )
    axis.set(
        xlabel="Metabolites ordered by module or loading fallback",
        ylabel="Metabolites ordered by module or loading fallback",
    )
    axis.set_xticks([])
    axis.set_yticks([])
    figure.colorbar(image, ax=axis, label="Signed Spearman correlation", fraction=0.046, pad=0.02)
    figure.suptitle(f"Signed metabolomics co-abundance modules: {region}", y=0.995, fontsize=12, fontweight="bold")
    figure.text(
        0.5,
        0.01,
        f"{selection_basis}; full matrix is persisted. n={n_samples} regional samples. Associations are co-abundance, not regulatory relationships.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output)
    plt.close(figure)


def _plot_module_stability(
    module_summary: pd.DataFrame,
    null_summary: pd.DataFrame,
    output: Path,
    *,
    region: str,
    n_samples: int,
) -> None:
    observed = module_summary.loc[module_summary["n_feature_pairs"].gt(0)].copy()
    observed_global = (
        float(np.average(observed["mean_co_membership"], weights=observed["n_feature_pairs"]))
        if not observed.empty
        else np.nan
    )
    null_values = null_summary["null_pair_same_fraction"]
    figure, axis = plt.subplots(figsize=(8.5, 5.5))
    if not null_values.empty:
        axis.boxplot(
            null_values,
            positions=[0],
            widths=0.35,
            patch_artist=True,
            boxprops={"facecolor": "#D9D9D9"},
            medianprops={"color": "black"},
        )
        axis.scatter(np.zeros(len(null_values)), null_values, color="#777777", s=10, alpha=0.55, label="100 permuted nulls")
    if pd.notna(observed_global):
        axis.scatter([1], [observed_global], color=COLORBLIND_COLORS[0], s=42, label="Observed global rate", zorder=3)
    axis.set(
        xticks=[0, 1],
        xticklabels=["Permuted null\n(global pair rate)", "Observed\n(global bootstrap rate)"],
        ylabel="Pair co-membership fraction",
        ylim=(0, 1),
        title=f"Metabolomics module co-membership stability: {region}",
    )
    axis.legend(frameon=True, fontsize=8)
    figure.text(
        0.5,
        0.01,
        f"Observed rate is pair-weighted across modules from 100 sample bootstraps; nulls independently permute sample order within each metabolite; n={n_samples}.",
        ha="center",
        fontsize=8,
    )
    figure.tight_layout(rect=(0, 0.04, 1, 1))
    save_figure(figure, output)
    plt.close(figure)


def _region_output(
    region: str,
    matrix: pd.DataFrame,
    metadata: pd.DataFrame,
    annotations: pd.DataFrame,
    output_directory: Path,
) -> dict[str, object]:
    samples = metadata.loc[metadata["Sample type"].eq(region), "Sample"].tolist()
    if not samples:
        raise ValueError(f"No samples found for region {region}.")
    complete = matrix.loc[:, samples].dropna(axis=0, how="any")
    if len(complete) < 3:
        raise ValueError(f"Fewer than three complete metabolites found for {region}.")
    aligned_annotations = annotations.loc[complete.index]
    aligned_annotations.index.name = "Feature"

    feature_loadings, sample_vectors, scree = fit_feature_margin_svd(complete)
    feature_table = feature_loadings.rename_axis("Feature").reset_index().merge(
        aligned_annotations.reset_index(), on="Feature", how="left", validate="one_to_one"
    )
    sample_table = sample_vectors.rename_axis("Sample").reset_index()
    sample_table.insert(0, "Region", region)
    _write_matrix(sample_table, output_directory / f"feature_margin_sample_vectors_{region.lower()}.csv")
    scree.insert(0, "Region", region)
    _write_matrix(scree, output_directory / f"feature_margin_scree_{region.lower()}.csv")
    _write_matrix(feature_table, output_directory / f"feature_margin_loadings_{region.lower()}.csv")

    direct_loadings, direct_scree = fit_sample_space_loadings(complete, scale_features=True)
    direct_table = direct_loadings.rename_axis("Feature").reset_index().merge(
        aligned_annotations.reset_index(), on="Feature", how="left", validate="one_to_one"
    )
    direct_scree.insert(0, "Region", region)
    _write_matrix(direct_table, output_directory / f"feature_view_loadings_{region.lower()}.csv")
    _write_matrix(direct_scree, output_directory / f"feature_view_scree_{region.lower()}.csv")
    direct_composition = loading_annotation_composition(
        direct_loadings,
        aligned_annotations["Pathway"],
        annotation_name="Pathway",
    )
    direct_composition.insert(0, "Region", region)
    _write_matrix(direct_composition, output_directory / f"feature_view_pathway_composition_{region.lower()}.csv")

    bootstrap = bootstrap_feature_loadings(
        complete,
        n_bootstraps=FEATURE_PCA_BOOTSTRAP_COUNT,
        random_state=FEATURE_PCA_RANDOM_SEED + REGIONS.index(region),
        n_components=2,
    )
    stability = loading_stability_summary(bootstrap, complete.index)
    stability.insert(0, "Region", region)
    split = split_half_loading_stability(
        complete,
        random_state=FEATURE_PCA_RANDOM_SEED + 100 + REGIONS.index(region),
        n_components=2,
    )
    split.insert(0, "Region", region)
    split["interpretation_allowed"] = split["split_half_loading_correlation"].ge(FEATURE_PCA_SPLIT_HALF_FLOOR)
    _write_matrix(split, output_directory / f"feature_loading_split_half_{region.lower()}.csv")
    allowed = split.set_index("Component")["interpretation_allowed"]
    stability["interpretation_allowed"] = stability["Component"].map(allowed).fillna(False).astype(bool)
    _write_matrix(stability, output_directory / f"feature_loading_stability_{region.lower()}.csv")
    feature_table["PC 1_interpretation_allowed"] = bool(allowed.get("PC 1", False))
    feature_table["PC 2_interpretation_allowed"] = bool(allowed.get("PC 2", False))

    correlation = spearman_correlation(complete)
    modules = assign_hierarchical_modules(
        correlation,
        distance_cut=FEATURE_MODULE_DISTANCE_CUT,
        signed=True,
    )
    co_membership = bootstrap_module_comembership(
        complete,
        n_bootstraps=FEATURE_MODULE_BOOTSTRAP_COUNT,
        random_state=FEATURE_PCA_RANDOM_SEED + 200 + REGIONS.index(region),
        distance_cut=FEATURE_MODULE_DISTANCE_CUT,
        signed=True,
    )
    module_summary = module_stability_summary(
        modules,
        co_membership,
        stability_floor=FEATURE_MODULE_STABILITY_FLOOR,
        minimum_size=FEATURE_MODULE_MIN_SIZE,
    )
    module_summary.insert(0, "Region", region)
    _write_matrix(module_summary, output_directory / f"module_stability_{region.lower()}.csv")
    module_pathways = module_annotation_composition(
        modules,
        aligned_annotations["Pathway"],
        annotation_name="Pathway",
    )
    module_pathways.insert(0, "Region", region)
    _write_matrix(module_pathways, output_directory / f"module_pathway_composition_{region.lower()}.csv")
    assignments = modules.rename_axis("Feature").reset_index().merge(
        aligned_annotations.reset_index(), on="Feature", how="left", validate="one_to_one"
    )
    assignments.insert(0, "Region", region)
    _write_matrix(assignments, output_directory / f"module_assignments_{region.lower()}.csv")
    correlation.to_csv(output_directory / f"feature_correlation_{region.lower()}.csv", index_label="Feature")
    co_membership.to_csv(output_directory / f"module_comembership_{region.lower()}.csv", index_label="Feature")

    null_sizes = permuted_null_module_sizes(
        complete,
        n_permutations=FEATURE_MODULE_NULL_COUNT,
        random_state=FEATURE_PCA_RANDOM_SEED + 300 + REGIONS.index(region),
        distance_cut=FEATURE_MODULE_DISTANCE_CUT,
        signed=True,
        minimum_size=FEATURE_MODULE_MIN_SIZE,
    )
    null_sizes.insert(0, "Region", region)
    _write_matrix(null_sizes, output_directory / f"module_null_sizes_{region.lower()}.csv")
    denominator = len(complete) * (len(complete) - 1)
    null_summary = null_sizes.groupby("null_permutation", as_index=False).agg(
        n_null_modules=("null_module", "size"),
        largest_null_module=("n_features", "max"),
        n_reportable_by_size=("reportable_by_size", "sum"),
        n_features=("n_features", "sum"),
    )
    null_summary["null_pair_same_fraction"] = (
        null_sizes.assign(pair_count=null_sizes["n_features"] * (null_sizes["n_features"] - 1))
        .groupby("null_permutation")["pair_count"]
        .sum()
        / denominator
    ).to_numpy()
    null_summary.insert(0, "Region", region)
    _write_matrix(null_summary, output_directory / f"module_null_summary_{region.lower()}.csv")

    selected, selection_basis = _heatmap_features(
        modules,
        module_summary,
        feature_loadings,
        min(FEATURE_HEATMAP_MAX_FEATURES, len(feature_loadings)),
    )
    selected_table = pd.DataFrame({
        "Feature": selected,
        "heatmap_rank": np.arange(1, len(selected) + 1),
        "selection_basis": selection_basis,
    })
    selected_table.insert(0, "Region", region)
    _write_matrix(selected_table, output_directory / f"heatmap_features_{region.lower()}.csv")

    figure_directory = output_directory / "figures"
    _plot_feature_view(direct_table, figure_directory / f"feature_view_loadings_{region.lower()}", region=region, n_samples=len(samples))
    _plot_loading_stability(stability, figure_directory / f"feature_loading_stability_{region.lower()}", region=region, n_samples=len(samples))
    _plot_correlation_heatmap(correlation, selected, figure_directory / f"feature_correlation_heatmap_{region.lower()}", region=region, n_samples=len(samples), selection_basis=selection_basis)
    _plot_module_stability(module_summary, null_summary, figure_directory / f"module_comembership_stability_{region.lower()}", region=region, n_samples=len(samples))

    return {
        "n_samples": len(samples),
        "n_complete_metabolites": len(complete),
        "n_metabolites_input": len(matrix),
        "n_metabolites_dropped_complete_case": len(matrix) - len(complete),
        "samples": samples,
        "feature_margin_pc1_variance_explained": float(scree.loc[scree["Component"].eq("PC 1"), "variance_explained"].iloc[0]),
        "n_modules": int(modules.nunique()),
        "n_reportable_modules": int(module_summary["reportable"].sum()),
        "split_half": split.loc[:, ["Component", "split_half_loading_correlation", "interpretation_allowed"]].to_dict(orient="records"),
    }


def run_metabolomics_feature_pca(project_root: Path, *, overwrite: bool = False) -> Path:
    """Run regional feature-space PCA and signed co-abundance modules."""
    apply_plot_style()
    feature_root = project_root / "results" / "metabolomics" / "04_multivariate" / "features"
    if feature_root.exists() and any(feature_root.iterdir()):
        if not overwrite:
            raise FileExistsError(f"Refusing to overwrite existing metabolomics feature outputs: {feature_root}")
        shutil.rmtree(feature_root)
    feature_root.mkdir(parents=True, exist_ok=True)

    raw, _, processed, annotations, metadata, details = _load_metabolomics(project_root)
    details["diagnostics"].to_csv(project_root / "results" / "metabolomics" / "01_preprocessing" / "metabolomics_preprocessing_diagnostics.csv", index=False)
    details["blank_features"].to_csv(project_root / "results" / "metabolomics" / "01_preprocessing" / "blank_dominated_features.csv", index=False)
    details["mode_medians"].to_csv(project_root / "results" / "metabolomics" / "01_preprocessing" / "mode_sample_log2_medians.csv")

    regions: dict[str, object] = {}
    for region in REGIONS:
        regions[region] = _region_output(region, processed, metadata, annotations, feature_root)

    manifest = {
        "analysis": "regional metabolomics feature-space PCA and signed co-abundance modules",
        "input_workbook": str(details["workbook"].relative_to(project_root)),
        "input_sheet": "Metabolomics",
        "n_raw_metabolites": len(raw),
        "n_samples": len(metadata),
        "missingness": {
            "matrix": "raw biological metabolomics values with non-positive values treated as missing",
            "n_metabolites": len(raw_observed),
            "n_samples": len(raw_observed.columns),
        },
        "preprocessing": "blank exclusion, below-detection masking, log2 transformation, and median normalization by acquisition mode; no imputation",
        "multivariate_input": "preprocessed metabolites with complete values within each region",
        "regions": regions,
        "feature_margin": "row-centred-only SVD; normalized U feature loadings",
        "clustering": {
            "method": "hierarchical",
            "linkage": "average",
            "distance": "1 - signed Spearman rho",
            "distance_cut": FEATURE_MODULE_DISTANCE_CUT,
            "signed": True,
        },
        "bootstrap_loading_count": FEATURE_PCA_BOOTSTRAP_COUNT,
        "bootstrap_module_count": FEATURE_MODULE_BOOTSTRAP_COUNT,
        "null_permutation_count": FEATURE_MODULE_NULL_COUNT,
        "random_seed": FEATURE_PCA_RANDOM_SEED,
        "split_half_loading_floor": FEATURE_PCA_SPLIT_HALF_FLOOR,
        "module_stability_floor": FEATURE_MODULE_STABILITY_FLOOR,
        "minimum_module_size": FEATURE_MODULE_MIN_SIZE,
        "heatmap_max_features": FEATURE_HEATMAP_MAX_FEATURES,
        "interpretation": "descriptive metabolite co-abundance associations, not regulatory relationships",
        "input_file_sha256": {"workbook": _sha256(details["workbook"])},
        "code_sha256": {
            "features.py": _sha256(project_root / "src" / "lpj_lipidomics" / "multivariate" / "features.py"),
            "run_metabolomics_feature_pca.py": _sha256(project_root / "src" / "lpj_lipidomics" / "runners" / "run_metabolomics_feature_pca.py"),
            "metabolomics_preprocessing.py": _sha256(project_root / "src" / "lpj_lipidomics" / "metabolomics_preprocessing.py"),
        },
    }
    (feature_root / "feature_pca_manifest.json").write_text(json.dumps(manifest, indent=2, default=str) + "\n", encoding="utf-8")
    return feature_root


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--overwrite", action="store_true", help="Replace feature outputs previously generated by this runner.")
    return parser.parse_args()


if __name__ == "__main__":
    arguments = _parse_args()
    run_metabolomics_feature_pca(arguments.project_root, overwrite=arguments.overwrite)
