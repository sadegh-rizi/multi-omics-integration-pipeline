"""Run the paired regional-signature persistence analysis for both modalities."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from ..config import CAGE_ICC_BOOTSTRAPS, CAGE_ICC_RANDOM_SEED, MAX_MISSING_FRACTION
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.metabolomics import metabolomics_measurement_columns, read_metabolomics_tables
from ..io.study_design import full_lipidomics_metadata, metabolomics_metadata
from ..metabolomics_preprocessing import preprocess_metabolomics
from ..preprocessing import (
    below_detection_reasons,
    exclude_below_detection,
    exclude_blank_dominated_features,
    exclude_low_prevalence_features,
    exclude_nonpositive,
    log2_transform,
    median_normalize,
)
from ..statistics.clustered import intraclass_correlation
from ..statistics.region_contrast import (
    REGION_CONTRASTS,
    apply_interaction_fdr,
    build_region_contrasts,
    concordance_summary,
    disattenuated_concordance,
    estimate_split_half_reliability,
    interaction_tests,
    one_sample_region_tests,
)


POPULATIONS = {
    "prevalence20_noexclusion": {
        "hotelling_limit": None,
        "source_variant": "prevalence20_noexclusion",
    },
    "prevalence20_hotelling95": {
        "hotelling_limit": 0.95,
        "source_variant": "prevalence20_t2_95",
    },
    "prevalence20_hotelling99": {
        "hotelling_limit": 0.99,
        "source_variant": "prevalence20_t2_99",
    },
}
MODALITIES = ("lipidomics", "metabolomics")
STAGE_NAMES = ("00_inputs", "01_preprocessing", "02_qc", "03_differential")
SPLIT_HALF_COUNT = 1_000
BOOTSTRAP_COUNT = 1_000
SPLIT_HALF_SEED = 20_260_919
BOOTSTRAP_SEED = 20_260_920


def _feature_table(index: pd.Index, **columns: object) -> pd.DataFrame:
    result = pd.DataFrame({"Feature": index})
    for name, values in columns.items():
        result[name] = values
    return result


def _read_hotelling_evidence(project_root: Path, limit: float) -> tuple[pd.Index, pd.DataFrame]:
    flag_column = f"hotelling_t2_{int(limit * 100)}_flag"
    rows: list[pd.DataFrame] = []
    for region in ("cerebellum", "cortex", "hippocampus"):
        path = project_root / "results" / "mia_vs_control" / "02_qc" / f"outlier_screen_{region}.csv"
        if not path.exists():
            raise FileNotFoundError(f"Required reviewed outlier evidence is missing: {path}")
        table = pd.read_csv(path)
        required = {"Sample number", "Mouse number", "Bio group", flag_column}
        missing = required.difference(table.columns)
        if missing:
            raise KeyError(f"Outlier evidence is missing columns: {sorted(missing)}")
        flagged = table.loc[
            table[flag_column].astype(str).str.lower().eq("true"),
            ["Sample number", "Mouse number", "Bio group"],
        ].copy()
        flagged.insert(0, "Region", region.title())
        flagged["reason"] = flag_column
        rows.append(flagged)
    evidence = pd.concat(rows, ignore_index=True)
    sample_numbers = pd.Index(pd.to_numeric(evidence["Sample number"], errors="raise").astype(int).unique())
    return sample_numbers, evidence


def _sample_selection(
    metadata: pd.DataFrame,
    population: str,
    excluded_numbers: pd.Index,
) -> pd.DataFrame:
    selected = metadata.copy()
    selected["selected"] = ~selected["Sample number"].isin(excluded_numbers)
    selected["exclusion_reason"] = np.where(
        selected["selected"],
        "",
        f"hotelling_t2_{int(POPULATIONS[population]['hotelling_limit'] * 100)}_flag" if len(excluded_numbers) else "",
    )
    selected["population"] = population
    return selected


def _prepare_lipidomics(project_root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, report = read_lipidomics_tables(workbook)
    samples, blank_columns, _ = lipidomics_measurement_columns(report)
    metadata = full_lipidomics_metadata(
        sample_sheet,
        samples,
        cage_workbook=project_root / "data" / "Samples for metabolomics.xlsx",
    )
    raw = report.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    blanks = report.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    annotations = report.loc[:, ["Lipid Name", "Lipid Class"]].copy()
    positive = exclude_nonpositive(raw)
    prevalence = _feature_table(
        positive.index,
        n_samples_denominator=len(positive.columns),
        n_missing=positive.isna().sum(axis=1).to_numpy(),
        missing_fraction=positive.isna().mean(axis=1).to_numpy(),
        max_missing_fraction=MAX_MISSING_FRACTION,
        excluded=positive.isna().mean(axis=1).gt(MAX_MISSING_FRACTION).to_numpy(),
        filter_basis="exclude_nonpositive(raw), pooled across all 60 biological samples",
    )
    prevalence = prevalence.merge(
        annotations.reset_index(names="Feature"),
        on="Feature",
        how="left",
        validate="one_to_one",
    )
    prevalent = exclude_low_prevalence_features(
        positive,
        max_missing_fraction=MAX_MISSING_FRACTION,
    )
    blank_filtered = exclude_blank_dominated_features(
        prevalent,
        blanks.loc[prevalent.index],
    )
    detection_reasons = below_detection_reasons(
        blank_filtered,
        blanks.loc[blank_filtered.index],
    )
    detectable = exclude_below_detection(
        blank_filtered,
        blanks.loc[blank_filtered.index],
    )
    fully_missing = detectable.index[detectable.isna().all(axis=1)]
    detectable = detectable.drop(index=fully_missing)
    normalized = median_normalize(log2_transform(detectable))
    diagnostics = pd.DataFrame([{
        "n_samples_input": len(samples),
        "n_lipids_input": len(raw),
        "n_lipids_after_prevalence": len(prevalent),
        "n_prevalence_excluded": len(raw) - len(prevalent),
        "n_blank_dominated_removed": len(prevalent) - len(blank_filtered),
        "n_fully_detection_excluded": len(fully_missing),
        "n_lipids_tested_panel": len(normalized),
        "n_below_detection_cells": int(detection_reasons.notna().sum().sum()),
        "missingness_basis": "raw positive-only values before detection masking",
        "imputation": "none",
    }])
    return normalized, metadata, prevalence, diagnostics


def _prepare_metabolomics(project_root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    sample_sheet, report = read_metabolomics_tables(workbook)
    samples, blank_columns, _ = metabolomics_measurement_columns(report)
    metadata = metabolomics_metadata(
        sample_sheet,
        samples,
        zero_padded=False,
        cage_workbook=project_root / "data" / "Samples for metabolomics.xlsx",
    )
    raw = report.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    positive = exclude_nonpositive(raw)
    prevalence = _feature_table(
        positive.index,
        n_samples_denominator=len(positive.columns),
        n_missing=positive.isna().sum(axis=1).to_numpy(),
        missing_fraction=positive.isna().mean(axis=1).to_numpy(),
        max_missing_fraction=MAX_MISSING_FRACTION,
        excluded=positive.isna().mean(axis=1).gt(MAX_MISSING_FRACTION).to_numpy(),
        filter_basis="exclude_nonpositive(raw), pooled across all 60 biological samples",
    )
    normalized, diagnostics, _, _ = preprocess_metabolomics(
        raw,
        report.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce"),
        report["Method"],
        max_missing_fraction=MAX_MISSING_FRACTION,
    )
    diagnostics = diagnostics.copy()
    diagnostics["n_samples_input"] = len(samples)
    diagnostics["imputation"] = "none"
    annotations = report.loc[:, ["Metabolite", "Method"]].copy()
    prevalence = prevalence.merge(
        annotations.reset_index(names="Feature"),
        on="Feature",
        how="left",
        validate="one_to_one",
    )
    return normalized, metadata, prevalence, diagnostics


def _relative_path(path: Path, project_root: Path) -> str:
    return str(path.relative_to(project_root))


def _contrast_slug(name: str) -> str:
    return name.lower().replace(" - ", "_minus_").replace(" ", "_")


def _write_modality_run(
    project_root: Path,
    output: Path,
    population: str,
    modality: str,
    excluded_numbers: pd.Index,
    evidence: pd.DataFrame,
    *,
    overwrite: bool = False,
) -> dict[str, object]:
    if not overwrite and output.exists() and any(path.is_file() for path in output.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite existing region-persistence output: {output}")
    stages = {name: output / name for name in STAGE_NAMES}
    for directory in stages.values():
        directory.mkdir(parents=True, exist_ok=True)

    if modality == "lipidomics":
        values, metadata, prevalence, diagnostics = _prepare_lipidomics(project_root)
    else:
        values, metadata, prevalence, diagnostics = _prepare_metabolomics(project_root)
    selection = _sample_selection(metadata, population, excluded_numbers)
    selected_samples = selection.loc[selection["selected"], "Sample"].tolist()
    selected_metadata = selection.loc[selection["selected"]].copy()
    selected_values = values.loc[:, selected_samples]
    if selected_values.shape[1] != (60 - len(excluded_numbers)):
        raise AssertionError("Population sample selection does not match the 60-sample source panel.")

    prevalence.to_csv(stages["01_preprocessing"] / "prevalence_filter_features.csv", index=False)
    diagnostics = diagnostics.copy()
    diagnostics["population"] = population
    diagnostics["modality"] = modality
    diagnostics["n_samples_after_population_selection"] = len(selected_samples)
    diagnostics["n_sample_exclusions"] = len(excluded_numbers)
    diagnostics.to_csv(stages["01_preprocessing"] / "preprocessing_diagnostics.csv", index=False)
    selection.to_csv(stages["02_qc"] / "sample_selection.csv", index=False)
    evidence.to_csv(stages["02_qc"] / "hotelling_evidence.csv", index=False)
    # Superseded name was specific to 95%, even in the no-exclusion arm.
    (stages["02_qc"] / "hotelling95_evidence.csv").unlink(missing_ok=True)
    selected_metadata.to_csv(stages["00_inputs"] / "region_input_metadata.csv", index=False)
    selected_values.to_csv(stages["00_inputs"] / "region_input_matrix.csv", index_label="Feature")

    contrasts = build_region_contrasts(selected_values, selected_metadata)
    pairing_rows = []
    for contrast in contrasts.values():
        for group, group_metadata in metadata.groupby("Bio group", sort=False):
            n_mice = int(contrast.metadata["Bio group"].eq(group).sum())
            dropped = group_metadata.loc[
                group_metadata["Mouse number"].isin(contrast.dropped_mice)
                & group_metadata["Sample type"].isin([contrast.region_a, contrast.region_b])
                & ~group_metadata["Sample"].isin(selected_samples)
            ]
            base = {"Contrast": contrast.name, "Group": group, "n_mice": n_mice}
            if dropped.empty:
                pairing_rows.append({**base, "dropped_mouse": "", "dropped_sample": "", "reason": ""})
            else:
                for _, row in dropped.iterrows():
                    pairing_rows.append({**base, "dropped_mouse": row["Mouse number"],
                                         "dropped_sample": row["Sample"],
                                         "reason": selection.set_index("Sample").loc[row["Sample"], "exclusion_reason"]})
    pd.DataFrame(pairing_rows).to_csv(stages["02_qc"] / "contrast_pairing.csv", index=False)
    within_group_tables: list[pd.DataFrame] = []
    interaction_tables: list[pd.DataFrame] = []
    icc_tables: list[pd.DataFrame] = []
    concordance_tables: list[pd.DataFrame] = []
    reliability_tables: list[pd.DataFrame] = []
    reliability_draw_tables: list[pd.DataFrame] = []
    disattenuation_tables: list[pd.DataFrame] = []
    population_offset = list(POPULATIONS).index(population) * 100

    for contrast_number, (contrast_name, _, _) in enumerate(REGION_CONTRASTS):
        contrast = contrasts[contrast_name]
        slug = _contrast_slug(contrast_name)
        contrast.values.to_csv(
            stages["00_inputs"] / f"difference_matrix_{slug}.csv",
            index_label="Feature",
        )
        contrast.metadata.to_csv(stages["00_inputs"] / f"paired_metadata_{slug}.csv", index=False)
        within_group_tables.append(one_sample_region_tests(contrast))
        icc_metadata = contrast.metadata.loc[:, ["Sample", "Cage", "Bio group"]]
        icc = intraclass_correlation(
            contrast.values,
            icc_metadata,
            n_bootstraps=CAGE_ICC_BOOTSTRAPS,
            random_state=CAGE_ICC_RANDOM_SEED + population_offset + contrast_number,
        )
        icc.insert(0, "Contrast", contrast_name)
        icc_tables.append(icc)
        interaction_tables.append(interaction_tests(contrast, icc))
        concordance_tables.append(concordance_summary(contrast))
        reliability, reliability_draws = estimate_split_half_reliability(
            contrast,
            n_splits=SPLIT_HALF_COUNT,
            random_state=SPLIT_HALF_SEED + population_offset + contrast_number,
        )
        reliability_tables.append(reliability)
        reliability_draw_tables.append(reliability_draws)
        disattenuation_tables.append(
            disattenuated_concordance(
                contrast,
                reliability,
                reliability_draws,
                n_bootstraps=BOOTSTRAP_COUNT,
                random_state=BOOTSTRAP_SEED + population_offset + contrast_number,
            )
        )

    within_group = pd.concat(within_group_tables, ignore_index=True)
    interactions = pd.concat(interaction_tables, ignore_index=True)
    interactions = apply_interaction_fdr(
        interactions,
        n_features=len(selected_values.index),
        n_contrasts=len(REGION_CONTRASTS),
    )
    pd.concat(icc_tables, ignore_index=True).to_csv(stages["02_qc"] / "cage_icc.csv", index=False)
    pd.concat(concordance_tables, ignore_index=True).to_csv(stages["02_qc"] / "concordance.csv", index=False)
    pd.concat(reliability_tables, ignore_index=True).to_csv(stages["02_qc"] / "split_half_reliability.csv", index=False)
    pd.concat(reliability_draw_tables, ignore_index=True).to_csv(stages["02_qc"] / "split_half_reliability_draws.csv", index=False)
    pd.concat(disattenuation_tables, ignore_index=True).to_csv(stages["02_qc"] / "disattenuated_concordance.csv", index=False)
    within_group.to_csv(stages["03_differential"] / "within_group_region_tests.csv", index=False)
    interactions.to_csv(stages["03_differential"] / "region_interactions.csv", index=False)

    paired_mouse_counts = {
        contrast.name: int(len(contrast.metadata)) for contrast in contrasts.values()
    }
    manifest = {
        "analysis": "regional lipid/metabolite signature persistence under MIA",
        "population": population,
        "modality": modality,
        "source_variant": POPULATIONS[population]["source_variant"],
        "source_workbook": _relative_path(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx", project_root),
        "cage_metadata_workbook": _relative_path(project_root / "data" / "Samples for metabolomics.xlsx", project_root),
        "primary_endpoints": ["disattenuated_concordance"],
        "secondary_descriptive_endpoints": ["per_lipid_or_metabolite_interaction"],
        "endpoint_decision": "Both endpoints were requested; the per-feature interaction remains secondary and descriptive.",
        "analysis_population": "prevalence20 pooled filter with population-specific sample selection",
        "n_samples_input": 60,
        "n_samples_after_population_selection": len(selected_samples),
        "n_paired_mice_by_contrast": paired_mouse_counts,
        "unit_of_observation": "mouse-level paired region difference per feature",
        "experimental_unit": "dam/cage; mouse-level bootstrap does not resolve cage dependence",
        "regions": ["Cerebellum", "Cortex", "Hippocampus"],
        "contrasts": [name for name, _, _ in REGION_CONTRASTS],
        "sex_stratified_analysis": "omitted because sex is confounded with cage in the MIA arm",
        "missing_values": "retained as missing; feature-wise complete pairs are used for each test",
        "imputation": "none",
        "normalization": "log2 transform followed by sample-wise median normalization; metabolomics normalization is mode-specific",
        "prevalence_threshold": MAX_MISSING_FRACTION,
        "primary_fdr_family": "all three region contrasts together",
        "primary_fdr_denominator": len(selected_values.index) * len(REGION_CONTRASTS),
        "fdr_method": "Benjamini-Hochberg",
        "exploratory_selection_disclosure": "The 2026-09-19 dry run examined all three contrasts before implementation; Cortex - Hippocampus is not preregistered.",
        "icc_bootstraps": CAGE_ICC_BOOTSTRAPS,
        "icc_random_seed": CAGE_ICC_RANDOM_SEED + population_offset,
        "split_half_splits": SPLIT_HALF_COUNT,
        "split_half_random_seed": SPLIT_HALF_SEED + population_offset,
        "disattenuation_bootstraps": BOOTSTRAP_COUNT,
        "disattenuation_inner_splits": 100,
        "pairing": "contrast-specific; only pairs involving a removed sample are dropped",
        "exclusion_evidence": "reviewed lipidomics per-region screen, mapped by sample number to both modalities",
        "disattenuation_random_seed": BOOTSTRAP_SEED + population_offset,
        "tissue_mass": "carried in paired metadata as region-specific mass and mass difference; not used as an adjusted inferential covariate",
        "cage_permutation": "not run; the exact 28-assignment p-value floor is not confirmatory",
    }
    with (output / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, indent=2, default=str)
    return manifest


def run_region_persistence(project_root: Path, *, overwrite: bool = False) -> Path:
    """Write all-60, T²-95 and T²-99 populations for both modalities."""
    output_root = project_root / "results" / "mia_vs_control" / "09_region_persistence"
    if not overwrite and output_root.exists() and any(path.is_file() for path in output_root.rglob("*")):
        raise FileExistsError(f"Refusing to overwrite existing output tree: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    run_manifests: list[dict[str, object]] = []
    for population, specification in POPULATIONS.items():
        if specification["hotelling_limit"] is None:
            population_exclusions = pd.Index([], dtype=int)
            evidence = pd.DataFrame(columns=["Region", "Sample number", "Mouse number", "Bio group", "reason"])
        else:
            population_exclusions, evidence = _read_hotelling_evidence(project_root, specification["hotelling_limit"])
        for modality in MODALITIES:
            output = output_root / population / modality
            run_manifests.append(
                _write_modality_run(
                    project_root,
                    output,
                    population,
                    modality,
                    population_exclusions,
                    evidence if len(population_exclusions) else pd.DataFrame(columns=evidence.columns),
                    overwrite=overwrite,
                )
            )
    root_manifest = {
        "analysis": "regional signature persistence",
        "output_root": _relative_path(output_root, project_root),
        "populations": list(POPULATIONS),
        "modalities": list(MODALITIES),
        "runs": run_manifests,
    }
    with (output_root / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(root_manifest, handle, indent=2, default=str)
    return output_root


if __name__ == "__main__":
    run_region_persistence(Path(__file__).resolve().parents[3])
