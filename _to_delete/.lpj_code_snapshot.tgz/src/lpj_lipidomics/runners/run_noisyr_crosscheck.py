"""Compare the manual abundance-similarity curve with noisyR's count approach."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..config import (
    NOISYR_MIN_COMPARATORS_PER_REFERENCE,
    NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
    NOISYR_MIN_PAIRWISE_OBSERVATIONS,
    NOISYR_SUSTAINED_WINDOWS,
    NOISYR_WINDOW_FRACTION,
    NOISYR_WINDOW_MIN_FEATURES,
)
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, full_lipidomics_metadata, lipid_feature_rows
from ..noisyr import (
    panel_scaled_window_parameters,
    run_noisyr,
    threshold_difference,
    threshold_median,
)
from ..plotting import COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import (
    exclude_below_detection,
    exclude_nonpositive,
    log2_transform,
)
from ..qc.abundance_similarity import abundance_similarity_curve, candidate_thresholds


def _manual_threshold(curve: pd.DataFrame, rule: str) -> float:
    thresholds = candidate_thresholds(
        curve,
        rules=(rule,),
        sustained_windows=NOISYR_SUSTAINED_WINDOWS,
    )
    return float(thresholds.iloc[0]["threshold_log2_abundance"])


def _curve_spearman(manual: pd.DataFrame, noisyr: pd.DataFrame | None) -> float:
    """Correlate the two curves only over their finite, shared abundance range."""
    if noisyr is None:
        return float("nan")
    manual_finite = manual.dropna(subset=["median_log2_abundance", "median_pearson"])
    noisyr_finite = noisyr.dropna(subset=["median_log2_abundance", "median_pearson"])
    if len(manual_finite) < 2 or len(noisyr_finite) < 2:
        return float("nan")
    noisyr_finite = noisyr_finite.sort_values("median_log2_abundance")
    shared = manual_finite.loc[
        manual_finite["median_log2_abundance"].between(
            noisyr_finite["median_log2_abundance"].min(),
            noisyr_finite["median_log2_abundance"].max(),
            inclusive="both",
        )
    ]
    if len(shared) < 2:
        return float("nan")
    aligned = np.interp(
        shared["median_log2_abundance"],
        noisyr_finite["median_log2_abundance"],
        noisyr_finite["median_pearson"],
    )
    return float(shared["median_pearson"].corr(pd.Series(aligned, index=shared.index), method="spearman"))


def _comparison_row(
    *,
    region: str,
    input_arm: str,
    status: str,
    manual_curve: pd.DataFrame,
    noisyr_curve: pd.DataFrame | None,
    noisyr_thresholds: pd.DataFrame | None,
    n_features_input: int,
    n_samples: int,
    n_missing_input_cells: int,
    window_fraction: float,
    window_floor_features: int,
    window_size: int,
    window_step: int,
) -> dict[str, object]:
    manual_threshold = _manual_threshold(manual_curve, "pearson_gt_0_25")
    sustained_threshold = _manual_threshold(manual_curve, "pearson_sustained_gt_0_25")
    noisyr_threshold = threshold_median(noisyr_thresholds, status)
    if status != "completed" and np.isfinite(noisyr_threshold):
        raise AssertionError("A non-completed noisyR run cannot carry a finite threshold.")
    if noisyr_curve is None:
        n_curve_points = 0
        n_curve_points_below_full_pairwise_set = np.nan
    else:
        n_curve_points = len(noisyr_curve)
        full_pairwise_set = n_samples * (n_samples - 1)
        n_curve_points_below_full_pairwise_set = int(
            noisyr_curve["n_pairwise_correlations"].lt(full_pairwise_set).sum()
        )
    return {
        "region": region,
        "input_arm": input_arm,
        "status": status,
        "manual_threshold_log2_abundance": manual_threshold,
        "manual_sustained_threshold_log2_abundance": sustained_threshold,
        "noisyr_threshold_log2_abundance_median": noisyr_threshold,
        "threshold_difference_log2": threshold_difference(
            noisyr_threshold,
            manual_threshold,
            status=status,
        ),
        "curve_spearman": _curve_spearman(manual_curve, noisyr_curve),
        "n_noisyr_curve_points": n_curve_points,
        "n_noisyr_curve_points_below_full_pairwise_set": n_curve_points_below_full_pairwise_set,
        "n_features_input": n_features_input,
        "n_missing_input_cells": n_missing_input_cells,
        "window_fraction": window_fraction,
        "window_floor_features": window_floor_features,
        "window_size": window_size,
        "window_step": window_step,
        "min_pairwise_observations": NOISYR_MIN_PAIRWISE_OBSERVATIONS,
        "min_comparators_per_reference": NOISYR_MIN_COMPARATORS_PER_REFERENCE,
        "sustained_windows": NOISYR_SUSTAINED_WINDOWS,
        "input_definition": (
            "log2 positive raw peak areas before detection-limit filtering"
            if input_arm == "raw"
            else "log2 positive raw peak areas after empirical per-lipid detection-limit masking"
        ),
    }


def _plot_scope_arms(
    region: str,
    curves: dict[str, tuple[pd.DataFrame, pd.DataFrame | None]],
    output_dir: Path,
) -> None:
    figure, axis = plt.subplots(figsize=(7.5, 5))
    manual_color, noisyr_color = COLORBLIND_COLORS[:2]
    styles = {
        "raw": ("-", "--"),
        "detection_masked": ("-.", ":"),
    }
    labels = {
        "raw": "Manual, raw positive",
        "detection_masked": "Manual, detection-masked",
    }
    for arm, (manual, noisyr) in curves.items():
        manual_style, noisyr_style = styles[arm]
        axis.plot(
            manual["median_log2_abundance"],
            manual["median_pearson"],
            color=manual_color,
            linestyle=manual_style,
            label=labels[arm],
        )
        if noisyr is not None:
            axis.plot(
                noisyr["median_log2_abundance"],
                noisyr["median_pearson"],
                color=noisyr_color,
                linestyle=noisyr_style,
                label=f"noisyR, {arm.replace('_', ' ')}",
            )
    axis.axhline(0.25, color="#777777", linestyle="--", linewidth=0.8)
    axis.set(
        xlabel="Log2 positive raw peak area",
        ylabel="Correlation",
        ylim=(-1, 1),
        title=f"noisyR comparison: {region}",
    )
    axis.legend(frameon=True)
    figure.tight_layout()
    save_figure(figure, output_dir / f"noisyr_vs_manual_{region.lower()}")
    plt.close(figure)


def run_noisyr_crosscheck(project_root: Path) -> None:
    """Write raw and detection-masked noisyR/manual comparisons."""
    apply_plot_style()
    results = project_root / "results" / "mia_vs_control" / "02_qc"
    figures = results / "figures"
    work_dir = results / "noisyr_work"
    work_dir.mkdir(parents=True, exist_ok=True)
    sample_sheet, report = read_lipidomics_tables(
        project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    )
    samples, blank_columns, techmix = lipidomics_measurement_columns(report)
    metadata = full_lipidomics_metadata(sample_sheet, samples)
    features = lipid_feature_rows(report)
    raw = features.loc[:, samples].apply(pd.to_numeric, errors="raise")
    raw_blanks = features.loc[:, blank_columns].apply(pd.to_numeric, errors="raise")
    techmix_raw = features.loc[:, techmix].apply(pd.to_numeric, errors="raise")

    positive = exclude_nonpositive(raw)
    positive_techmix = exclude_nonpositive(techmix_raw)
    masked = exclude_below_detection(positive, raw_blanks)
    masked_techmix = exclude_below_detection(positive_techmix, raw_blanks)
    scopes = [
        (
            region.lower(),
            positive.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]],
            masked.loc[:, metadata.loc[metadata["Sample type"].eq(region), "Sample"]],
        )
        for region in REGIONS
    ]
    scopes.append(("techmix", positive_techmix, masked_techmix))

    rows: list[dict[str, object]] = []
    for label, raw_values, masked_values in scopes:
        window_size, window_step = panel_scaled_window_parameters(
            len(raw_values),
            NOISYR_WINDOW_FRACTION,
            minimum_features=NOISYR_WINDOW_MIN_FEATURES,
        )
        arm_curves: dict[str, tuple[pd.DataFrame, pd.DataFrame | None]] = {}
        for input_arm, values in (("raw", raw_values), ("detection_masked", masked_values)):
            log_values = log2_transform(values)
            manual_curve = abundance_similarity_curve(
                log_values,
                window_size=window_size,
                step=window_step,
                min_pairwise_correlations_per_point=NOISYR_MIN_PAIRWISE_CORRELATIONS_PER_POINT,
                min_comparators_per_reference=NOISYR_MIN_COMPARATORS_PER_REFERENCE,
                min_pairwise_observations=NOISYR_MIN_PAIRWISE_OBSERVATIONS,
            )
            noisyr_label = label if input_arm == "raw" else f"detection_masked_{label}"
            noisyr_curve, noisyr_thresholds, status = run_noisyr(
                log_values,
                work_dir,
                noisyr_label,
                project_root,
                window=window_size,
                step=window_step,
            )
            rows.append(
                _comparison_row(
                    region=label,
                    input_arm=input_arm,
                    status=status,
                    manual_curve=manual_curve,
                    noisyr_curve=noisyr_curve,
                    noisyr_thresholds=noisyr_thresholds,
                    n_features_input=len(values),
                    n_samples=values.shape[1],
                    n_missing_input_cells=int(values.isna().sum().sum()),
                    window_fraction=NOISYR_WINDOW_FRACTION,
                    window_floor_features=NOISYR_WINDOW_MIN_FEATURES,
                    window_size=window_size,
                    window_step=window_step,
                )
            )
            arm_curves[input_arm] = (manual_curve, noisyr_curve)
        _plot_scope_arms(label, arm_curves, figures)
    pd.DataFrame(rows).to_csv(results / "noisyr_comparison.csv", index=False)


if __name__ == "__main__":
    run_noisyr_crosscheck(Path(__file__).resolve().parents[3])
