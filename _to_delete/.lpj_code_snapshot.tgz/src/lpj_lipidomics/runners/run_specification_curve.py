"""Run the pre-specified QC-CV by imputation multiverse analysis."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..config import MAX_MISSING_FRACTION, QC_CV_MIN_INJECTIONS, QC_CV_THRESHOLD
from ..imputation import censoring_mask, impute_mnar_halfmin, impute_none, impute_rf_all, impute_rf_mar_only
from ..io.lipidomics import lipidomics_measurement_columns, read_lipidomics_tables
from ..io.study_design import REGIONS, analysis_metadata
from ..multivariate.plsda import fit_plsda, permutation_test_plsda
from ..plotting import COLORBLIND_COLORS, apply_plot_style, save_figure
from ..preprocessing import below_detection_reasons, exclude_blank_dominated_features, exclude_low_prevalence_features, exclude_nonpositive, log2_transform, median_normalize
from ..qc.variance import qc_injection_cv
from ..statistics.differential import fit_regionwise_differential


IMPUTERS = {"none": impute_none, "mnar_halfmin": impute_mnar_halfmin, "rf_mar_only": impute_rf_mar_only, "rf_all": impute_rf_all}
RANDOM_SEED = 20_260_807


def _base_values(
    raw: pd.DataFrame,
    blanks: pd.DataFrame,
    *,
    use_prevalence_filter: bool,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    filtered = exclude_blank_dominated_features(raw, blanks)
    positive = exclude_nonpositive(filtered)
    reasons = below_detection_reasons(positive, blanks.loc[filtered.index])
    detectable = positive.mask(reasons.notna())
    # The vendor table contains three blank rows and a repeated header row.
    # Remove these non-features before prevalence is counted on the lipid panel.
    detectable = detectable.dropna(axis=0, how="all")
    reasons = reasons.loc[detectable.index]
    filtered = filtered.loc[detectable.index]
    if use_prevalence_filter:
        detectable = exclude_low_prevalence_features(
            detectable,
            max_missing_fraction=MAX_MISSING_FRACTION,
        )
        reasons = reasons.loc[detectable.index]
        filtered = filtered.loc[detectable.index]
    return median_normalize(log2_transform(detectable)), censoring_mask(filtered, reasons)


def _imputed_by_region(values: pd.DataFrame, mask: pd.DataFrame, metadata: pd.DataFrame, method: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    completed = values.copy()
    routes = pd.DataFrame("none", index=values.index, columns=values.columns)
    for region, region_metadata in metadata.groupby("Sample type", sort=False, observed=True):
        samples = region_metadata["Sample"]
        result, result_routes = IMPUTERS[method](values.loc[:, samples], mask.loc[:, samples])
        completed.loc[:, samples] = result
        routes.loc[:, samples] = result_routes
    return completed, routes


def _recovery_rmse(values: pd.DataFrame, mask: pd.DataFrame, metadata: pd.DataFrame, method: str) -> float:
    observed = values.stack().sample(frac=0.01, random_state=RANDOM_SEED)
    masked = values.copy()
    for feature, sample in observed.index:
        masked.loc[feature, sample] = np.nan
        mask.loc[feature, sample] = "mar"
    completed, _ = _imputed_by_region(masked, mask, metadata, method)
    return float(np.sqrt(np.mean((completed.stack().reindex(observed.index) - observed) ** 2)))


def run_specification_curve(project_root: Path) -> None:
    """Report every pre-specified QC-CV/imputation combination together."""
    apply_plot_style()
    sample_sheet, lipidomics = read_lipidomics_tables(project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx")
    samples, blank_columns, techmix_columns = lipidomics_measurement_columns(lipidomics)
    metadata = analysis_metadata(sample_sheet, samples)
    raw = lipidomics.loc[:, samples].apply(pd.to_numeric, errors="coerce")
    blanks = lipidomics.loc[:, blank_columns].apply(pd.to_numeric, errors="coerce")
    annotations = lipidomics.loc[:, ["Lipid Name", "Lipid Class"]].copy(); annotations.index = lipidomics.index
    unfiltered_values, _ = _base_values(raw, blanks, use_prevalence_filter=False)
    filtered_values, _ = _base_values(raw, blanks, use_prevalence_filter=True)
    output = project_root / "results" / "mia_vs_control"
    preprocessing_dir = output / "01_preprocessing"
    preprocessing_dir.mkdir(parents=True, exist_ok=True)
    annotations.loc[unfiltered_values.index.difference(filtered_values.index)].to_csv(
        preprocessing_dir / "prevalence_filter_features.csv",
        index_label="Feature",
    )
    cv = qc_injection_cv(lipidomics.loc[:, techmix_columns], min_injections=QC_CV_MIN_INJECTIONS)
    keep_cv = cv.index[cv["normalized_cv_percent"].le(QC_CV_THRESHOLD)]
    rows: list[dict[str, object]] = []
    summaries: list[dict[str, object]] = []
    recovery: list[dict[str, object]] = []
    for use_prevalence_filter in (False, True):
        values, mask = _base_values(raw, blanks, use_prevalence_filter=use_prevalence_filter)
        values = values.loc[:, metadata["Sample"]]
        mask = mask.loc[:, metadata["Sample"]]
        for use_cv in (False, True):
            features = values.index.intersection(keep_cv) if use_cv else values.index
            for method in IMPUTERS:
                specification = f"prevalence_{'on' if use_prevalence_filter else 'off'}__qc_cv_{'on' if use_cv else 'off'}__{method}"
                completed, routes = _imputed_by_region(values.loc[features], mask.loc[features], metadata, method)
                fitted = fit_regionwise_differential(completed, metadata, annotations=annotations.loc[features])
                n_imputed = int(routes.ne("none").sum().sum())
                summaries.append({"specification": specification, "prevalence_filter": use_prevalence_filter, "qc_cv_filter": use_cv, "imputation": method, "n_features": len(features), "n_cells_imputed": n_imputed})
                recovery.append({"specification": specification, "prevalence_filter": use_prevalence_filter, "imputation": method, "rmse": _recovery_rmse(values.loc[features], mask.loc[features].copy(), metadata, method) if method != "none" else np.nan})
                for region in REGIONS:
                    regional = metadata.loc[metadata["Sample type"].eq(region)]
                    matrix = completed.loc[:, regional["Sample"]]
                    complete = matrix.dropna(axis=0, how="any")
                    if len(complete) >= 2:
                        labels = regional.set_index("Sample")["Bio group"]; sexes = regional.set_index("Sample")["Sex"]
                        _, permutation = fit_plsda(complete, labels), None
                        permutation, _ = permutation_test_plsda(complete, labels, sexes, n_permutations=1_000, random_state=RANDOM_SEED)
                        pls_p = float(permutation["permutation_p_value"])
                    else:
                        pls_p = np.nan
                    for effect, effect_rows in fitted.effects.loc[fitted.effects["Region"].eq(region)].groupby("Effect", observed=True):
                        hits = effect_rows.loc[effect_rows["p_value_fdr"].le(0.05), "Feature"]
                        hit_routes = routes.loc[routes.index.intersection(hits)]
                        rows.append({"specification": specification, "prevalence_filter": use_prevalence_filter, "qc_cv_filter": use_cv, "imputation": method, "Region": region, "Effect": effect, "n_features_tested": len(effect_rows), "n_fdr_significant": len(hits), "smallest_q_value": effect_rows["p_value_fdr"].min(), "n_nominal_p_lt_0_01": effect_rows["p_value"].lt(0.01).sum(), "nominal_p_lt_0_01_expected": len(effect_rows) * 0.01, "plsda_permutation_p_value": pls_p, "n_cells_imputed": n_imputed, "mean_imputed_fraction_among_fdr_hits": hit_routes.ne("none").mean(axis=1).mean() if len(hits) else np.nan})
    results = pd.DataFrame(rows)
    pd.DataFrame(summaries).to_csv(preprocessing_dir / "imputation_summary.csv", index=False)
    pd.DataFrame(recovery).to_csv(preprocessing_dir / "imputation_recovery_rmse.csv", index=False)
    result_dir = output / "07_specification_curve"; result_dir.mkdir(parents=True, exist_ok=True)
    results.to_csv(result_dir / "specification_results.csv", index=False)
    ordered = results.groupby("specification", observed=True)["smallest_q_value"].min().sort_values()
    figure, axis = plt.subplots(figsize=(9, 4.5)); axis.scatter(range(len(ordered)), ordered, color=COLORBLIND_COLORS[0]); axis.axhline(0.05, color="#666666", linestyle="--"); axis.set(xticks=range(len(ordered)), xticklabels=ordered.index, ylabel="Smallest FDR q-value", xlabel="Pre-specified specification", title="QC-CV and imputation specification curve"); axis.tick_params(axis="x", rotation=45); figure.tight_layout(); save_figure(figure, result_dir / "figures" / "specification_curve"); plt.close(figure)


if __name__ == "__main__":
    run_specification_curve(Path(__file__).resolve().parents[3])
