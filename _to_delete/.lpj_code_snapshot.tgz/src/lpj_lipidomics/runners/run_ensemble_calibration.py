"""Compatibility entry point for the complete staged ensemble run."""

from __future__ import annotations

from pathlib import Path

from .run_outlier_ensemble import run_outlier_ensemble


def run_ensemble_calibration(
    project_root: Path,
    *,
    n_null_replicates: int = 200,
    isolation_forest_replicates: int = 50,
    isolation_forest_estimators: int = 100,
) -> list[Path]:
    """Run the same staged protocol as the primary ensemble driver.

    Ensemble calibration is part of the complete detector run.  Keeping this
    entry point as a thin wrapper prevents a second, stage-blind verdict path
    from drifting away from the prespecified output schema.
    """
    return run_outlier_ensemble(
        project_root,
        n_null_replicates=n_null_replicates,
        isolation_forest_replicates=isolation_forest_replicates,
        isolation_forest_estimators=isolation_forest_estimators,
    )


if __name__ == "__main__":
    run_ensemble_calibration(Path(__file__).resolve().parents[3])
