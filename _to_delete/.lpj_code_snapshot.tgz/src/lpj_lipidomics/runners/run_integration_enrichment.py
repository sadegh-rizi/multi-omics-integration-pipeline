"""Run local-GMT protein enrichment for the confirmed integration extensions."""

from __future__ import annotations

import argparse
import json
from collections.abc import Iterable
from pathlib import Path

import pandas as pd

from ..integration.common import POPULATION, extension_root
from ..integration.enrichment import (
    benjamini_hochberg,
    hypergeometric_enrichment,
    infer_gmt_version,
    parse_gmt,
    sha256_file,
)


N_DETECTED_PROTEINS = 3_821
GMT_SUFFIXES = (".gmt", ".gmt.gz")


def _required_file(path: Path, description: str) -> Path:
    if not path.is_file():
        raise FileNotFoundError(f"{description} is absent: {path}")
    return path


def _reference_gmt_files(reference_root: Path) -> list[tuple[str, Path]]:
    """Find versioned local GO and Reactome GMT files."""
    if not reference_root.is_dir():
        raise FileNotFoundError(
            "Reference GMT files are absent. Expected local GO and Reactome GMT files "
            f"under {reference_root}; download the approved references before running WP3."
        )

    files = sorted(
        path for path in reference_root.iterdir()
        if path.is_file() and path.name.casefold().endswith(GMT_SUFFIXES)
    )
    go_files = [
        path for path in files
        if "gene_ontology" in path.name.casefold()
        or "geneontology" in path.name.casefold()
        or "go" in path.stem.casefold()
    ]
    reactome_files = [path for path in files if "reactome" in path.name.casefold()]
    if not go_files or not reactome_files:
        found = ", ".join(path.name for path in files) or "none"
        raise FileNotFoundError(
            "Reference GMT files are incomplete. Expected at least one local GO GMT "
            f"and one local Reactome GMT under {reference_root}; found {found}. "
            "Download the approved references before running WP3."
        )
    return [("GO", path) for path in go_files] + [("Reactome", path) for path in reactome_files]


def _load_annotation(project_root: Path) -> pd.DataFrame:
    path = _required_file(
        project_root
        / "results"
        / "mia_vs_control"
        / "14_integration"
        / POPULATION
        / "00_inputs"
        / "proteomics_feature_annotation.csv",
        "The detected-protein annotation required for enrichment",
    )
    annotation = pd.read_csv(path)
    required = {"Protein ID", "Gene"}
    missing = required.difference(annotation.columns)
    if missing:
        raise KeyError(f"{path} is missing annotation columns: {sorted(missing)}")
    if len(annotation) != N_DETECTED_PROTEINS:
        raise ValueError(
            f"Expected the confirmed background of {N_DETECTED_PROTEINS} detected proteins, "
            f"but {path} contains {len(annotation)} rows."
        )

    annotation = annotation.loc[:, ["Protein ID", "Gene"]].copy()
    annotation["Protein ID"] = annotation["Protein ID"].map(
        lambda value: str(value).strip() if pd.notna(value) else ""
    )
    if annotation["Protein ID"].eq("").any() or annotation["Protein ID"].duplicated().any():
        raise ValueError("Detected-protein annotation contains missing or duplicate Protein IDs.")
    annotation["Gene"] = annotation["Gene"].map(
        lambda value: str(value).strip() if pd.notna(value) else ""
    )
    return annotation


def _protein_features(features: Iterable[object], *, source: str) -> list[str]:
    values = [str(feature).strip() for feature in features if pd.notna(feature) and str(feature).strip()]
    unique = list(dict.fromkeys(values))
    if not unique:
        raise ValueError(f"{source} contains no protein features.")
    return unique


def _load_analysis_units(project_root: Path) -> list[dict[str, object]]:
    extension = extension_root(project_root)
    top_path = _required_file(
        extension / "01_mofa_within_region" / "top_features.csv",
        "WP1 top-loading feature output",
    )
    sensitivity_path = _required_file(
        extension / "01_mofa_within_region" / "top_features_sensitivity_10pct.csv",
        "WP1 10% top-loading sensitivity output",
    )
    module_path = _required_file(
        extension / "02_cross_omics_screen" / "modules.csv",
        "WP2 module output",
    )

    units: list[dict[str, object]] = []
    for feature_path, cutoff, unit_suffix in (
        (top_path, "top_5_percent", ""),
        (sensitivity_path, "top_10_percent", " (top 10%)"),
    ):
        top_features = pd.read_csv(feature_path)
        required_top = {"View", "Factor", "Feature"}
        missing_top = required_top.difference(top_features.columns)
        if missing_top:
            raise KeyError(f"{feature_path} is missing columns: {sorted(missing_top)}")
        protein_top = top_features.loc[top_features["View"].eq("proteomics")]
        for factor, rows in protein_top.groupby("Factor", sort=False, dropna=False):
            if pd.isna(factor):
                raise ValueError(f"{feature_path} contains a missing WP1 factor name.")
            units.append({
                "analysis_type": "factor",
                "analysis_unit": f"{factor}{unit_suffix}",
                "Factor": str(factor),
                "Region": "",
                "module": "",
                "loading_cutoff": cutoff,
                "features": _protein_features(rows["Feature"], source=f"WP1 factor {factor} {cutoff}"),
            })
    if not units:
        raise ValueError(f"{top_path} contains no proteomics top-loading proteins.")

    modules = pd.read_csv(module_path)
    required_modules = {"Region", "target_view", "module", "target_features"}
    missing_modules = required_modules.difference(modules.columns)
    if missing_modules:
        raise KeyError(f"{module_path} is missing columns: {sorted(missing_modules)}")
    if "finding_candidate" in modules:
        modules = modules.loc[modules["finding_candidate"].fillna(False)]
    protein_modules = modules.loc[modules["target_view"].eq("proteomics")]
    seen_modules: set[str] = set()
    for row_number, row in protein_modules.iterrows():
        if pd.isna(row["Region"]) or pd.isna(row["module"]):
            raise ValueError(f"{module_path} has a proteomics module with missing identity at row {row_number}.")
        module_name = f"{row['Region']}:proteomics:module{row['module']}"
        if module_name in seen_modules:
            raise ValueError(f"{module_path} contains duplicate module identity {module_name!r}.")
        seen_modules.add(module_name)
        features = str(row["target_features"]).split(";") if pd.notna(row["target_features"]) else []
        units.append({
            "analysis_type": "module",
            "analysis_unit": module_name,
            "Factor": "",
            "Region": str(row["Region"]),
            "module": str(row["module"]),
            "loading_cutoff": "module",
            "features": _protein_features(features, source=f"WP2 module {module_name}"),
        })
    return units


def _existing_outputs(output_root: Path, reference_root: Path) -> list[Path]:
    return [
        path for path in output_root.rglob("*")
        if path.is_file() and reference_root not in path.parents
    ]


def run_enrichment(project_root: Path, *, overwrite: bool = False) -> Path:
    """Write GO/Reactome protein over-representation results for WP1 and WP2."""
    output_root = extension_root(project_root) / "03_enrichment"
    reference_root = project_root / "data" / "reference"
    if not overwrite and _existing_outputs(output_root, reference_root):
        raise FileExistsError(f"Refusing to overwrite existing enrichment outputs: {output_root}")

    reference_files = _reference_gmt_files(reference_root)
    annotation = _load_annotation(project_root)
    units = _load_analysis_units(project_root)
    background = set(annotation["Protein ID"])
    gene_by_protein = {
        row["Protein ID"]: row["Gene"].casefold()
        for _, row in annotation.iterrows()
        if row["Gene"]
    }
    background_mapped = set(gene_by_protein)

    all_gene_sets: list[tuple[str, Path, str, frozenset[str]]] = []
    reference_rows: list[dict[str, object]] = []
    for collection, path in reference_files:
        gene_sets = parse_gmt(path)
        reference_rows.append({
            "collection": collection,
            "reference_file": path.name,
            "version": infer_gmt_version(path),
            "sha256": sha256_file(path),
            "n_gene_sets": len(gene_sets),
        })
        for term, members in gene_sets.items():
            all_gene_sets.append((collection, path, term, frozenset(member.casefold() for member in members)))

    term_proteins: list[tuple[str, Path, str, set[str]]] = []
    for collection, path, term, members in all_gene_sets:
        proteins = {
            protein for protein, gene in gene_by_protein.items()
            if protein.casefold() in members or gene in members
        }
        term_proteins.append((collection, path, term, proteins))
    if not any(proteins for _, _, _, proteins in term_proteins):
        raise ValueError(
            "No GO or Reactome GMT members mapped to the 3,821 detected proteins. "
            "Check that local GMT identifiers match the annotation Gene column."
        )

    enrichment_rows: list[dict[str, object]] = []
    mapping_rows: list[dict[str, object]] = []
    for unit in units:
        selected = set(unit["features"])
        absent = selected.difference(background)
        if absent:
            preview = ", ".join(sorted(absent)[:5])
            raise ValueError(
                f"{unit['analysis_unit']} contains protein IDs absent from the 3,821-protein "
                f"background ({preview})."
            )
        selected_mapped = selected & background_mapped
        mapping_base = {
            "analysis_type": unit["analysis_type"],
            "analysis_unit": unit["analysis_unit"],
            "Factor": unit["Factor"],
            "Region": unit["Region"],
            "module": unit["module"],
            "loading_cutoff": unit["loading_cutoff"],
            "n_input_proteins": len(selected),
            "n_input_mapped": len(selected_mapped),
            "n_input_unmapped": len(selected - selected_mapped),
            "n_background_proteins": len(background),
            "n_background_mapped": len(background_mapped),
            "n_background_unmapped": len(background - background_mapped),
        }
        mapping_rows.append(mapping_base)
        for collection, path, term, proteins in term_proteins:
            result = hypergeometric_enrichment(background, selected, proteins)
            overlap = selected & proteins
            enrichment_rows.append({
                **mapping_base,
                "collection": collection,
                "reference_file": path.name,
                "term": term,
                "n_term_background": result.gene_set_size,
                "n_overlap": result.overlap_size,
                "overlap_proteins": ";".join(sorted(overlap)),
                "raw_p_value": result.raw_p_value,
            })

    enrichment = pd.DataFrame(enrichment_rows)
    enrichment["bh_q_value"] = (
        enrichment.groupby("analysis_unit", sort=False)["raw_p_value"]
        .transform(lambda values: benjamini_hochberg(values.tolist()))
    )
    output_root.mkdir(parents=True, exist_ok=True)
    enrichment.to_csv(output_root / "protein_enrichment.csv", index=False)
    pd.DataFrame(mapping_rows).to_csv(output_root / "mapping_summary.csv", index=False)
    pd.DataFrame(reference_rows).to_csv(output_root / "reference_metadata.csv", index=False)

    input_root = project_root / "results" / "mia_vs_control" / "14_integration" / POPULATION
    manifest = {
        "analysis": "local GO/Reactome protein over-representation enrichment",
        "population": POPULATION,
        "inputs": {
            "wp1_top_features": str((extension_root(project_root) / "01_mofa_within_region" / "top_features.csv").relative_to(project_root)),
            "wp1_top_features_sensitivity_10pct": str((extension_root(project_root) / "01_mofa_within_region" / "top_features_sensitivity_10pct.csv").relative_to(project_root)),
            "wp2_modules": str((extension_root(project_root) / "02_cross_omics_screen" / "modules.csv").relative_to(project_root)),
            "protein_annotation": str((input_root / "00_inputs" / "proteomics_feature_annotation.csv").relative_to(project_root)),
        },
        "background": {
            "n_detected_proteins": N_DETECTED_PROTEINS,
            "mapping_column": "Gene",
            "unmapped_policy": "protein IDs without a Gene annotation are retained in the 3,821-protein universe but cannot map to GMT terms",
        },
        "loading_cutoffs": ["top_5_percent", "top_10_percent_sensitivity"],
        "reference_gmt": reference_rows,
        "reference_provenance": "data/reference/reference_manifest.json",
        "identifier_mapping": "GO symbols and Reactome UniProt IDs are matched case-insensitively to the annotation and expanded to detected protein IDs",
        "test": "one-sided hypergeometric over-representation",
        "multiple_testing": "Benjamini-Hochberg across all loaded GO and Reactome terms separately within each WP1 factor or WP2 proteomics module",
        "outputs": ["protein_enrichment.csv", "mapping_summary.csv", "reference_metadata.csv", "manifest.json"],
        "downloads": "performed once into data/reference and recorded with source metadata",
    }
    (output_root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return output_root


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[3])
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    run_enrichment(args.project_root, overwrite=args.overwrite)
