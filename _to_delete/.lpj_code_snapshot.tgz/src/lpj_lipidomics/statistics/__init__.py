"""Statistical models and diagnostics."""
