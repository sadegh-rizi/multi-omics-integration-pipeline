"""Stable project-relative paths shared by analysis runners."""

from __future__ import annotations

from pathlib import Path


WORKBOOK_NAME = "1 MB2_088_Lalowski_Report_Final.xlsx"


def repository_root() -> Path:
    """Return the repository root for this source checkout."""
    return Path(__file__).resolve().parents[2]


def source_workbook(project_root: Path) -> Path:
    """Return the source workbook path without depending on the current directory."""
    return Path(project_root) / "data" / WORKBOOK_NAME


def results_root(project_root: Path, analysis: str) -> Path:
    """Return the root directory for one named analysis."""
    return Path(project_root) / "results" / analysis
