"""Shared loading, alignment, and small statistical helpers for integration extensions."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata


POPULATION = "prevalence20_noexclusion"
REGIONS = ("Cerebellum", "Cortex", "Hippocampus")
VIEWS = ("lipidomics", "metabolomics", "proteomics")


def extension_root(project_root: Path) -> Path:
    return project_root / "results" / "mia_vs_control" / "16_integration_extensions" / POPULATION


def integration_root(project_root: Path) -> Path:
    return project_root / "results" / "mia_vs_control" / "14_integration" / POPULATION


def load_integration_inputs(project_root: Path) -> tuple[dict[str, pd.DataFrame], pd.DataFrame]:
    """Load the delivered complete blocks and align metadata to their sample order."""
    root = integration_root(project_root) / "00_inputs"
    blocks: dict[str, pd.DataFrame] = {}
    sample_order: pd.Index | None = None
    for view in VIEWS:
        table = pd.read_csv(root / "blocks" / f"{view}.csv").set_index("Sample")
        table.index = table.index.astype(str)
        if table.index.has_duplicates:
            raise ValueError(f"{view} contains duplicate sample identifiers.")
        if table.isna().to_numpy().any():
            raise ValueError(f"{view} contains missing values.")
        if sample_order is None:
            sample_order = table.index
        elif not table.index.equals(sample_order):
            raise ValueError("Integration blocks do not have identical sample order.")
        blocks[view] = table.apply(pd.to_numeric, errors="raise")

    assert sample_order is not None
    metadata = pd.read_csv(root / "sample_metadata.csv")
    metadata["Sample"] = metadata["Sample"].astype(str)
    metadata = metadata.set_index("Sample").loc[sample_order].reset_index()
    if metadata["Mouse number"].nunique() != 20 or len(metadata) != 60:
        raise ValueError("Extensions require the confirmed 60-sample/20-mouse population.")
    return blocks, metadata


def zscore_columns(values: pd.DataFrame) -> pd.DataFrame:
    """Standardize columns without changing sample order."""
    numeric = values.astype(float)
    scale = numeric.std(axis=0, ddof=1)
    if (scale <= 0).any():
        raise ValueError("Cannot standardize a constant feature.")
    return (numeric - numeric.mean(axis=0)) / scale


def spearman_matrix(left: pd.DataFrame, right: pd.DataFrame) -> np.ndarray:
    """Return feature-by-feature Spearman correlations for complete samples."""
    if len(left) != len(right) or len(left) < 4:
        raise ValueError("Spearman correlations require aligned data with at least four samples.")
    left_rank = np.apply_along_axis(rankdata, 0, left.to_numpy(dtype=float))
    right_rank = np.apply_along_axis(rankdata, 0, right.to_numpy(dtype=float))
    left_rank = np.divide(
        left_rank - left_rank.mean(axis=0),
        left_rank.std(axis=0, ddof=1),
        out=np.zeros_like(left_rank),
        where=left_rank.std(axis=0, ddof=1) > 0,
    )
    right_rank = np.divide(
        right_rank - right_rank.mean(axis=0),
        right_rank.std(axis=0, ddof=1),
        out=np.zeros_like(right_rank),
        where=right_rank.std(axis=0, ddof=1) > 0,
    )
    return left_rank.T @ right_rank / (len(left) - 1)


def r_squared(values: pd.Series | np.ndarray, predictor: pd.Series) -> float:
    """Descriptive R-squared for a numeric or categorical covariate."""
    response = np.asarray(values, dtype=float)
    if not np.isfinite(response).all() or np.var(response) == 0:
        return 0.0
    if pd.api.types.is_numeric_dtype(predictor):
        design_values = predictor.to_numpy(dtype=float)[:, None]
    else:
        design_values = pd.get_dummies(predictor.astype(str), dtype=float).to_numpy()
    design = np.column_stack([np.ones(len(predictor)), design_values])
    fitted = design @ np.linalg.lstsq(design, response, rcond=None)[0]
    return float(np.clip(1 - np.sum((response - fitted) ** 2) / np.sum((response - response.mean()) ** 2), 0, 1))


def sample_mask(metadata: pd.DataFrame, region: str) -> pd.Series:
    if region not in REGIONS:
        raise ValueError(f"Unknown region: {region}")
    mask = metadata["Sample type"].eq(region)
    if int(mask.sum()) != 20:
        raise ValueError(f"Expected 20 samples in {region}, found {int(mask.sum())}.")
    return mask
