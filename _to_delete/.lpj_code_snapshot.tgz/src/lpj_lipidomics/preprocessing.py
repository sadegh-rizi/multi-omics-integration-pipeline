"""Preprocessing utilities for LPJ lipidomics intensity tables.

Input convention: intensity tables have lipid features as rows and
biological samples as columns, matching how `notebooks/sandbox.ipynb`
loads the Lipidomics sheet from
``data/1 MB2_088_Lalowski_Report_Final.xlsx``.

These functions never impute. Non-positive or missing intensities are
propagated as NaN and excluded from downstream calculations, per
`doc/agent-rules.md` ("never silently replace missing or zero values").
See `doc/decisions/2026-07-21-mia-vs-control-lipidomics-plan.md` for the
rationale behind the two pipelines below.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


DEFAULT_BLANK_MULTIPLIER = 3.0
DEFAULT_ABSOLUTE_FLOOR = 1.0


def exclude_nonpositive(intensity: pd.DataFrame) -> pd.DataFrame:
    """Coerce to numeric and mask non-positive or non-numeric intensities as NaN.

    Does not impute. Values that are zero, negative, or fail numeric
    coercion become NaN so they are excluded from later steps rather than
    silently treated as zero.
    """
    numeric = intensity.apply(pd.to_numeric, errors="coerce")
    return numeric.where(numeric > 0)


def exclude_blank_dominated_features(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    *,
    blank_multiplier: float = DEFAULT_BLANK_MULTIPLIER,
) -> pd.DataFrame:
    """Remove features whose biological median is below their blank signal.

    A feature is removed only when it has non-zero mean blank signal and its
    median biological intensity is below ``blank_multiplier * mean_blank``.
    Missing and zero values are excluded from the biological median; blank
    missing values are treated as zero as in the value-level detection rule.
    """
    if blank_multiplier <= 0:
        raise ValueError("blank_multiplier must be positive.")
    if intensity.index.has_duplicates or blank_intensity.index.has_duplicates:
        raise ValueError("Intensity and blank feature indexes must be unique.")
    if not intensity.index.equals(blank_intensity.index):
        raise ValueError("Intensity and blank feature indexes must match exactly.")
    if blank_intensity.shape[1] == 0:
        raise ValueError("At least one blank-injection column is required.")

    numeric_intensity = intensity.apply(pd.to_numeric, errors="coerce")
    numeric_blank = blank_intensity.apply(pd.to_numeric, errors="coerce")
    if numeric_blank.lt(0).to_numpy().any():
        raise ValueError("Blank intensities must be non-negative.")

    mean_blank = numeric_blank.fillna(0).mean(axis=1)
    biological_median = numeric_intensity.where(numeric_intensity > 0).median(axis=1, skipna=True)
    remove = mean_blank.gt(0) & biological_median.lt(blank_multiplier * mean_blank)
    return intensity.loc[~remove].copy()


def below_detection_reasons(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    *,
    blank_multiplier: float = DEFAULT_BLANK_MULTIPLIER,
    absolute_floor: float = DEFAULT_ABSOLUTE_FLOOR,
) -> pd.DataFrame:
    """Label positive raw values below the empirical detection limit.

    The per-lipid limit is ``max(blank_multiplier * mean_blank,
    absolute_floor)``. Missing and zero blank injections are treated as zero
    signal. A reason identifies the criterion that sets the active limit, so
    the blank-derived and absolute-floor counts do not overlap.
    """
    if blank_multiplier <= 0:
        raise ValueError("blank_multiplier must be positive.")
    if absolute_floor <= 0:
        raise ValueError("absolute_floor must be positive.")
    if intensity.index.has_duplicates or blank_intensity.index.has_duplicates:
        raise ValueError("Intensity and blank feature indexes must be unique.")
    if not intensity.index.equals(blank_intensity.index):
        raise ValueError("Intensity and blank feature indexes must match exactly.")
    if blank_intensity.shape[1] == 0:
        raise ValueError("At least one blank-injection column is required.")

    numeric_intensity = intensity.apply(pd.to_numeric, errors="coerce")
    numeric_blank = blank_intensity.apply(pd.to_numeric, errors="coerce")
    if numeric_blank.lt(0).to_numpy().any():
        raise ValueError("Blank intensities must be non-negative.")

    blank_limit = blank_multiplier * numeric_blank.fillna(0).mean(axis=1)
    blank_sets_limit = blank_limit.gt(absolute_floor)
    positive = numeric_intensity.gt(0)
    below_blank_limit = (
        positive
        & numeric_intensity.lt(blank_limit, axis="index")
        & blank_sets_limit.to_numpy()[:, np.newaxis]
    )
    below_absolute_floor = (
        positive
        & numeric_intensity.lt(absolute_floor)
        & ~blank_sets_limit.to_numpy()[:, np.newaxis]
    )

    reasons = pd.DataFrame(
        pd.NA,
        index=intensity.index,
        columns=intensity.columns,
        dtype="string",
    )
    reasons = reasons.mask(below_blank_limit, "below_blank_limit")
    return reasons.mask(below_absolute_floor, "below_absolute_floor")


def exclude_below_detection(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    *,
    blank_multiplier: float = DEFAULT_BLANK_MULTIPLIER,
    absolute_floor: float = DEFAULT_ABSOLUTE_FLOOR,
) -> pd.DataFrame:
    """Mask below-detection raw values as missing without imputing them.

    Call after :func:`exclude_nonpositive` and before log2 transformation.
    This reverts inferred gap-filled non-detects to missing values; the
    underlying vendor gap-filling setting has not been independently verified.
    """
    reasons = below_detection_reasons(
        intensity,
        blank_intensity,
        blank_multiplier=blank_multiplier,
        absolute_floor=absolute_floor,
    )
    return intensity.mask(reasons.notna())


def exclude_low_prevalence_features(
    intensity: pd.DataFrame,
    *,
    max_missing_fraction: float,
) -> pd.DataFrame:
    """Remove features missing in more than the allowed share of samples.

    The caller controls the missingness basis.  For the filtered sensitivity
    pipeline this is called on ``exclude_nonpositive(raw)`` before blank or
    detection-limit filtering, pooled across all biological samples.  A
    feature exactly at the threshold is retained.
    """
    if not 0 <= max_missing_fraction < 1:
        raise ValueError("max_missing_fraction must be in [0, 1).")
    missing_fraction = intensity.isna().mean(axis=1)
    return intensity.loc[missing_fraction.le(max_missing_fraction)].copy()


def log2_transform(positive_intensity: pd.DataFrame) -> pd.DataFrame:
    """Log2-transform an intensity table already filtered to positive values.

    Raises ValueError if any non-positive, non-NaN value is present, which
    indicates the caller skipped `exclude_nonpositive`.
    """
    invalid = positive_intensity.le(0)
    if invalid.to_numpy().any():
        raise ValueError(
            "log2_transform received non-positive values; call "
            "exclude_nonpositive first."
        )
    return np.log2(positive_intensity)


def median_normalize(log_intensity: pd.DataFrame) -> pd.DataFrame:
    """Median-normalize each sample (column) by subtracting its median
    log-intensity across features.

    Corrects for sample-to-sample loading/concentration differences while
    preserving each feature's log fold-change, which differential testing
    depends on.
    """
    sample_medians = log_intensity.median(axis=0, skipna=True)
    return log_intensity.subtract(sample_medians, axis=1)


def pqn_normalize(log_intensity: pd.DataFrame, groups: pd.Series) -> pd.DataFrame:
    """Subtract median log-ratios to each region's median-centred reference.

    ``groups`` is sample-indexed region metadata, never treatment labels. The
    reference pools both treatments. Centring each reference to median zero
    provides the same relative between-region anchor as median normalization.
    Conventional even-sized medians do not commute exactly with log; this is
    explicitly the log-space definition, not arithmetic raw-quotient PQN.
    At least half the retained panel must be observed in sample and reference.
    """
    if log_intensity.empty or log_intensity.index.has_duplicates or log_intensity.columns.has_duplicates:
        raise ValueError("PQN requires a nonempty matrix with unique feature and sample IDs.")
    if groups.index.has_duplicates or set(groups.index) != set(log_intensity.columns):
        raise ValueError("PQN region labels must align with the sample columns.")
    groups = groups.reindex(log_intensity.columns)
    if groups.isna().any() or np.isinf(log_intensity.to_numpy(dtype=float)).any():
        raise ValueError("PQN requires nonmissing region labels and finite observed intensities.")
    normalized = log_intensity.copy()
    for _, samples in groups.groupby(groups, sort=False, observed=True).groups.items():
        current = log_intensity.loc[:, samples]
        reference = current.median(axis=1, skipna=True)
        reference = reference - reference.median(skipna=True)
        quotients = current.subtract(reference, axis=0)
        insufficient = quotients.notna().sum(axis=0).lt(len(log_intensity) / 2)
        if insufficient.any():
            raise ValueError(f"PQN requires at least 50% observed overlap: {insufficient.index[insufficient].tolist()}")
        normalized.loc[:, samples] = current.subtract(quotients.median(axis=0), axis=1)
    return normalized


def drop_zero_variance_features(values: pd.DataFrame) -> pd.DataFrame:
    """Drop rows (features) with zero, negative, or undefined variance.

    Required before `autoscale`, which divides by the standard deviation.
    """
    feature_std = values.std(axis=1, ddof=1, skipna=True)
    keep = feature_std.gt(0) & feature_std.notna()
    return values.loc[keep]


def filter_low_iqr_features(
    values: pd.DataFrame,
    *,
    remove_fraction: float = 0.25,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Remove the lowest-IQR features without using biological labels.

    Missing values are ignored when calculating IQR. Features with undefined
    IQR are ranked first for removal because they contain insufficient usable
    information. Feature identifiers break ties deterministically.
    """
    if not 0 <= remove_fraction < 1:
        raise ValueError("remove_fraction must be in [0, 1).")
    if values.empty:
        return values.copy(), pd.DataFrame(columns=["Feature", "iqr", "iqr_rank", "removed"])

    iqr = values.quantile(0.75, axis=1) - values.quantile(0.25, axis=1)
    ranking = pd.DataFrame({"Feature": values.index, "iqr": iqr.to_numpy()})
    ranking["feature_sort_key"] = ranking["Feature"].astype(str)
    ranking = ranking.sort_values(
        ["iqr", "feature_sort_key"],
        ascending=[True, True],
        na_position="first",
        kind="mergesort",
    ).reset_index(drop=True)
    n_remove = int(np.ceil(len(ranking) * remove_fraction))
    ranking["iqr_rank"] = np.arange(1, len(ranking) + 1)
    ranking["removed"] = ranking["iqr_rank"].le(n_remove)
    ranking = ranking.drop(columns="feature_sort_key")
    removed = pd.Index(ranking.loc[ranking["removed"], "Feature"])
    return values.drop(index=removed), ranking


def autoscale(values: pd.DataFrame) -> pd.DataFrame:
    """Auto-scale each feature (row): mean-center and divide by its
    standard deviation across samples.

    Intended for PCA/PERMANOVA-style multivariate analyses, not for
    differential testing, since scaling removes each feature's original
    fold-change magnitude. Call `drop_zero_variance_features` first.
    """
    feature_std = values.std(axis=1, ddof=1, skipna=True)
    if feature_std.le(0).any() or feature_std.isna().any():
        raise ValueError(
            "autoscale received zero-variance or all-NaN features; call "
            "drop_zero_variance_features first."
        )
    feature_mean = values.mean(axis=1, skipna=True)
    centered = values.subtract(feature_mean, axis=0)
    return centered.divide(feature_std, axis=0)


def pareto_scale(values: pd.DataFrame) -> pd.DataFrame:
    """Mean-center and divide each feature by its square-root SD.

    Pareto scaling is kept separate from ``autoscale`` because it preserves
    more of each feature's original variance while still making features
    comparable for the requested sensitivity branch.
    """
    feature_std = values.std(axis=1, ddof=1, skipna=True)
    if feature_std.le(0).any() or feature_std.isna().any():
        raise ValueError(
            "pareto_scale received zero-variance or all-NaN features; call "
            "drop_zero_variance_features first."
        )
    feature_mean = values.mean(axis=1, skipna=True)
    centered = values.subtract(feature_mean, axis=0)
    return centered.divide(np.sqrt(feature_std), axis=0)


def preprocess_for_differential(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    *,
    blank_multiplier: float = DEFAULT_BLANK_MULTIPLIER,
    absolute_floor: float = DEFAULT_ABSOLUTE_FLOOR,
) -> pd.DataFrame:
    """Positive- and detection-limit-filter, log2-transform, and median-normalize.

    Input for per-lipid differential testing (see planned `diffexp.py`),
    where preserving fold-change direction and magnitude matters.
    """
    feature_filtered = exclude_blank_dominated_features(
        intensity, blank_intensity, blank_multiplier=blank_multiplier
    )
    positive = exclude_nonpositive(feature_filtered)
    detectable = exclude_below_detection(
        positive,
        blank_intensity.loc[feature_filtered.index],
        blank_multiplier=blank_multiplier,
        absolute_floor=absolute_floor,
    )
    log_values = log2_transform(detectable)
    return median_normalize(log_values)


def preprocess_for_multivariate(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    *,
    blank_multiplier: float = DEFAULT_BLANK_MULTIPLIER,
    absolute_floor: float = DEFAULT_ABSOLUTE_FLOOR,
) -> pd.DataFrame:
    """Positive- and detection-limit-filter, log2-transform, median-normalize, drop
    zero-variance features, then auto-scale.

    Input for PCA/PERMANOVA-style multivariate analyses (see planned
    `variance.py`), where features need comparable scale.
    """
    normalized = preprocess_for_differential(
        intensity,
        blank_intensity,
        blank_multiplier=blank_multiplier,
        absolute_floor=absolute_floor,
    )
    variable = drop_zero_variance_features(normalized)
    return autoscale(variable)
