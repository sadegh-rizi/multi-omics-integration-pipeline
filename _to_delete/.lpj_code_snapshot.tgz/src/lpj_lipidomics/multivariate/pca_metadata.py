"""Descriptive PCA metadata attribution and a shared two-modality composite."""

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

from ..plotting import BRAIN_REGION_COLORS, COLORBLIND_COLORS, MARKER_CYCLE, save_figure


def between_group_r2(score: pd.Series, groups: pd.Series) -> float:
    frame = pd.DataFrame({"score": score, "group": groups}).dropna()
    overall_mean = frame["score"].mean()
    total_ss = ((frame["score"] - overall_mean) ** 2).sum()
    if total_ss == 0:
        return 0.0
    grouped = frame.groupby("group", observed=True)["score"]
    return float((((grouped.mean() - overall_mean) ** 2) * grouped.size()).sum() / total_ss)


def linear_score_r2(score: pd.Series, covariate: pd.Series) -> float:
    frame = pd.DataFrame({"score": score, "covariate": covariate}).dropna()
    correlation = frame["score"].corr(frame["covariate"])
    return float(correlation ** 2) if pd.notna(correlation) else 0.0


def score_attribution(
    scores: pd.DataFrame, variance: np.ndarray, metadata: pd.DataFrame, scope: str,
) -> pd.DataFrame:
    """Marginal R², not additive variance partitioning or an inferential test."""
    metadata = metadata.set_index("Sample").loc[scores.index]
    factors = [("Region", "Sample type")] if scope == "pooled" else []
    factors += [("Bio group", "Bio group"), ("Sex", "Sex"), ("Tissue mass", "Tissue mass (mg)"),
                ("Cage", "Cage"), ("Collection date", "Date collected")]
    rows = []
    for component, pc_share in zip(scores.columns[:5], variance[:5]):
        for factor, column in [("Total", None), *factors]:
            if factor == "Total":
                r2 = 1.0
            elif factor == "Tissue mass":
                r2 = linear_score_r2(scores[component], pd.to_numeric(metadata[column], errors="raise"))
            else:
                r2 = between_group_r2(scores[component], metadata[column])
            rows.append({"scope": scope, "Component": component, "Factor": factor,
                         "pc_variance_explained": pc_share, "factor_score_r2": r2,
                         "factor_share_of_total_variance": pc_share * r2})
    return pd.DataFrame(rows)


def pooled_region_group_composite(
    scores: pd.DataFrame, variance: np.ndarray, metadata: pd.DataFrame,
    attribution: pd.DataFrame, output: Path,
) -> None:
    """Show both PC pairs with region/group, cage/date and marginal attribution."""
    joined = metadata.set_index("Sample").loc[scores.index].copy()
    joined["Date collected"] = pd.to_datetime(joined["Date collected"]).dt.strftime("%Y-%m-%d")
    figure = plt.figure(figsize=(17, 11))
    grid = figure.add_gridspec(2, 3, width_ratios=[1, 1, 1.25], height_ratios=[1, 1.8])
    lower = grid[1, :2].subgridspec(2, 2, hspace=0.48)
    pairs = [("PC 1", "PC 2"), ("PC 3", "PC 4")]
    for column, (x, y) in enumerate(pairs):
        axis = figure.add_subplot(grid[0, column])
        for region, color in BRAIN_REGION_COLORS.items():
            for group, marker in [("Saline Control", "o"), ("MIA", "^")]:
                selected = joined["Sample type"].eq(region) & joined["Bio group"].eq(group)
                axis.scatter(scores.loc[selected, x], scores.loc[selected, y], marker=marker,
                             facecolors=color if group == "MIA" else "none", edgecolors=color, s=40)
        axis.set_title("Region (colour) and treatment (marker)")
        axes = [axis]
        for row, variable in enumerate(("Cage", "Date collected")):
            current = figure.add_subplot(lower[row, column])
            categories = sorted(joined[variable].astype(str).unique())
            for number, category in enumerate(categories):
                selected = joined[variable].astype(str).eq(category)
                current.scatter(scores.loc[selected, x], scores.loc[selected, y],
                                color=(*COLORBLIND_COLORS, "#000000")[number],
                                marker=MARKER_CYCLE[number], s=32, label=category)
            current.set_title(variable)
            if column == 0:
                current.legend(fontsize=7, ncol=2, loc="best")
            axes.append(current)
        for current in axes:
            current.axhline(0, color="0.8", linewidth=0.6)
            current.axvline(0, color="0.8", linewidth=0.6)
            current.set_xlabel(f"{x} ({variance[int(x.split()[1]) - 1] * 100:.1f}%)")
            current.set_ylabel(f"{y} ({variance[int(y.split()[1]) - 1] * 100:.1f}%)")

    heatmap = figure.add_subplot(grid[:, 2])
    factors = ["Region", "Bio group", "Sex", "Cage", "Collection date", "Tissue mass"]
    table = attribution.pivot(index="Component", columns="Factor", values="factor_score_r2").loc[scores.columns[:5], factors]
    image = heatmap.imshow(table, vmin=0, vmax=1, cmap="cividis", aspect="auto")
    heatmap.grid(False)
    for row in range(len(table)):
        for column in range(len(factors)):
            value = table.iloc[row, column]
            heatmap.text(column, row, f"{value:.2f}", ha="center", va="center",
                         color="white" if value < 0.5 else "black", fontsize=9)
    heatmap.set(xticks=range(len(factors)), xticklabels=factors,
                yticks=range(len(table)), yticklabels=table.index,
                title="Marginal score attribution (R²)")
    heatmap.tick_params(axis="x", labelrotation=60)
    figure.colorbar(image, ax=heatmap, shrink=0.5, label="R² (overlapping factors)")
    handles = [Line2D([], [], color=color, marker="s", linestyle="none", label=region)
               for region, color in BRAIN_REGION_COLORS.items()]
    handles += [Line2D([], [], color="black", marker=marker, markerfacecolor=fill,
                       linestyle="none", label=label)
                for marker, fill, label in [("o", "none", "Saline Control"), ("^", "black", "MIA")]]
    figure.legend(handles=handles, ncol=5, loc="upper center", bbox_to_anchor=(0.5, 0.98))
    figure.suptitle(f"Pooled PCA: {len(joined)} regional samples, {joined['Mouse number'].nunique()} mice", y=1.00)
    figure.text(0.5, 0.01,
                "Log₂-normalized intensities; complete features; autoscaled. Descriptive only; regional samples repeat within mouse.\n"
                "Group-associated variance is cage/date-aliased wherever cage/date R² exceeds group R²; treatment is confounded with these factors.\n"
                "Marginal R² values overlap and do not establish an independent treatment effect.", ha="center", fontsize=9)
    figure.subplots_adjust(top=0.92, bottom=0.16, left=0.05, right=0.97, hspace=0.32, wspace=0.38)
    save_figure(figure, output)
    plt.close(figure)
