"""PCA, PLS-DA, and loading summaries."""
