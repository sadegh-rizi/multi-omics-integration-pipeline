"""Small, deterministic summaries used to inspect PCA feature loadings."""

from __future__ import annotations

import numpy as np
import pandas as pd


def align_loading_signs(loadings: pd.DataFrame) -> pd.DataFrame:
    """Orient each PC so its first largest-magnitude loading is positive."""
    aligned = loadings.copy()
    for component in aligned:
        largest = aligned[component].abs().idxmax()
        if aligned.loc[largest, component] < 0:
            aligned[component] = -aligned[component]
    return aligned


def top_loadings(loadings: pd.DataFrame, n_features: int) -> pd.DataFrame:
    """Return the top features per PC, ranked by absolute loading."""
    if n_features < 1:
        raise ValueError("n_features must be at least one.")
    rows = []
    for component in loadings:
        ranked = pd.DataFrame({"Feature": loadings.index, "loading": loadings[component]})
        ranked["absolute_loading"] = ranked["loading"].abs()
        ranked = ranked.nlargest(n_features, "absolute_loading", keep="all")
        ranked.insert(0, "Component", component)
        rows.append(ranked)
    return pd.concat(rows, ignore_index=True)


def loading_concentration(loadings: pd.DataFrame, n_features: tuple[int, ...] = (10, 25, 50)) -> pd.DataFrame:
    """Return each PC's share of squared loading carried by its strongest features."""
    if not n_features or any(count < 1 for count in n_features):
        raise ValueError("n_features must contain positive counts.")
    rows = []
    for component in loadings:
        squared = loadings[component].pow(2).sort_values(ascending=False, kind="stable")
        total = squared.sum()
        for count in n_features:
            rows.append({"Component": component, "n_features": count, "squared_loading_share": squared.iloc[:count].sum() / total})
    return pd.DataFrame(rows)


def class_composition(loadings: pd.DataFrame, lipid_classes: pd.Series, n_largest: int = 6) -> pd.DataFrame:
    """Summarise each component's squared-loading share by lipid class."""
    if n_largest < 1:
        raise ValueError("n_largest must be positive.")
    classes = lipid_classes.reindex(loadings.index).fillna("Unannotated").astype(str)
    panel_share = classes.value_counts(normalize=True)
    rows = []
    for component in loadings:
        shares = loadings[component].pow(2).groupby(classes, observed=True).sum()
        shares = shares / shares.sum()
        largest = shares.nlargest(n_largest, keep="all").index
        kept = shares.loc[largest]
        if len(largest) < len(shares):
            kept.loc["Other"] = shares.drop(largest).sum()
        for lipid_class, share in kept.items():
            rows.append({
                "Component": component,
                "Lipid Class": lipid_class,
                "squared_loading_share": share,
                "panel_feature_share": panel_share.get(lipid_class, np.nan),
                "enrichment_vs_panel": share / panel_share[lipid_class] if lipid_class in panel_share else np.nan,
            })
    return pd.DataFrame(rows)


def cumulative_share_curve(loadings: pd.DataFrame) -> pd.DataFrame:
    """Return cumulative squared-loading shares ordered by absolute loading."""
    rows = []
    for component in loadings:
        squared = loadings[component].pow(2).sort_values(ascending=False, kind="stable")
        total = squared.sum()
        for count, share in enumerate((squared / total).cumsum(), start=1):
            rows.append({"Component": component, "n_features": count, "cumulative_squared_loading_share": share, "uniform_share": count / len(squared)})
    return pd.DataFrame(rows)
