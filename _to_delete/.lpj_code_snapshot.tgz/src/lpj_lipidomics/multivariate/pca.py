"""PCA helpers for complete, feature-by-sample lipidomics matrices."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import beta, chi2
from sklearn.decomposition import PCA


def _complete_numeric(values: pd.DataFrame) -> pd.DataFrame:
    numeric = values.apply(pd.to_numeric, errors="coerce")
    if numeric.empty or numeric.isna().to_numpy().any():
        raise ValueError("PCA requires a non-empty complete feature-by-sample matrix.")
    return numeric


def fit_pca(
    values: pd.DataFrame,
    *,
    n_components: int | None = None,
) -> tuple[PCA, pd.DataFrame, pd.DataFrame]:
    """Fit PCA to a complete feature-by-sample matrix.

    Returns the fitted model, sample scores, and feature loadings. Features
    are expected to have been auto-scaled before this call.
    """
    numeric = _complete_numeric(values)
    maximum = min(numeric.shape)
    if n_components is None:
        n_components = maximum
    if not 1 <= n_components <= maximum:
        raise ValueError(f"n_components must be between 1 and {maximum}.")

    model = PCA(n_components=n_components)
    scores = model.fit_transform(numeric.T.to_numpy(dtype=float))
    components = [f"PC {number}" for number in range(1, n_components + 1)]
    return (
        model,
        pd.DataFrame(scores, index=numeric.columns, columns=components),
        pd.DataFrame(model.components_.T, index=numeric.index, columns=components),
    )


def scree_table(model: PCA) -> pd.DataFrame:
    """Return explained and cumulative variance for a fitted PCA model."""
    ratios = model.explained_variance_ratio_
    return pd.DataFrame({
        "Component": [f"PC {number}" for number in range(1, len(ratios) + 1)],
        "variance_explained": ratios,
        "cumulative_variance_explained": np.cumsum(ratios),
    })


def loadings_table(
    loadings: pd.DataFrame,
    annotations: pd.DataFrame | None = None,
    *,
    n_features: int = 20,
) -> pd.DataFrame:
    """Rank the strongest positive and negative feature loadings per PC."""
    if n_features < 1:
        raise ValueError("n_features must be at least one.")
    rows: list[pd.DataFrame] = []
    for component in loadings:
        ranking = pd.DataFrame({"Feature": loadings.index, "loading": loadings[component]})
        ranking["absolute_loading"] = ranking["loading"].abs()
        ranking = ranking.nlargest(n_features, "absolute_loading", keep="all")
        ranking.insert(0, "Component", component)
        rows.append(ranking)
    result = pd.concat(rows, ignore_index=True)
    if annotations is not None:
        result = result.merge(
            annotations.loc[:, ["Lipid Name", "Lipid Class"]],
            left_on="Feature",
            right_index=True,
            how="left",
            validate="many_to_one",
        )
    return result.sort_values(["Component", "absolute_loading"], ascending=[True, False], kind="stable")


def confidence_ellipse(
    x: pd.Series | np.ndarray,
    y: pd.Series | np.ndarray,
    *,
    level: float = 0.95,
    n_points: int = 100,
) -> np.ndarray:
    """Return normal-theory data-ellipse coordinates for two score vectors."""
    coordinates = np.column_stack((np.asarray(x, dtype=float), np.asarray(y, dtype=float)))
    if coordinates.shape[0] < 3:
        raise ValueError("A confidence ellipse requires at least three observations.")
    if not 0 < level < 1:
        raise ValueError("level must be between zero and one.")
    if not np.isfinite(coordinates).all():
        raise ValueError("Ellipse coordinates must be finite.")
    covariance = np.cov(coordinates, rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    if np.any(eigenvalues <= 0):
        raise ValueError("Ellipse coordinates must have non-singular covariance.")
    angles = np.linspace(0, 2 * np.pi, n_points)
    circle = np.column_stack((np.cos(angles), np.sin(angles)))
    scale = np.sqrt(chi2.ppf(level, df=2))
    return circle @ (eigenvectors * (np.sqrt(eigenvalues) * scale)).T + coordinates.mean(axis=0)


def _two_dimensional_scores(scores: pd.DataFrame) -> pd.DataFrame:
    """Validate the PC1/PC2 score space used for a plotted T-squared boundary."""
    numeric = scores.apply(pd.to_numeric, errors="coerce")
    if numeric.shape[1] != 2:
        raise ValueError("Hotelling T-squared ellipse requires exactly two score columns.")
    if len(numeric) <= 2:
        raise ValueError("Hotelling T-squared ellipse requires more than two samples.")
    if numeric.isna().to_numpy().any() or not np.isfinite(numeric.to_numpy()).all():
        raise ValueError("Hotelling T-squared scores must be finite.")
    score_sd = numeric.std(axis=0, ddof=1)
    if score_sd.le(0).any():
        raise ValueError("Hotelling T-squared scores must vary on both displayed components.")
    return numeric


def hotelling_t2_2d(scores: pd.DataFrame) -> pd.Series:
    """Return per-sample T-squared in the displayed PC1/PC2 score space."""
    numeric = _two_dimensional_scores(scores)
    centered = numeric.subtract(numeric.mean(axis=0), axis=1)
    standardized = centered.divide(numeric.std(axis=0, ddof=1), axis=1)
    return standardized.pow(2).sum(axis=1).rename("hotelling_t2")


def hotelling_ellipse(
    scores: pd.DataFrame,
    *,
    alpha: float = 0.95,
    n_points: int = 100,
) -> tuple[np.ndarray, float]:
    """Return an axis-aligned 2-D Hotelling T-squared boundary and limit.

    The displayed plane fixes p=2; using the outlier screen's higher-dimensional
    PC count here would draw a boundary that does not match this plot.
    """
    numeric = _two_dimensional_scores(scores)
    if not 0 < alpha < 1:
        raise ValueError("alpha must be between zero and one.")
    if n_points < 3:
        raise ValueError("n_points must be at least three.")
    n_samples = len(numeric)
    p = numeric.shape[1]
    # The Beta quantile calibrates in-sample observations, unlike the F form
    # used for a future observation from the fitted score distribution.
    limit = (n_samples - 1) ** 2 / n_samples * beta.ppf(
        alpha,
        p / 2,
        (n_samples - p - 1) / 2,
    )
    angles = np.linspace(0, 2 * np.pi, n_points)
    semi_axes = numeric.std(axis=0, ddof=1).to_numpy() * np.sqrt(limit)
    center = numeric.mean(axis=0).to_numpy()
    boundary = np.column_stack((np.cos(angles), np.sin(angles))) * semi_axes + center
    return boundary, float(limit)
