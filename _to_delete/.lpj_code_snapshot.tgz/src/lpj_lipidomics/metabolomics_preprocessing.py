"""Metabolomics-specific preprocessing for the cross-modality QC screen."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .preprocessing import (
    below_detection_reasons,
    drop_zero_variance_features,
    exclude_blank_dominated_features,
    exclude_low_prevalence_features,
    exclude_nonpositive,
    log2_transform,
    pqn_normalize,
)


BLANK_MULTIPLIER = 3.0


def global_minimum_positive(intensity: pd.DataFrame) -> float:
    """Return the global positive biological intensity used as the absolute floor."""
    values = intensity.apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
    positive = values[np.isfinite(values) & (values > 0)]
    if not len(positive):
        raise ValueError("No positive metabolomics biological values are available.")
    return float(positive.min())


def median_normalize_by_mode(log_intensity: pd.DataFrame, methods: pd.Series) -> tuple[pd.DataFrame, pd.Series]:
    """Median-normalize each sample separately within each acquisition mode."""
    if not log_intensity.index.equals(methods.index):
        raise ValueError("Method labels must align exactly with metabolite rows.")
    if methods.isna().any():
        raise ValueError("Every metabolite requires an acquisition Method label.")
    normalized = log_intensity.copy()
    medians: dict[str, pd.Series] = {}
    for method, feature_index in methods.groupby(methods, sort=True).groups.items():
        mode_medians = log_intensity.loc[feature_index].median(axis=0, skipna=True)
        normalized.loc[feature_index] = log_intensity.loc[feature_index].subtract(mode_medians, axis=1)
        medians[str(method)] = mode_medians
    return normalized, pd.DataFrame(medians).T.rename_axis("Method")


def pqn_normalize_by_mode(
    log_intensity: pd.DataFrame, methods: pd.Series, groups: pd.Series,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Apply per-region log-space PQN separately within each acquisition mode."""
    if not log_intensity.index.equals(methods.index) or methods.isna().any():
        raise ValueError("Nonmissing Method labels must align exactly with metabolite rows.")
    normalized = log_intensity.copy()
    shifts = {}
    for method, features in methods.groupby(methods, sort=True).groups.items():
        current = log_intensity.loc[features]
        corrected = pqn_normalize(current, groups)
        normalized.loc[features] = corrected
        shifts[str(method)] = (current - corrected).median(axis=0)
    return normalized, pd.DataFrame(shifts).T.rename_axis("Method")


def preprocess_metabolomics(
    intensity: pd.DataFrame,
    blank_intensity: pd.DataFrame,
    methods: pd.Series,
    *,
    max_missing_fraction: float | None = None,
    normalization: str = "median",
    groups: pd.Series | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Apply the pre-specified blank, detection, log2, and per-mode chain.

    The absolute floor is the global minimum positive biological measurement,
    which puts the floor on this panel's observed intensity scale. Missing
    values are never imputed.
    """
    if max_missing_fraction is not None and not 0 <= max_missing_fraction < 1:
        raise ValueError("max_missing_fraction must be in [0, 1).")
    if normalization not in {"median", "pqn"}:
        raise ValueError("normalization must be 'median' or 'pqn'.")
    if normalization == "pqn" and groups is None:
        raise ValueError("PQN requires sample-indexed region labels.")
    floor = global_minimum_positive(intensity)
    numeric = intensity.apply(pd.to_numeric, errors="coerce")
    n_input = len(numeric)
    prevalence_excluded = pd.Index([], dtype=numeric.index.dtype)
    if max_missing_fraction is not None:
        positive = exclude_nonpositive(numeric)
        retained = exclude_low_prevalence_features(
            positive,
            max_missing_fraction=max_missing_fraction,
        )
        prevalence_excluded = numeric.index.difference(retained.index, sort=False)
        numeric = numeric.loc[retained.index]
        blank_intensity = blank_intensity.loc[retained.index]
    blank_dominated = numeric.index.difference(
        exclude_blank_dominated_features(numeric, blank_intensity, blank_multiplier=BLANK_MULTIPLIER).index,
        sort=False,
    )
    reasons_all = below_detection_reasons(
        numeric,
        blank_intensity,
        blank_multiplier=BLANK_MULTIPLIER,
        absolute_floor=floor,
    )
    retained = numeric.drop(index=blank_dominated)
    positive = exclude_nonpositive(retained)
    detectable = positive.mask(reasons_all.loc[retained.index].notna())
    nonempty = detectable.dropna(axis=0, how="all")
    logged = log2_transform(nonempty)
    if normalization == "pqn":
        normalized, mode_medians = pqn_normalize_by_mode(logged, methods.loc[logged.index], groups)
    else:
        normalized, mode_medians = median_normalize_by_mode(logged, methods.loc[logged.index])
    variable = drop_zero_variance_features(normalized)

    blank_limits = BLANK_MULTIPLIER * blank_intensity.fillna(0).apply(pd.to_numeric, errors="coerce").mean(axis=1)
    diagnostics = pd.DataFrame([{
        "n_metabolites_input": n_input,
        "n_prevalence_excluded": len(prevalence_excluded),
        "max_missing_fraction": max_missing_fraction,
        "normalization": normalization,
        "n_blank_dominated_removed": len(blank_dominated),
        "n_metabolites_multivariate": len(variable),
        "n_below_detection_cells": int(reasons_all.notna().sum().sum()),
        "absolute_floor": floor,
        "absolute_floor_derivation": "global minimum positive metabolomics biological value",
        "n_nonpositive_masked": int(numeric.le(0).sum().sum()),
        "n_features_blank_limit": int(blank_limits.gt(0).sum()),
        "n_features_zero_mean_blank": int(blank_limits.eq(0).sum()),
        "n_features_no_values_after_masking": len(retained) - len(nonempty),
        "n_zero_variance_removed": len(normalized) - len(variable),
        "blank_dominated_percent": 100 * len(blank_dominated) / len(numeric),
        "blank_dominated_comparison": "7.1% metabolomics versus 1.1% lipidomics (19/267 versus 11/992 expected)",
    }])
    blank_table = pd.DataFrame({"Metabolite": blank_dominated})
    return variable, diagnostics, blank_table, mode_medians
