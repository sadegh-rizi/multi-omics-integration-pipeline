"""Interpretable lipid summary features for the within-region discovery screen."""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd

from .aggregation import annotate_lipid_structures, structural_index_profiles
from .io.lipidomics import read_lipidomics_tables
from .io.study_design import lipid_feature_rows


_ETHER_RE = re.compile(r"(?:^|[(_])(?:O-|P-)")
_SPHINGOLIPID_CLASSES = frozenset({"Cer", "SM", "Hex1Cer", "Hex2Cer", "GD1a", "GD1b", "GM1", "GM2", "GM3"})


def load_selected_lipid_annotations(project_root: Path, feature_ids: pd.Index) -> pd.DataFrame:
    """Map persistence feature indices back to the supplied workbook annotation."""
    workbook = project_root / "data" / "1 MB2_088_Lalowski_Report_Final.xlsx"
    _, report = read_lipidomics_tables(workbook)
    features = lipid_feature_rows(report).loc[:, ["Lipid Name", "Lipid Class"]]
    numeric_ids = pd.to_numeric(pd.Index(feature_ids), errors="coerce")
    if numeric_ids.isna().any() or not np.all(numeric_ids == numeric_ids.astype(int)):
        raise ValueError("Lipid block features are not source report row indices.")
    numeric_ids = numeric_ids.astype(int)
    valid = numeric_ids.isin(features.index)
    annotations = features.loc[numeric_ids[valid]].copy()
    annotations.index = pd.Index(feature_ids[valid].astype(str), name="Feature")
    annotations["source_feature_id"] = numeric_ids[valid].to_numpy()
    return annotations


def _mean_profile(values: pd.DataFrame, features: pd.Index, name: str) -> pd.Series:
    if len(features) == 0:
        raise ValueError(f"Cannot build empty lipid summary {name}.")
    return values.loc[:, features].mean(axis=1).rename(name)


def build_lipid_summary_features(
    values: pd.DataFrame,
    annotations: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build fixed compositional summaries and return values plus definitions.

    The delivered lipid block is log2-normalized.  We exponentiate and divide
    each sample by its total signal before summarizing, so class and structural
    summaries are within-sample shares rather than absolute-intensity totals.
    """
    values = values.loc[:, annotations.index]
    if annotations.isna().any().any():
        raise ValueError("Lipid annotations do not cover every delivered feature.")

    positive = np.exp2(values.astype(float))
    shares = positive.divide(positive.sum(axis=1), axis=0)
    structures = annotate_lipid_structures(annotations)
    structural_profiles, _, _ = structural_index_profiles(values.T, annotations)
    structural_profiles = structural_profiles.T
    rows: list[pd.Series] = []
    definitions: list[dict[str, object]] = []

    def add(name: str, feature_mask: pd.Series, description: str) -> None:
        selected = annotations.index[feature_mask.to_numpy()]
        if len(selected) == 0:
            return
        rows.append(_mean_profile(shares, selected, name))
        definitions.append({"Feature": name, "description": description, "n_source_lipids": len(selected)})

    class_counts = annotations["Lipid Class"].value_counts()
    for lipid_class in class_counts.index.sort_values():
        mask = annotations["Lipid Class"].eq(lipid_class)
        add(f"class_share::{lipid_class}", mask, f"Mean within-sample share of {lipid_class} features")

    for name, mask, description in (
        ("ether_share", annotations["Lipid Name"].astype(str).str.contains(_ETHER_RE), "Ether lipid share"),
        ("ester_share", ~annotations["Lipid Name"].astype(str).str.contains(_ETHER_RE), "Non-ether lipid share"),
        ("20:4_share", annotations["Lipid Name"].astype(str).str.contains(r"20:4", regex=True), "Features containing a 20:4 chain"),
        ("22:6_share", annotations["Lipid Name"].astype(str).str.contains(r"22:6", regex=True), "Features containing a 22:6 chain"),
        (
            "very_long_chain_sphingolipid_share",
            annotations["Lipid Class"].isin(_SPHINGOLIPID_CLASSES) & structures["total_chain_length"].ge(24),
            "Sphingolipid features with total chain length at least C24",
        ),
    ):
        add(name, mask, description)

    for name, mask in (
        ("chain_length_le_16", structures["total_chain_length"].le(16)),
        ("chain_length_17_18", structures["total_chain_length"].between(17, 18)),
        ("chain_length_19_20", structures["total_chain_length"].between(19, 20)),
        ("chain_length_21_22", structures["total_chain_length"].between(21, 22)),
        ("chain_length_ge_23", structures["total_chain_length"].ge(23)),
        ("double_bonds_0", structures["total_double_bond_count"].eq(0)),
        ("double_bonds_1", structures["total_double_bond_count"].eq(1)),
        ("double_bonds_2", structures["total_double_bond_count"].eq(2)),
        ("double_bonds_ge_3", structures["total_double_bond_count"].ge(3)),
    ):
        add(name, mask.fillna(False), f"Mean within-sample share for {name.replace('_', ' ')}")

    for metric in ("mean_chain_length", "mean_double_bond_count", "pufa_fraction", "saturated_to_unsaturated_ratio"):
        feature = f"structural::Overall::{metric}"
        rows.append(structural_profiles[feature].rename(feature))
        definitions.append({"Feature": feature, "description": f"Overall structural index: {metric}", "n_source_lipids": len(structures)})

    # Add structural summaries for the 10 largest classes to keep the panel
    # interpretable and within the planned approximately 60-80 features.
    for lipid_class in class_counts.nlargest(10).index.sort_values():
        class_index = structures.index[structures["Lipid Class"].eq(lipid_class)]
        for metric in ("mean_chain_length", "mean_double_bond_count"):
            feature = f"structural::{lipid_class}::{metric}"
            rows.append(structural_profiles[feature].rename(feature))
            definitions.append({"Feature": feature, "description": f"Mean {metric} among {lipid_class} annotations", "n_source_lipids": len(class_index)})

    summaries = pd.concat(rows, axis=1)
    definition_table = pd.DataFrame(definitions).drop_duplicates("Feature").set_index("Feature")
    if len(summaries.columns) > 100:
        raise AssertionError(f"Unexpectedly large lipid summary panel: {len(summaries.columns)}")
    return summaries, definition_table
