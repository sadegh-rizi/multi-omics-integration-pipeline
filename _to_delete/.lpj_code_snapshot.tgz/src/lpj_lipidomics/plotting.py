"""Shared Matplotlib style and categorical encodings for LPJ figures."""

from collections.abc import Iterable, Mapping
from pathlib import Path
from types import MappingProxyType
from typing import Hashable

import matplotlib.pyplot as plt


SEX_ORDER = ("Male", "Female")
BIO_GROUP_ORDER = ("Saline Control", "MIA")
BRAIN_REGION_ORDER = ("Cortex", "Cerebellum", "Hippocampus")

SEX_COLORS = MappingProxyType({
    "Male": "#0072B2",
    "Female": "#CC79A7",
})
BIO_GROUP_COLORS = MappingProxyType({
    "Saline Control": "#009E73",
    "MIA": "#D55E00",
})
BRAIN_REGION_COLORS = MappingProxyType({
    "Cortex": "#56B4E9",
    "Cerebellum": "#E69F00",
    "Hippocampus": "#0072B2",
})
MARKER_CYCLE = ("o", "s", "^", "D", "P", "X", "v", "<", ">")
COLORBLIND_COLORS = (
    "#0072B2", "#D55E00", "#009E73", "#E69F00", "#56B4E9", "#CC79A7", "#999999",
)

_STYLE = {
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 10,
    "axes.titleweight": "bold",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "axes.axisbelow": True,
    "grid.color": "#D9D9D9",
    "grid.linewidth": 0.8,
    "grid.alpha": 0.7,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 9,
    "legend.title_fontsize": 10,
    "figure.dpi": 100,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
}


def apply_plot_style() -> None:
    """Apply the project-wide Matplotlib defaults to the current session."""
    plt.rcParams.update(_STYLE)


def validate_categories(
    categories: Iterable[Hashable],
    palette: Mapping[Hashable, str],
    category_name: str,
) -> None:
    """Raise when plotted labels lack an explicitly defined colour."""
    unknown = sorted(set(categories).difference(palette), key=str)
    if unknown:
        raise ValueError(
            f"Unknown {category_name} label(s) with no configured colour: {unknown}."
        )


# Placeholders, not fixed specs -- tune per venue when the target is known.
# See doc/agent-rules.md's "Figures and tables" section.
PRESENTATION_DPI = 150
MANUSCRIPT_DPI = 300


def save_figure(fig: plt.Figure, path: Path) -> dict[str, Path]:
    """Save a figure as vector PDF plus a presentation- and a manuscript-DPI PNG.

    ``path`` sets the output directory and base filename; the returned paths
    use that base with a format-specific suffix
    (``<name>.pdf``, ``<name>_presentation.png``, ``<name>_manuscript.png``).
    DPI is controlled by ``PRESENTATION_DPI``/``MANUSCRIPT_DPI`` above --
    change those two constants rather than call sites when the actual
    target size/resolution is known.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    outputs = {
        "pdf": path.with_suffix(".pdf"),
        "presentation_png": path.with_name(f"{path.stem}_presentation.png"),
        "manuscript_png": path.with_name(f"{path.stem}_manuscript.png"),
    }
    fig.savefig(outputs["pdf"], bbox_inches="tight")
    fig.savefig(outputs["presentation_png"], dpi=PRESENTATION_DPI, bbox_inches="tight")
    fig.savefig(outputs["manuscript_png"], dpi=MANUSCRIPT_DPI, bbox_inches="tight")
    return outputs
