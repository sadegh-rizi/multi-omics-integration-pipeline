"""Missingness calculation and diagnostic functions."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, ranksums

def missingness_by_feature(
    intensity: pd.DataFrame,
    lipid_annotations: pd.DataFrame
) -> pd.DataFrame:
    """Calculate missingness per feature (lipid)."""
    n_samples = intensity.shape[1]
    n_missing = intensity.isna().sum(axis=1)
    pct_missing = (n_missing / n_samples) * 100

    df = pd.DataFrame({
        "n_missing": n_missing,
        "pct_missing": pct_missing
    })

    # Merge annotations
    result = lipid_annotations.merge(df, left_index=True, right_index=True, how="inner")
    result.index.name = "Feature"
    return result.sort_values("n_missing", ascending=False).reset_index()


def missingness_by_sample(
    intensity: pd.DataFrame,
    metadata: pd.DataFrame,
) -> pd.DataFrame:
    """Calculate missingness per sample."""
    n_features = intensity.shape[0]
    n_missing = intensity.isna().sum(axis=0)
    pct_missing = (n_missing / n_features) * 100

    df = pd.DataFrame({
        "n_missing": n_missing,
        "pct_missing": pct_missing
    })
    df.index.name = "Sample"

    # Merge metadata
    result = metadata.merge(df, on="Sample", how="inner")
    return result


def missingness_by_group(
    sample_missingness: pd.DataFrame,
    group_col: str,
) -> pd.DataFrame:
    """Summarize sample missingness by a grouping column."""
    grouped = sample_missingness.groupby(group_col)["pct_missing"].agg(
        n_samples="count",
        mean_pct_missing="mean",
        median_pct_missing="median",
        q25_pct_missing=lambda x: x.quantile(0.25),
        q75_pct_missing=lambda x: x.quantile(0.75),
    ).reset_index()

    grouped["iqr_pct_missing"] = grouped["q75_pct_missing"] - grouped["q25_pct_missing"]
    return grouped


def test_missingness_by_group(
    sample_missingness: pd.DataFrame,
    group_col: str,
    group_1: str,
    group_2: str
) -> dict:
    """Perform a Wilcoxon rank-sum test on % missing between two groups."""
    data_1 = sample_missingness.loc[sample_missingness[group_col] == group_1, "pct_missing"]
    data_2 = sample_missingness.loc[sample_missingness[group_col] == group_2, "pct_missing"]

    stat, p_val = ranksums(data_1, data_2)
    return {
        "comparison": f"{group_1} vs {group_2}",
        "test": "Wilcoxon rank-sum",
        "statistic": stat,
        "p_value": p_val
    }


def missingness_by_class_and_group(
    intensity: pd.DataFrame,
    lipid_annotations: pd.DataFrame,
    metadata: pd.DataFrame,
    group_col: str
) -> pd.DataFrame:
    """Calculate % missing by Lipid Class and group, and run Fisher's exact test."""
    mask = intensity.isna()
    long_mask = mask.rename_axis(index="Feature", columns="Sample").stack().reset_index(name="is_missing")

    # annotations might not have 'Feature' as a column, but as index.
    annot = lipid_annotations.rename_axis(index="Feature").reset_index()
    long_annot = long_mask.merge(annot, on="Feature", how="left")
    long_full = long_annot.merge(metadata[["Sample", group_col]], on="Sample", how="left")

    summary = long_full.groupby(["Lipid Class", group_col])["is_missing"].agg(
        n_missing="sum",
        n_total="count"
    ).reset_index()
    summary["pct_missing"] = (summary["n_missing"] / summary["n_total"]) * 100
    summary["n_observed"] = summary["n_total"] - summary["n_missing"]

    return summary


def fisher_test_by_class(
    class_group_summary: pd.DataFrame,
    group_col: str,
    group_1: str,
    group_2: str
) -> pd.DataFrame:
    """Run Fisher's exact test for each class between two groups."""
    results = []
    classes = class_group_summary["Lipid Class"].unique()

    for cls in classes:
        sub = class_group_summary[class_group_summary["Lipid Class"] == cls]
        row_1 = sub[sub[group_col] == group_1]
        row_2 = sub[sub[group_col] == group_2]

        if row_1.empty or row_2.empty:
            continue

        missing_1 = int(row_1["n_missing"].iloc[0])
        obs_1 = int(row_1["n_observed"].iloc[0])
        missing_2 = int(row_2["n_missing"].iloc[0])
        obs_2 = int(row_2["n_observed"].iloc[0])

        table = [[missing_1, obs_1], [missing_2, obs_2]]
        res = fisher_exact(table)

        results.append({
            "Lipid Class": cls,
            f"pct_missing_{group_1}": float(row_1["pct_missing"].iloc[0]),
            f"pct_missing_{group_2}": float(row_2["pct_missing"].iloc[0]),
            "odds_ratio": res.statistic,
            "p_value": res.pvalue
        })

    return pd.DataFrame(results)

def filtering_stage_summary(
    raw_intensity: pd.DataFrame,
    stages: list[tuple[str, pd.DataFrame]],
    metadata: pd.DataFrame,
    group_col: str = "Bio group",
    group_1: str = "MIA",
    group_2: str = "Saline Control"
) -> pd.DataFrame:
    """Summarize missingness across filtering stages."""
    results = []

    samples_1 = metadata[metadata[group_col] == group_1]["Sample"].tolist()
    samples_2 = metadata[metadata[group_col] == group_2]["Sample"].tolist()

    for stage_name, df in stages:
        n_lipids = df.shape[0]
        n_cells_missing = df.isna().sum().sum()
        total_cells = df.size
        pct_missing = (n_cells_missing / total_cells) * 100 if total_cells > 0 else 0

        cells_missing_1 = df[samples_1].isna().sum().sum()
        total_1 = df[samples_1].size
        pct_1 = (cells_missing_1 / total_1) * 100 if total_1 > 0 else 0

        cells_missing_2 = df[samples_2].isna().sum().sum()
        total_2 = df[samples_2].size
        pct_2 = (cells_missing_2 / total_2) * 100 if total_2 > 0 else 0

        max_diff = abs(pct_1 - pct_2)

        results.append({
            "Stage": stage_name,
            "n_lipids": n_lipids,
            "n_cells_missing": n_cells_missing,
            "pct_missing": pct_missing,
            f"pct_missing_{group_1}": pct_1,
            f"pct_missing_{group_2}": pct_2,
            "max_group_difference": max_diff
        })

    return pd.DataFrame(results)
