"""Quality-control calculations."""
