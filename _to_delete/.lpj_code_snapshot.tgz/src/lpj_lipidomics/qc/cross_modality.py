"""Concordance summaries for aligned lipidomics and metabolomics QC screens."""

from __future__ import annotations

import pandas as pd


SHARED_PROVENANCE_CAVEAT = (
    "Concordant across two assays of possibly shared provenance; metabolomics and "
    "lipidomics may derive from a single biphasic extraction and are not confirmed "
    "independent replicates. Ask the vendor whether assays used split phases or separate aliquots."
)


def expected_under_independence(n_samples: int, probability: float = 0.05) -> float:
    """Expected shared flags when two calibrated screens are independent."""
    return n_samples * probability**2


def concordance_table(lipidomics: pd.DataFrame, metabolomics: pd.DataFrame, statistic: str) -> pd.DataFrame:
    """Join same-region flags by integer sample number and report a 2x2 table."""
    flag = f"{statistic}_95_flag"
    required = {"Sample number", "Region", flag}
    for name, table in (("lipidomics", lipidomics), ("metabolomics", metabolomics)):
        missing = required.difference(table.columns)
        if missing:
            raise ValueError(f"{name} diagnostics missing columns: {sorted(missing)}.")
    merged = lipidomics.loc[:, ["Sample number", "Region", flag]].rename(columns={flag: "lipidomics_flag"}).merge(
        metabolomics.loc[:, ["Sample number", "Region", flag]].rename(columns={flag: "metabolomics_flag"}),
        on=["Sample number", "Region"], how="inner", validate="one_to_one",
    )
    if len(merged) != 60:
        raise ValueError(f"Expected 60 aligned regional samples, found {len(merged)}.")
    merged["concordant"] = merged["lipidomics_flag"] & merged["metabolomics_flag"]
    cells = pd.MultiIndex.from_product(
        [merged["Region"].drop_duplicates(), [False, True], [False, True]],
        names=["Region", "lipidomics_flag", "metabolomics_flag"],
    )
    summary = (
        merged.groupby(["Region", "lipidomics_flag", "metabolomics_flag"], dropna=False)
        .size().reindex(cells, fill_value=0).rename("n_samples").reset_index()
    )
    summary["statistic"] = statistic
    summary["expected_concordant_under_independence"] = expected_under_independence(len(merged))
    summary["shared_provenance_caveat"] = SHARED_PROVENANCE_CAVEAT
    return summary
