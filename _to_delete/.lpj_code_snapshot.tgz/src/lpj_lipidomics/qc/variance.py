"""Technical-versus-biological variance diagnostics for lipidomics QC."""

from __future__ import annotations

import numpy as np
import pandas as pd


def qc_injection_cv(
    techmix: pd.DataFrame,
    *,
    min_injections: int = 4,
) -> pd.DataFrame:
    """Compute raw and injection-median-normalized pooled-QC CVs per feature.

    The normalised CV is the QC reproducibility diagnostic: each injection is
    divided by its median positive signal and rescaled to the overall median.
    Features below ``min_injections`` usable positive injections are marked
    ``cv_not_assessable`` rather than treated as passing.
    """
    if min_injections < 2:
        raise ValueError("min_injections must be at least 2.")
    numeric = techmix.apply(pd.to_numeric, errors="coerce").where(lambda values: values > 0)
    injection_medians = numeric.median(axis=0, skipna=True)
    if injection_medians.isna().any() or injection_medians.le(0).any():
        raise ValueError("Each Tech-Mix injection needs at least one positive intensity.")
    overall_median = injection_medians.median()
    normalized = numeric.divide(injection_medians, axis=1).multiply(overall_median)
    counts = numeric.notna().sum(axis=1)
    raw_cv = 100 * numeric.std(axis=1, ddof=1, skipna=True) / numeric.mean(axis=1, skipna=True)
    normalized_cv = 100 * normalized.std(axis=1, ddof=1, skipna=True) / normalized.mean(axis=1, skipna=True)
    assessable = counts.ge(min_injections)
    return pd.DataFrame({
        "n_techmix_used": counts,
        "raw_cv_percent": raw_cv.where(assessable),
        "normalized_cv_percent": normalized_cv.where(assessable),
        "cv_status": np.where(assessable, "assessable", "cv_not_assessable"),
    }, index=techmix.index)


def technical_variance(
    techmix_intensity: pd.DataFrame,
    *,
    min_replicates: int = 4,
) -> pd.Series:
    """Return per-lipid log2 technical SD from pooled QC injections.

    Input values must already be positive-filtered and log2-transformed. A
    lipid with fewer than ``min_replicates`` usable injections is retained as
    missing rather than imputed.
    """
    if min_replicates < 2:
        raise ValueError("min_replicates must be at least 2.")
    counts = techmix_intensity.notna().sum(axis=1)
    standard_deviation = techmix_intensity.std(axis=1, ddof=1, skipna=True)
    return standard_deviation.where(counts >= min_replicates).rename("technical_sd_log2")


def biological_variance_by_region(
    biological_intensity: pd.DataFrame,
    metadata: pd.DataFrame,
    *,
    sample_column: str = "Sample",
    region_column: str = "Sample type",
    min_per_region: int = 15,
) -> pd.DataFrame:
    """Return log2 biological SD and usable sample count per lipid and region."""
    if min_per_region < 2:
        raise ValueError("min_per_region must be at least 2.")
    if sample_column not in metadata or region_column not in metadata:
        raise KeyError(f"Metadata must contain {sample_column!r} and {region_column!r}.")
    if metadata[sample_column].duplicated().any():
        raise ValueError("Metadata sample identifiers must be unique.")
    missing_samples = set(biological_intensity.columns).difference(metadata[sample_column])
    if missing_samples:
        raise ValueError(f"Metadata is missing intensity samples: {sorted(missing_samples)}")

    aligned_metadata = metadata.set_index(sample_column, drop=False).loc[biological_intensity.columns]
    rows: list[pd.DataFrame] = []
    for region, region_metadata in aligned_metadata.groupby(region_column, sort=False, observed=True):
        values = biological_intensity.loc[:, region_metadata[sample_column]]
        counts = values.notna().sum(axis=1)
        standard_deviation = values.std(axis=1, ddof=1, skipna=True).where(counts >= min_per_region)
        rows.append(pd.DataFrame({
            "Feature": values.index,
            "Region": region,
            "biological_sd_log2": standard_deviation.to_numpy(),
            "n_biological_used": counts.to_numpy(),
        }))
    return pd.concat(rows, ignore_index=True)


def variance_ratio_table(
    technical_sd: pd.Series,
    biological_sd_by_region: pd.DataFrame,
    *,
    technical_counts: pd.Series | None = None,
) -> pd.DataFrame:
    """Combine technical and biological SDs into raw technical variance ratios."""
    required = {"Feature", "Region", "biological_sd_log2", "n_biological_used"}
    if missing := required.difference(biological_sd_by_region):
        raise KeyError(f"Biological variance table is missing columns: {sorted(missing)}")
    technical = technical_sd.rename("technical_sd_log2").rename_axis("Feature").reset_index()
    if technical_counts is not None:
        technical = technical.merge(
            technical_counts.rename("n_techmix_used").rename_axis("Feature").reset_index(),
            on="Feature",
            how="left",
            validate="one_to_one",
        )
    else:
        technical["n_techmix_used"] = pd.NA
    table = biological_sd_by_region.merge(technical, on="Feature", how="left", validate="many_to_one")
    table["variance_ratio"] = (table["technical_sd_log2"] ** 2) / (table["biological_sd_log2"] ** 2)
    table.loc[table["biological_sd_log2"].le(0), "variance_ratio"] = np.nan
    table["technical_dominated"] = table["variance_ratio"].ge(0.5).where(table["variance_ratio"].notna(), pd.NA).astype("boolean")
    return table.loc[:, [
        "Feature", "Region", "technical_sd_log2", "biological_sd_log2", "variance_ratio",
        "technical_dominated", "n_techmix_used", "n_biological_used",
    ]]
