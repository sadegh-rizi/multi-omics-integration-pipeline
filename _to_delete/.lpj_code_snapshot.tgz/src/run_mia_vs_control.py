"""Compatibility entry point for the package runner."""

from lpj_lipidomics.runners.run_mia_vs_control import *
from lpj_lipidomics.runners.run_mia_vs_control import _between_group_r2, _linear_score_r2

if __name__ == "__main__":
    import runpy
    runpy.run_module("lpj_lipidomics.runners.run_mia_vs_control", run_name="__main__")
