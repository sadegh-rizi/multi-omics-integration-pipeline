"""Compatibility alias for the package outlier ensemble module."""

import sys

from lpj_lipidomics.outliers import ensemble as _implementation

sys.modules[__name__] = _implementation
