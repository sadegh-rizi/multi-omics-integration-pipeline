"""Compatibility imports for the package metabolomics I/O module."""

from lpj_lipidomics.io.metabolomics import *
