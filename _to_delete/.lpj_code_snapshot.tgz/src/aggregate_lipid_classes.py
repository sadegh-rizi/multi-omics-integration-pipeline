"""Compatibility imports for the package aggregation module."""

from lpj_lipidomics.aggregation import *
