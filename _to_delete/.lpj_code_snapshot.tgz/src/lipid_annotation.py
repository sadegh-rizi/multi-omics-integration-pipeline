"""Compatibility alias for the package annotation module."""

import sys

from lpj_lipidomics import annotation as _implementation

sys.modules[__name__] = _implementation
