"""Compatibility imports for the package PCA loading module."""

from lpj_lipidomics.multivariate.loadings import *
