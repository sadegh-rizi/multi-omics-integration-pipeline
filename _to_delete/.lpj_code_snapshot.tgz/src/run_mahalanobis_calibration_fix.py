"""Compatibility entry point for the package runner."""

from lpj_lipidomics.runners.run_mahalanobis_calibration_fix import *

if __name__ == "__main__":
    import runpy
    runpy.run_module("lpj_lipidomics.runners.run_mahalanobis_calibration_fix", run_name="__main__")
