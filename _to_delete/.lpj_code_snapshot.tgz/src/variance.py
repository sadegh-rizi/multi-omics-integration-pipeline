"""Compatibility imports for the package variance module."""

from lpj_lipidomics.statistics.variance import *
