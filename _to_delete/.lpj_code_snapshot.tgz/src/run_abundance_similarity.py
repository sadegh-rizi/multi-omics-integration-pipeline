"""Compatibility entry point for the package runner."""

from lpj_lipidomics.runners.run_abundance_similarity import *
from lpj_lipidomics.runners.run_abundance_similarity import _add_window_size_sensitivity
from lpj_lipidomics.io.study_design import lipid_feature_rows as _lipid_feature_rows

if __name__ == "__main__":
    import runpy
    runpy.run_module("lpj_lipidomics.runners.run_abundance_similarity", run_name="__main__")
