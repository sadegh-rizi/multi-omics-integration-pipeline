All files in this folder are SIMULATED by mia_multiomics.toy_data (seed 2026).
They copy the layout of the real study files but contain no real measurements.
Ground truth: strong region effect, small sex effect, NO MIA effect, two shared within-region factors,
outlying samples: TOY_001-10, TOY_001-45.
