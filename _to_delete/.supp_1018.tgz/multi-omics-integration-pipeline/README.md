# MIA multi-omics integration pipeline

Does **maternal immune activation (MIA)** during pregnancy change the brains of
the offspring? This repository holds the analysis pipeline for a mouse study
with **20 offspring** (10 MIA, 10 saline control). Each mouse gives **3 brain
regions** (cortex, cerebellum, hippocampus), and every sample was measured with
**lipidomics, metabolomics and proteomics**.

The pipeline goes from the core facility's raw files to quality control,
outlier screening, per-feature models, multivariate analysis and multi-omics
integration (MOFA+). Its central lesson is methodological. Brain region is a
strong, known signal (the positive control) and MIA turns out to be null (the
negative control). That pairing makes the dataset a test bed: does each method
find region, and does it correctly find *nothing* for MIA?

> **The data in this repository are simulated.** The real study data cannot be
> shared. `mia_multiomics.toy_data` writes files with exactly the same layout as
> the real deliverables, with a known truth planted in them: a strong region
> effect, a small sex effect, **no MIA effect**, litter effects, two shared
> within-region programmes, and two outlying samples.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -e .                                   # makes `import mia_multiomics` work everywhere

python -m mia_multiomics.toy_data                  # writes the simulated data into data/
jupyter notebook notebooks/walkthrough.ipynb       # guided run, about 15-20 min
jupyter notebook notebooks/supplementary_figures.ipynb   # every other figure, with your own settings (~1-2 min)
# or, without the notebook:
python -m mia_multiomics.pipeline --fast           # every step, small resampling counts
python -m mia_multiomics.pipeline --fast --only qc outliers differential
pytest                                             # 185 tests, ~5 min
```

All tables and figures are written to `results/`. Both notebooks have been
executed already, so their outputs are visible without running anything.

## The supplementary notebook: explore with your own settings

`notebooks/supplementary_figures.ipynb` draws the figures of the original
thesis repository that the walkthrough does not show: QC and missingness,
every PCA loading view, influence plots, the outlier-ensemble diagnostics,
p-value calibration, feature modules, litter plots, the facility-style figures
and the lipid-protein myelin check (73 figures). Everything is recomputed from
one settings cell:

```python
OMICS = "lipidomics"            # or "metabolomics", "proteomics"
EXCLUDE = [10, 45]              # remove any samples (numbers or IDs); [] = all 60
MAX_MISSING_FRACTION = 0.20     # prevalence filter (None = off)
BLANK_MULTIPLIER = 3.0          # blank filter and detection limit
NORMALIZATION = "median"        # or "pqn"
SCALING = "autoscaled"          # or "pareto", "unscaled"
FDR_ALPHA = 0.05
```

The defaults reproduce the primary analysis (all 60 samples, current
filtering). The notebook lists the samples flagged by the Hotelling T² screen
and warns if a whole mouse is removed. The figure functions live in
`src/mia_multiomics/explore/` and can be used without the notebook:

```python
from mia_multiomics import explore
view = explore.build_view(settings, explore.Options(exclude=[10, 45], normalization="pqn"))
explore.volcano(view, region="Cortex", effect="Female vs Male")
```

## How the pipeline is organised

```mermaid
flowchart LR
  A[raw files<br/>Excel report, cage sheet,<br/>Perseus exports] --> B[inputs.py<br/>tidy tables]
  B --> C[preprocessing.py<br/>prevalence, blank filter,<br/>detection limit, log2, normalise]
  C --> D[1 QC<br/>pooled QC, missingness,<br/>PCA, noise floor, modules]
  C --> E[2 outliers<br/>T2 screen, calibrated<br/>6-detector ensemble]
  E -->|t2_95 / t2_99 populations| F[3 differential<br/>group x sex per region,<br/>permutation null, power]
  F --> G[4 sensitivity<br/>specification curve, RF, PQN,<br/>litter-aware models]
  C --> H[5 region persistence<br/>6 ASCA+<br/>7 effect sizes]
  C --> I[8 integration<br/>MOFA+, within-region MOFA+,<br/>benchmark, cross-omics screen,<br/>enrichment, covariate map]
```

Every stage is one module in `src/mia_multiomics/stages/` with a `run(settings, ...)` function.

| Step | Module | Output folder | What it answers |
|---|---|---|---|
| QC | `stages/qc.py` | `results/<omics>/01_qc/` | What did preprocessing remove? Is the pooled QC reproducible? What structure is there? |
| noise floor | `stages/noise_floor.py` | `.../01_qc/noise_floor/` | Below which abundance are lipids noise? |
| feature modules | `stages/feature_modules.py` | `.../01_qc/feature_modules/` | Do features form co-abundance modules beyond chance? |
| outlier screen | `stages/outliers.py: run_screen` | `.../02_outliers/` | Hotelling T², robust Mahalanobis, DModX; defines `t2_95` and `t2_99` |
| outlier ensemble | `stages/outliers.py: run_ensemble` | `.../02_outliers/ensemble/` | Do several calibrated detectors agree on a sample? |
| differential | `stages/differential.py` | `.../03_differential/<population>/` | Group x sex model per region, FDR, permutation null, effective tests, MDE |
| sensitivity | `stages/sensitivity.py` | `.../04_sensitivity/` | Does the answer change with filtering, imputation, normalisation or litter-aware models? |
| region persistence | `stages/region_persistence.py` | `.../05_region_persistence/` | Is the control region-difference profile preserved in MIA? |
| ASCA+ | `stages/asca.py` | `.../06_asca/` | Variance share of region, MIA and sex, with permutation tests at the right unit |
| effect sizes | `stages/effect_sizes.py` | `results/integration/07_effect_sizes/` | How large could an MIA effect be? Lipid composites, protein sets |
| integration | `stages/integration.py` | `results/integration/` | MOFA+, within-region MOFA+, benchmark, cross-omics modules, enrichment, covariate map |
| facility figures | `stages/vendor_figures.py` | `results/lipidomics/09_vendor_figures/` | The facility's heatmaps and PLS-DA plots, plus the permutation test they lacked |

`pipeline.py` runs all steps in order (`python -m mia_multiomics.pipeline`).

## Repository layout

```
src/mia_multiomics/
  config.py            every threshold, file name and run size in one place (Settings.fast / Settings.full)
  toy_data.py          simulator that writes the toy dataset in the real file layout
  inputs.py            readers for the vendor files -> OmicsData(values, blanks, techmix, features, metadata)
  preprocessing.py     filtering, detection limit, log2, median/PQN normalisation, scaling
  imputation.py        label-free imputers (sensitivity analyses only)
  qc.py                pooled-QC CV, technical vs biological variance, missingness, assay concordance
  lipids.py            lipid-name parsing, class and structural summaries
  noise_floor.py, noisyr.py   abundance-similarity curves (+ optional R noisyR)
  lipid_databases.py   optional LIPID MAPS / KEGG annotation (needs internet)
  plotting.py          colours, style and the shared plot types
  stats/               differential models, permutation nulls, power, diagnostics, litter (cage) statistics,
                       region contrasts, PERMANOVA, ASCA permutation schemes, small shared helpers
  multivariate/        PCA (+ loadings, design attribution), PLS-DA, ASCA+, feature-space modules
  outliers/            detectors, simulation calibration, stability rules, the regional T2 screen
  integration/         MOFA+ helpers, litter-aware treatment tests, enrichment
  stages/              one module per analysis step (see the table above)
  explore/             build a view from your own settings + every supplementary figure (used by the 2nd notebook)
  pipeline.py          runs every stage in order
notebooks/walkthrough.ipynb   the guided run (generated by notebooks/build_notebook.py)
notebooks/supplementary_figures.ipynb   all other figures with adjustable settings (built by build_supplementary.py)
tests/                 pytest suite (library functions + end-to-end smoke tests on toy data)
r/                     optional R cross-checks (limma, noisyR, DIABLO, MFA, ASCA), see r/README.md
docs/                  design notes and how the code maps to the original thesis repository
data/                  the simulated toy data (re-create with python -m mia_multiomics.toy_data); see data/README.md
```

## Analysis rules built into the code

* **Populations.** Only three are allowed: all 60 samples (`all60`, the
  primary analysis), or a sample-level removal of the samples flagged by the
  regional Hotelling T² screen at 95 % or 99 % (`t2_95`, `t2_99`). A whole mouse
  is never removed. These are listed in `config.POPULATIONS`.
* **No silent imputation.** Missing and below-detection values stay missing.
  Imputation appears only in sensitivity analyses, and only label-free.
* **The litter is the experimental unit for MIA.** Pups share a mother, cage
  and collection date. Tests are therefore also run with whole-cage
  permutations, whose smallest possible p-value (1/28 here) is reported.
* **Calibrate against a null.** Outlier detectors, integration factors and
  significance counts are always compared with simulated or permuted null data.

## Running on the real data

Put the real files in `data/` and point the file names in `config.py`
(`REPORT_WORKBOOK`, `CAGE_WORKBOOK`, `PROTEOMICS_FILES`, `REFERENCE_DIR`) and
`SAMPLE_PREFIX` at them. `data/README.md` describes the expected layout. Then
run `python -m mia_multiomics.pipeline` (full size) or the notebook with
`Settings.full`.

## Optional R steps

The Python pipeline is complete on its own. `r/` holds the R cross-checks used
in the thesis: limma, noisyR, mixOmics DIABLO, FactoMineR MFA and a base-R ASCA.
Enable the first two with `--with-r` or `settings.with_(use_r=True)`. The others
are run by hand after the pipeline. See `r/README.md`.
